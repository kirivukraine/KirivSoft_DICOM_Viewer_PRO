# DicomView PRO — Compatibility + SmoothStack + Fidelity Edition

Ця збірка об'єднує підхід Weasis-compatible foundation із виправленням проблеми ривків масштабу при перегляді стеків і Cine.

## Додано / виправлено

- SmoothStack Engine: стабільний bbox/viewport для всієї серії, а не auto-fit для кожного зрізу окремо.
- Cine Stabilizer: Cine використовує той самий locked viewport, що й 2D axial, тому кадри не повинні змінювати масштаб під час відтворення.
- Diagnostic Fidelity: залишено 16-bit pipeline до фінального display render, Lanczos/PIL diagnostics, sharpen OFF за замовчуванням.
- Weasis-inspired compatibility foundation: DICOM SR/SEG/RT classification, DICOMweb foundation, FrameOfReference sync, Dicomizer foundation.
- Старі ПК: важкі модулі лишаються optional/fallback і не повинні валити основний Viewer.

## Що перевіряти вручну

1. Відкрити CT Brain серію.
2. Прокрутити колесом/PageUp/PageDown — зображення не повинно стрибати в масштабі.
3. Відкрити Cine/Angio — кадри мають йти без зміни viewport.
4. Перевірити Brain W80/C35, Lanczos, Fit anatomy.
5. Відкрити вкладки SR/SEG/RT/DICOMweb foundation — без крашу, навіть якщо таких об'єктів немає.
