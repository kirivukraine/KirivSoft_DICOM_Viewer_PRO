# DicomView PRO — KirivSoft

Автор: Іван Кіранчук  
Компанія: KirivSoft

Робочий прототип DICOM Viewer з підтримкою:

- відкриття DICOM файлу/папки;
- Series Selector;
- 2D Viewer;
- MPR PRO;
- MIP / MinIP / AvgIP;
- ROI / HU PRO;
- Segmentation Basic;
- 3D VTK + Safe 3D для старих ПК;
- Cine / Angio Viewer;
- Cine export GIF/MP4;
- DICOMDIR;
- STL/OBJ/PLY/GLB export;
- anonymized ZIP;
- PACS PRO: C-ECHO, C-FIND, C-STORE.

## Збірка EXE

Запустіть:

```bat
build_exe.bat
```

Готова portable-папка буде:

```text
dist\DicomView_PRO\DicomView_PRO.exe
```

## Для старих медичних ПК

На слабких комп’ютерах використовуйте режим:

```text
Auto Safe / старий ПК
```

Цей режим не запускає важкий OpenGL/VTK Volume Rendering і показує CPU-only MIP Preview.

## Для PACS

Потрібно знати:

- Local AE Title;
- PACS AE Title;
- IP / Host;
- Port.

PACS-функції знаходяться у вкладці **PACS PRO**.

## Важливо

Програма не є сертифікованим медичним виробом. Використання — для тестування, навчання та розробки.


## Додано у версії Hospital Ready / Orthanc-Reporting-Radiomics

- Orthanc Integration: перевірка сервера, список досліджень, upload DICOM-файлу.
- Reporting: PDF/DOCX звіти з DICOM-метаданими та вимірюваннями ROI/HU.
- Radiomics Base: базові кількісні ознаки обсягу або сегментаційної маски.
- Adaptive Safe 3D лишається режимом за замовчуванням для старих лікарняних ПК.

### Збірка EXE
Запустіть `build_exe.bat`. Готовий файл буде у `dist\DicomView_PRO\DicomView_PRO.exe`.

## HospitalReady Advanced modules

This package includes optional clinical workflow modules:

- Orthanc Explorer PRO: REST connectivity, study listing/search/upload/download foundation.
- Reporting PRO: PDF/DOCX reporting foundation.
- Radiomics PRO Base: NumPy quantitative features; PyRadiomics can be installed optionally.
- Cine PRO: XA/XRF/coronary angiography cine playback and GIF/MP4 export.
- Vessel Analysis: threshold-based vessel preview, HU statistics and vessel MIP.
- 3D Angio: DSA subtraction preview, temporal max projection and pseudo-3D vessel mask.
- 4D Cardiac: cine/4D inspection and timeline routing.
- AI / MONAI: optional MONAI/Torch checks with safe fallback segmentation.

For old hospital PCs use the default 3D mode: `Auto Safe / старий ПК`.


## Clinical Foundation / Safe Fallback

Додано вкладку **Clinical Foundation**, яка показує готовність великих модулів і їх fallback-режими. Це потрібно для старих лікарняних ПК: якщо VTK/OpenGL/MONAI/PyRadiomics недоступні, програма не повинна падати, а має переходити в безпечний режим.

## Portable Layout / Segmentation Fix

У цій збірці виправлено обрізання значень `Min HU` / `Max HU` у блоці `Segmentation Basic`, додано видимий статус поточного пресету сегментації та просту діагностику codec/build-залежностей через `run_codec_diagnostics.bat`.

## Slicer Bridge PRO

У цій версії додано вкладку **Slicer Bridge** для інтеграції з 3D Slicer:

- відкрити поточну DICOM-папку у Slicer;
- експортувати volume у `.nrrd`;
- експортувати маску сегментації у `.seg.nrrd`;
- імпортувати STL/OBJ/PLY/GLB як результат зовнішнього моделювання.

3D Slicer не входить у пакет DicomView PRO. Його шлях можна знайти автоматично або вказати вручну.

## Clinic Test Harness

Додано контрольний тестовий режим для реальних DICOM-наборів. Він потрібен для перевірки великих КТ-серій, зокрема `Data.zip`, без включення самого тестового набору в реліз.

Швидкий запуск:

```bat
run_clinic_test_harness.bat C:\Path\To\Data.zip
```

Результат буде збережено у `diagnostics\clinic_test_report.json`.

Документація: `docs/CLINIC_TEST_HARNESS_UA.md`.
