import numpy as np
from dicomview_pro.core.ai_realesrgan import superres_slice, realesrgan_status, find_realesrgan_ncnn


def test_realesrgan_safe_fallback_x2():
    img = np.arange(16, dtype=np.float32).reshape(4, 4)
    res = superres_slice(img, 2, prefer_external=False)
    assert res.ok
    assert res.image2d.shape == (8, 8)
    assert res.details is not None
    assert res.details.get("diagnostic") is False


def test_realesrgan_safe_fallback_x4():
    img = np.arange(16, dtype=np.float32).reshape(4, 4)
    res = superres_slice(img, 4, prefer_external=False)
    assert res.ok
    assert res.image2d.shape == (16, 16)


def test_realesrgan_status_has_copy_target():
    st = realesrgan_status()
    assert "copy_target" in st
    assert "realesrgan" in st["copy_target"].lower()
