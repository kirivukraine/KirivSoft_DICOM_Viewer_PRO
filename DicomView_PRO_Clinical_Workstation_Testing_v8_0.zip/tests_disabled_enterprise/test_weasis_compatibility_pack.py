from pathlib import Path

from dicomview_pro.core.dicomweb_client import DicomWebConfig, config_to_json
from dicomview_pro.core.dicom_special_objects import classify_dataset
from dicomview_pro.core.frame_sync import can_sync, sync_report


def test_dicomweb_config_masks_password():
    cfg = DicomWebConfig(base_url='http://x/dicom-web', username='u', password='secret')
    d = config_to_json(cfg)
    assert d['password'] == '***'
    assert d['base_url'].endswith('/dicom-web')


def test_special_object_classification_sr_seg_rt():
    class DS: pass
    ds = DS(); ds.SOPClassUID = '1.2.840.10008.5.1.4.1.1.88.22'; ds.Modality = 'SR'; ds.ContentSequence = [1,2]
    assert classify_dataset(ds).kind == 'DICOM SR'
    ds2 = DS(); ds2.SOPClassUID = '1.2.840.10008.5.1.4.1.1.66.4'; ds2.Modality = 'SEG'; ds2.SegmentSequence = [1]
    assert classify_dataset(ds2).kind == 'DICOM SEG'
    ds3 = DS(); ds3.SOPClassUID = '1.2.840.10008.5.1.4.1.1.481.3'; ds3.Modality = 'RTSTRUCT'; ds3.StructureSetROISequence = [1,2,3]
    assert classify_dataset(ds3).kind == 'DICOM RT'


def test_frame_sync():
    a = {'tags': {'FrameOfReferenceUID': 'FOR1'}, 'series_uid': 'A'}
    b = {'tags': {'FrameOfReferenceUID': 'FOR1'}, 'series_uid': 'B'}
    c = {'tags': {'FrameOfReferenceUID': 'FOR2'}, 'series_uid': 'C'}
    assert can_sync(a, b)
    assert not can_sync(a, c)
    r = sync_report(a, [b, c])
    assert r['count'] == 1
