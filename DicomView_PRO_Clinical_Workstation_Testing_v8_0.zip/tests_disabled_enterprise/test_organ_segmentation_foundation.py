from pathlib import Path
from dicomview_pro.core.organ_segmentation_foundation import (
    DEFAULT_ROIS,
    build_organ_segmentation_plan,
    discover_organ_meshes,
    normalize_roi_list,
    organ_ai_status,
    write_plan_manifest,
)


def test_organ_ai_status_safe_dict():
    status = organ_ai_status()
    data = status.to_dict()
    assert "totalsegmentator" in data
    assert data["mode"] in ("optional_plugin", "safe_fallback")
    assert "heart" in data["supported_rois"]


def test_plan_contains_rois_and_fast_command(tmp_path: Path):
    plan = build_organ_segmentation_plan(tmp_path / "dicom", tmp_path / "work", rois=["heart", "liver"], fast=True)
    assert plan.rois == ["heart", "liver"]
    assert "totalsegmentator" in plan.command
    assert "--roi_subset" in plan.command
    assert "--fast" in plan.command
    manifest = tmp_path / "manifest.json"
    write_plan_manifest(plan, manifest)
    assert manifest.exists()


def test_normalize_rois_defaults_and_deduplicates():
    assert normalize_roi_list([]) == list(DEFAULT_ROIS)
    assert normalize_roi_list(["heart", "heart", " liver "]) == ["heart", "liver"]


def test_discover_organ_meshes(tmp_path: Path):
    (tmp_path / "heart.stl").write_text("solid heart\nendsolid heart\n")
    (tmp_path / "liver.obj").write_text("# obj\n")
    meshes = discover_organ_meshes(tmp_path)
    assert [m["organ"] for m in meshes] == ["liver", "heart"] or {m["organ"] for m in meshes} == {"heart", "liver"}
