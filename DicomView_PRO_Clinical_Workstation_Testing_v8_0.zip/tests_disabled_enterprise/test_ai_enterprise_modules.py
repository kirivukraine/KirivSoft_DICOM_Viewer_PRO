import numpy as np
from dicomview_pro.core.ai_engine import ai_engine_status
from dicomview_pro.core.ai_models import scan_models, ensure_model_dirs
from dicomview_pro.core.ai_medsam import mobile_sam_segment_slice
from dicomview_pro.core.ai_dncnn import denoise_slice
from dicomview_pro.core.ai_realesrgan import superres_slice


def test_ai_engine_status_safe():
    st = ai_engine_status()
    assert st.ok
    assert "onnxruntime" in st.environment
    assert "models_dir" in st.models


def test_model_dirs_scan(tmp_path):
    root = ensure_model_dirs(tmp_path / "models")
    assert (root / "segmentation").exists()
    assert scan_models(root)


def test_ai_fallbacks_without_models():
    img = np.zeros((64, 64), dtype=np.float32)
    img[24:40, 24:40] = 120
    seg = mobile_sam_segment_slice(img, 32, 32, model_path="missing.onnx")
    assert seg.ok and seg.mask2d is not None and seg.mask2d.shape == img.shape
    den = denoise_slice(img, model_path="missing.onnx")
    assert den.ok and den.image2d.shape == img.shape
    sr = superres_slice(img, 2, model_path="missing.onnx")
    assert sr.ok and sr.image2d.shape[0] >= img.shape[0]
