import pytest
from pathlib import Path

from dicomview_pro.ai import AISegmentationMode, MODE_LABELS_UA, ai_segmentation_status, detect_gpu
from dicomview_pro.ai.segmentation_modes import normalize_mode
from dicomview_pro.ai.totalsegmentator_runner import build_totalseg_command
from dicomview_pro.ai.nnunet_runner import build_nnunet_plan
from dicomview_pro.ai.model_manager import audit_zip_archive


def test_ai_modes_exist():
    assert normalize_mode("totalsegmentator_cpu_safe") == AISegmentationMode.TOTALSEG_CPU_SAFE
    assert "TotalSegmentator Fast GPU" in MODE_LABELS_UA[AISegmentationMode.TOTALSEG_FAST_GPU]
    assert normalize_mode("bad") == AISegmentationMode.TOTALSEG_FAST_GPU


def test_gpu_detector_safe_without_cuda():
    info = detect_gpu()
    assert isinstance(info.name, str)
    assert info.recommended_mode
    assert isinstance(info.vram_mb, int)


def test_totalseg_command_builder_cpu_and_gpu():
    plan = build_totalseg_command("input.nii.gz", "out", rois=["heart", "liver"], fast=True, device="cpu")
    assert "totalsegmentator" in " ".join(plan.command)
    assert "--roi_subset" in plan.command
    assert "heart" in plan.command
    assert "--fast" in plan.command
    assert "--device" in plan.command and "cpu" in plan.command


def test_nnunet_research_plan_is_safe_when_unconfigured():
    plan = build_nnunet_plan("in", "out")
    assert plan.command
    assert plan.ready in (True, False)
    assert plan.message


def test_ai_status_shape():
    st = ai_segmentation_status()
    d = st.to_dict()
    assert "gpu" in d and "dependencies" in d
    assert "recommended_mode" in d


def test_uploaded_ai_archives_are_source_archives():
    root = Path(__file__).resolve().parents[1]
    if (root / "modules" / "ai_segmentation.disabled").exists():
        pytest.skip("Lite build: heavy AI source archives are external/disabled")
    ts = root / "_internal" / "ai_modules" / "totalsegmentator" / "TotalSegmentator-master.zip"
    nn = root / "_internal" / "ai_modules" / "nnunet" / "nnUNet-master.zip"
    audit_ts = audit_zip_archive("TotalSegmentator", ts)
    audit_nn = audit_zip_archive("nnU-Net", nn)
    assert audit_ts.exists and audit_ts.looks_like_source
    assert audit_nn.exists and audit_nn.looks_like_source
