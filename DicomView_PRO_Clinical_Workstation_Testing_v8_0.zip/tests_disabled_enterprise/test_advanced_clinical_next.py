import numpy as np
from dicomview_pro.core.vessel_analysis import analyze_vessels, threshold_vessels, estimate_centerline_length
from dicomview_pro.core.cardiac_metrics import cardiac_volume_metrics
from dicomview_pro.core.adaptive_engine import adaptive_dict


def test_vessel_analysis_basic():
    vol = np.zeros((8, 16, 16), dtype=np.float32)
    vol[:, 7:10, 7:10] = 300
    mask = threshold_vessels(vol)
    assert mask.any()
    res = analyze_vessels(vol, spacing_zyx=(2.0, 0.5, 0.5))
    assert res.ok
    assert res.voxel_count > 0
    assert res.mean_diameter_mm > 0
    assert res.estimated_centerline_length_mm > 0


def test_centerline_empty():
    assert estimate_centerline_length(np.zeros((2, 3, 4), dtype=bool)) == 0.0


def test_cardiac_metrics():
    mask = np.zeros((3, 4, 8, 8), dtype=bool)
    mask[0, :, 2:6, 2:6] = True
    mask[1, :, 3:5, 3:5] = True
    mask[2, :, 2:5, 2:5] = True
    m = cardiac_volume_metrics(mask, spacing_zyx=(1.0, 1.0, 1.0))
    assert m.ok
    assert m.edv_ml > m.esv_ml
    assert 0 < m.ef_percent <= 100


def test_adaptive_dict_has_mode():
    d = adaptive_dict()
    assert d["tier"] in ("safe", "balanced", "full")
    assert d["viewer_3d_mode"]
