from pathlib import Path

from dicomview_pro.core.organ_segmentation_executor import OrganSegmentationResult, _find_nifti_file


def test_organ_result_to_dict():
    r = OrganSegmentationResult(True, 'w', 'n.nii.gz', 'masks', 'meshes', ['heart'], [], 'log.txt', 'ok')
    d = r.to_dict()
    assert d['ok'] is True
    assert d['rois'] == ['heart']


def test_find_nifti_file(tmp_path: Path):
    p = tmp_path / 'a.nii.gz'
    p.write_text('x')
    assert _find_nifti_file(tmp_path) == p


def test_vtk_viewer_source_has_organ_mesh_api():
    source = Path('src/dicomview_pro/ui/vtk_viewer.py').read_text(encoding='utf-8')
    assert 'def add_organ_mesh' in source
    assert 'def set_organ_mesh_visible' in source
    assert 'def clear_organ_meshes' in source
