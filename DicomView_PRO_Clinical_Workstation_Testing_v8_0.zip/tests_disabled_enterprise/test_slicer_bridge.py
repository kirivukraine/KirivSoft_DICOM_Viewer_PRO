import numpy as np
from dicomview_pro.core.slicer_bridge import create_slicer_bridge_script, export_volume_nrrd, find_slicer


def test_export_volume_nrrd(tmp_path):
    vol = np.arange(2*3*4, dtype=np.int16).reshape(2,3,4)
    out = tmp_path / "test.nrrd"
    res = export_volume_nrrd(vol, (1.5, 0.7, 0.7), out, {"x": 1})
    assert res.ok
    data = out.read_bytes()
    assert data.startswith(b"NRRD0005")
    assert b"sizes: 4 3 2" in data[:300]


def test_find_slicer_safe():
    res = find_slicer()
    assert isinstance(res.ok, bool)
    assert isinstance(res.message, str)


def test_find_slicer_in_bundled_internal_tools(tmp_path, monkeypatch):
    exe = tmp_path / "_internal" / "tools" / "3d-slicer" / "Slicer.exe"
    exe.parent.mkdir(parents=True)
    exe.write_bytes(b"")
    monkeypatch.chdir(tmp_path)

    res = find_slicer()

    assert res.ok
    assert res.path == str(exe)


def test_find_slicer_in_bundled_internal_slicer(tmp_path, monkeypatch):
    exe = tmp_path / "_internal" / "slicer" / "Slicer.exe"
    exe.parent.mkdir(parents=True)
    exe.write_bytes(b"")
    monkeypatch.chdir(tmp_path)

    res = find_slicer()

    assert res.ok
    assert res.path == str(exe)


def test_find_slicer_in_local_appdata_slicer_org(tmp_path, monkeypatch):
    exe = tmp_path / "slicer.org" / "3D Slicer 5.10.0" / "Slicer.exe"
    exe.parent.mkdir(parents=True)
    exe.write_bytes(b"")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))

    res = find_slicer()

    assert res.ok
    assert res.path == str(exe)


def test_create_slicer_bridge_script(tmp_path):
    out = tmp_path / "dicomview_slicer_bridge.py"
    res = create_slicer_bridge_script(out)

    assert res.ok
    text = out.read_text(encoding="utf-8")
    assert "TemporaryDICOMDatabase" in text
    assert "SegmentEditor" in text
