from pathlib import Path
import numpy as np

from dicomview_pro.core.sam_preprocess import prepare_dicom_for_sam, resize_mask_to_original
from dicomview_pro.core.ai_medsam import mobile_sam_segment_slice


def test_prepare_dicom_for_sam_tensor_shape():
    img = np.arange(64 * 32, dtype=np.int16).reshape(64, 32)
    prepared = prepare_dicom_for_sam(img, target_size=128)
    assert prepared.image_tensor.shape == (1, 3, 128, 128)
    assert prepared.image_tensor.dtype == np.float32
    assert prepared.original_shape == (64, 32)


def test_resize_mask_to_original_shape():
    mask = np.zeros((128, 128), dtype=np.uint8)
    mask[20:60, 30:70] = 255
    out = resize_mask_to_original(mask, (64, 32))
    assert out.shape == (64, 32)
    assert out.dtype == np.uint8


def test_mobile_sam_segment_fallback_without_model(tmp_path: Path):
    img = np.zeros((64, 64), dtype=np.float32)
    img[24:40, 24:40] = 100.0
    result = mobile_sam_segment_slice(img, 32, 32, model_path=tmp_path / 'missing.onnx')
    assert result.ok
    assert result.mask2d is not None
    assert result.mask2d.shape == img.shape
    assert result.details and result.details.get('fallback') is True
