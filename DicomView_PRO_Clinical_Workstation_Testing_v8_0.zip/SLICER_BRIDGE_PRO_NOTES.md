# DicomView PRO — Slicer Bridge PRO

Додано інтеграційний міст із 3D Slicer без втручання в ядро Viewer.

## Що вміє модуль

- Автопошук `Slicer.exe` через змінні середовища та типові Windows-шляхи.
- Відкриття поточного DICOM-файлу/папки у 3D Slicer.
- Експорт поточного volume у NRRD для 3D Slicer.
- Експорт поточної маски сегментації у NRRD.
- Імпорт STL/OBJ/PLY/GLB як зовнішнього результату з Slicer/Geomagic.
- Manifest `slicer_bridge_manifest.json` для відстеження джерел даних.

## Навіщо це потрібно

3D Slicer має готові потужні модулі: Segment Editor, SlicerMorph, VMTK, MONAI Label, Radiomics. DicomView PRO може бути швидким клінічним viewer/навігатором, а Slicer — важкою станцією для глибокої сегментації та моделювання.

## Безпечна логіка

Якщо 3D Slicer не встановлений, програма не падає: користувач бачить повідомлення і може вказати шлях вручну.
