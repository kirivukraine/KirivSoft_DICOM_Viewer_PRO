# DicomView PRO AI Enterprise — повна інтеграція MobileSAM ONNX

У цій збірці MobileSAM підключений як повна ONNX-зв'язка:

```text
_internal/models/segmentation/mobile_sam_image_encoder.onnx
_internal/models/segmentation/sam_mask_decoder_single.onnx
_internal/models/segmentation/sam_mask_decoder_multi.onnx
_internal/models/segmentation/mobile_sam.onnx   # сумісність зі старою назвою decoder
```

## Як користуватися

1. Запустіть DicomView PRO.
2. Відкрийте DICOM-серію.
3. Перейдіть на вкладку 2D.
4. Натисніть `Smart Click ROI: OFF`, щоб стало `Smart Click ROI: ON`.
5. Клацніть лівою кнопкою миші по структурі, яку потрібно виділити.
6. Дочекайтеся результату в AI Preview.
7. Програма покаже маску й приблизну площу ROI в мм²/см².

## Що відбувається всередині

```text
DICOM 2D slice
  -> window/level normalization
  -> MobileSAM image encoder ONNX
  -> image_embeddings
  -> MobileSAM mask decoder ONNX
  -> 2D mask overlay
```

## Важливо

- Це експериментальний AI-режим, не сертифікований медичний виріб.
- Для діагностики потрібна клінічна валідація.
- Якщо ONNX Runtime або модель недоступні, програма не падає, а переходить у safe fallback.
- Найкращий перший тест: великі контрастні структури на КТ/МРТ. Для дрібних судин MobileSAM може працювати посередньо.

## Файли моделей

Основний режим використовує `sam_mask_decoder_single.onnx` — одна маска на один клік. `sam_mask_decoder_multi.onnx` залишений у комплекті для майбутнього режиму вибору кількох масок.
