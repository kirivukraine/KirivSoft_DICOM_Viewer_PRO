# DicomView PRO AI Enterprise Edition — AuditFix build

Автор: Іван Кіранчук  
Компанія: KirivSoft

## Виправлено після аудиту

1. `main_window.py` — mmap `.npy` тепер явно скидається після `.copy()` через `del volume_mmap`, щоб Windows не блокував тимчасові файли.
2. `dicom_reader.py` — DICOM WindowCenter/WindowWidth тепер зберігаються як перше значення і як повний список `dicom_window_center_values` / `dicom_window_width_values`; при кількох пресетах пишеться warning у лог.
3. `dicom_reader.py` — spacing по зрізах рахується по відсортованих унікальних позиціях і тільки по позитивних різницях.
4. `dicom_reader.py` — при відкиданні кадрів з іншим розміром додається попередження у `decode_errors` і лог.
5. `measurements.py` — `circle_roi_stats_hu()` тепер будує справжнє коло за радіусом `hypot(dx, dy)`, а не еліпс.
6. `media_export.py` — DICOMDIR fallback тепер повідомляє, якщо `pydicom.fileset` недоступний і потрібен `pydicom >= 2.3`.
7. `dicomweb_client.py` — дефолтний DICOMweb timeout збільшено з 20 до 60 секунд.
8. `main_window.py` — `external_model_path` оголошено в `__init__`.
9. `main_window.py` — локальний дубль імпорту `QInputDialog` прибрано.
10. `main_window.py` — `closeEvent()` зупиняє Cine timer і коректно чекає `scan_thread`, `load_thread` та background tasks перед cleanup.

## Перевірка

- `python -m compileall -q src tests` — OK.
- `PYTHONPATH=src pytest -q` — 33 passed, 4 skipped.

## Примітка

AI-модулі залишені у safe-fallback режимі: якщо ONNX-моделі відсутні в `models/`, програма не падає і показує контрольований fallback/повідомлення.
