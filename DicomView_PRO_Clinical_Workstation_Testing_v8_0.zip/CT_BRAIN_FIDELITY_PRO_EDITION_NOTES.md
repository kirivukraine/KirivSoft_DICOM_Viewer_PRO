# DicomView PRO — CT Brain Fidelity PRO Edition

Ціль збірки: стабілізувати якість 2D CT Brain без змін у 3D/MPR/VTK.

## Основні зміни

- 3D Volume, MPR, VTK, STL/OBJ/PLY і VMTK не змінювались.
- Додано HU-рівневий `Brain Bilateral PRO` перед Window/Level.
- Додано `Brain Fidelity PRO`: Bilateral PRO + ITK Curvature Anisotropic Diffusion до Window/Level.
- Додано `Brain Fidelity Ultra`: сильніший режим для Hr64/H70/H80/U90/Sharp/Bone/High Resolution CT Brain.
- За замовчуванням для CT Brain/Hr64: `Brain Soft W100 C35`, `Cubic/Smooth`, `Brain Fidelity Ultra`.
- Для звичайного CT Brain: `Brain Fidelity PRO`.
- Fit-to-window тепер не робить прихований auto-crop; `Fit anatomy` залишено тільки ручним режимом.
- Додано окреме збереження 2D-профілю для кожної серії: W/L, interpolation, fit mode, fidelity filter.
- Cine і stack перегляд мають використовувати стабільний viewport без автоматичного перерахунку crop у Fit-to-window.

## Нові профілі Display Processing

- Brain Fidelity PRO
- Brain Fidelity Ultra
- Brain Bilateral PRO
- ITK Anisotropic CT Brain
- ITK Anisotropic Strong
- Syngo soft brain (max)
- CT Brain fidelity (strong)
- Brain smooth (less noise)
- CLAHE Low / Medium / Angio
- Off / raw diagnostic

## Рекомендовано для тесту

1. Відкрити CT Brain Hr64.
2. Перевірити дефолт: Brain Soft W100 C35 + Cubic/Smooth + Brain Fidelity Ultra.
3. Порівняти режими:
   - Off / raw diagnostic
   - Brain Bilateral PRO
   - Brain Fidelity PRO
   - Brain Fidelity Ultra
4. Відкрити другу CT Brain серію без перезапуску програми й перевірити, що якість не деградує.
5. У Cine/scroll перевірити відсутність стрибків масштабу.
