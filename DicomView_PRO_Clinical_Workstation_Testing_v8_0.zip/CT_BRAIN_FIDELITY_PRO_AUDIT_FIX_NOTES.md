# DicomView PRO — CT Brain Fidelity PRO Audit Fix

Виправлено аудит CT Brain Fidelity PRO Edition:

- MR / US / NM / unknown більше не успадковують CT Brain HU-фільтр: reset виставляє `sharpen_mode = off`, adaptive profile явно вмикає CT Brain фільтри тільки для CT Brain.
- `skull` прибрано з CT Brain detector; лишено `skull base`, щоб кісткові серії не отримували soft-tissue denoise.
- `bone` і `kernel` прибрано з sharp-kernel detector, щоб GE `BONE` не вмикав Brain Fidelity Ultra помилково.
- `proj_label` і `seg_preview` отримують той самий axial SmoothStack bbox, щоб projection/segmentation не стрибали у fit_content.
- Додано явні abdomen/liver/pelvis window defaults: C50/W350.
- Додано unit-тести для adaptive 2D profile detector; тести пропускаються, якщо PySide6 недоступний у CI.

3D/MPR/VTK не змінювались.
