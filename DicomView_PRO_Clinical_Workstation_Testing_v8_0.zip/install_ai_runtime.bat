@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv (
  py -3.11 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip setuptools wheel
pip install TotalSegmentator dicom2nifti nibabel scikit-image nnunetv2
python -c "import totalsegmentator, dicom2nifti, nibabel, skimage; print('AI runtime OK')"
pause
