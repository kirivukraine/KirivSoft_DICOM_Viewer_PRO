# DicomView PRO — Real-ESRGAN AI Zoom Integration

Додано підтримку Real-ESRGAN як зовнішнього локального AI-модуля.

## Варіант 1: рекомендовано — ncnn-vulkan portable

Скопіюйте офіційний `realesrgan-ncnn-vulkan.exe` і його папку `models` сюди:

```text
DicomView_PRO\_internal\tools\realesrgan\
```

Очікувана структура:

```text
_internal/
  tools/
    realesrgan/
      realesrgan-ncnn-vulkan.exe
      models/
        realesrgan-x4plus.bin
        realesrgan-x4plus.param
        ...
```

Після цього у вкладці **AI** працюють кнопки:

- **Real-ESRGAN AI Zoom x2**
- **Real-ESRGAN AI Zoom x4**

## Варіант 2: ONNX fallback

Можна покласти ONNX-модель сюди:

```text
_internal\models\superres\realesrgan_x2.onnx
_internal\models\superres\realesrgan_x4.onnx
```

## Без моделей

Якщо EXE або ONNX немає, програма не падає — використовується safe Lanczos preview fallback.

## Медична безпека

Real-ESRGAN використовується тільки як **preview/enhancement**. Він не є діагностичною реконструкцією і може створювати штучні деталі.
