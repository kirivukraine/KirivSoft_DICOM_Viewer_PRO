# DicomView PRO v8.0 Clinical Workstation Testing Edition

Це перша збірка для реального тестування на колекції DICOM-дисків.

## Що об'єднано у v8.0

- Viewer Fidelity: 2D/MPR якість, SmoothStack, fidelity modes.
- Scanner Intelligence: аналіз Manufacturer, Model, Kernel, SliceThickness, PixelSpacing.
- Scanner Kernel DB: профілі Siemens / GE / Philips / Canon / Toshiba / Hitachi.
- Series Quality: оцінка якості серії та причин обмежень.
- Cinematic/Fidelity 3D: реальний VTK pipeline у `ui/vtk_viewer.py`, adaptive sample distance, jittering, gradient opacity.
- Hemorrhage Protocol: класична HU/morphology маска, об'єм, розміри, звіт.
- Trauma Protocol: bone/air/dense fragments/hematoma candidates, Trauma Focus report.
- Comparative Viewer: Study A vs Study B, delta volume/size/HU, overlay when shape/spacing match.
- DICOM Validation: попередня перевірка основних тегів і transfer syntax.
- Stability Cleanup: безпечні AI stubs, optional module manager, покращений JSON parsing runtime/controller.

## Як тестувати

1. Відкрити одну якісну КТ-серію мозку.
2. Записати відео: Axial, Coronal, Sagittal, MPR, 3D, Hemorrhage Protocol, Звіт.
3. Відкрити травматичну або кісткову серію.
4. Записати відео: Bone Window, 3D Trauma/Cinematic, Trauma Protocol, Звіт.
5. Відкрити дві серії одного пацієнта для Comparative Viewer.
6. Зберегти diagnostic log з програми.
7. Передати відео + log для аналізу.

## Що свідомо не включено у v8.0

- Повний рефакторинг MainWindow на контролери.
- SSAO / Ambient Occlusion.
- Clip Box.
- Oblique / Curved MPR.
- ROI Volume.
- DICOM SEG / RTSTRUCT export.
- Повний Orthanc/DICOMweb workflow.

Ці функції залишені для v8.1+ після реального тестування.

## Попередження

Це дослідницька/тестова збірка. Вона не є сертифікованим медичним виробом і не повинна замінювати висновок лікаря.
