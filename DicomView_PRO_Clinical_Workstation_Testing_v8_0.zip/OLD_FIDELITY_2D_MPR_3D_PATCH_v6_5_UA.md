# DicomView PRO v6.5 — Old Fidelity 2D/MPR + Legacy 3D

Цей патч не додає нові AI-модулі. Він виправляє саме те, що було видно у відео:

1. Покращення 2D/MPR у трьох площинах:
   - coronal/sagittal тепер будуються через high-fidelity MPR engine;
   - додано 3-slice thin slab averaging для coronal/sagittal, щоб зменшити шум і «сходинки»;
   - збережено правильний масштаб у мм;
   - для coronal/sagittal автоматично застосовується сильніший `mpr_fidelity_max` display filter;
   - вимірювання та координати залишаються в системі slice/crosshair.

2. Legacy 3D:
   - в `set_legacy_headface_volume()` перенесено логіку Old Lung/Face Fidelity;
   - використовується `vtkFixedPointVolumeRayCastMapper`, якщо він доступний;
   - знижений HU-поріг для напівпрозорої шкіри/м’яких тканин;
   - тепліша кістка, видимі контури обличчя/носа/вух;
   - це має повторити якість старої програми у вкладці Legacy 3D.

3. Це свідомо малий патч:
   - без нових гігабайтних залежностей;
   - без AI;
   - без зміни DICOM-даних;
   - зміни лише в 2D/MPR display pipeline та Legacy 3D transfer function.

Файли, які реально змінено:
- `src/dicomview_pro/core/mpr_fidelity_engine.py`
- `src/dicomview_pro/core/image_ops.py`
- `src/dicomview_pro/ui/main_window.py`
- `src/dicomview_pro/ui/vtk_viewer.py`
