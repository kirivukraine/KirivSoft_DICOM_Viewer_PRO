# DicomView PRO — Clinical Foundation / Safe Fallback пакет

Цей пакет фіксує стабільну основу великих клінічних модулів:

1. Orthanc Explorer PRO — REST-клієнт, який не блокує локальний Viewer, якщо Orthanc недоступний.
2. Reporting PRO — PDF/DOCX за наявності залежностей, TXT fallback без падіння.
3. Radiomics PRO — базова NumPy-радіоміка, PyRadiomics як optional.
4. Cine PRO — playback і export, але без падіння при відсутності відео-кодеків.
5. Vessel Analysis — threshold/MIP preview без діагностичних обіцянок.
6. 3D Angio Reconstruction — VTK preview за наявності GPU/OpenGL, CPU MIP fallback для старих ПК.
7. 4D Cardiac Viewer v1 — timeline foundation для cine/t,z,y,x даних.
8. AI/MONAI — optional; якщо MONAI/Torch відсутні, працюють threshold fallback-маски.

Головне правило: Core DICOM Viewer, 2D, Series Selector, MPR і Logs мають працювати навіть тоді, коли всі важкі модулі недоступні.
