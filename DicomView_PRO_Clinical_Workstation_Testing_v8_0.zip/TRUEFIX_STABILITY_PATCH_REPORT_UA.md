# DicomView PRO TrueFix Stability Patch

## Що виправлено

### 1. AutoClean 3D більше не ламається без scipy

Файл:

```text
src/dicomview_pro/core/volume_cleaner.py
```

Було:
- якщо `scipy` не встановлено, AutoClean робив тільки threshold-mask;
- дрібні компоненти / пластини / шум залишались у 3D;
- тест без scipy падав.

Стало:
- додано власний fallback connected-components на NumPy/Python;
- використовується 26-connected neighborhood;
- `Bone/Skull largest` тепер видаляє дрібні компоненти навіть без scipy;
- `scipy` залишається рекомендованим швидким шляхом, але не є єдиною робочою логікою.

Для перевірки fallback можна задати:

```bat
set DICOMVIEW_VOLUME_CLEANER_NO_SCIPY=1
pytest tests\test_volume_cleaner.py
```

### 2. Real-ESRGAN зроблено чесним portable-модулем

Було:
- кнопки AI Zoom є;
- програма шукає `realesrgan-ncnn-vulkan.exe`;
- але build-скрипт не копіював `_internal\tools` у dist.

Стало:
- `build_portable.bat` і `build_exe.bat` копіюють `_internal\tools` і `tools` у portable `dist`;
- PyInstaller отримав `--add-data "_internal\tools;tools"`;
- пошук Real-ESRGAN `.exe` тепер рекурсивний, якщо користувач розпакував офіційний release у підпапку;
- додано `PUT_REALESRGAN_NCNN_VULKAN_HERE.txt`;
- додано `REALESRGAN_PORTABLE_STATUS_UA.md`.

Важливо: офіційний `realesrgan-ncnn-vulkan.exe`, DLL і `models/*.bin/*.param` не вшиті в архів. Їх треба покласти вручну в:

```text
DicomView_PRO\_internal\tools\realesrgan\
```

Якщо exe відсутній, AI Zoom x2/x4 чесно працює як safe fallback preview.

### 3. Заблоковано ризик випадкової збірки на Python 3.14

Було:
- `py -3.11` міг не спрацювати;
- `build_portable.bat` мовчки переходив на будь-який `python`, наприклад Python 3.14;
- це суперечить `pyproject.toml` (`>=3.10,<3.13`).

Стало:
- build pinned на Python 3.11 x64;
- якщо Python 3.11 немає — збірка зупиняється з помилкою;
- якщо існуючий `.venv` не Python 3.11 — збірка просить видалити `.venv` і створити заново;
- перед PyInstaller виконується runtime-check `scipy` + `onnxruntime`.

## Перевірка

```text
python -m compileall -q src  OK
PYTHONPATH=src pytest -q    46 passed, 4 skipped
```

## Висновок

Це стабілізаційна збірка. Вона не видає Real-ESRGAN за повністю вбудований модуль без наявності офіційного `.exe`, і не залежить критично від scipy для базового видалення плаваючих 3D-компонентів.
