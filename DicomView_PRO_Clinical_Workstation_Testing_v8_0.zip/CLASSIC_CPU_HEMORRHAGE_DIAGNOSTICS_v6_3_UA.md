# DicomView PRO v6.3 — Classic CPU Hemorrhage + Diagnostics

Це малий патч без AI і без великих залежностей. Додано прозорий CPU-only модуль для КТ голови:

- DICOM series loader із сортуванням зрізів по `ImagePositionPatient[2]` / `InstanceNumber`.
- Перерахунок pixel data у HU через `RescaleSlope` / `RescaleIntercept`.
- 3D-сегментація крововиливу за HU діапазоном, який задається в UI.
- 3D морфологія через `scipy.ndimage`.
- Connected components із фільтрацією дрібного шуму.
- Розрахунок обʼєму крововиливу в мл.
- BBox, центр мас, список компонентів.
- Brain asymmetry map без AI.
- Збереження JSON-звіту.
- 3D overlay крововиливу як STL mesh, якщо доступний `skimage`.

## Де шукати у програмі

Вкладка `Clinical`:

- `Classic CPU Analyze`
- `Classic Hemorrhage 3D`
- `Save Classic JSON`

Меню `Файл`:

- `Classic CPU: крововилив + асиметрія`

## Залежності

Мінімально:

```bash
pip install numpy pydicom scipy
```

Для STL/PLY/OBJ mesh export бажано:

```bash
pip install scikit-image
```

## Важливо

Це не AI і не автоматичний діагноз. Це детермінований HU/morphology інструмент для візуалізації та тестування workflow.
