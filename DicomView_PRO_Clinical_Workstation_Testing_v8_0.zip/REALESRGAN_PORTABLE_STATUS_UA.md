# Real-ESRGAN portable integration status

У цій збірці Real-ESRGAN інтегрований як **зовнішній portable AI tool**, а не як вбудований виконуваний файл.

Чому так:
- `realesrgan-ncnn-vulkan.exe` і його `models/*.bin/*.param` потрібно брати з офіційного release Real-ESRGAN.
- Програма не повинна робити вигляд, що AI Zoom працює, якщо `.exe` фізично відсутній.

Куди класти:

```text
DicomView_PRO\_internal\tools\realesrgan\
  realesrgan-ncnn-vulkan.exe
  *.dll
  models\*.bin
  models\*.param
```

Можна також розпакувати офіційний архів підпапкою всередині `realesrgan` — програма тепер шукає `.exe` рекурсивно.

Якщо `.exe` не знайдений, кнопки AI Zoom x2/x4 працюють тільки як safe Lanczos preview fallback і чесно пишуть це в лог.
