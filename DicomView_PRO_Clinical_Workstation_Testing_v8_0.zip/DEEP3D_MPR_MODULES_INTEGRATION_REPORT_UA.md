# DicomView PRO — Deep 3D / MPR Modules Integration Report

Інтегровано модулі з архіву `DicomView_PRO_Deep3D_MPR_Modules(1).zip` як стабілізаційний шар для існуючого VTK/MPR движка.

## Додані модулі

- `src/dicomview_pro/rendering/shared_crosshair_state.py` — єдиний стан координат 3D/MPR/clip/slab.
- `src/dicomview_pro/rendering/clip_plane_controller.py` — керування площинами відсікання.
- `src/dicomview_pro/rendering/deep_camera_controller.py` — Shift+Wheel рухає камеру вглиб без підміни на zoom.
- `src/dicomview_pro/rendering/slab_controller.py` — MIP / MinIP / Average slab, із numpy fallback.
- `src/dicomview_pro/rendering/vtk_volume_builder.py` — конвертація numpy z/y/x у `vtkImageData` без втрати spacing.
- `src/dicomview_pro/rendering/volume_render_engine.py` — модульний GPU Volume Rendering engine.
- `src/dicomview_pro/rendering/hardware_profile.py` — HIGH/MEDIUM/LOW/SAFE render profile.
- `src/dicomview_pro/rendering/integration_bridge.py` — безпечний міст до існуючого `VtkVolumeViewer`.

## UI / поведінка

- `Clip Navigate` більше не замінює interactor style на `vtkInteractorStyleUser`, тому ротація/панорамування не повинні ламатися після 3D ножа.
- Wheel у Clip Navigate рухає площину відсікання, а не zoom.
- Shift+Wheel у 3D рухає камеру вперед/назад по осі погляду.
- Ctrl+Wheel змінює товщину SlabController.
- Додано UI для Slab MPR: Off / MIP / MinIP / Average + товщина в мм.

## Важливо

Це інтеграційна основа, а не повна заміна всього старого 3D-коду. Старі режими Surface/Volume/MIP Preview залишені як fallback, щоб програма не втрачала працездатність на слабких ПК.
