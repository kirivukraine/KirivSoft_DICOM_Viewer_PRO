# DicomView PRO — MobileSAM Smart Click ROI Integration

Збірка додає реальну інтеграційну шину MobileSAM для локальної інтерактивної сегментації 2D DICOM-зрізу.

## Додано

- `src/dicomview_pro/core/sam_preprocess.py`
  - DICOM grayscale/HU → RGB tensor `[1,3,1024,1024]`.
  - підтримка Window Center / Window Width;
  - resize без OpenCV-залежності: Pillow, а при відсутності Pillow — numpy fallback;
  - зворотне масштабування AI-маски до оригінального розміру DICOM.

- `src/dicomview_pro/core/sam_worker.py`
  - асинхронний `MobileSAMWorker(QThread)`;
  - UI/VTK не зависає під час інференсу;
  - safe fallback, якщо `mobile_sam.onnx` або `onnxruntime` відсутні.

- `src/dicomview_pro/core/ai_medsam.py`
  - оновлений `mobile_sam_segment_slice()`;
  - підтримка `mobile_sam.onnx`;
  - fallback-сегментація за кліком.

- UI:
  - кнопка `Smart Click ROI: ON/OFF` у вкладці AI;
  - клік по вкладці 2D запускає MobileSAM-сегментацію;
  - результат кладеться у `AI Preview`, `Segmentation Preview` та `current_mask` для подальшого експорту;
  - розраховується площа маски у мм²/см² за PixelSpacing.

## Куди класти модель

```text
models/segmentation/mobile_sam.onnx
```

Якщо модель відсутня, програма не падає — буде використано safe fallback.

## Які ONNX-моделі підтримуються

Підтримується комбінований MobileSAM ONNX, який приймає зображення та точки:

- `images` / `image` / `input`;
- `point_coords`;
- `point_labels`;
- додатково, якщо є: `mask_input`, `has_mask_input`, `orig_im_size`.

Decoder-only модель, яка очікує `image_embeddings`, не запуститься без окремого encoder.onnx. У такому випадку програма покаже зрозуміле повідомлення й увімкне fallback.

## Перевірка

- `compileall` — OK
- `pytest` — 33 passed, 4 skipped
