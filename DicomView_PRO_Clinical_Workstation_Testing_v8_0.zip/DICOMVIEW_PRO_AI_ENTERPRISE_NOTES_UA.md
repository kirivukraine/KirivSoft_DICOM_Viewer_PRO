# DicomView PRO AI Enterprise Edition — KirivSoft

Додано локальну AI-шину без передачі DICOM-даних у хмару.

## Нові модулі

- `core/ai_engine.py` — загальний статус AI-середовища.
- `core/ai_models.py` — менеджер папок і моделей `.onnx`.
- `core/ai_onnx.py` — безпечний optional ONNX Runtime wrapper.
- `core/ai_medsam.py` — MobileSAM/MedSAM 2D segmentation + safe fallback.
- `core/ai_dncnn.py` — DnCNN/FFDNet denoise + safe fallback.
- `core/ai_realesrgan.py` — Real-ESRGAN AI Zoom preview + safe fallback.
- `runtime/ai_worker.py` — основа для окремого AIWorker-процесу.

## Папки моделей

```text
models/
  segmentation/mobile_sam.onnx
  segmentation/medsam.onnx
  denoise/dncnn.onnx
  denoise/ffdnet.onnx
  superres/realesrgan_x2.onnx
  superres/realesrgan_x4.onnx
  monai/*.onnx
```

Ваги моделей не вшиті в архів, щоб не роздувати збірку і не порушувати ліцензії. Програма сама створює папки моделей і працює без них у safe fallback-режимі.

## Нове в UI

У вкладці **AI** додано:

- `AI Models Manager`
- `MobileSAM Segment 2D`
- `DnCNN Denoise 2D`
- `Real-ESRGAN AI Zoom x2`

## Важливо

`Real-ESRGAN AI Zoom` позначено як preview/enhancement. Його не можна трактувати як діагностичну реконструкцію, бо супер-роздільні моделі можуть домальовувати структури.

## Рекомендовані optional пакети

```bash
pip install onnxruntime
```

Для NVIDIA GPU:

```bash
pip install onnxruntime-gpu
```
