DicomView PRO AI Models
========================

КУДИ КОПІЮВАТИ МОДЕЛІ У PORTABLE-ЗБІРЦІ:
  DicomView_PRO\_internal\models\segmentation\mobile_sam.onnx

Папки для локальних моделей:
- segmentation/mobile_sam.onnx або medsam.onnx
- denoise/dncnn.onnx або ffdnet.onnx
- superres/realesrgan_x2.onnx або realesrgan_x4.onnx
- external Real-ESRGAN: _internal/tools/realesrgan/realesrgan-ncnn-vulkan.exe + models/*.bin/*.param
- monai/*.onnx для медичних органних моделей

Моделі НЕ вшиті в архів, бо вони великі й мають окремі ліцензії.
Програма працює без цих файлів у safe fallback-режимі.
Для ONNX inference рекомендовано встановити: onnxruntime або onnxruntime-gpu.
Real-ESRGAN використовуйте тільки як preview/enhancement, не як діагностичну реконструкцію.
