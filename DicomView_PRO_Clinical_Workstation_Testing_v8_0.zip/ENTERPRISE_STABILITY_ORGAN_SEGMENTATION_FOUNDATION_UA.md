# DicomView PRO Enterprise Stability & Organ Segmentation Foundation

## Мета збірки
Це стабілізаційна збірка. Основна ідея — не додавати випадкові кнопки, а закласти перевірювану модульну основу для органної сегментації та 3D-анатомічних моделей.

## Що додано

### 1. Organ Segmentation Foundation
Додано модуль:

```text
src/dicomview_pro/core/organ_segmentation_foundation.py
```

Він не вшиває важкий PyTorch/TotalSegmentator у головну програму. Натомість він:

- перевіряє наявність `TotalSegmentator`, `dicom2nifti`, `nibabel`, `scikit-image`, `trimesh`, `torch`;
- формує безпечний план обробки;
- готує робочу папку для конвеєра:

```text
DICOM → NIfTI → TotalSegmentator → organ masks → STL/PLY/OBJ → VTK viewer
```

### 2. AI вкладка
Додано кнопки:

```text
Organ AI Status
Prepare Organ Seg Plan
```

Перша показує, чи готовий optional runtime. Друга створює manifest для майбутнього запуску органної сегментації.

### 3. Підтримувані ROI за замовчуванням

```text
heart
liver
kidney_left
kidney_right
spleen
lung_upper_left
lung_lower_left
lung_upper_right
lung_middle_right
lung_lower_right
trachea
urinary_bladder
```

### 4. Стабільність
У головну програму не додано обов'язкових multi-GB залежностей. Якщо TotalSegmentator не встановлено, програма працює у safe fallback і не падає.

## Що не робить ця збірка

Ця збірка ще не запускає повну автоматичну сегментацію органів усередині EXE. Це навмисно: TotalSegmentator, PyTorch і nnUNet можуть зробити portable-збірку дуже великою. Правильна архітектура — optional plugin/runtime.

## Наступний крок

Наступна збірка може додати executor:

```text
Run Organ Segmentation
Cancel Task
Open Organ Mesh Viewer
Organ checklist: Heart / Liver / Kidneys / Lungs
```

Після встановлення optional runtime програма зможе запускати TotalSegmentator у фоні через QThread/окремий процес і відкривати готові органи у VTK 3D-сцені.
