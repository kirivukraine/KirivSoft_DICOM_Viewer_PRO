@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo DicomView PRO Lite - NORMAL PORTABLE build
echo Author: Ivan Kiranchuk / KirivSoft
echo ========================================
echo.

set "APP_NAME=DicomView_PRO_Lite"
set "PYTHON_TAG=3.11"
set "LOG_DIR=build_logs"
set "LOG_FILE=%LOG_DIR%\build_lite.log"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>nul

echo [INFO] Build started > "%LOG_FILE%"
echo [INFO] Working dir: %CD% >> "%LOG_FILE%"

where py >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python Launcher py.exe not found. Install Python 3.11 x64.
    echo [ERROR] py.exe not found >> "%LOG_FILE%"
    pause
    exit /b 1
)

py -%PYTHON_TAG% -c "import struct, sys; assert sys.version_info[:2] == (3, 11); assert struct.calcsize('P')*8 == 64" >nul 2>>"%LOG_FILE%"
if errorlevel 1 (
    echo [ERROR] Required Python 3.11 x64 was not found.
    echo Install Python 3.11 x64 and rerun this script.
    pause
    exit /b 1
)

if not exist .venv (
    echo [INFO] Creating .venv Python 3.11 x64...
    py -%PYTHON_TAG% -m venv .venv >> "%LOG_FILE%" 2>&1
    if errorlevel 1 goto :fail
)

call .venv\Scripts\activate.bat
python -c "import sys, struct; raise SystemExit(0 if sys.version_info[:2] == (3,11) and struct.calcsize('P')*8 == 64 else 1)" >nul 2>>"%LOG_FILE%"
if errorlevel 1 (
    echo [ERROR] Existing .venv is not Python 3.11 x64.
    echo Delete .venv and rerun build_portable.bat.
    pause
    exit /b 1
)

echo [INFO] Upgrading build tools...
python -m pip install --upgrade pip setuptools wheel >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :fail

echo [INFO] Installing Lite requirements. Heavy AI runtimes are NOT bundled.
pip install -r requirements_lite.txt >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :fail

echo [INFO] Checking required Lite runtime modules...
python -c "import PySide6, numpy, pydicom, vtk, PIL, scipy, SimpleITK, cv2; print('Lite runtime check OK')" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [ERROR] Lite runtime check failed. See %LOG_FILE%
    pause
    exit /b 1
)

echo [INFO] Checking optional modules. Missing optional modules will NOT stop Lite build...
python -c "import importlib.util; mods=['onnxruntime','totalsegmentator','torch','nnunetv2']; print('Optional:', {m: bool(importlib.util.find_spec(m)) for m in mods})" >> "%LOG_FILE%" 2>&1

echo [INFO] Running Python syntax check...
python -m compileall -q src run_app.py >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [ERROR] Python syntax check failed. See %LOG_FILE%
    pause
    exit /b 1
)

echo [INFO] Cleaning previous build folders...
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul

echo [INFO] Preparing PyInstaller data folders...
set "ADD_DATA_ARGS=--add-data assets;assets"
if exist "_internal\models" set "ADD_DATA_ARGS=!ADD_DATA_ARGS! --add-data _internal\models;models"
if exist "_internal\tools" set "ADD_DATA_ARGS=!ADD_DATA_ARGS! --add-data _internal\tools;tools"
if exist "_internal\slicer" set "ADD_DATA_ARGS=!ADD_DATA_ARGS! --add-data _internal\slicer;slicer"

echo [INFO] Building portable EXE...
pyinstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onedir ^
  --contents-directory _internal ^
  --name %APP_NAME% ^
  --paths src ^
  !ADD_DATA_ARGS! ^
  --icon assets\icon.ico ^
  --collect-submodules pydicom ^
  --collect-submodules PIL ^
  --collect-data PIL ^
  --hidden-import PIL.Image ^
  --hidden-import PIL.ImageQt ^
  --collect-submodules pylibjpeg ^
  --collect-submodules vtkmodules ^
  --collect-binaries vtkmodules ^
  --exclude-module torch ^
  --exclude-module torchvision ^
  --exclude-module torchaudio ^
  --exclude-module totalsegmentator ^
  --exclude-module nnunetv2 ^
  --exclude-module onnxruntime ^
  --exclude-module monai ^
  --exclude-module pyradiomics ^
  --exclude-module seaborn ^
  --exclude-module pandas ^
  --exclude-module pyarrow ^
  --collect-submodules trimesh ^
  --collect-submodules pynetdicom ^
  --collect-submodules imageio ^
  --collect-submodules scipy ^
  --collect-binaries scipy ^
  --collect-submodules SimpleITK ^
  --collect-submodules cv2 ^
  --collect-submodules reportlab ^
  --collect-submodules docx ^
  run_app.py >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :fail

if exist "_internal\models" xcopy /E /I /Y "_internal\models" "dist\%APP_NAME%\_internal\models" >> "%LOG_FILE%" 2>&1
if exist "_internal\tools" xcopy /E /I /Y "_internal\tools" "dist\%APP_NAME%\_internal\tools" >> "%LOG_FILE%" 2>&1

echo.
echo ========================================
echo [OK] Lite portable build ready:
echo dist\%APP_NAME%\%APP_NAME%.exe
echo.
echo Notes:
echo - onnxruntime / TotalSegmentator / torch / 3D Slicer are optional external modules.
echo - Lite build must start even when optional AI modules are absent.
echo - Build log: %LOG_FILE%
echo ========================================
pause
exit /b 0

:fail
echo.
echo [ERROR] Build failed. See %LOG_FILE%
pause
exit /b 1
