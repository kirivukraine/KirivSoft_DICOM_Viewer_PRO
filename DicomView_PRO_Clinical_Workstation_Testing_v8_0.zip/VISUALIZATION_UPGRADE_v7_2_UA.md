# DicomView PRO v7.2 Visualization Upgrade

Ціль збірки: покращити практичну 2D/MPR/3D-візуалізацію без додавання важких AI-runtime.

## 1. 2D/MPR

Додано режим **Fidelity Max (MPR/Protocol)** у блоці `Якість 2D`.

Для coronal/sagittal продовжує використовуватися high-fidelity MPR:
- cubic resampling;
- thin-slab 3-slice для reconstructed planes;
- стабільне фізичне співвідношення pixel spacing;
- display-only фільтрація без зміни HU-даних.

## 2. Маска протоколу поверх 2D/MPR

Додано кольоровий overlay протоколу на:
- головний 2D viewer;
- axial MPR;
- coronal MPR;
- sagittal MPR.

Overlay є лише display-layer. Він не змінює HU, вимірювання, ROI або вихідні DICOM-дані.

У панелі `Якість 2D` є перемикач:

`Показувати маску протоколу на 2D/MPR`

## 3. 3D

Для протоколу **Гемораж** 3D-візуалізація тепер запускає спеціальний режим:

`Hemorrhage Focus 3D`

У цьому режимі:
- базовий CT volume прозорий;
- крововилив — окремий червоний 3D-об'єкт;
- bounding box — жовтий;
- на екрані показуються volume/size/components, якщо вони є в результаті протоколу.

## 4. UI

Нижній тестовий AI/overlay button-row у 3D більше не додається до layout.
Це звільняє нижню частину 3D-вікна для візуалізації.

## 5. Перевірка

- `python -m compileall -q src` — OK
- Активні тести без Enterprise-disabled: 36 passed, 4 skipped
- Точкові тести MPR/clinical/classic measurements: 5 passed

## Обмеження

Повне відтворення старого EXE Lung/Face render один-в-один неможливо гарантувати без відкритого вихідного коду старої програми. У цій збірці продовжено наближення через Legacy Head/Face 3D і Hemorrhage Focus 3D.
