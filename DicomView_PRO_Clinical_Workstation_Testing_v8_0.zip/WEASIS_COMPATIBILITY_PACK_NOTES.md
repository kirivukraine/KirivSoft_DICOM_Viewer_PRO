# DicomView PRO — Weasis-Inspired Compatibility Pack

Цей пакет не копіює код Weasis. Він додає сумісні підходи, які корисні для DicomView PRO:

## Додано

- **DICOMweb foundation**: QIDO-RS, WADO-RS metadata, STOW-RS upload через `core/dicomweb_client.py`.
- **SR/SEG/RT/ECG inspector**: класифікація спеціальних DICOM-об'єктів через SOP Class UID та Modality.
- **FrameOfReference sync foundation**: пошук серій, які можна анатомічно синхронізувати.
- **Dicomizer foundation**: імпорт JPG/PNG/BMP/TIFF як Secondary Capture DICOM, PDF як Encapsulated PDF, STL як Encapsulated STL.
- **Меню “Сумісність”** у UI: швидкий доступ до аналізу SR/SEG/RT/ECG, DICOMweb, Dicomizer, FrameOfReference sync.

## Важливо

Це foundation-рівень. Модулі зроблені як optional/fallback, щоб Viewer Core не падав, якщо немає DICOMweb-сервера або сторонніх залежностей.

## Наступний розвиток

- повноцінний DICOM SEG overlay поверх 2D/MPR;
- RTSTRUCT контури поверх CT;
- ECG waveform viewer;
- DICOMweb WADO download у локальну базу;
- portable media viewer як у Weasis: дослідження + viewer + індекс + стартовий ярлик.
