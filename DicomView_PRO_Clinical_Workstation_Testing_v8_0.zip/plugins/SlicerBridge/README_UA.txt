SlicerBridge plugin placeholder для DicomView PRO Lite.
Цей модуль не імпортується при старті Lite.
Додайте runtime/файли Enterprise-версії окремо, якщо потрібен цей функціонал.
