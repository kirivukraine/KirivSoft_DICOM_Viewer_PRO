DicomView PRO Lite: Enterprise/AI модулі винесені з автозавантаження.

У Lite ядро не імпортує TotalSegmentator, nnU-Net, SlicerBridge, Radiomics, VMTK, SAM/ONNX при старті.
Ці модулі збережені тут як довідкові/майбутні плагіни, але не входять у робочий runtime Lite.

Активне Lite-ядро: 2D, Cine, MPR, MIP, Seg Basic, VTK 3D, Clip/Knife, 2D/3D лінійки, export PNG/STL/OBJ/PLY/PDF.
