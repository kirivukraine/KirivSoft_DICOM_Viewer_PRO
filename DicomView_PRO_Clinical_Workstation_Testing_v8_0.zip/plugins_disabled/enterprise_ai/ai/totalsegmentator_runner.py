from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import os
import subprocess
import sys
from typing import Callable, Iterable

from .gpu_detector import detect_gpu
from .external_runtime import build_totalseg_external_command, find_totalsegmentator_runtime

ProgressText = Callable[[str], None]


@dataclass(frozen=True)
class TotalSegCommandPlan:
    input_path: str
    output_dir: str
    rois: list[str]
    fast: bool
    device: str
    command: list[str]
    low_vram: bool
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


def build_totalseg_command(
    input_path: str | os.PathLike[str],
    output_dir: str | os.PathLike[str],
    *,
    rois: Iterable[str] | None = None,
    fast: bool = True,
    device: str = "auto",
) -> TotalSegCommandPlan:
    gpu = detect_gpu()
    if device == "auto":
        device = "gpu" if gpu.torch_cuda else "cpu"
    roi_list = [str(r).strip() for r in (rois or []) if str(r).strip()]
    # Heavy TotalSegmentator is intentionally launched from an external Python
    # runtime. This keeps the packaged viewer small and avoids importing torch
    # in the main UI process.
    try:
        cmd = build_totalseg_external_command(
            input_path,
            output_dir,
            rois=roi_list,
            fast=fast,
            device=device if device != "auto" else ("gpu" if gpu.torch_cuda else "cpu"),
            output_type="nifti",
        )
    except RuntimeError:
        # Keep command planning safe in environments where the optional runtime
        # is not installed. Execution will still fail with a clear diagnostic,
        # but the UI/tests can show the intended command and module status.
        cmd = [sys.executable, "-m", "totalsegmentator.bin.TotalSegmentator", "-i", str(input_path), "-o", str(output_dir), "--output_type", "nifti"]
        if roi_list:
            cmd += ["--roi_subset", *roi_list]
        if fast:
            cmd.append("--fast")
        if device in ("gpu", "cpu", "mps"):
            cmd += ["--device", device]
    return TotalSegCommandPlan(
        input_path=str(input_path),
        output_dir=str(output_dir),
        rois=roi_list,
        fast=bool(fast),
        device=device,
        command=cmd,
        low_vram=gpu.low_vram,
        message=gpu.message,
    )


def run_totalseg_subprocess(plan: TotalSegCommandPlan, progress: ProgressText | None = None) -> int:
    Path(plan.output_dir).mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    commands = [plan.command]
    if "--device" in plan.command:
        idx = plan.command.index("--device")
        commands.append(plan.command[:idx] + plan.command[idx + 2:])
    last_rc = 1
    for attempt, cmd in enumerate(commands, start=1):
        if progress:
            progress(f"TotalSegmentator attempt {attempt}: {' '.join(cmd)}")
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env)
        assert proc.stdout is not None
        unsupported_device = False
        for line in proc.stdout:
            text = line.rstrip()
            if progress:
                progress(text)
            if "unrecognized arguments" in text and "--device" in text:
                unsupported_device = True
        last_rc = proc.wait()
        if last_rc == 0:
            return 0
        if unsupported_device and attempt == 1:
            continue
        return last_rc
    return last_rc
