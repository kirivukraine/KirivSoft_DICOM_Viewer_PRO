from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Iterable
import json
import os

from dicomview_pro.core.organ_segmentation_executor import (
    convert_dicom_to_nifti,
    mask_to_meshes,
)
from dicomview_pro.core.organ_segmentation_foundation import DEFAULT_ROIS, normalize_roi_list, discover_organ_meshes
from dicomview_pro.core.slicer_bridge import find_slicer
from dicomview_pro.runtime.runtime_paths import data_dir

from .gpu_detector import detect_gpu
from .model_manager import runtime_dependency_status
from .nnunet_runner import build_nnunet_plan
from .segmentation_modes import AISegmentationMode, normalize_mode
from .totalsegmentator_runner import build_totalseg_command, run_totalseg_subprocess

Progress = Callable[[int, str], None]
Cancel = Callable[[], bool]


@dataclass(frozen=True)
class AISegmentationStatus:
    gpu: dict
    dependencies: dict
    slicer_found: bool
    slicer_path: str
    recommended_mode: str
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class AISegmentationResult:
    ok: bool
    mode: str
    work_dir: str
    nifti_path: str
    masks_dir: str
    mesh_dir: str
    mesh_files: list[dict]
    message: str
    report_path: str

    def to_dict(self) -> dict:
        return asdict(self)


def ai_segmentation_status() -> AISegmentationStatus:
    gpu = detect_gpu()
    deps = runtime_dependency_status()
    slicer = find_slicer()
    if deps.get("totalsegmentator") and deps.get("torch"):
        recommended = gpu.recommended_mode
    else:
        recommended = AISegmentationMode.TOTALSEG_CPU_SAFE.value
    msg = gpu.message
    if not deps.get("totalsegmentator"):
        msg += " TotalSegmentator Python package is not installed yet."
    return AISegmentationStatus(gpu.to_dict(), deps, bool(slicer.ok), slicer.path, recommended, msg)


def _emit(progress: Progress | None, value: int, message: str) -> None:
    if progress:
        progress(max(0, min(100, int(value))), str(message))


def _check_cancel(cancel: Cancel | None) -> None:
    if cancel and cancel():
        raise RuntimeError("AI segmentation cancelled by user")


def run_ai_segmentation(
    dicom_folder: str | os.PathLike[str],
    work_dir: str | os.PathLike[str] | None = None,
    *,
    mode: str | AISegmentationMode = AISegmentationMode.TOTALSEG_FAST_GPU,
    rois: Iterable[str] | None = None,
    export_formats: Iterable[str] = ("stl", "ply", "obj"),
    progress: Progress | None = None,
    cancel: Cancel | None = None,
) -> AISegmentationResult:
    selected_mode = normalize_mode(mode)
    roi_list = normalize_roi_list(rois or DEFAULT_ROIS)
    root = Path(work_dir) if work_dir else data_dir() / "ai_segmentation_work"
    root.mkdir(parents=True, exist_ok=True)
    nifti_path = root / "input_ct.nii.gz"
    masks_dir = root / "masks"
    mesh_dir = root / "meshes"
    report_path = root / "ai_segmentation_report.json"

    status = ai_segmentation_status()
    _emit(progress, 3, "AI status: " + status.message)
    _check_cancel(cancel)

    if selected_mode == AISegmentationMode.SLICER_TOTALSEG_BRIDGE:
        if not status.slicer_found:
            raise RuntimeError("3D Slicer не знайдено. Покладіть Slicer у _internal/slicer або встановіть його окремо.")
        raise RuntimeError("Slicer TotalSegmentator Bridge підготовлено, але Slicer зараз не вкладений у збірку. Додайте Slicer пізніше.")

    if selected_mode == AISegmentationMode.NNUNET_RESEARCH:
        plan = build_nnunet_plan(dicom_folder, root / "nnunet_output")
        report_path.write_text(json.dumps({"mode": selected_mode.value, "plan": plan.to_dict()}, ensure_ascii=False, indent=2), encoding="utf-8")
        raise RuntimeError(plan.message)

    _emit(progress, 10, "Конвертація DICOM → NIfTI...")
    convert_dicom_to_nifti(dicom_folder, nifti_path, progress=lambda v, m: _emit(progress, v, m), cancel=cancel)
    _check_cancel(cancel)

    device = "cpu" if selected_mode == AISegmentationMode.TOTALSEG_CPU_SAFE else "auto"
    fast = selected_mode == AISegmentationMode.TOTALSEG_FAST_GPU
    plan = build_totalseg_command(nifti_path, masks_dir, rois=roi_list, fast=fast, device=device)
    _emit(progress, 30, f"Запуск {selected_mode.value}: device={plan.device}, fast={plan.fast}")
    rc = run_totalseg_subprocess(plan, progress=lambda text: _emit(progress, 35, text[:180]))
    if rc != 0 and selected_mode == AISegmentationMode.TOTALSEG_FAST_GPU:
        _emit(progress, 42, "Fast GPU не спрацював або бракує VRAM. Автоматичний перехід у CPU Safe...")
        cpu_plan = build_totalseg_command(nifti_path, masks_dir, rois=roi_list, fast=False, device="cpu")
        rc = run_totalseg_subprocess(cpu_plan, progress=lambda text: _emit(progress, 45, text[:180]))
    if rc != 0:
        raise RuntimeError(f"TotalSegmentator завершився з кодом {rc}")

    _check_cancel(cancel)
    _emit(progress, 78, "Генерація STL/PLY/OBJ моделей органів...")
    meshes = mask_to_meshes(masks_dir, mesh_dir, formats=export_formats, progress=lambda v, m: _emit(progress, 78 + int(v * 0.18), m), cancel=cancel)
    if not meshes:
        meshes = discover_organ_meshes(mesh_dir)
    result = AISegmentationResult(True, selected_mode.value, str(root), str(nifti_path), str(masks_dir), str(mesh_dir), meshes, "AI segmentation completed", str(report_path))
    report_path.write_text(json.dumps({"status": status.to_dict(), "result": result.to_dict()}, ensure_ascii=False, indent=2), encoding="utf-8")
    _emit(progress, 100, "AI segmentation completed.")
    return result
