from __future__ import annotations

from dataclasses import dataclass, asdict
import re
import shutil
import subprocess
from typing import Optional


@dataclass(frozen=True)
class GPUInfo:
    available: bool
    name: str
    vram_mb: int
    cuda: bool
    torch_cuda: bool
    low_vram: bool
    recommended_mode: str
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


def _from_torch() -> tuple[bool, str, int]:
    try:
        import torch  # type: ignore
        if not torch.cuda.is_available():
            return False, "", 0
        idx = 0
        props = torch.cuda.get_device_properties(idx)
        return True, str(props.name), int(props.total_memory // (1024 * 1024))
    except Exception:
        return False, "", 0


def _from_nvidia_smi() -> tuple[bool, str, int]:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return False, "", 0
    try:
        cmd = [exe, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"]
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=8)
        if p.returncode != 0 or not p.stdout.strip():
            return False, "", 0
        first = p.stdout.strip().splitlines()[0]
        if "," in first:
            name, mem = first.rsplit(",", 1)
        else:
            name, mem = first, "0"
        digits = re.findall(r"\d+", mem)
        return True, name.strip(), int(digits[0]) if digits else 0
    except Exception:
        return False, "", 0


def detect_gpu() -> GPUInfo:
    torch_ok, torch_name, torch_mem = _from_torch()
    smi_ok, smi_name, smi_mem = _from_nvidia_smi()
    available = torch_ok or smi_ok
    name = torch_name or smi_name or "CPU only"
    vram = torch_mem or smi_mem or 0
    low = bool(available and 0 < vram <= 6144)
    if torch_ok and vram >= 6144:
        mode = "totalsegmentator_fast_gpu"
        msg = f"CUDA GPU ready: {name}, {vram} MB VRAM."
    elif torch_ok and vram > 0:
        mode = "totalsegmentator_fast_gpu_low_vram"
        msg = f"CUDA GPU detected but VRAM is limited: {name}, {vram} MB. Use Fast GPU first, auto-fallback to CPU Safe if OOM."
    elif available:
        mode = "totalsegmentator_cpu_safe"
        msg = f"NVIDIA GPU found ({name}, {vram} MB), but PyTorch CUDA is not ready. Use CPU Safe until CUDA runtime is installed."
    else:
        mode = "totalsegmentator_cpu_safe"
        msg = "No CUDA GPU detected. Use TotalSegmentator CPU Safe."
    return GPUInfo(
        available=available,
        name=name,
        vram_mb=vram,
        cuda=available,
        torch_cuda=torch_ok,
        low_vram=low,
        recommended_mode=mode,
        message=msg,
    )
