from .ai_segmentation_manager import ai_segmentation_status, run_ai_segmentation, AISegmentationResult, AISegmentationStatus
from .segmentation_modes import AISegmentationMode, MODE_LABELS_UA
from .gpu_detector import detect_gpu, GPUInfo

__all__ = [
    "ai_segmentation_status", "run_ai_segmentation", "AISegmentationResult", "AISegmentationStatus",
    "AISegmentationMode", "MODE_LABELS_UA", "detect_gpu", "GPUInfo",
]
