from __future__ import annotations

"""Optional external runtime discovery for heavy AI tools.

This module deliberately imports only the Python standard library.  The main
DicomView PRO process must remain small and must not import torch,
TotalSegmentator, nnU-Net, MONAI or 3D Slicer at startup.  Heavy tools are
launched as external processes when the user explicitly asks for them.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
import os
import subprocess
import sys
from typing import Iterable

TOTALSEG_MODULE = "totalsegmentator.bin.TotalSegmentator"


@dataclass(frozen=True)
class ExternalRuntimeInfo:
    name: str
    ok: bool
    python_path: str
    executable_path: str
    launch_mode: str
    version: str
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


def _project_root() -> Path:
    # src/dicomview_pro/ai/external_runtime.py -> project root
    return Path(__file__).resolve().parents[3]


def _candidate_python_paths() -> list[Path]:
    root = _project_root()
    env_value = os.environ.get("DICOMVIEW_TOTALSEG_PYTHON") or os.environ.get("TOTALSEG_PYTHON")
    candidates: list[Path] = []
    if env_value:
        candidates.append(Path(env_value))
    candidates.extend([
        root / "external_runtime" / "TotalSegmentatorRuntime" / "Scripts" / "python.exe",
        root / "_external" / "TotalSegmentatorRuntime" / "Scripts" / "python.exe",
        root / "_internal" / "ai_runtime" / "TotalSegmentatorRuntime" / "Scripts" / "python.exe",
        Path("C:/TotalSegmentatorRuntime/Scripts/python.exe"),
        Path.home() / "TotalSegmentatorRuntime" / "Scripts" / "python.exe",
    ])
    # Last resort: current interpreter. This is useful in source/dev mode but
    # should not pull heavy packages into packaged builds unless already present.
    candidates.append(Path(sys.executable))

    unique: list[Path] = []
    seen: set[str] = set()
    for p in candidates:
        s = str(p).lower()
        if s not in seen:
            seen.add(s)
            unique.append(p)
    return unique


def _run_probe(python_path: Path, code: str, timeout: int = 12) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            [str(python_path), "-c", code],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        return proc.returncode == 0, proc.stdout.strip()
    except Exception as exc:
        return False, str(exc)


def find_totalsegmentator_runtime() -> ExternalRuntimeInfo:
    for py in _candidate_python_paths():
        if not py.exists():
            continue
        ok, out = _run_probe(py, "import totalsegmentator; print(getattr(totalsegmentator, '__version__', 'installed'))")
        if ok:
            version = out.splitlines()[-1] if out else "installed"
            return ExternalRuntimeInfo(
                name="TotalSegmentator",
                ok=True,
                python_path=str(py),
                executable_path="",
                launch_mode=f"{py} -m {TOTALSEG_MODULE}",
                version=version,
                message="TotalSegmentator external runtime found. Heavy AI will run outside the main DicomView process.",
            )
    return ExternalRuntimeInfo(
        name="TotalSegmentator",
        ok=False,
        python_path="",
        executable_path="",
        launch_mode="external_python_module",
        version="",
        message=(
            "TotalSegmentator runtime not found. Install it to C:\\TotalSegmentatorRuntime or set "
            "DICOMVIEW_TOTALSEG_PYTHON to the runtime python.exe. Basic viewer features remain available."
        ),
    )


def build_totalseg_external_command(
    input_path: str | os.PathLike[str],
    output_dir: str | os.PathLike[str],
    *,
    rois: Iterable[str] | None = None,
    fast: bool = True,
    device: str = "cpu",
    output_type: str = "nifti",
) -> list[str]:
    rt = find_totalsegmentator_runtime()
    if not rt.ok or not rt.python_path:
        raise RuntimeError(rt.message)
    cmd = [
        rt.python_path,
        "-m",
        TOTALSEG_MODULE,
        "-i",
        str(input_path),
        "-o",
        str(output_dir),
        "--output_type",
        output_type,
    ]
    clean_rois = [str(r).strip() for r in (rois or []) if str(r).strip()]
    if clean_rois:
        cmd += ["--roi_subset", *clean_rois]
    if fast:
        cmd.append("--fast")
    if device in {"cpu", "gpu", "mps"} or device.startswith("gpu:"):
        cmd += ["--device", device]
    return cmd
