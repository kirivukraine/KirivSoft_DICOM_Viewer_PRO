from __future__ import annotations

from enum import Enum


class AISegmentationMode(str, Enum):
    TOTALSEG_FAST_GPU = "totalsegmentator_fast_gpu"
    TOTALSEG_CPU_SAFE = "totalsegmentator_cpu_safe"
    SLICER_TOTALSEG_BRIDGE = "slicer_totalsegmentator_bridge"
    NNUNET_RESEARCH = "nnunet_research"


MODE_LABELS_UA: dict[AISegmentationMode, str] = {
    AISegmentationMode.TOTALSEG_FAST_GPU: "TotalSegmentator Fast GPU",
    AISegmentationMode.TOTALSEG_CPU_SAFE: "TotalSegmentator CPU Safe",
    AISegmentationMode.SLICER_TOTALSEG_BRIDGE: "Slicer TotalSegmentator Bridge",
    AISegmentationMode.NNUNET_RESEARCH: "nnU-Net Research Mode",
}


def normalize_mode(value: str | AISegmentationMode | None) -> AISegmentationMode:
    if isinstance(value, AISegmentationMode):
        return value
    raw = (value or AISegmentationMode.TOTALSEG_FAST_GPU.value).strip().lower()
    for mode in AISegmentationMode:
        if raw == mode.value or raw == MODE_LABELS_UA[mode].lower():
            return mode
    return AISegmentationMode.TOTALSEG_FAST_GPU
