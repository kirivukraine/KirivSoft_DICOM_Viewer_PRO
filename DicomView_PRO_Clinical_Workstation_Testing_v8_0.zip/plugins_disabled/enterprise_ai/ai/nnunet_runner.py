from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import os
import subprocess
import sys


@dataclass(frozen=True)
class NnUNetPlan:
    input_dir: str
    output_dir: str
    dataset_id: str
    configuration: str
    fold: str
    command: list[str]
    ready: bool
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


def build_nnunet_plan(input_dir: str | os.PathLike[str], output_dir: str | os.PathLike[str], *, dataset_id: str = "", configuration: str = "3d_fullres", fold: str = "all") -> NnUNetPlan:
    try:
        import nnunetv2  # type: ignore  # noqa: F401
        mod_ok = True
    except Exception:
        mod_ok = False
    env_ok = all(os.environ.get(k) for k in ("nnUNet_raw", "nnUNet_preprocessed", "nnUNet_results"))
    ready = bool(mod_ok and env_ok and dataset_id)
    cmd = [sys.executable, "-m", "nnunetv2.inference.predict_from_raw_data", "-i", str(input_dir), "-o", str(output_dir)]
    if dataset_id:
        cmd += ["-d", dataset_id]
    cmd += ["-c", configuration, "-f", fold]
    msg = "nnU-Net Research ready." if ready else "nnU-Net Research needs nnunetv2, trained model folder and nnUNet_* environment variables."
    return NnUNetPlan(str(input_dir), str(output_dir), dataset_id, configuration, fold, cmd, ready, msg)


def run_nnunet_subprocess(plan: NnUNetPlan) -> int:
    if not plan.ready:
        raise RuntimeError(plan.message)
    Path(plan.output_dir).mkdir(parents=True, exist_ok=True)
    return subprocess.call(plan.command)
