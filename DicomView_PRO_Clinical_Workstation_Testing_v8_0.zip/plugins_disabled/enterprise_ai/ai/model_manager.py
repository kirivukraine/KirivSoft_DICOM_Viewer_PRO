from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util
import zipfile

from .external_runtime import find_totalsegmentator_runtime


@dataclass(frozen=True)
class AIModuleAudit:
    name: str
    archive_path: str
    exists: bool
    looks_like_source: bool
    has_model_weights: bool
    top_level_items: list[str]
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


KNOWN_WEIGHT_EXTENSIONS = (".pt", ".pth", ".ckpt", ".model", ".onnx", ".pkl", ".npz", ".safetensors")


def has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def audit_zip_archive(name: str, archive_path: str | Path) -> AIModuleAudit:
    path = Path(archive_path)
    if not path.exists():
        return AIModuleAudit(name, str(path), False, False, False, [], f"{name}: archive not found")
    try:
        with zipfile.ZipFile(path, "r") as zf:
            names = zf.namelist()
    except Exception as exc:
        return AIModuleAudit(name, str(path), True, False, False, [], f"{name}: invalid zip: {exc}")
    top = sorted({n.split("/", 1)[0] for n in names if n and not n.endswith("/")})[:20]
    lower = [n.lower() for n in names]
    looks_source = any(n.endswith("pyproject.toml") or n.endswith("setup.py") or n.endswith("README.md".lower()) for n in lower)
    weights = any(n.endswith(KNOWN_WEIGHT_EXTENSIONS) for n in lower)
    msg = (
        f"{name}: source archive found; model weights are not bundled and may be downloaded on first run."
        if looks_source and not weights else
        f"{name}: archive contains possible model weights."
        if weights else
        f"{name}: archive found but type is unclear."
    )
    return AIModuleAudit(name, str(path), True, looks_source, weights, top, msg)


def project_internal_root(project_root: str | Path) -> Path:
    return Path(project_root) / "_internal"


def ai_modules_dir(project_root: str | Path) -> Path:
    p = project_internal_root(project_root) / "ai_modules"
    p.mkdir(parents=True, exist_ok=True)
    return p


def ai_models_dir(project_root: str | Path) -> Path:
    p = project_internal_root(project_root) / "models"
    p.mkdir(parents=True, exist_ok=True)
    return p


def runtime_dependency_status() -> dict:
    """Return lightweight dependency status.

    Heavy AI packages are optional and may live in an external runtime such as
    C:/TotalSegmentatorRuntime.  This function therefore reports both local
    imports and external runtime discovery.
    """
    ts_runtime = find_totalsegmentator_runtime()
    local_ts = has_module("totalsegmentator")
    return {
        "totalsegmentator": bool(local_ts or ts_runtime.ok),
        "totalsegmentator_local": local_ts,
        "totalsegmentator_external": ts_runtime.ok,
        "totalsegmentator_python": ts_runtime.python_path,
        "totalsegmentator_launch_mode": ts_runtime.launch_mode,
        "dicom2nifti": has_module("dicom2nifti"),
        "nibabel": has_module("nibabel"),
        "skimage": has_module("skimage"),
        "trimesh": has_module("trimesh"),
        "torch": has_module("torch"),
        "nnunetv2": has_module("nnunetv2"),
    }
