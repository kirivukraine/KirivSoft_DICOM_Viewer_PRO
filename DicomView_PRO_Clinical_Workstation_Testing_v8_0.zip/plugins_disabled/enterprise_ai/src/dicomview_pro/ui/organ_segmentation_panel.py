from __future__ import annotations

from pathlib import Path
import traceback

from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog,
    QCheckBox, QProgressBar, QTreeWidget, QTreeWidgetItem, QTextEdit,
    QGroupBox, QSpinBox, QDoubleSpinBox, QMessageBox, QComboBox
)

from dicomview_pro.core.organ_segmentation_foundation import DEFAULT_ROIS, ORGAN_COLORS, organ_ai_status, discover_organ_meshes
from dicomview_pro.core.organ_segmentation_executor import OrganSegmentationCancelled
from dicomview_pro.ai import ai_segmentation_status, run_ai_segmentation, AISegmentationMode, MODE_LABELS_UA
from dicomview_pro.runtime.runtime_paths import data_dir


class OrganSegmentationWorker(QThread):
    progress = Signal(int, str)
    finished_ok = Signal(dict)
    failed = Signal(str)

    def __init__(self, dicom_folder: str, work_dir: str, rois: list[str], mode: str, formats: list[str]):
        super().__init__()
        self.dicom_folder = dicom_folder
        self.work_dir = work_dir
        self.rois = rois
        self.mode = mode
        self.formats = formats
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    def run(self) -> None:
        try:
            result = run_ai_segmentation(
                self.dicom_folder,
                self.work_dir,
                mode=self.mode,
                rois=self.rois,
                export_formats=self.formats,
                progress=lambda v, m: self.progress.emit(int(v), str(m)),
                cancel=lambda: self._cancel,
            )
            self.finished_ok.emit(result.to_dict())
        except OrganSegmentationCancelled:
            self.failed.emit("Сегментацію скасовано користувачем.")
        except Exception as exc:
            self.failed.emit(str(exc) + "\n\n" + traceback.format_exc(limit=6))


class OrganSegmentationPanel(QWidget):
    """Qt panel: AI Segmentation modes + organ mesh checkboxes."""

    def __init__(self, main_window=None, vtk_viewer=None):
        super().__init__()
        self.main_window = main_window
        self.vtk_viewer = vtk_viewer
        self.worker: OrganSegmentationWorker | None = None
        self.mesh_items: dict[str, QTreeWidgetItem] = {}
        self.mesh_records: list[dict] = []
        self._build_ui()
        self.refresh_status()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.status_label = QLabel("Organ AI: перевірка...")
        self.status_label.setWordWrap(True)
        b_status = QPushButton("Перевірити runtime")
        b_status.clicked.connect(self.refresh_status)
        b_folder = QPushButton("Вибрати DICOM папку")
        b_folder.clicked.connect(self.choose_dicom_folder)
        self.folder_label = QLabel("DICOM: поточна серія або не вибрано")
        self.folder_label.setWordWrap(True)
        top.addWidget(self.status_label, 2)
        top.addWidget(b_status)
        top.addWidget(b_folder)
        root.addLayout(top)
        root.addWidget(self.folder_label)

        roibox = QGroupBox("Органи для автоматичної сегментації")
        roi_layout = QHBoxLayout(roibox)
        self.roi_checks: dict[str, QCheckBox] = {}
        for roi in DEFAULT_ROIS:
            cb = QCheckBox(roi)
            cb.setChecked(True)
            self.roi_checks[roi] = cb
            roi_layout.addWidget(cb)
        root.addWidget(roibox)

        opts = QHBoxLayout()
        self.mode_combo = QComboBox()
        for mode, label in MODE_LABELS_UA.items():
            self.mode_combo.addItem(label, mode.value)
        self.mode_combo.setCurrentIndex(0)
        self.fast_check = QCheckBox("Fast mode")
        self.fast_check.setChecked(True)
        self.fmt_stl = QCheckBox("STL"); self.fmt_stl.setChecked(True)
        self.fmt_ply = QCheckBox("PLY"); self.fmt_ply.setChecked(True)
        self.fmt_obj = QCheckBox("OBJ"); self.fmt_obj.setChecked(True)
        self.opacity = QDoubleSpinBox(); self.opacity.setRange(0.05, 1.0); self.opacity.setSingleStep(0.05); self.opacity.setValue(0.82)
        opts.addWidget(QLabel("AI режим:")); opts.addWidget(self.mode_combo)
        opts.addWidget(self.fast_check); opts.addWidget(QLabel("Експорт:")); opts.addWidget(self.fmt_stl); opts.addWidget(self.fmt_ply); opts.addWidget(self.fmt_obj)
        opts.addWidget(QLabel("Прозорість органів")); opts.addWidget(self.opacity); opts.addStretch(1)
        root.addLayout(opts)

        actions = QHBoxLayout()
        self.b_run = QPushButton("Run AI Segmentation")
        self.b_run.clicked.connect(self.start_segmentation)
        self.b_cancel = QPushButton("Скасувати")
        self.b_cancel.clicked.connect(self.cancel_segmentation)
        self.b_cancel.setEnabled(False)
        self.b_load_mesh_dir = QPushButton("Відкрити готову папку моделей")
        self.b_load_mesh_dir.clicked.connect(self.choose_mesh_folder)
        actions.addWidget(self.b_run); actions.addWidget(self.b_cancel); actions.addWidget(self.b_load_mesh_dir); actions.addStretch(1)
        root.addLayout(actions)

        self.progress = QProgressBar(); self.progress.setRange(0, 100); self.progress.setValue(0)
        self.progress_label = QLabel("Очікування запуску.")
        root.addWidget(self.progress)
        root.addWidget(self.progress_label)

        split = QHBoxLayout()
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Орган / модель", "Формат", "Файл"])
        self.tree.itemChanged.connect(self.on_item_changed)
        self.log = QTextEdit(); self.log.setReadOnly(True)
        split.addWidget(self.tree, 2)
        split.addWidget(self.log, 3)
        root.addLayout(split, 1)

    def current_dicom_folder(self) -> str:
        folder = getattr(self.main_window, "current_folder", None) or getattr(self.main_window, "folder_path", None) or ""
        if folder:
            return str(folder)
        return ""

    def choose_dicom_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Вибрати DICOM папку")
        if folder:
            if self.main_window is not None:
                setattr(self.main_window, "current_folder", folder)
            self.folder_label.setText("DICOM: " + folder)

    def choose_mesh_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Вибрати папку STL/PLY/OBJ")
        if folder:
            self.load_mesh_folder(folder)

    def refresh_status(self) -> None:
        st = ai_segmentation_status()
        deps = st.dependencies
        missing = [name for name in ("totalsegmentator", "dicom2nifti", "nibabel", "skimage", "trimesh") if not deps.get(name)]
        if missing:
            self.status_label.setText("AI Segmentation SAFE fallback. Немає: " + ", ".join(missing) + ". " + st.message)
        else:
            self.status_label.setText("AI Segmentation READY. " + st.message)
        # Auto-select safest default for detected hardware/runtime.
        rec = st.recommended_mode
        for i in range(self.mode_combo.count()):
            if self.mode_combo.itemData(i) == rec or (rec.endswith("low_vram") and self.mode_combo.itemData(i) == AISegmentationMode.TOTALSEG_FAST_GPU.value):
                self.mode_combo.setCurrentIndex(i)
                break
        folder = self.current_dicom_folder()
        if folder:
            self.folder_label.setText("DICOM: " + folder)

    def selected_rois(self) -> list[str]:
        rois = [name for name, cb in self.roi_checks.items() if cb.isChecked()]
        return rois or list(DEFAULT_ROIS)

    def selected_formats(self) -> list[str]:
        fmts = []
        if self.fmt_stl.isChecked(): fmts.append("stl")
        if self.fmt_ply.isChecked(): fmts.append("ply")
        if self.fmt_obj.isChecked(): fmts.append("obj")
        return fmts or ["stl"]

    def start_segmentation(self) -> None:
        folder = self.current_dicom_folder()
        if not folder:
            self.choose_dicom_folder()
            folder = self.current_dicom_folder()
        if not folder:
            QMessageBox.warning(self, "Organ Segmentation", "Спочатку виберіть DICOM папку або відкрийте серію.")
            return
        work = data_dir() / "organ_ai_work"
        self.progress.setValue(0)
        self.log.clear()
        self.b_run.setEnabled(False)
        self.b_cancel.setEnabled(True)
        self.worker = OrganSegmentationWorker(folder, str(work), self.selected_rois(), str(self.mode_combo.currentData()), self.selected_formats())
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def cancel_segmentation(self) -> None:
        if self.worker is not None:
            self.worker.cancel()
            self.progress_label.setText("Скасування...")

    def on_progress(self, value: int, message: str) -> None:
        self.progress.setValue(value)
        self.progress_label.setText(message)
        self.log.append(f"[{value:03d}%] {message}")

    def on_finished(self, result: dict) -> None:
        self.b_run.setEnabled(True)
        self.b_cancel.setEnabled(False)
        self.progress.setValue(100)
        self.progress_label.setText("Готово. Моделі органів завантажені у 3D-панель.")
        self.log.append("\nRESULT:\n" + str(result))
        self.mesh_records = result.get("mesh_files", []) or discover_organ_meshes(result.get("mesh_dir", ""))
        self.populate_mesh_tree(self.mesh_records)
        self.load_mesh_records_to_vtk(self.mesh_records)

    def on_failed(self, message: str) -> None:
        self.b_run.setEnabled(True)
        self.b_cancel.setEnabled(False)
        self.progress_label.setText("Помилка Organ Segmentation. Програма залишилась у safe fallback.")
        self.log.append("\nERROR:\n" + message)
        QMessageBox.warning(self, "Organ Segmentation", message.splitlines()[0] if message else "Unknown error")

    def load_mesh_folder(self, folder: str) -> None:
        records = discover_organ_meshes(folder)
        self.mesh_records = records
        self.populate_mesh_tree(records)
        self.load_mesh_records_to_vtk(records)
        self.log.append(f"Завантажено моделей: {len(records)} з {folder}")

    def populate_mesh_tree(self, records: list[dict]) -> None:
        self.tree.blockSignals(True)
        self.tree.clear()
        self.mesh_items.clear()
        for rec in records:
            path = str(rec.get("path", ""))
            organ = str(rec.get("organ", Path(path).stem))
            fmt = Path(path).suffix.lstrip(".").upper()
            item = QTreeWidgetItem([organ, fmt, path])
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(0, Qt.CheckState.Checked if rec.get("visible", True) else Qt.CheckState.Unchecked)
            self.tree.addTopLevelItem(item)
            self.mesh_items[path] = item
        self.tree.resizeColumnToContents(0)
        self.tree.blockSignals(False)

    def load_mesh_records_to_vtk(self, records: list[dict]) -> None:
        viewer = self.vtk_viewer or getattr(self.main_window, "vtk_viewer", None)
        if viewer is None or not hasattr(viewer, "add_organ_mesh"):
            self.log.append("3D viewer не підтримує add_organ_mesh; моделі тільки у списку.")
            return
        for rec in records:
            path = str(rec.get("path", ""))
            if not path:
                continue
            organ = str(rec.get("organ", Path(path).stem))
            color = tuple(rec.get("color", ORGAN_COLORS.get(organ, (0.75, 0.75, 0.75))))
            ok = viewer.add_organ_mesh(path, name=organ, color=color, opacity=float(self.opacity.value()))
            if not ok:
                self.log.append("Не вдалося відкрити модель: " + path)

    def on_item_changed(self, item: QTreeWidgetItem, column: int) -> None:
        path = item.text(2)
        visible = item.checkState(0) == Qt.CheckState.Checked
        viewer = self.vtk_viewer or getattr(self.main_window, "vtk_viewer", None)
        if viewer is not None and hasattr(viewer, "set_organ_mesh_visible"):
            viewer.set_organ_mesh_visible(path, visible)
