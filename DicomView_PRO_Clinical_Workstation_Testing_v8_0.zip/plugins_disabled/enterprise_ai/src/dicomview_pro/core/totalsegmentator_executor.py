from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional


DEFAULT_ORGANS = [
    "lung_upper_lobe_left", "lung_lower_lobe_left", "lung_upper_lobe_right", "lung_middle_lobe_right", "lung_lower_lobe_right",
    "heart", "liver", "kidney_left", "kidney_right", "pancreas", "stomach", "small_bowel", "colon", "urinary_bladder",
]


@dataclass
class SegmentationJobResult:
    ok: bool
    output_dir: str
    message: str
    produced_files: List[str]


class TotalSegmentatorExecutor:
    """Background-safe wrapper for TotalSegmentator CLI.

    It does not import torch on the GUI thread.  The caller may run execute() in
    QThread/threading.Thread and subscribe to progress_callback text lines.
    """
    def __init__(self, python_exe: Optional[str] = None) -> None:
        self.python_exe = python_exe or sys.executable

    def is_available(self) -> bool:
        return shutil.which("TotalSegmentator") is not None or self._module_available()

    def _module_available(self) -> bool:
        try:
            p = subprocess.run([self.python_exe, "-m", "totalsegmentator", "--help"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            return p.returncode in (0, 1)
        except Exception:
            return False

    def execute(self, input_path: str, output_dir: str, organs: Optional[Iterable[str]] = None,
                fast: bool = True, preview: bool = False,
                progress_callback: Optional[Callable[[str], None]] = None) -> SegmentationJobResult:
        inp = Path(input_path); out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
        if not inp.exists():
            return SegmentationJobResult(False, str(out), f"Input path not found: {inp}", [])
        organs = list(organs or DEFAULT_ORGANS)
        cmd = [self.python_exe, "-m", "totalsegmentator", "-i", str(inp), "-o", str(out), "--roi_subset", *organs]
        if fast: cmd.append("--fast")
        if preview: cmd.append("--preview")
        if progress_callback: progress_callback("Запуск TotalSegmentator: " + " ".join(cmd))
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
            assert proc.stdout is not None
            for line in proc.stdout:
                if progress_callback: progress_callback(line.rstrip())
            rc = proc.wait()
        except Exception as exc:
            return SegmentationJobResult(False, str(out), str(exc), [])
        files = [str(p) for p in out.rglob("*.nii.gz")] + [str(p) for p in out.rglob("*.stl")] + [str(p) for p in out.rglob("*.ply")]
        report = {"ok": rc == 0, "returncode": rc, "input": str(inp), "output": str(out), "organs": organs, "files": files}
        (out / "totalsegmentator_job_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return SegmentationJobResult(rc == 0, str(out), "OK" if rc == 0 else f"TotalSegmentator exited with code {rc}", files)
