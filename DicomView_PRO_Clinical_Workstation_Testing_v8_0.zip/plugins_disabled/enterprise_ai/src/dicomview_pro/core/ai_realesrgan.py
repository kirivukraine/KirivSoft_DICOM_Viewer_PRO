from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
from typing import Iterable

import numpy as np

from .ai_models import app_base_dir, find_model_path, model_roots
from .ai_onnx import onnxruntime_available, run_single_input_model


@dataclass
class SuperResResult:
    ok: bool
    message: str
    image2d: np.ndarray
    details: dict | None = None


REAL_ESRGAN_NCNN_NAMES = (
    "realesrgan-ncnn-vulkan.exe",
    "realesrgan-ncnn-vulkan",
)


def _candidate_tool_dirs() -> list[Path]:
    base = app_base_dir()
    roots: list[Path] = [
        base / "_internal" / "tools" / "realesrgan",
        base / "tools" / "realesrgan",
        Path.cwd() / "_internal" / "tools" / "realesrgan",
        Path.cwd() / "tools" / "realesrgan",
    ]
    env = os.environ.get("DICOMVIEW_REALESRGAN_DIR")
    if env:
        roots.insert(0, Path(env).expanduser())
    # If a user puts the executable directly into one of the model roots.
    for root in model_roots():
        roots.append(root.parent / "tools" / "realesrgan")
        roots.append(root / "superres")
    out: list[Path] = []
    seen: set[str] = set()
    for p in roots:
        try:
            key = str(p.resolve()).lower()
        except Exception:
            key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def find_realesrgan_ncnn() -> Path | None:
    """Find Real-ESRGAN ncnn-vulkan executable for portable preview mode."""
    env_exe = os.environ.get("DICOMVIEW_REALESRGAN_EXE")
    if env_exe:
        p = Path(env_exe).expanduser()
        if p.exists():
            return p.resolve()

    for folder in _candidate_tool_dirs():
        for name in REAL_ESRGAN_NCNN_NAMES:
            p = folder / name
            if p.exists():
                return p.resolve()
        # Users often extract the official release archive as a nested folder,
        # e.g. _internal/tools/realesrgan/realesrgan-ncnn-vulkan-*/.
        try:
            for name in REAL_ESRGAN_NCNN_NAMES:
                matches = list(folder.glob(f"**/{name}")) if folder.exists() else []
                for p in matches:
                    if p.is_file():
                        return p.resolve()
        except Exception:
            pass

    for name in REAL_ESRGAN_NCNN_NAMES:
        found = shutil.which(name)
        if found:
            return Path(found).resolve()
    return None


def _fallback_upscale(image: np.ndarray, scale: int = 2) -> np.ndarray:
    arr = np.asarray(image, dtype=np.float32)
    try:
        from PIL import Image
        lo, hi = float(np.nanmin(arr)), float(np.nanmax(arr))
        norm = np.zeros_like(arr, dtype=np.uint8) if hi <= lo else np.clip((arr - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)
        up = Image.fromarray(norm).resize((arr.shape[1] * scale, arr.shape[0] * scale), Image.Resampling.LANCZOS)
        upa = np.asarray(up, dtype=np.float32)
        return upa / 255.0 * (hi - lo) + lo if hi > lo else upa
    except Exception:
        return np.repeat(np.repeat(arr, scale, axis=0), scale, axis=1)


def _to_uint8(image: np.ndarray) -> tuple[np.ndarray, float, float]:
    arr = np.asarray(image, dtype=np.float32)
    lo, hi = float(np.nanmin(arr)), float(np.nanmax(arr))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return np.zeros(arr.shape, dtype=np.uint8), 0.0, 1.0
    return np.clip((arr - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8), lo, hi


def _from_uint8(u8: np.ndarray, lo: float, hi: float) -> np.ndarray:
    arr = np.asarray(u8, dtype=np.float32)
    return arr / 255.0 * (hi - lo) + lo if hi > lo else arr


def _run_ncnn_preview(image: np.ndarray, scale: int, exe: Path, timeout_sec: int = 120) -> SuperResResult:
    """Run official Real-ESRGAN ncnn-vulkan executable on an 8-bit preview PNG.

    This path is intentionally marked as preview-only.  The output is mapped
    back to the original slice value range so the existing viewer renderer can
    display it, but it must not be used as diagnostic reconstruction.
    """
    try:
        from PIL import Image
    except Exception as exc:
        return SuperResResult(False, f"Pillow недоступний для Real-ESRGAN preview: {exc}", np.asarray(image), {"fallback": True})

    scale = 4 if int(scale) >= 4 else 2
    u8, lo, hi = _to_uint8(image)
    rgb = np.stack([u8, u8, u8], axis=-1)
    with tempfile.TemporaryDirectory(prefix="dicomview_realesrgan_") as td:
        tdp = Path(td)
        inp = tdp / "input.png"
        out = tdp / "output.png"
        Image.fromarray(rgb).save(inp)
        cmd = [str(exe), "-i", str(inp), "-o", str(out), "-n", "realesrgan-x4plus", "-s", str(scale)]
        proc = subprocess.run(
            cmd,
            cwd=str(exe.parent),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
        if proc.returncode != 0 or not out.exists():
            msg = (proc.stdout or "").strip()[-1200:]
            raise RuntimeError(f"Real-ESRGAN ncnn-vulkan failed, code={proc.returncode}: {msg}")
        out_img = Image.open(out).convert("L")
        res = _from_uint8(np.asarray(out_img, dtype=np.uint8), lo, hi)
        return SuperResResult(
            True,
            f"Real-ESRGAN ncnn-vulkan AI Zoom x{scale} preview виконано. Preview enhancement — не для діагностики.",
            res.astype(np.float32),
            {"engine": "realesrgan-ncnn-vulkan", "exe": str(exe), "scale": scale, "fallback": False, "diagnostic": False},
        )


def superres_slice(image: np.ndarray, scale: int = 2, model_path: str | Path | None = None, prefer_external: bool = True) -> SuperResResult:
    """Super-resolution preview for the active 2D slice.

    Order:
    1) Official Real-ESRGAN ncnn-vulkan executable if copied to
       _internal/tools/realesrgan.
    2) Optional experimental ONNX model in _internal/models/superres.
    3) Safe Lanczos fallback.
    """
    scale = 4 if int(scale) >= 4 else 2

    if prefer_external:
        exe = find_realesrgan_ncnn()
        if exe is not None:
            try:
                return _run_ncnn_preview(image, scale, exe)
            except Exception as exc:
                # Continue to ONNX/fallback, but keep the external error visible.
                external_error = str(exc)
        else:
            external_error = "realesrgan-ncnn-vulkan executable not found"
    else:
        external_error = "external engine disabled"

    p = Path(model_path) if model_path else find_model_path("superres", [f"realesrgan_x{scale}.onnx", "realesrgan_x2.onnx"])
    if p.exists() and onnxruntime_available():
        try:
            out = run_single_input_model(p, image)
            res = np.squeeze(out).astype(np.float32)
            return SuperResResult(
                True,
                "Real-ESRGAN/ONNX preview виконано. Preview enhancement — не для діагностики.",
                res,
                {"engine": "onnxruntime", "model": str(p), "scale": scale, "fallback": False, "diagnostic": False},
            )
        except Exception as exc:
            res = _fallback_upscale(image, scale)
            return SuperResResult(
                True,
                f"Real-ESRGAN external/ONNX не запустився, safe preview fallback: external={external_error}; onnx={exc}",
                res,
                {"model": str(p), "external_error": external_error, "fallback": True, "diagnostic": False},
            )

    res = _fallback_upscale(image, scale)
    why = "модель не знайдена" if not p.exists() else "onnxruntime не встановлено"
    return SuperResResult(
        True,
        f"AI Zoom x{scale} safe preview ({why}; external={external_error}). Preview enhancement — не для діагностики.",
        res,
        {"model": str(p), "external_error": external_error, "fallback": True, "diagnostic": False},
    )


def realesrgan_status() -> dict:
    exe = find_realesrgan_ncnn()
    return {
        "ncnn_vulkan_exe": str(exe) if exe else None,
        "tool_search_dirs": [str(p) for p in _candidate_tool_dirs()],
        "copy_target": str(app_base_dir() / "_internal" / "tools" / "realesrgan"),
        "note": "Скопіюйте realesrgan-ncnn-vulkan.exe та файли models/*.bin/*.param з офіційного release у _internal/tools/realesrgan. Використовується тільки як preview/enhancement, не для діагностики.",
    }
