from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class RadiomicsSummary:
    available: bool
    message: str
    features: dict[str, float | int | str]


def basic_radiomics(volume: np.ndarray, mask: np.ndarray | None = None, spacing=(1.0,1.0,1.0)) -> RadiomicsSummary:
    arr = np.asarray(volume, dtype=np.float32)
    if mask is not None:
        m = np.asarray(mask, dtype=bool)
        if m.shape != arr.shape:
            return RadiomicsSummary(False, 'Маска не відповідає розміру обсягу', {})
        vox = arr[m]
    else:
        vox = arr[np.isfinite(arr)]
    if vox.size == 0:
        return RadiomicsSummary(False, 'Немає вокселів для аналізу', {})
    sp = tuple(float(x) for x in spacing)
    voxel_ml = (sp[0]*sp[1]*sp[2]) / 1000.0
    hist, _ = np.histogram(vox, bins=64)
    prob = hist.astype(np.float64) / max(1, hist.sum())
    entropy = float(-(prob[prob>0] * np.log2(prob[prob>0])).sum())
    feats: dict[str, float | int | str] = {
        'count': int(vox.size), 'volume_ml': float(vox.size * voxel_ml),
        'mean': float(np.mean(vox)), 'min': float(np.min(vox)), 'max': float(np.max(vox)),
        'std': float(np.std(vox)), 'p10': float(np.percentile(vox, 10)), 'p50': float(np.percentile(vox, 50)), 'p90': float(np.percentile(vox, 90)),
        'histogram_entropy': entropy,
        'engine': 'basic_numpy'
    }
    return RadiomicsSummary(True, 'Basic radiomics розраховано', feats)


def pyradiomics_available() -> bool:
    try:
        import radiomics  # type: ignore  # noqa: F401
        return True
    except Exception:
        return False
