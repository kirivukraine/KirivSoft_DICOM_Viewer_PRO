from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
from typing import Any

import numpy as np


@dataclass
class SlicerBridgeResult:
    ok: bool
    message: str
    path: str = ""
    details: dict[str, Any] | None = None


@dataclass
class SlicerBridgeConfig:
    slicer_exe: str = ""
    work_dir: str = ""
    anonymize_export: bool = False


def _app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        try:
            return Path(sys.executable).resolve().parent
        except Exception:
            pass
    return Path.cwd()


def _bundled_internal_dirs() -> list[Path]:
    roots: list[Path] = []
    mei = getattr(sys, "_MEIPASS", None)
    if mei:
        roots.append(Path(mei))

    base = _app_base_dir()
    roots.extend([
        base / "_internal",
        base.parent / "_internal",
        Path.cwd() / "_internal",
    ])

    out: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        key = str(root).lower()
        if key not in seen:
            seen.add(key)
            out.append(root)
    return out


def _slicer_exe_candidates_from_folder(folder: Path) -> list[Path]:
    return [
        folder / "Slicer.exe",
        folder / "Slicer",
        folder / "bin" / "Slicer.exe",
        folder / "bin" / "Slicer",
    ]


def _candidate_paths() -> list[Path]:
    candidates: list[Path] = []
    for key in ("SLICER_EXE", "SLICER_PATH", "SLICER_HOME", "THREED_SLICER_HOME"):
        value = os.environ.get(key, "").strip().strip('"')
        if value:
            p = Path(value)
            if p.is_dir():
                candidates.extend(_slicer_exe_candidates_from_folder(p))
            else:
                candidates.append(p)

    for internal in _bundled_internal_dirs():
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "slicer"))
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "3D Slicer"))
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "3D Slicer 5.10.0"))
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "tools" / "3d-slicer"))
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "tools" / "slicer"))
        candidates.extend(_slicer_exe_candidates_from_folder(internal / "3d-slicer"))

    local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
    if local_appdata:
        local_slicer_org = Path(local_appdata) / "slicer.org"
        try:
            for folder in local_slicer_org.glob("3D Slicer*"):
                candidates.extend(_slicer_exe_candidates_from_folder(folder))
            for folder in local_slicer_org.glob("Slicer*"):
                candidates.extend(_slicer_exe_candidates_from_folder(folder))
        except Exception:
            pass

    if os.name == "nt":
        bases = [Path(os.environ.get("ProgramFiles", r"C:\Program Files")), Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))]
        patterns = ["3D Slicer*", "Slicer*"]
        for base in bases:
            for pat in patterns:
                try:
                    for folder in base.glob(pat):
                        candidates.extend(_slicer_exe_candidates_from_folder(folder))
                except Exception:
                    pass
    else:
        for name in ("Slicer", "slicer", "SlicerApp-real"):
            found = shutil.which(name)
            if found:
                candidates.append(Path(found))
    # keep order, unique
    out: list[Path] = []
    seen: set[str] = set()
    for p in candidates:
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def find_slicer() -> SlicerBridgeResult:
    for path in _candidate_paths():
        try:
            if path.exists() and path.is_file():
                return SlicerBridgeResult(True, "3D Slicer знайдено", str(path), {"candidates": [str(p) for p in _candidate_paths()]})
        except Exception:
            continue
    return SlicerBridgeResult(False, "3D Slicer не знайдено. Вкажіть шлях до Slicer.exe вручну.", "", {"candidates": [str(p) for p in _candidate_paths()]})


def _nrrd_type(dtype: np.dtype) -> str:
    dt = np.dtype(dtype)
    if dt == np.uint8:
        return "uint8"
    if dt == np.int16:
        return "short"
    if dt == np.uint16:
        return "ushort"
    if dt == np.int32:
        return "int"
    if dt == np.float32:
        return "float"
    if dt == np.float64:
        return "double"
    return "short"


def export_volume_nrrd(volume: np.ndarray, spacing_zyx: tuple[float, float, float], out_path: str | Path, metadata: dict[str, Any] | None = None) -> SlicerBridgeResult:
    """Write a simple single-file NRRD readable by 3D Slicer.

    Internal volume is Z,Y,X. NRRD data is written as X,Y,Z with correct spacing.
    """
    try:
        arr = np.asarray(volume)
        if arr.ndim != 3:
            return SlicerBridgeResult(False, f"NRRD експорт підтримує тільки 3D volume, отримано shape={arr.shape}")
        if arr.dtype not in (np.uint8, np.int16, np.uint16, np.int32, np.float32, np.float64):
            arr = arr.astype(np.int16)
        out = Path(out_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        z, y, x = arr.shape
        sz, sy, sx = spacing_zyx
        nrrd_arr = np.ascontiguousarray(arr.transpose(2, 1, 0))
        header = (
            "NRRD0005\n"
            "# Created by DicomView PRO KirivSoft Slicer Bridge\n"
            f"type: {_nrrd_type(nrrd_arr.dtype)}\n"
            "dimension: 3\n"
            f"sizes: {x} {y} {z}\n"
            f"space directions: ({sx},0,0) (0,{sy},0) (0,0,{sz})\n"
            "kinds: domain domain domain\n"
            "encoding: raw\n"
            "endian: little\n"
            "space origin: (0,0,0)\n"
            "\n"
        ).encode("ascii")
        with out.open("wb") as f:
            f.write(header)
            f.write(nrrd_arr.tobytes(order="C"))
        sidecar = out.with_suffix(out.suffix + ".json")
        try:
            sidecar.write_text(json.dumps(metadata or {}, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        return SlicerBridgeResult(True, "NRRD експортовано для 3D Slicer", str(out), {"shape_zyx": list(arr.shape), "spacing_zyx": list(spacing_zyx), "sidecar": str(sidecar)})
    except Exception as exc:
        return SlicerBridgeResult(False, "NRRD export error: " + str(exc))


def export_mask_nrrd(mask: np.ndarray, spacing_zyx: tuple[float, float, float], out_path: str | Path) -> SlicerBridgeResult:
    try:
        arr = (np.asarray(mask) > 0).astype(np.uint8)
        return export_volume_nrrd(arr, spacing_zyx, out_path, {"kind": "segmentation_mask"})
    except Exception as exc:
        return SlicerBridgeResult(False, "Mask NRRD export error: " + str(exc))


def launch_slicer(slicer_exe: str | Path, files: list[str | Path], wait: bool = False) -> SlicerBridgeResult:
    try:
        exe = Path(str(slicer_exe).strip().strip('"'))
        if not exe.exists():
            return SlicerBridgeResult(False, f"Slicer.exe не знайдено: {exe}")
        args = [str(exe)] + [str(Path(f)) for f in files if str(f)]
        proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if wait:
            code = proc.wait()
            return SlicerBridgeResult(code == 0, f"3D Slicer завершився з кодом {code}", details={"args": args, "code": code})
        return SlicerBridgeResult(True, "3D Slicer запущено", details={"args": args, "pid": proc.pid})
    except Exception as exc:
        return SlicerBridgeResult(False, "Launch Slicer error: " + str(exc))


def create_slicer_bridge_script(out_path: str | Path | None = None) -> SlicerBridgeResult:
    """Create the helper script executed inside 3D Slicer's own Python runtime."""
    try:
        if out_path is None:
            out_path = default_work_dir() / "dicomview_slicer_bridge.py"
        out = Path(out_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        script = r'''
# DicomView PRO -> 3D Slicer Bridge
# Run with: Slicer.exe --python-script dicomview_slicer_bridge.py manifest.json
import json
import os
import sys

result = {"ok": False, "message": "Slicer bridge started", "loaded": []}

try:
    import slicer  # type: ignore
    from DICOMLib import DICOMUtils  # type: ignore
except Exception as exc:
    result["message"] = "This script must run inside 3D Slicer: " + str(exc)
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0)


def _load_dicom(path):
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    with DICOMUtils.TemporaryDICOMDatabase() as db:
        DICOMUtils.importDicom(path, db)
        patient_uids = db.patients()
        loaded = 0
        for patient_uid in patient_uids:
            loaded += int(bool(DICOMUtils.loadPatientByUID(patient_uid)))
        return {"patients": list(patient_uids), "loaded": loaded}


def _load_volume(path):
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    node = None
    if path.lower().endswith(".seg.nrrd"):
        try:
            node = slicer.util.loadSegmentation(path)
        except Exception:
            node = None
    if node is None:
        node = slicer.util.loadVolume(path)
    return getattr(node, "GetName", lambda: str(path))()


def _first_volume_node():
    try:
        nodes = slicer.util.getNodesByClass("vtkMRMLScalarVolumeNode")
        return nodes[0] if nodes else None
    except Exception:
        return None


def _open_segment_editor():
    slicer.util.selectModule("SegmentEditor")
    volume_node = _first_volume_node()
    seg_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLSegmentationNode", "DicomView_SEG")
    seg_node.CreateDefaultDisplayNodes()
    if volume_node is not None:
        seg_node.SetReferenceImageGeometryParameterFromVolumeNode(volume_node)
    try:
        editor = slicer.modules.segmenteditor.widgetRepresentation().self()
        editor.setSegmentationNode(seg_node)
        if volume_node is not None:
            editor.setMasterVolumeNode(volume_node)
    except Exception as exc:
        result["segment_editor_warning"] = str(exc)
    return {"segmentation": seg_node.GetName(), "master_volume": volume_node.GetName() if volume_node else ""}


try:
    manifest_path = sys.argv[1] if len(sys.argv) > 1 else ""
    if not manifest_path:
        raise RuntimeError("Manifest path argument is missing")
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    command = manifest.get("command", "load")
    dicom_path = manifest.get("dicom_path") or manifest.get("source")
    volume_nrrd = manifest.get("volume_nrrd")
    mask_nrrd = manifest.get("mask_nrrd")
    output_dir = manifest.get("output_dir") or os.path.dirname(manifest_path)
    os.makedirs(output_dir, exist_ok=True)

    if dicom_path:
        result["loaded"].append({"dicom": _load_dicom(dicom_path)})
    if volume_nrrd:
        result["loaded"].append({"volume": _load_volume(volume_nrrd)})
    if mask_nrrd:
        result["loaded"].append({"mask": _load_volume(mask_nrrd)})

    if command in ("segment_editor", "export_models"):
        result["segment_editor"] = _open_segment_editor()

    result["ok"] = True
    result["message"] = "DicomView bridge payload loaded in 3D Slicer"
    result["output_dir"] = output_dir
    result_path = os.path.join(output_dir, "slicer_bridge_result.json")
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
except Exception as exc:
    result["message"] = "Slicer bridge error: " + str(exc)

print(json.dumps(result, ensure_ascii=False))
'''.lstrip()
        out.write_text(script, encoding="utf-8")
        return SlicerBridgeResult(True, "Slicer bridge script created", str(out), {"mode": "slicer-python"})
    except Exception as exc:
        return SlicerBridgeResult(False, "Slicer bridge script error: " + str(exc))


def run_slicer_script(
    slicer_exe: str | Path,
    script_path: str | Path,
    args: list[str | Path] | None = None,
    wait: bool = False,
) -> SlicerBridgeResult:
    try:
        exe = Path(str(slicer_exe).strip().strip('"'))
        script = Path(script_path)
        if not exe.exists():
            return SlicerBridgeResult(False, f"Slicer.exe не знайдено: {exe}")
        if not script.exists():
            return SlicerBridgeResult(False, f"Slicer bridge script не знайдено: {script}")
        cmd = [str(exe), "--python-script", str(script)] + [str(a) for a in (args or [])]
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if wait:
            code = proc.wait()
            return SlicerBridgeResult(code == 0, f"3D Slicer bridge завершився з кодом {code}", str(script), {"args": cmd, "code": code})
        return SlicerBridgeResult(True, "3D Slicer bridge запущено", str(script), {"args": cmd, "pid": proc.pid})
    except Exception as exc:
        return SlicerBridgeResult(False, "Run Slicer script error: " + str(exc))


def launch_bridge_payload(
    slicer_exe: str | Path,
    payload: dict[str, Any],
    wait: bool = False,
) -> SlicerBridgeResult:
    try:
        work = Path(payload.get("work_dir") or default_work_dir())
        output_dir = Path(payload.get("output_dir") or (work / "results"))
        output_dir.mkdir(parents=True, exist_ok=True)
        payload = {**payload, "output_dir": str(output_dir)}
        manifest = write_bridge_manifest(work, payload)
        script_res = create_slicer_bridge_script(work / "dicomview_slicer_bridge.py")
        if not script_res.ok:
            return script_res
        run_res = run_slicer_script(slicer_exe, script_res.path, [manifest], wait=wait)
        run_res.details = {
            **(run_res.details or {}),
            "manifest": str(manifest),
            "output_dir": str(output_dir),
            "payload": payload,
        }
        return run_res
    except Exception as exc:
        return SlicerBridgeResult(False, "Launch Slicer bridge payload error: " + str(exc))


def send_dicom_series(slicer_exe: str | Path, dicom_path: str | Path, command: str = "load", wait: bool = False) -> SlicerBridgeResult:
    p = Path(dicom_path)
    if not p.exists():
        return SlicerBridgeResult(False, "Файл/папка DICOM не існує: " + str(p))
    return launch_bridge_payload(slicer_exe, {"command": command, "dicom_path": str(p), "source": str(p)}, wait=wait)


def open_folder_in_slicer(slicer_exe: str | Path, folder_or_file: str | Path) -> SlicerBridgeResult:
    p = Path(folder_or_file)
    if not p.exists():
        return SlicerBridgeResult(False, "Файл/папка DICOM не існує: " + str(p))
    return launch_slicer(slicer_exe, [p])


def write_bridge_manifest(work_dir: str | Path, payload: dict[str, Any]) -> Path:
    wd = Path(work_dir)
    wd.mkdir(parents=True, exist_ok=True)
    path = wd / "slicer_bridge_manifest.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def default_work_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", tempfile.gettempdir())) / "KirivSoft" / "DicomViewPRO" / "slicer_bridge"
    base.mkdir(parents=True, exist_ok=True)
    return base
