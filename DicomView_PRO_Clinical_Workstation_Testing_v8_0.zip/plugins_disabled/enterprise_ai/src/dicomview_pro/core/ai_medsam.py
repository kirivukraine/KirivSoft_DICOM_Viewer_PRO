from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from .ai_models import find_model_path

@dataclass
class SegmentResult:
    ok: bool
    message: str
    mask2d: np.ndarray | None = None
    details: dict | None = None


def fallback_click_region(image: np.ndarray, x: int | None = None, y: int | None = None) -> np.ndarray:
    arr = np.asarray(image, dtype=np.float32)
    if arr.ndim != 2:
        arr = np.squeeze(arr)
        if arr.ndim != 2:
            raise ValueError("fallback_click_region очікує 2D-зріз")
    h, w = arr.shape
    cx = int(np.clip(w // 2 if x is None else x, 0, w - 1))
    cy = int(np.clip(h // 2 if y is None else y, 0, h - 1))
    seed = float(arr[cy, cx])
    local = arr[max(0, cy-24):min(h, cy+25), max(0, cx-24):min(w, cx+25)]
    tol = max(15.0, float(np.std(local)) * 2.75)
    yy, xx = np.ogrid[:h, :w]
    radius = max(16, min(h, w) // 9)
    near = (xx - cx) ** 2 + (yy - cy) ** 2 <= radius ** 2
    intensity = np.abs(arr - seed) <= tol
    return np.logical_and(intensity, near).astype(bool)

# Backward-compatible private name used by older code/tests.
_fallback_click_region = fallback_click_region


def mobile_sam_segment_slice(image: np.ndarray, x: int | None = None, y: int | None = None, model_path: str | Path | None = None, window_center: float | None = None, window_width: float | None = None) -> SegmentResult:
    p = Path(model_path) if model_path else find_model_path("segmentation", ["sam_mask_decoder_single.onnx", "mobile_sam.onnx", "sam_mask_decoder_multi.onnx", "medsam.onnx"])
    xx = int(x if x is not None else np.asarray(image).shape[1] // 2)
    yy = int(y if y is not None else np.asarray(image).shape[0] // 2)
    try:
        from .sam_preprocess import mobile_sam_onnx_segment
        mask, details = mobile_sam_onnx_segment(image, xx, yy, p, window_center=window_center, window_width=window_width)
        return SegmentResult(True, "MobileSAM ONNX inference виконано", mask.astype(bool), details)
    except Exception as exc:
        mask = fallback_click_region(image, xx, yy)
        why = str(exc)
        return SegmentResult(True, f"AI Segment safe fallback: {why}", mask, {"model": str(p), "fallback": True, "reason": why})
