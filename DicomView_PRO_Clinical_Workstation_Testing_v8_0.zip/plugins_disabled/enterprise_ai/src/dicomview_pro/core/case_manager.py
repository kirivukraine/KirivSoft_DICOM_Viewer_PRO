from __future__ import annotations
from pathlib import Path
from typing import Any
import json, sqlite3, datetime

class CaseManager:
    """Small local SQLite case index for DicomView PRO.

    It stores metadata and source path only, not PixelData.
    """
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self):
        return sqlite3.connect(str(self.db_path))

    def _init_db(self) -> None:
        with self._connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS cases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                patient_name TEXT,
                patient_id TEXT,
                modality TEXT,
                series_description TEXT,
                series_uid TEXT,
                source_path TEXT,
                notes TEXT
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_cases_patient ON cases(patient_name, patient_id)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_cases_series ON cases(series_uid)")

    def add_from_metadata(self, metadata: dict[str, Any], source_path: str = "", notes: str = "") -> int:
        tags = metadata.get('tags', {}) if isinstance(metadata.get('tags', {}), dict) else {}
        patient_name = str(metadata.get('patient_name') or tags.get('PatientName') or tags.get('(0010,0010)') or '')
        patient_id = str(metadata.get('patient_id') or tags.get('PatientID') or tags.get('(0010,0020)') or '')
        modality = str(metadata.get('modality') or tags.get('Modality') or '')
        series_description = str(metadata.get('series_description') or tags.get('SeriesDescription') or '')
        series_uid = str(metadata.get('series_uid') or tags.get('SeriesInstanceUID') or '')
        created_at = datetime.datetime.now().isoformat(timespec='seconds')
        with self._connect() as con:
            cur = con.execute("""INSERT INTO cases(created_at, patient_name, patient_id, modality, series_description, series_uid, source_path, notes)
                VALUES(?,?,?,?,?,?,?,?)""", (created_at, patient_name, patient_id, modality, series_description, series_uid, source_path, notes))
            return int(cur.lastrowid)

    def list_cases(self, limit: int = 200) -> list[dict[str, Any]]:
        with self._connect() as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("SELECT * FROM cases ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
            return [dict(r) for r in rows]

    def search(self, query: str, limit: int = 200) -> list[dict[str, Any]]:
        q = f"%{query}%"
        with self._connect() as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("""SELECT * FROM cases WHERE patient_name LIKE ? OR patient_id LIKE ? OR series_description LIKE ? OR modality LIKE ?
                ORDER BY id DESC LIMIT ?""", (q,q,q,q,int(limit))).fetchall()
            return [dict(r) for r in rows]

    def export_json(self, out_path: str | Path) -> str:
        out = Path(out_path)
        out.write_text(json.dumps(self.list_cases(10000), ensure_ascii=False, indent=2), encoding='utf-8')
        return str(out)
