from __future__ import annotations

"""Executable TotalSegmentator organ pipeline for DicomView PRO.

Dependency policy:
- The main viewer can import this file without TotalSegmentator installed.
- Heavy packages are imported only inside the worker functions.
- Every stage reports progress and raises clear RuntimeError messages.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Iterable, Sequence
import json
import os
import shutil
import subprocess
import sys
import time

from dicomview_pro.ai.external_runtime import build_totalseg_external_command, find_totalsegmentator_runtime

from .organ_segmentation_foundation import (
    DEFAULT_ROIS,
    ORGAN_COLORS,
    build_organ_segmentation_plan,
    discover_organ_meshes,
    normalize_roi_list,
    organ_ai_status,
)

ProgressCallback = Callable[[int, str], None]
CancelCallback = Callable[[], bool]


@dataclass(frozen=True)
class OrganSegmentationResult:
    ok: bool
    work_dir: str
    nifti_path: str
    masks_dir: str
    mesh_dir: str
    rois: list[str]
    mesh_files: list[dict]
    log_path: str
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


class OrganSegmentationCancelled(RuntimeError):
    pass


def _emit(cb: ProgressCallback | None, value: int, message: str) -> None:
    if cb is not None:
        cb(max(0, min(100, int(value))), str(message))


def _cancelled(cb: CancelCallback | None) -> bool:
    try:
        return bool(cb()) if cb is not None else False
    except Exception:
        return False


def _check_cancel(cb: CancelCallback | None) -> None:
    if _cancelled(cb):
        raise OrganSegmentationCancelled("Organ segmentation cancelled by user")


def _write_log(log_path: Path, text: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", errors="replace") as f:
        f.write(text.rstrip() + "\n")


def _find_nifti_file(folder: Path) -> Path:
    candidates = sorted(list(folder.glob("*.nii.gz")) + list(folder.glob("*.nii")), key=lambda p: p.stat().st_mtime, reverse=True)
    if not candidates:
        raise RuntimeError(f"DICOM→NIfTI conversion finished but no .nii/.nii.gz file was found in {folder}")
    return candidates[0]


def convert_dicom_to_nifti(
    dicom_folder: str | os.PathLike[str],
    output_nifti_path: str | os.PathLike[str],
    *,
    progress: ProgressCallback | None = None,
    cancel: CancelCallback | None = None,
) -> Path:
    """Convert one DICOM series/folder to NIfTI using optional dicom2nifti."""
    _check_cancel(cancel)
    dicom = Path(dicom_folder)
    out = Path(output_nifti_path)
    if not dicom.exists():
        raise FileNotFoundError(f"DICOM folder does not exist: {dicom}")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp_dir = out.parent / "_dicom2nifti_tmp"
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir, ignore_errors=True)
    tmp_dir.mkdir(parents=True, exist_ok=True)

    _emit(progress, 12, "Конвертація DICOM у NIfTI...")
    try:
        import dicom2nifti  # type: ignore
        # reorient=True keeps TotalSegmentator anatomical expectations stable.
        dicom2nifti.convert_directory(str(dicom), str(tmp_dir), compression=True, reorient=True)
    except ImportError as exc:
        raise RuntimeError("dicom2nifti не встановлено. Встановіть optional runtime: pip install dicom2nifti") from exc
    except Exception as exc:
        raise RuntimeError(f"DICOM→NIfTI conversion failed: {exc}") from exc

    _check_cancel(cancel)
    found = _find_nifti_file(tmp_dir)
    if out.exists():
        out.unlink()
    shutil.move(str(found), str(out))
    shutil.rmtree(tmp_dir, ignore_errors=True)
    _emit(progress, 25, f"NIfTI готовий: {out.name}")
    return out


def run_totalsegmentator(
    nifti_path: str | os.PathLike[str],
    masks_dir: str | os.PathLike[str],
    *,
    rois: Sequence[str] | None = None,
    fast: bool = True,
    progress: ProgressCallback | None = None,
    cancel: CancelCallback | None = None,
    log_path: str | os.PathLike[str] | None = None,
) -> Path:
    """Run TotalSegmentator in a subprocess so the GUI remains protected."""
    _check_cancel(cancel)
    rt = find_totalsegmentator_runtime()
    if not rt.ok:
        raise RuntimeError(rt.message)

    nifti = Path(nifti_path)
    out = Path(masks_dir)
    out.mkdir(parents=True, exist_ok=True)
    roi_list = normalize_roi_list(rois)
    cmd = build_totalseg_external_command(
        nifti,
        out,
        rois=roi_list,
        fast=fast,
        device="cpu",
        output_type="nifti",
    )

    log_file = Path(log_path) if log_path else out.parent / "organ_segmentation.log"
    _write_log(log_file, "[TotalSegmentator] " + " ".join(cmd))
    _emit(progress, 30, "Запуск TotalSegmentator у фоновому процесі...")

    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )

    last_tick = time.monotonic()
    pseudo = 32
    assert process.stdout is not None
    for line in process.stdout:
        _write_log(log_file, line)
        if _cancelled(cancel):
            try:
                process.terminate()
            except Exception:
                pass
            raise OrganSegmentationCancelled("TotalSegmentator cancelled by user")
        now = time.monotonic()
        if now - last_tick > 1.2:
            pseudo = min(72, pseudo + 1)
            _emit(progress, pseudo, "TotalSegmentator працює: " + line.strip()[:160])
            last_tick = now

    code = process.wait()
    if code != 0:
        raise RuntimeError(f"TotalSegmentator failed with exit code {code}. Дивіться лог: {log_file}")
    _emit(progress, 75, "Маски органів готові.")
    return out


def mask_to_meshes(
    masks_dir: str | os.PathLike[str],
    mesh_dir: str | os.PathLike[str],
    *,
    formats: Iterable[str] = ("stl", "ply", "obj"),
    progress: ProgressCallback | None = None,
    cancel: CancelCallback | None = None,
) -> list[dict]:
    """Convert TotalSegmentator .nii/.nii.gz organ masks to STL/PLY/OBJ."""
    _check_cancel(cancel)
    try:
        import nibabel as nib  # type: ignore
        import numpy as np  # type: ignore
        from skimage import measure  # type: ignore
        import trimesh  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Для експорту STL/PLY/OBJ потрібні nibabel, scikit-image, trimesh") from exc

    src = Path(masks_dir)
    dst = Path(mesh_dir)
    dst.mkdir(parents=True, exist_ok=True)
    formats_clean = [f.lower().lstrip(".") for f in formats if f.lower().lstrip(".") in {"stl", "ply", "obj"}]
    if not formats_clean:
        formats_clean = ["stl"]

    masks = sorted(list(src.glob("*.nii.gz")) + list(src.glob("*.nii")))
    if not masks:
        raise RuntimeError(f"Не знайдено NIfTI-масок у {src}")

    exported: list[dict] = []
    total = max(1, len(masks))
    for i, mask_path in enumerate(masks, start=1):
        _check_cancel(cancel)
        organ = mask_path.name.replace(".nii.gz", "").replace(".nii", "")
        _emit(progress, 75 + int(20 * i / total), f"Генерація 3D-моделі: {organ}")
        img = nib.load(str(mask_path))
        data = img.get_fdata() > 0.5
        if not bool(data.any()):
            continue
        spacing = tuple(float(x) for x in img.header.get_zooms()[:3])
        verts, faces, normals, _ = measure.marching_cubes(data.astype("float32"), level=0.5, spacing=spacing)
        mesh = trimesh.Trimesh(vertices=verts, faces=faces, vertex_normals=normals, process=True)
        try:
            trimesh.repair.fix_normals(mesh)
        except Exception:
            pass
        for fmt in formats_clean:
            out = dst / f"{organ}.{fmt}"
            mesh.export(str(out))
            exported.append({
                "organ": organ,
                "path": str(out),
                "format": fmt,
                "vertices": int(len(verts)),
                "faces": int(len(faces)),
                "color": ORGAN_COLORS.get(organ, (0.75, 0.75, 0.75)),
                "visible": True,
            })
    _emit(progress, 96, "3D-моделі органів згенеровані.")
    return exported


def run_organ_segmentation_pipeline(
    dicom_folder: str | os.PathLike[str],
    work_dir: str | os.PathLike[str],
    *,
    rois: Sequence[str] | None = None,
    fast: bool = True,
    formats: Iterable[str] = ("stl", "ply", "obj"),
    progress: ProgressCallback | None = None,
    cancel: CancelCallback | None = None,
) -> OrganSegmentationResult:
    """Full pipeline: DICOM → NIfTI → TotalSegmentator → masks → STL/PLY/OBJ."""
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    log_path = work / "organ_segmentation_executor.log"
    if log_path.exists():
        log_path.unlink()
    roi_list = normalize_roi_list(rois)
    plan = build_organ_segmentation_plan(dicom_folder, work, rois=roi_list, fast=fast)
    (work / "organ_segmentation_plan.json").write_text(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    _emit(progress, 2, "Підготовка Organ Segmentation Executor...")
    status = organ_ai_status()
    _write_log(log_path, json.dumps(status.to_dict(), ensure_ascii=False, indent=2))
    if not (status.totalsegmentator and status.dicom2nifti and status.nibabel and status.skimage and status.trimesh):
        missing = [k for k, v in status.to_dict().items() if k in {"totalsegmentator", "dicom2nifti", "nibabel", "skimage", "trimesh"} and not v]
        raise RuntimeError("Organ AI runtime неповний. Немає: " + ", ".join(missing))

    nifti = convert_dicom_to_nifti(plan.dicom_folder, plan.nifti_path, progress=progress, cancel=cancel)
    masks = run_totalsegmentator(nifti, plan.masks_dir, rois=roi_list, fast=fast, progress=progress, cancel=cancel, log_path=log_path)
    mesh_files = mask_to_meshes(masks, plan.mesh_dir, formats=formats, progress=progress, cancel=cancel)
    # Prefer discover output for stable panel loading, but preserve metadata from conversion too.
    discovered = discover_organ_meshes(plan.mesh_dir)
    if discovered:
        mesh_files = discovered
    result = OrganSegmentationResult(
        ok=True,
        work_dir=plan.work_dir,
        nifti_path=str(nifti),
        masks_dir=str(masks),
        mesh_dir=plan.mesh_dir,
        rois=roi_list,
        mesh_files=mesh_files,
        log_path=str(log_path),
        message="Organ segmentation completed",
    )
    (work / "organ_segmentation_result.json").write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    _emit(progress, 100, "Готово: органи сегментовані і моделі відкриті для 3D-панелі.")
    return result
