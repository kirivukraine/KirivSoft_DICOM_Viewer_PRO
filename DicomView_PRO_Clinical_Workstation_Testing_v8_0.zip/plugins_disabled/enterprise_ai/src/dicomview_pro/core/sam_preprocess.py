from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from functools import lru_cache
import numpy as np

try:
    from PIL import Image
except Exception:  # Pillow is optional in the portable build
    Image = None  # type: ignore


@dataclass
class SAMInput:
    image_tensor: np.ndarray
    original_shape: tuple[int, int]
    target_size: int
    scale_x: float
    scale_y: float


@dataclass
class SAMEncoderInput:
    image_tensor: np.ndarray
    original_shape: tuple[int, int]
    resized_shape: tuple[int, int]
    target_size: int
    scale: float


def _resize_u8_rgb(img_rgb: np.ndarray, width: int, height: int) -> np.ndarray:
    if Image is not None:
        pil = Image.fromarray(img_rgb, mode="RGB")
        pil = pil.resize((int(width), int(height)), Image.Resampling.BILINEAR)
        return np.asarray(pil, dtype=np.uint8)
    h, w = img_rgb.shape[:2]
    yy = (np.linspace(0, h - 1, int(height))).astype(np.int64)
    xx = (np.linspace(0, w - 1, int(width))).astype(np.int64)
    return img_rgb[yy][:, xx]


def _window_to_u8(pixel_array: np.ndarray, window_center: float | None = None, window_width: float | None = None) -> np.ndarray:
    arr = np.asarray(pixel_array)
    if arr.ndim != 2:
        raise ValueError("MobileSAM очікує один 2D-зріз DICOM")
    src = arr.astype(np.float32, copy=False)
    if window_center is not None and window_width is not None and float(window_width) > 1e-6:
        lo = float(window_center) - float(window_width) / 2.0
        hi = float(window_center) + float(window_width) / 2.0
    else:
        lo, hi = np.percentile(src, [0.5, 99.5])
        if hi <= lo:
            lo, hi = float(np.min(src)), float(np.max(src))
    if hi <= lo:
        return np.zeros(src.shape, dtype=np.uint8)
    img = np.clip((src - lo) / (hi - lo), 0.0, 1.0)
    return (img * 255.0).astype(np.uint8)


def prepare_dicom_for_sam(pixel_array: np.ndarray, target_size: int = 1024, window_center: float | None = None, window_width: float | None = None) -> SAMInput:
    """Legacy square-stretch preprocessing for combined SAM ONNX variants."""
    img_u8 = _window_to_u8(pixel_array, window_center, window_width)
    img_rgb = np.repeat(img_u8[:, :, None], 3, axis=2)
    img_resized = _resize_u8_rgb(img_rgb, target_size, target_size)
    tensor = img_resized.astype(np.float32) / 255.0
    tensor = np.transpose(tensor, (2, 0, 1))[None, ...].astype(np.float32)
    h, w = img_u8.shape[:2]
    return SAMInput(tensor, (int(h), int(w)), int(target_size), target_size / max(float(w), 1.0), target_size / max(float(h), 1.0))


def prepare_dicom_for_sam_encoder(pixel_array: np.ndarray, target_size: int = 1024, window_center: float | None = None, window_width: float | None = None) -> SAMEncoderInput:
    """Prepare a DICOM slice for MobileSAM image_encoder.onnx.

    This follows the SAM/MobileSAM preprocessing idea more closely than the old
    square-stretch helper: resize the long side to 1024, pad the short side to a
    1024x1024 canvas, convert gray to RGB, and apply SAM ImageNet-style mean/std
    normalization.  Point coordinates are scaled by the same long-side factor.
    """
    img_u8 = _window_to_u8(pixel_array, window_center, window_width)
    h, w = img_u8.shape[:2]
    scale = float(target_size) / max(float(h), float(w), 1.0)
    new_h = max(1, int(round(h * scale)))
    new_w = max(1, int(round(w * scale)))
    img_rgb = np.repeat(img_u8[:, :, None], 3, axis=2)
    resized = _resize_u8_rgb(img_rgb, new_w, new_h).astype(np.float32)

    canvas = np.zeros((target_size, target_size, 3), dtype=np.float32)
    canvas[:new_h, :new_w, :] = resized

    mean = np.array([123.675, 116.28, 103.53], dtype=np.float32).reshape(1, 1, 3)
    std = np.array([58.395, 57.12, 57.375], dtype=np.float32).reshape(1, 1, 3)
    norm = (canvas - mean) / std
    tensor = np.transpose(norm, (2, 0, 1))[None, ...].astype(np.float32)
    return SAMEncoderInput(tensor, (int(h), int(w)), (int(new_h), int(new_w)), int(target_size), float(scale))


def resize_mask_to_original(mask: np.ndarray, original_shape: tuple[int, int]) -> np.ndarray:
    m = np.asarray(mask)
    if m.ndim > 2:
        m = np.squeeze(m)
        if m.ndim > 2:
            # Common multimask output: [num_masks, H, W]. Take the first mask.
            m = m[0]
    m = (m > 0).astype(np.uint8) * 255
    out_h, out_w = int(original_shape[0]), int(original_shape[1])
    if m.shape == (out_h, out_w):
        return m
    if Image is not None:
        pil = Image.fromarray(m, mode="L")
        pil = pil.resize((out_w, out_h), Image.Resampling.NEAREST)
        return np.asarray(pil, dtype=np.uint8)
    yy = (np.linspace(0, m.shape[0] - 1, out_h)).astype(np.int64)
    xx = (np.linspace(0, m.shape[1] - 1, out_w)).astype(np.int64)
    return m[yy][:, xx].astype(np.uint8)


def preferred_onnx_providers() -> list[str]:
    try:
        import onnxruntime as ort  # type: ignore
        available = set(ort.get_available_providers())
        order = ["CUDAExecutionProvider", "DmlExecutionProvider", "OpenVINOExecutionProvider", "CPUExecutionProvider"]
        providers = [x for x in order if x in available]
        return providers or list(available)
    except Exception:
        return []


def default_sam_encoder_path() -> Path:
    from .ai_models import find_model_path
    return find_model_path("segmentation", ["mobile_sam_image_encoder.onnx", "mobile_sam_encoder.onnx", "image_encoder.onnx"])


def default_sam_model_path() -> Path:
    from .ai_models import find_model_path
    return find_model_path("segmentation", ["sam_mask_decoder_single.onnx", "mobile_sam.onnx", "sam_mask_decoder_multi.onnx", "medsam.onnx"])


@lru_cache(maxsize=8)
def _cached_session(path_str: str, providers_key: tuple[str, ...]):
    import onnxruntime as ort  # type: ignore
    return ort.InferenceSession(path_str, providers=list(providers_key))


def _session(path: Path):
    try:
        import onnxruntime as ort  # noqa: F401  # type: ignore
    except Exception as exc:
        raise RuntimeError(f"onnxruntime не встановлено або не стартує: {exc}") from exc
    providers = tuple(preferred_onnx_providers() or ["CPUExecutionProvider"])
    return _cached_session(str(Path(path)), providers)


def clear_mobile_sam_session_cache() -> None:
    _cached_session.cache_clear()


def warm_mobile_sam_sessions() -> dict[str, Any]:
    """Load MobileSAM ONNX sessions once at startup so first click is faster.

    The function is safe: it returns a diagnostic dictionary instead of raising
    into the UI. It does not run a full segmentation; it only opens the ONNX
    sessions and records providers/inputs.
    """
    info: dict[str, Any] = {"ok": False, "encoder": None, "decoder": None, "providers": [], "message": ""}
    try:
        enc = default_sam_encoder_path()
        dec = default_sam_model_path()
        info["encoder"] = str(enc)
        info["decoder"] = str(dec)
        if not enc.exists():
            raise FileNotFoundError(f"encoder ONNX не знайдено: {enc}")
        if not dec.exists():
            raise FileNotFoundError(f"decoder ONNX не знайдено: {dec}")
        enc_s = _session(enc)
        dec_s = _session(dec)
        info["providers"] = {"encoder": enc_s.get_providers(), "decoder": dec_s.get_providers()}
        info["encoder_inputs"] = [i.name for i in enc_s.get_inputs()]
        info["decoder_inputs"] = [i.name for i in dec_s.get_inputs()]
        info["ok"] = True
        info["message"] = "MobileSAM ONNX sessions preloaded"
    except Exception as exc:
        info["message"] = str(exc)
    return info


def _shape_to_zeros(shape: list[Any], dtype=np.float32) -> np.ndarray:
    fixed = [1 if not isinstance(s, int) or s <= 0 else int(s) for s in list(shape)]
    return np.zeros(fixed if fixed else [1], dtype=dtype)


def _run_mobile_sam_encoder(pixel_array: np.ndarray, encoder_path: Path, target_size: int, window_center: float | None, window_width: float | None):
    enc_in = prepare_dicom_for_sam_encoder(pixel_array, target_size=target_size, window_center=window_center, window_width=window_width)
    sess = _session(encoder_path)
    feed: dict[str, np.ndarray] = {}
    for meta in sess.get_inputs():
        lname = meta.name.lower()
        if any(k in lname for k in ("image", "input", "x")):
            feed[meta.name] = enc_in.image_tensor
        else:
            feed[meta.name] = _shape_to_zeros(list(meta.shape))
    outputs = sess.run(None, feed)
    embeddings = np.asarray(outputs[0], dtype=np.float32)
    return embeddings, enc_in, {"encoder": str(encoder_path), "encoder_inputs": [i.name for i in sess.get_inputs()], "encoder_outputs": [o.name for o in sess.get_outputs()], "encoder_providers": sess.get_providers()}


def _run_mobile_sam_decoder(embeddings: np.ndarray, enc_in: SAMEncoderInput, decoder_path: Path, x: int, y: int):
    sess = _session(decoder_path)
    sx = float(np.clip(x, 0, enc_in.original_shape[1] - 1)) * enc_in.scale
    sy = float(np.clip(y, 0, enc_in.original_shape[0] - 1)) * enc_in.scale
    point_coords = np.array([[[sx, sy]]], dtype=np.float32)
    point_labels = np.array([[1]], dtype=np.float32)
    feed: dict[str, np.ndarray] = {}
    for meta in sess.get_inputs():
        name = meta.name
        lname = name.lower()
        shape = list(meta.shape)
        if "embedding" in lname:
            feed[name] = embeddings.astype(np.float32, copy=False)
        elif "point_coords" in lname or lname.endswith("coords"):
            feed[name] = point_coords
        elif "point_labels" in lname or lname.endswith("labels"):
            feed[name] = point_labels
        elif "mask_input" in lname or lname == "masks":
            feed[name] = np.zeros((1, 1, 256, 256), dtype=np.float32)
        elif "has_mask" in lname:
            feed[name] = np.zeros((1,), dtype=np.float32)
        elif "orig_im_size" in lname or "original_size" in lname:
            # SAM decoder expects original image size as [H, W].
            feed[name] = np.array([enc_in.original_shape[0], enc_in.original_shape[1]], dtype=np.float32)
        else:
            feed[name] = _shape_to_zeros(shape)
    outputs = sess.run(None, feed)
    raw = np.asarray(outputs[0])
    if raw.ndim >= 4:
        raw = raw[0, 0]
    elif raw.ndim == 3:
        raw = raw[0]
    mask = resize_mask_to_original(raw > 0.0, enc_in.original_shape)
    return mask, {"decoder": str(decoder_path), "decoder_inputs": [i.name for i in sess.get_inputs()], "decoder_outputs": [o.name for o in sess.get_outputs()], "decoder_providers": sess.get_providers(), "output_shape": list(np.asarray(outputs[0]).shape)}


def _run_combined_or_legacy_sam(pixel_array: np.ndarray, x: int, y: int, model_path: Path, target_size: int, window_center: float | None, window_width: float | None) -> tuple[np.ndarray, dict[str, Any]]:
    sam_in = prepare_dicom_for_sam(pixel_array, target_size=target_size, window_center=window_center, window_width=window_width)
    sess = _session(model_path)
    inputs_meta = sess.get_inputs()
    names = [i.name for i in inputs_meta]
    if any("embedding" in n.lower() for n in names) and not any(n.lower() in ("image", "images", "input", "x") for n in names):
        raise RuntimeError("Цей ONNX схожий на decoder-only модель і потребує image_encoder.onnx")

    sx = float(np.clip(x, 0, sam_in.original_shape[1] - 1)) * sam_in.scale_x
    sy = float(np.clip(y, 0, sam_in.original_shape[0] - 1)) * sam_in.scale_y
    point_coords = np.array([[[sx, sy]]], dtype=np.float32)
    point_labels = np.array([[1]], dtype=np.float32)
    feed: dict[str, np.ndarray] = {}
    for meta in inputs_meta:
        name = meta.name
        lname = name.lower()
        shape = list(meta.shape)
        if lname in ("images", "image", "input", "x") or ("image" in lname and "embedding" not in lname and "orig" not in lname):
            feed[name] = sam_in.image_tensor
        elif "point_coords" in lname or lname.endswith("coords"):
            feed[name] = point_coords
        elif "point_labels" in lname or lname.endswith("labels"):
            feed[name] = point_labels
        elif "mask_input" in lname or "low_res" in lname or lname == "masks":
            feed[name] = np.zeros((1, 1, 256, 256), dtype=np.float32)
        elif "has_mask" in lname:
            feed[name] = np.zeros((1,), dtype=np.float32)
        elif "orig_im_size" in lname or "original_size" in lname:
            feed[name] = np.array([target_size, target_size], dtype=np.float32)
        else:
            feed[name] = _shape_to_zeros(shape)
    outputs = sess.run(None, feed)
    raw = np.asarray(outputs[0])
    if raw.ndim >= 4:
        raw = raw[0, 0]
    elif raw.ndim == 3:
        raw = raw[0]
    mask = resize_mask_to_original(raw > 0.0, sam_in.original_shape)
    return mask, {"model": str(model_path), "providers": sess.get_providers(), "inputs": names, "output_shape": list(np.asarray(outputs[0]).shape), "target_size": target_size, "mode": "combined_or_legacy", "fallback": False}


def mobile_sam_onnx_segment(pixel_array: np.ndarray, x: int, y: int, model_path: str | Path | None = None, target_size: int = 1024, window_center: float | None = None, window_width: float | None = None) -> tuple[np.ndarray, dict[str, Any]]:
    """Run MobileSAM ONNX segmentation.

    Supported model layouts:
    1. Full recommended layout:
       segmentation/mobile_sam_image_encoder.onnx + segmentation/sam_mask_decoder_single.onnx
    2. Optional multimask decoder:
       segmentation/sam_mask_decoder_multi.onnx
    3. Legacy combined models that accept images/image + point inputs.

    Decoder-only files no longer fail when the encoder is present.  The function
    automatically runs encoder -> image_embeddings -> decoder.
    """
    p = Path(model_path) if model_path else default_sam_model_path()
    if not p.exists():
        raise FileNotFoundError(f"MobileSAM ONNX decoder/combined model не знайдено: {p}")

    # Inspect decoder/combined inputs once.  If the file expects embeddings, pair
    # it with mobile_sam_image_encoder.onnx from the same model roots.
    sess = _session(p)
    names = [i.name for i in sess.get_inputs()]
    del sess
    is_decoder = any("embedding" in n.lower() for n in names) and not any(n.lower() in ("image", "images", "input", "x") for n in names)
    if is_decoder:
        encoder_path = default_sam_encoder_path()
        if not encoder_path.exists():
            raise FileNotFoundError(f"MobileSAM decoder знайдено, але encoder відсутній: {encoder_path}")
        embeddings, enc_in, enc_details = _run_mobile_sam_encoder(pixel_array, encoder_path, target_size, window_center, window_width)
        mask, dec_details = _run_mobile_sam_decoder(embeddings, enc_in, p, x, y)
        details: dict[str, Any] = {
            "mode": "encoder_decoder",
            "model": "MobileSAM full ONNX",
            "encoder": str(encoder_path),
            "decoder": str(p),
            "original_shape": list(enc_in.original_shape),
            "resized_shape": list(enc_in.resized_shape),
            "target_size": target_size,
            "scale": enc_in.scale,
            "fallback": False,
        }
        details.update(enc_details)
        details.update(dec_details)
        return mask, details

    return _run_combined_or_legacy_sam(pixel_array, x, y, p, target_size, window_center, window_width)
