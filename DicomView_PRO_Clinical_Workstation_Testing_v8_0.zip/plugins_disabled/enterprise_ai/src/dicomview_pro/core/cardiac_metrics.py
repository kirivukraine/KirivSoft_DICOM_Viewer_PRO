from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class CardiacVolumeMetrics:
    ok: bool
    message: str
    edv_ml: float = 0.0
    esv_ml: float = 0.0
    sv_ml: float = 0.0
    ef_percent: float = 0.0
    frames: int = 0


def cardiac_volume_metrics(mask_4d: np.ndarray, spacing_zyx=(1.0,1.0,1.0)) -> CardiacVolumeMetrics:
    """Compute EDV/ESV/SV/EF from a time-series binary mask t,z,y,x.

    This is a foundation method, not a diagnostic auto-segmentation. The input
    mask should already describe the chamber/structure of interest.
    """
    arr = np.asarray(mask_4d).astype(bool)
    if arr.ndim != 4 or arr.shape[0] < 2:
        return CardiacVolumeMetrics(False, "Потрібна 4D маска формату t,z,y,x з мінімум двома фазами")
    voxel_ml = float(spacing_zyx[0] * spacing_zyx[1] * spacing_zyx[2] / 1000.0)
    volumes = arr.reshape(arr.shape[0], -1).sum(axis=1).astype(float) * voxel_ml
    edv = float(np.max(volumes))
    esv = float(np.min(volumes))
    sv = max(0.0, edv - esv)
    ef = float((sv / edv * 100.0) if edv > 0 else 0.0)
    return CardiacVolumeMetrics(True, "Кардіальні об'єми розраховані з готової 4D маски", edv, esv, sv, ef, int(arr.shape[0]))
