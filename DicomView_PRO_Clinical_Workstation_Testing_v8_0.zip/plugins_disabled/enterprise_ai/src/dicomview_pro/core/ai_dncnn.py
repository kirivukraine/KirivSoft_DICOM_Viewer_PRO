from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from .ai_models import find_model_path
from .ai_onnx import run_single_input_model, onnxruntime_available

@dataclass
class DenoiseResult:
    ok: bool
    message: str
    image2d: np.ndarray
    details: dict | None = None


def _fallback_denoise(image: np.ndarray, strength: str = "medium") -> np.ndarray:
    arr = np.asarray(image, dtype=np.float32)
    try:
        from scipy.ndimage import gaussian_filter  # type: ignore
        sigma = {"light": 0.6, "medium": 1.0, "strong": 1.45}.get(strength, 1.0)
        return gaussian_filter(arr, sigma=sigma)
    except Exception:
        # tiny numpy box blur fallback
        pad = np.pad(arr, 1, mode="edge")
        return (
            pad[:-2, :-2] + pad[:-2, 1:-1] + pad[:-2, 2:] +
            pad[1:-1, :-2] + pad[1:-1, 1:-1] + pad[1:-1, 2:] +
            pad[2:, :-2] + pad[2:, 1:-1] + pad[2:, 2:]
        ) / 9.0


def denoise_slice(image: np.ndarray, strength: str = "medium", model_path: str | Path | None = None) -> DenoiseResult:
    p = Path(model_path) if model_path else find_model_path("denoise", ["dncnn.onnx", "ffdnet.onnx"])
    if p.exists() and onnxruntime_available():
        try:
            out = run_single_input_model(p, image)
            res = np.squeeze(out).astype(np.float32)
            if res.shape != np.asarray(image).shape:
                res = _fallback_denoise(image, strength)
            return DenoiseResult(True, "DnCNN/ONNX denoise виконано", res, {"model": str(p), "fallback": False})
        except Exception as exc:
            res = _fallback_denoise(image, strength)
            return DenoiseResult(True, f"DnCNN ONNX не запустився, safe fallback: {exc}", res, {"model": str(p), "fallback": True})
    res = _fallback_denoise(image, strength)
    why = "модель не знайдена" if not p.exists() else "onnxruntime не встановлено"
    return DenoiseResult(True, f"AI Denoise safe fallback ({why})", res, {"model": str(p), "fallback": True})
