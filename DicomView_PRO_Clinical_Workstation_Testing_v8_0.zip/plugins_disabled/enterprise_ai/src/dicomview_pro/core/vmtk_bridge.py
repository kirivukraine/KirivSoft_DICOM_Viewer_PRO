from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from dicomview_pro.runtime.runtime_paths import data_dir
from dicomview_pro.core.slicer_bridge import find_slicer


@dataclass
class VmtkBridgeResult:
    ok: bool
    message: str
    path: str = ""
    details: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def vmtk_available_in_python() -> bool:
    try:
        import vmtk  # noqa: F401
        return True
    except Exception:
        return False


def create_vmtk_slicer_script(out_path: str | Path | None = None) -> VmtkBridgeResult:
    """Create a helper Python script that can be run inside 3D Slicer.

    DicomView PRO does not redistribute VMTK. VMTK is expected to be installed
    in 3D Slicer as the SlicerVMTK extension. This script is intentionally a
    safe bridge/foundation: it opens the volume/model in Slicer and prepares a
    place for VMTK centerline extraction. If the extension is not available,
    the script exits gracefully instead of crashing DicomView PRO.
    """
    try:
        if out_path is None:
            out_path = data_dir() / "slicer_bridge" / "dicomview_vmtk_bridge.py"
        out = Path(out_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        script = r'''
# DicomView PRO -> 3D Slicer VMTK bridge helper
# Run with: Slicer.exe --python-script dicomview_vmtk_bridge.py
import json
import os
import sys

result = {"ok": False, "message": "VMTK bridge started", "loaded": []}
try:
    import slicer  # type: ignore
    result["slicer"] = True
except Exception as exc:
    result["message"] = "This script must run inside 3D Slicer: " + str(exc)
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0)

# SlicerVMTK extension check. Module names differ by Slicer/VMTK version.
possible_modules = ["ExtractCenterline", "CenterlineComputation", "VMTKCenterlines"]
available = []
for name in possible_modules:
    try:
        if hasattr(slicer.modules, name.lower()):
            available.append(name)
    except Exception:
        pass

result["vmtk_modules"] = available
if not available:
    result["message"] = "SlicerVMTK extension not found. Install SlicerVMTK in 3D Slicer Extension Manager."
else:
    result["ok"] = True
    result["message"] = "SlicerVMTK detected. Use Segment Editor / Extract Centerline inside Slicer, then export STL/OBJ/PLY back to DicomView PRO."

print(json.dumps(result, ensure_ascii=False))
'''.lstrip()
        out.write_text(script, encoding="utf-8")
        return VmtkBridgeResult(True, "VMTK bridge script created", str(out), {"mode": "slicer-extension"})
    except Exception as exc:
        return VmtkBridgeResult(False, "VMTK bridge script error: " + str(exc))


def run_vmtk_bridge_in_slicer(slicer_exe: str | Path | None = None) -> VmtkBridgeResult:
    """Launch 3D Slicer with the generated VMTK bridge script.

    This is a safe external integration. It never imports VTK/VMTK into the main
    DicomView process, so old hospital PCs do not crash if Slicer/VMTK is absent.
    """
    try:
        if slicer_exe is None or not str(slicer_exe).strip():
            found = find_slicer()
            if not found.ok or not found.path:
                return VmtkBridgeResult(False, "3D Slicer не знайдено. Встановіть 3D Slicer або вкажіть шлях до Slicer.exe.", details=found.details)
            slicer_exe = found.path
        exe = Path(slicer_exe)
        if not exe.exists():
            return VmtkBridgeResult(False, "Slicer.exe не знайдено: " + str(exe))
        script_res = create_vmtk_slicer_script()
        if not script_res.ok:
            return script_res
        proc = subprocess.Popen([str(exe), "--python-script", script_res.path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return VmtkBridgeResult(True, "3D Slicer запущено з VMTK bridge helper", str(script_res.path), {"pid": proc.pid})
    except Exception as exc:
        return VmtkBridgeResult(False, "VMTK/Slicer launch error: " + str(exc))
