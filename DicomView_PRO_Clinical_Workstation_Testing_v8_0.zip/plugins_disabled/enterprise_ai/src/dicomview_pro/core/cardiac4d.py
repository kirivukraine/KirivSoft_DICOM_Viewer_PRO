from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class Cardiac4DInfo:
    ok: bool
    message: str
    frames: int = 0
    fps: float = 0.0
    shape: tuple = ()
    is_volume_time_series: bool = False


def inspect_4d(volume: np.ndarray, metadata: dict) -> Cardiac4DInfo:
    vol = np.asarray(volume)
    fps = float(metadata.get('cine_fps', 0.0) or 0.0)
    modality = str(metadata.get('modality','')).upper()
    if vol.ndim == 3 and modality in ('XA','XRF','US'):
        return Cardiac4DInfo(True, 'Виявлено cine/multi-frame послідовність', int(vol.shape[0]), fps, tuple(vol.shape), False)
    if vol.ndim == 4:
        return Cardiac4DInfo(True, 'Виявлено 4D обсяг t,z,y,x', int(vol.shape[0]), fps, tuple(vol.shape), True)
    return Cardiac4DInfo(False, '4D/cine дані не виявлені або серія є звичайним 3D CT/MR', int(vol.shape[0]) if vol.ndim>=3 else 0, fps, tuple(vol.shape), False)


def get_time_frame(volume: np.ndarray, frame: int) -> np.ndarray:
    vol = np.asarray(volume)
    if vol.ndim == 4:
        return vol[int(np.clip(frame, 0, vol.shape[0]-1))]
    if vol.ndim == 3:
        return vol[int(np.clip(frame, 0, vol.shape[0]-1))]
    raise ValueError('Непідтримуваний формат 4D/cine')
