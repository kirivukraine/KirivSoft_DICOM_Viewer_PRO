from __future__ import annotations
from dataclasses import dataclass
import importlib.util
import numpy as np
from .ai_engine import ai_engine_status

@dataclass
class AIResult:
    ok: bool
    message: str
    mask: np.ndarray | None = None
    details: dict | None = None


def monai_available() -> bool:
    return importlib.util.find_spec('monai') is not None


def torch_available() -> bool:
    return importlib.util.find_spec('torch') is not None


def ai_environment() -> dict:
    status = ai_engine_status()
    base = {'monai': monai_available(), 'torch': torch_available(), 'mode': 'MONAI optional; safe fallback available'}
    base.update(status.environment)
    base['models_dir'] = status.models.get('models_dir')
    return base


def fallback_lung_mask(volume: np.ndarray) -> AIResult:
    vol = np.asarray(volume)
    if vol.ndim != 3:
        return AIResult(False, 'AI fallback потребує 3D CT обсяг')
    mask = np.logical_and(vol >= -1000, vol <= -350)
    if int(mask.sum()) == 0:
        return AIResult(False, 'Fallback lung mask порожній', mask, {'voxels':0})
    return AIResult(True, 'Fallback lung segmentation виконано без MONAI', mask, {'voxels': int(mask.sum())})


def fallback_bone_mask(volume: np.ndarray) -> AIResult:
    vol = np.asarray(volume)
    if vol.ndim != 3:
        return AIResult(False, 'AI fallback потребує 3D CT обсяг')
    mask = vol >= 300
    return AIResult(bool(mask.any()), 'Fallback bone segmentation виконано без MONAI', mask, {'voxels': int(mask.sum())})
