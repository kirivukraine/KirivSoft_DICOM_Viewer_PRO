from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np

@dataclass
class VesselAnalysisResult:
    ok: bool
    message: str
    voxel_count: int = 0
    volume_ml: float = 0.0
    projected_area_mm2: float = 0.0
    estimated_centerline_length_mm: float = 0.0
    mean_intensity_hu: float = 0.0
    max_intensity_hu: float = 0.0
    min_intensity_hu: float = 0.0
    min_diameter_mm: float = 0.0
    max_diameter_mm: float = 0.0
    mean_diameter_mm: float = 0.0
    estimated_stenosis_percent: float = 0.0
    notes: str = ""


def _voxel_volume_ml(spacing_zyx: tuple[float, float, float]) -> float:
    return float(spacing_zyx[0] * spacing_zyx[1] * spacing_zyx[2] / 1000.0)


def threshold_vessels(volume: np.ndarray, min_hu: float = 180.0, max_hu: float = 1200.0) -> np.ndarray:
    vol = np.asarray(volume)
    return np.logical_and(vol >= min_hu, vol <= max_hu)


def _safe_diameter_estimates(mask: np.ndarray, spacing_zyx: tuple[float, float, float]) -> tuple[float, float, float, float]:
    """Fallback vessel diameter proxy per slice.

    It estimates an equivalent circular diameter from connected foreground area
    in each non-empty slice. This is safe on old PCs and does not require scipy.
    """
    yz_area = float(spacing_zyx[1] * spacing_zyx[2])
    diameters = []
    for sl in mask:
        a = float(np.count_nonzero(sl) * yz_area)
        if a > 0:
            diameters.append(2.0 * math.sqrt(a / math.pi))
    if not diameters:
        return 0.0, 0.0, 0.0, 0.0
    mn, mx, mean = min(diameters), max(diameters), sum(diameters) / len(diameters)
    stenosis = 0.0
    if mx > 0:
        stenosis = max(0.0, min(100.0, (1.0 - mn / mx) * 100.0))
    return float(mn), float(mx), float(mean), float(stenosis)


def estimate_centerline_length(mask: np.ndarray, spacing_zyx=(1.0,1.0,1.0)) -> float:
    """Conservative centerline length foundation.

    If scikit-image is available, skeletonize the maximum projection. Otherwise
    use bounding-box diagonal as a safe approximate path length.
    """
    m = np.asarray(mask).astype(bool)
    if m.ndim != 3 or not m.any():
        return 0.0
    spacing = tuple(float(x) for x in spacing_zyx)
    try:
        from skimage.morphology import skeletonize  # type: ignore
        proj = m.max(axis=0)
        skel = skeletonize(proj)
        return float(np.count_nonzero(skel) * min(spacing[1], spacing[2]))
    except Exception:
        coords = np.argwhere(m)
        z0, y0, x0 = coords.min(axis=0)
        z1, y1, x1 = coords.max(axis=0)
        dz = (z1 - z0 + 1) * spacing[0]
        dy = (y1 - y0 + 1) * spacing[1]
        dx = (x1 - x0 + 1) * spacing[2]
        return float(math.sqrt(dx*dx + dy*dy + dz*dz))


def analyze_vessels(volume: np.ndarray, spacing_zyx=(1.0,1.0,1.0), min_hu: float = 180.0, max_hu: float = 1200.0) -> VesselAnalysisResult:
    vol = np.asarray(volume)
    if vol.ndim != 3 or vol.size == 0:
        return VesselAnalysisResult(False, "Немає 3D-обсягу для аналізу судин")
    mask = threshold_vessels(vol, min_hu, max_hu)
    count = int(mask.sum())
    if count == 0:
        return VesselAnalysisResult(False, "Судинна маска порожня. Спробуйте зменшити нижній HU-поріг.")
    spacing = tuple(float(x) for x in spacing_zyx)
    volume_ml = count * _voxel_volume_ml(spacing)
    proj = mask.max(axis=0)
    projected_area_mm2 = float(proj.sum() * spacing[1] * spacing[2])
    vals = vol[mask]
    min_d, max_d, mean_d, stenosis = _safe_diameter_estimates(mask, spacing)
    return VesselAnalysisResult(
        True,
        "Базовий Vessel Analysis PRO виконано у safe/fallback режимі",
        voxel_count=count,
        volume_ml=float(volume_ml),
        projected_area_mm2=projected_area_mm2,
        estimated_centerline_length_mm=estimate_centerline_length(mask, spacing),
        mean_intensity_hu=float(np.mean(vals)),
        max_intensity_hu=float(np.max(vals)),
        min_intensity_hu=float(np.min(vals)),
        min_diameter_mm=min_d,
        max_diameter_mm=max_d,
        mean_diameter_mm=mean_d,
        estimated_stenosis_percent=stenosis,
        notes="Foundation-модуль: safe diameter/stenosis proxy. Для діагностики потрібна клінічна валідація.",
    )


def vessel_mip(volume: np.ndarray, min_hu: float = 180.0) -> np.ndarray:
    vol = np.asarray(volume)
    masked = np.where(vol >= min_hu, vol, vol.min() if vol.size else 0)
    return np.max(masked, axis=0)
