from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib, json, os, sys
from typing import Any

MODEL_CATEGORIES = {
    "segmentation": ["mobile_sam_image_encoder.onnx", "sam_mask_decoder_single.onnx", "sam_mask_decoder_multi.onnx", "mobile_sam.onnx", "medsam.onnx"],
    "denoise": ["dncnn.onnx", "ffdnet.onnx"],
    "superres": ["realesrgan_x2.onnx", "realesrgan_x4.onnx", "realesrgan_x2plus.onnx", "realesrgan_x4plus.onnx"],
    "monai": ["lung.onnx", "liver.onnx", "spleen.onnx", "brain.onnx"],
}

@dataclass(frozen=True)
class ModelInfo:
    category: str
    name: str
    path: str
    exists: bool
    size_mb: float = 0.0
    sha256_12: str = ""
    source: str = "primary"


def project_root() -> Path:
    # src/dicomview_pro/core/ai_models.py -> project root in source mode
    return Path(__file__).resolve().parents[3]


def app_base_dir() -> Path:
    """Return the folder that contains the EXE in portable mode, or the source root.

    PyInstaller one-dir with ``--contents-directory _internal`` exposes bundled
    files through ``sys._MEIPASS`` (usually ``.../DicomView_PRO/_internal``),
    while the EXE itself is one directory higher.  We support both layouts.
    """
    if getattr(sys, "frozen", False):
        try:
            return Path(sys.executable).resolve().parent
        except Exception:
            pass
    return project_root()


def bundled_internal_dir() -> Path | None:
    p = getattr(sys, "_MEIPASS", None)
    if p:
        return Path(p).resolve()
    candidate = app_base_dir() / "_internal"
    return candidate.resolve() if candidate.exists() else None


def model_roots() -> list[Path]:
    """Ordered model search paths.

    1. DICOMVIEW_MODELS_DIR, if the user set it.
    2. Portable PyInstaller folder: ``_internal/models``.
    3. Source/developer portable template: ``./_internal/models``.
    4. Legacy source path: ``./models``.
    5. EXE-near fallback: ``./models``.
    """
    roots: list[Path] = []
    env = os.environ.get("DICOMVIEW_MODELS_DIR")
    if env:
        roots.append(Path(env).expanduser())

    internal = bundled_internal_dir()
    if internal is not None:
        roots.append(internal / "models")

    base = app_base_dir()
    roots.append(base / "_internal" / "models")
    roots.append(project_root() / "_internal" / "models")
    roots.append(project_root() / "models")
    roots.append(base / "models")

    out: list[Path] = []
    seen: set[str] = set()
    for r in roots:
        rr = r.resolve()
        key = str(rr).lower()
        if key not in seen:
            seen.add(key)
            out.append(rr)
    return out


def default_models_dir() -> Path:
    # Preferred writable/copy target.  In the portable build this is
    # DicomView_PRO/_internal/models, exactly where the user asked to copy ONNX.
    return model_roots()[0]


def ensure_model_dirs(base: Path | None = None) -> Path:
    root = (base or default_models_dir()).resolve()
    for category in MODEL_CATEGORIES:
        (root / category).mkdir(parents=True, exist_ok=True)
    return root


def ensure_all_model_dirs() -> Path:
    root = ensure_model_dirs(default_models_dir())
    write_model_readme(root)
    return root


def _sha12(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def _scan_root(root: Path, source: str) -> list[ModelInfo]:
    root = root.resolve()
    items: list[ModelInfo] = []
    for category, names in MODEL_CATEGORIES.items():
        seen: set[str] = set()
        folder = root / category
        for name in names:
            p = folder / name
            seen.add(name.lower())
            if p.exists():
                items.append(ModelInfo(category, name, str(p), True, p.stat().st_size / (1024 * 1024), _sha12(p), source))
            else:
                items.append(ModelInfo(category, name, str(p), False, source=source))
        if folder.exists():
            for p in sorted(folder.glob("*.onnx")):
                if p.name.lower() in seen:
                    continue
                items.append(ModelInfo(category, p.name, str(p), True, p.stat().st_size / (1024 * 1024), _sha12(p), source))
    return items


def scan_models(base: Path | None = None) -> list[ModelInfo]:
    if base is not None:
        return _scan_root(ensure_model_dirs(base), "custom")

    # Create the preferred _internal/models folder, then also show legacy roots
    # if models are present there.  Missing placeholders are shown only for the
    # preferred root to avoid a noisy manager window.
    primary = ensure_model_dirs(default_models_dir())
    items = _scan_root(primary, "primary")
    primary_key = str(primary).lower()
    existing_names = {(i.category, i.name.lower()) for i in items if i.exists}
    for idx, root in enumerate(model_roots()[1:], start=1):
        if str(root).lower() == primary_key or not root.exists():
            continue
        for it in _scan_root(root, f"fallback_{idx}"):
            if not it.exists:
                continue
            key = (it.category, it.name.lower())
            if key not in existing_names:
                items.append(it)
                existing_names.add(key)
    return items


def find_model_path(category: str, names: str | list[str]) -> Path:
    if isinstance(names, str):
        names = [names]
    for root in model_roots():
        for name in names:
            p = root / category / name
            if p.exists():
                return p.resolve()
    # Return preferred target for clear error messages and easy copy-paste path.
    return default_models_dir() / category / names[0]


def model_report(base: Path | None = None) -> dict[str, Any]:
    root = ensure_model_dirs(base) if base is not None else ensure_all_model_dirs()
    models = scan_models(root if base is not None else None)
    return {
        "models_dir": str(root),
        "portable_copy_target": str(root),
        "search_roots": [str(p) for p in model_roots()],
        "note": "Скопіюйте .onnx у _internal/models/<категорія>. Програма працює без моделей у safe fallback-режимі.",
        "models": [asdict(m) for m in models],
    }


def write_model_readme(base: Path | None = None) -> Path:
    root = ensure_model_dirs(base)
    readme = root / "README_MODELS_UA.txt"
    readme.write_text(
        "DicomView PRO AI Models\n"
        "========================\n\n"
        "КУДИ КОПІЮВАТИ МОДЕЛІ У PORTABLE-ЗБІРЦІ:\n"
        "  DicomView_PRO\\_internal\\models\\segmentation\\mobile_sam.onnx\n\n"
        "Папки для локальних моделей:\n"
        "- segmentation/mobile_sam.onnx або medsam.onnx\n"
        "- denoise/dncnn.onnx або ffdnet.onnx\n"
        "- superres/realesrgan_x2.onnx або realesrgan_x4.onnx\n"
        "- external Real-ESRGAN: _internal/tools/realesrgan/realesrgan-ncnn-vulkan.exe + models/*.bin/*.param\n"
        "- monai/*.onnx для медичних органних моделей\n\n"
        "Моделі НЕ вшиті в архів, бо вони великі й мають окремі ліцензії.\n"
        "Програма працює без цих файлів у safe fallback-режимі.\n"
        "Для ONNX inference рекомендовано встановити: onnxruntime або onnxruntime-gpu.\n"
        "Real-ESRGAN використовуйте тільки як preview/enhancement, не як діагностичну реконструкцію.\n",
        encoding="utf-8",
    )
    return readme
