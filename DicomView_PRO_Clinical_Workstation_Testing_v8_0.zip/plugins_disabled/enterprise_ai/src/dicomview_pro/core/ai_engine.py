from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import importlib.util
from .ai_models import model_report, write_model_readme
from .ai_onnx import onnx_status

@dataclass
class AIEngineStatus:
    ok: bool
    environment: dict[str, Any]
    models: dict[str, Any]


def package_available(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def ai_engine_status() -> AIEngineStatus:
    write_model_readme()
    st = onnx_status()
    env = {
        "onnxruntime": st.available,
        "onnx_providers": st.providers,
        "onnx_message": st.message,
        "torch": package_available("torch"),
        "monai": package_available("monai"),
        "scipy": package_available("scipy"),
        "pillow": package_available("PIL"),
        "mode": "Local AI: ONNX/PyTorch optional, safe fallback завжди доступний",
    }
    return AIEngineStatus(True, env, model_report())
