from __future__ import annotations

from pathlib import Path
import numpy as np
from PySide6.QtCore import QThread, Signal

from .ai_medsam import fallback_click_region, SegmentResult
from .sam_preprocess import mobile_sam_onnx_segment, default_sam_model_path


class MobileSAMWorker(QThread):
    """Asynchronous MobileSAM click segmentation worker.

    It keeps the PySide6/VTK UI responsive. If the ONNX model or runtime is
    missing, it emits a safe fallback mask instead of raising into the GUI loop.
    """
    segmentation_success = Signal(object)
    segmentation_failed = Signal(str)

    def __init__(self, pixel_array: np.ndarray, click_x: int, click_y: int, model_path: str | Path | None = None, window_center: float | None = None, window_width: float | None = None, parent=None):
        super().__init__(parent)
        self.pixel_array = np.asarray(pixel_array)
        self.click_x = int(click_x)
        self.click_y = int(click_y)
        self.model_path = Path(model_path) if model_path else default_sam_model_path()
        self.window_center = window_center
        self.window_width = window_width

    def run(self):
        try:
            try:
                mask, details = mobile_sam_onnx_segment(self.pixel_array, self.click_x, self.click_y, self.model_path, window_center=self.window_center, window_width=self.window_width)
                self.segmentation_success.emit(SegmentResult(True, "MobileSAM ONNX: інтерактивна сегментація виконана", mask.astype(bool), details))
            except Exception as exc:
                mask = fallback_click_region(self.pixel_array, self.click_x, self.click_y)
                self.segmentation_success.emit(SegmentResult(True, f"MobileSAM недоступний, застосовано safe fallback: {exc}", mask.astype(bool), {"model": str(self.model_path), "fallback": True, "reason": str(exc)}))
        except Exception as exc:
            self.segmentation_failed.emit(str(exc))
