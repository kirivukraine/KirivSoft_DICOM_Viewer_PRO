from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from .radiomics_base import basic_radiomics, pyradiomics_available


@dataclass(frozen=True)
class RadiomicsPROResult:
    ok: bool
    message: str
    features: dict[str, Any]
    engine: str


def analyze_roi_or_mask(volume: np.ndarray, mask: np.ndarray | None = None, spacing=(1.0,1.0,1.0)) -> RadiomicsPROResult:
    """Stable radiomics wrapper.

    Uses PyRadiomics only as optional future backend; current safe path is a
    deterministic NumPy feature set that cannot crash when PyRadiomics is absent.
    """
    base = basic_radiomics(volume, mask, spacing)
    if not base.available:
        return RadiomicsPROResult(False, base.message, base.features, "none")
    feats = dict(base.features)
    # Extra lightweight descriptors useful in reports and QA.
    vals = np.asarray(volume, dtype=np.float32)
    if mask is not None:
        vals = vals[np.asarray(mask, dtype=bool)]
    vals = vals[np.isfinite(vals)]
    if vals.size:
        q25, q75 = np.percentile(vals, [25, 75])
        feats["iqr"] = float(q75 - q25)
        feats["range"] = float(np.max(vals) - np.min(vals))
        feats["pyradiomics_available"] = bool(pyradiomics_available())
    return RadiomicsPROResult(True, "Radiomics PRO базовий аналіз виконано", feats, "numpy_safe")
