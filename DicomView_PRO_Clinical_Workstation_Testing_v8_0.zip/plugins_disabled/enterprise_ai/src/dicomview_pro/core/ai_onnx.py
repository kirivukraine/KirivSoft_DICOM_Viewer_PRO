from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import importlib.util
from typing import Any
import numpy as np

@dataclass
class OnnxStatus:
    available: bool
    providers: list[str]
    message: str


def onnxruntime_available() -> bool:
    return importlib.util.find_spec("onnxruntime") is not None


def onnx_status() -> OnnxStatus:
    if not onnxruntime_available():
        return OnnxStatus(False, [], "onnxruntime не встановлено; активний safe fallback")
    try:
        import onnxruntime as ort  # type: ignore
        return OnnxStatus(True, list(ort.get_available_providers()), "onnxruntime готовий")
    except Exception as exc:
        return OnnxStatus(False, [], f"onnxruntime знайдено, але не стартує: {exc}")


def normalize_2d_for_ai(image: np.ndarray, size: tuple[int, int] | None = None) -> np.ndarray:
    arr = np.asarray(image, dtype=np.float32)
    if arr.ndim != 2:
        raise ValueError("Очікується 2D зріз для AI inference")
    lo, hi = np.percentile(arr, [0.5, 99.5])
    if hi <= lo:
        lo, hi = float(arr.min()), float(arr.max())
    if hi <= lo:
        return np.zeros_like(arr, dtype=np.float32)
    arr = np.clip((arr - lo) / (hi - lo), 0.0, 1.0)
    if size is not None and tuple(arr.shape[::-1]) != tuple(size):
        try:
            from PIL import Image
            arr = np.asarray(Image.fromarray((arr * 255).astype(np.uint8)).resize(size), dtype=np.float32) / 255.0
        except Exception:
            pass
    return arr.astype(np.float32)


def run_single_input_model(model_path: str | Path, image: np.ndarray, providers: list[str] | None = None) -> np.ndarray:
    if not onnxruntime_available():
        raise RuntimeError("onnxruntime не встановлено")
    import onnxruntime as ort  # type: ignore
    sess = ort.InferenceSession(str(model_path), providers=providers or ort.get_available_providers())
    inp = sess.get_inputs()[0]
    shape = list(inp.shape)
    arr = normalize_2d_for_ai(image)
    # Support common NCHW / NHWC / HW model inputs.
    if len(shape) == 4:
        if shape[1] in (1, 3, "1", "3"):
            if shape[1] in (3, "3"):
                x = np.stack([arr, arr, arr], axis=0)[None, ...]
            else:
                x = arr[None, None, ...]
        else:
            x = arr[None, ..., None]
    elif len(shape) == 3:
        x = arr[None, ...]
    else:
        x = arr.astype(np.float32)
    out = sess.run(None, {inp.name: x.astype(np.float32)})[0]
    return np.asarray(out)
