from __future__ import annotations

"""Optional Organ Segmentation Foundation utilities.

This module is intentionally dependency-light.  It exposes a stable interface
for DicomView PRO to discover whether TotalSegmentator/dicom2nifti/nibabel are
available and to prepare command lines / local output folders without making the
main viewer depend on multi-GB AI stacks.  The heavy execution can be enabled by
installing the optional plugin/runtime.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence
import importlib.util
import json
import os
import sys

DEFAULT_ROIS: tuple[str, ...] = (
    "heart",
    "liver",
    "kidney_left",
    "kidney_right",
    "spleen",
    "lung_upper_left",
    "lung_lower_left",
    "lung_upper_right",
    "lung_middle_right",
    "lung_lower_right",
    "trachea",
    "urinary_bladder",
)

ORGAN_COLORS: dict[str, tuple[float, float, float]] = {
    "heart": (0.95, 0.05, 0.08),
    "liver": (0.55, 0.22, 0.12),
    "kidney_left": (0.55, 0.12, 0.75),
    "kidney_right": (0.55, 0.12, 0.75),
    "spleen": (0.35, 0.18, 0.85),
    "lung_upper_left": (0.95, 0.55, 0.70),
    "lung_lower_left": (0.95, 0.55, 0.70),
    "lung_upper_right": (0.95, 0.55, 0.70),
    "lung_middle_right": (0.95, 0.55, 0.70),
    "lung_lower_right": (0.95, 0.55, 0.70),
    "trachea": (0.20, 0.85, 0.95),
    "urinary_bladder": (0.20, 0.45, 0.95),
    "bone": (0.93, 0.90, 0.82),
}


@dataclass(frozen=True)
class OptionalOrganAIStatus:
    totalsegmentator: bool
    dicom2nifti: bool
    nibabel: bool
    skimage: bool
    trimesh: bool
    torch: bool
    python: str
    mode: str
    message: str
    supported_rois: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class OrganSegmentationPlan:
    dicom_folder: str
    work_dir: str
    nifti_path: str
    masks_dir: str
    mesh_dir: str
    rois: list[str]
    fast: bool
    command: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def _has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def organ_ai_status() -> OptionalOrganAIStatus:
    ts = _has_module("totalsegmentator")
    d2n = _has_module("dicom2nifti")
    nib = _has_module("nibabel")
    ski = _has_module("skimage")
    tri = _has_module("trimesh")
    torch = _has_module("torch")
    ready = ts and d2n and nib and ski and tri
    msg = (
        "Organ Segmentation PRO ready: TotalSegmentator runtime found."
        if ready else
        "Organ Segmentation PRO optional runtime is not fully installed; viewer remains in safe fallback."
    )
    return OptionalOrganAIStatus(
        totalsegmentator=ts,
        dicom2nifti=d2n,
        nibabel=nib,
        skimage=ski,
        trimesh=tri,
        torch=torch,
        python=sys.executable,
        mode="optional_plugin" if ready else "safe_fallback",
        message=msg,
        supported_rois=list(DEFAULT_ROIS),
    )


def normalize_roi_list(rois: Iterable[str] | None = None) -> list[str]:
    if rois is None:
        return list(DEFAULT_ROIS)
    cleaned: list[str] = []
    for item in rois:
        name = str(item).strip()
        if not name:
            continue
        if name not in cleaned:
            cleaned.append(name)
    return cleaned or list(DEFAULT_ROIS)


def build_organ_segmentation_plan(
    dicom_folder: str | os.PathLike[str],
    work_dir: str | os.PathLike[str],
    *,
    rois: Sequence[str] | None = None,
    fast: bool = True,
) -> OrganSegmentationPlan:
    dicom = Path(dicom_folder)
    work = Path(work_dir)
    roi_list = normalize_roi_list(rois)
    nifti_path = work / "input_ct.nii.gz"
    masks_dir = work / "organ_masks"
    mesh_dir = work / "organ_meshes"
    cmd = [
        sys.executable,
        "-m",
        "totalsegmentator",
        "-i",
        str(nifti_path),
        "-o",
        str(masks_dir),
        "--roi_subset",
        *roi_list,
    ]
    if fast:
        cmd.append("--fast")
    return OrganSegmentationPlan(
        dicom_folder=str(dicom),
        work_dir=str(work),
        nifti_path=str(nifti_path),
        masks_dir=str(masks_dir),
        mesh_dir=str(mesh_dir),
        rois=roi_list,
        fast=bool(fast),
        command=cmd,
    )


def write_plan_manifest(plan: OrganSegmentationPlan, path: str | os.PathLike[str]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def discover_organ_meshes(mesh_dir: str | os.PathLike[str]) -> list[dict]:
    root = Path(mesh_dir)
    found: list[dict] = []
    for ext in ("*.stl", "*.ply", "*.obj"):
        for p in sorted(root.glob(ext)):
            organ = p.stem
            found.append({
                "organ": organ,
                "path": str(p),
                "color": ORGAN_COLORS.get(organ, (0.75, 0.75, 0.75)),
                "visible": True,
            })
    return found


def mask_nifti_to_stl(mask_path: str | os.PathLike[str], stl_path: str | os.PathLike[str]) -> dict:
    """Convert one binary NIfTI organ mask to STL when optional deps exist.

    The affine scaling is approximated by nibabel's zooms for stable real-size
    output.  If optional dependencies are missing, a clear RuntimeError is
    raised instead of crashing the GUI.
    """
    if not (_has_module("nibabel") and _has_module("skimage") and _has_module("trimesh")):
        raise RuntimeError("nibabel, scikit-image and trimesh are required for mask-to-STL export")
    import nibabel as nib  # type: ignore
    from skimage import measure  # type: ignore
    import trimesh  # type: ignore
    import numpy as np

    img = nib.load(str(mask_path))
    data = img.get_fdata() > 0.5
    if not bool(data.any()):
        raise ValueError(f"Mask is empty: {mask_path}")
    spacing = tuple(float(x) for x in img.header.get_zooms()[:3])
    verts, faces, normals, _ = measure.marching_cubes(data.astype("float32"), level=0.5, spacing=spacing)
    mesh = trimesh.Trimesh(vertices=verts, faces=faces, vertex_normals=normals, process=True)
    out = Path(stl_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    mesh.export(str(out))
    return {"ok": True, "path": str(out), "vertices": int(len(verts)), "faces": int(len(faces)), "spacing": spacing}
