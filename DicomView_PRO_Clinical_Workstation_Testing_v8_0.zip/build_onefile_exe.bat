@echo off
echo One-file build is disabled for DicomView PRO Lite because PySide6/VTK are more stable in portable onedir mode.
echo Use build_portable.bat.
pause
exit /b 0
