# DicomView PRO — DICOM Fidelity / Viewer Quality Hotfix

Виправлення після аудиту якості 2D:

- PyInstaller build scripts явно включають `PIL` / Pillow: `--collect-submodules PIL`, `--collect-data PIL`.
- Якщо обрано Lanczos, програма більше не має тихо втрачати якість через відсутній Pillow у portable bundle.
- `ImageLabel._widget_to_image()` більше не виконує повторний expensive resize при кожному кліку миші; координати беруться з кешованого останнього розміру/зсуву.
- `auto_window()` тепер підтримує різні percentile-вікна.
- Для MR/US/NM пріоритетно використовуються DICOM WindowCenter/WindowWidth; fallback: MR p2..p98, US/NM p5..p95.
- `diagnostic_content_bbox()` отримав адаптивний поріг замість жорсткого `img > 4`, щоб не обрізати темні MR/US/NM області.

Мета: стабільніша якість 2D, кращий fit-to-view і менше артефактів при масштабуванні.
