from pathlib import Path
import numpy as np
import pydicom
from pydicom.dataset import Dataset, FileDataset
from pydicom.uid import ExplicitVRLittleEndian, generate_uid
import datetime

out = Path('test_dicom_series'); out.mkdir(exist_ok=True)
study_uid = generate_uid(); series_uid = generate_uid()
for i in range(16):
    meta = Dataset(); meta.MediaStorageSOPClassUID = pydicom.uid.CTImageStorage; meta.MediaStorageSOPInstanceUID = generate_uid(); meta.TransferSyntaxUID = ExplicitVRLittleEndian
    ds = FileDataset(str(out/f'slice_{i:03d}.dcm'), {}, file_meta=meta, preamble=b'\0'*128)
    ds.PatientName = 'KirivSoft^Test'; ds.PatientID='TEST001'; ds.Modality='CT'; ds.StudyInstanceUID=study_uid; ds.SeriesInstanceUID=series_uid
    ds.SeriesDescription='Synthetic CT Test'; ds.SOPClassUID=meta.MediaStorageSOPClassUID; ds.SOPInstanceUID=meta.MediaStorageSOPInstanceUID
    ds.InstanceNumber=i+1; ds.ImagePositionPatient=[0,0,float(i)]; ds.PixelSpacing=[1.0,1.0]; ds.SliceThickness=1.0
    ds.Rows=128; ds.Columns=128; ds.SamplesPerPixel=1; ds.PhotometricInterpretation='MONOCHROME2'; ds.BitsAllocated=16; ds.BitsStored=16; ds.HighBit=15; ds.PixelRepresentation=1
    y,x=np.ogrid[:128,:128]; arr=(((x-64)**2+(y-64)**2) < (20+i)**2).astype(np.int16)*800 - 500
    ds.PixelData=arr.tobytes(); ds.RescaleSlope=1; ds.RescaleIntercept=0; ds.ContentDate=datetime.date.today().strftime('%Y%m%d'); ds.ContentTime='120000'
    ds.save_as(out/f'slice_{i:03d}.dcm')
print(out.resolve())
