from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any


def _json_safe(value: Any) -> Any:
    try:
        import numpy as np
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        if isinstance(value, (np.ndarray,)):
            return value.tolist()
    except Exception:
        pass
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, list):
        return [_json_safe(x) for x in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    return value


def _prepare_input(input_path: Path, temp_root: Path) -> Path:
    if input_path.is_file() and input_path.suffix.lower() == ".zip":
        out = temp_root / "dicom_zip_extract"
        out.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(input_path, "r") as zf:
            zf.extractall(out)
        return out
    return input_path


def run_clinic_test(input_path: str | Path, output_path: str | Path | None = None, series_uid: str | None = None) -> dict[str, Any]:
    started = time.time()
    report: dict[str, Any] = {
        "tool": "DicomView PRO Clinic Test Harness",
        "status": "started",
        "input": str(input_path),
        "series_uid_requested": series_uid,
        "steps": [],
        "warnings": [],
        "errors": [],
    }
    temp_root = Path(tempfile.mkdtemp(prefix="dicomview_clinic_test_"))
    try:
        source = _prepare_input(Path(input_path), temp_root)
        report["prepared_input"] = str(source)

        from dicomview_pro.core.dicom_reader import scan_series, load_series_to_runtime
        from dicomview_pro.core.image_ops import auto_window, get_slice, projection, window_to_uint8
        from dicomview_pro.core.segmentation import segment_bones, segment_lungs, segment_vessels
        import numpy as np

        series = scan_series(source)
        report["series_count"] = len(series)
        report["series"] = [
            {
                "uid": s.uid,
                "description": s.description,
                "modality": s.modality,
                "patient": s.patient,
                "count": s.count,
                "is_cine": s.is_cine,
                "frames": s.frames,
                "fps": s.fps,
            }
            for s in series[:25]
        ]
        report["steps"].append("scan_series")
        if not series:
            raise RuntimeError("Не знайдено жодної DICOM-серії")

        selected_uid = series_uid or series[0].uid
        runtime_dir = temp_root / "runtime"
        loaded = load_series_to_runtime(source, runtime_dir, selected_uid)
        report["selected_series"] = {
            "uid": loaded.series_uid,
            "description": loaded.series_description,
            "modality": loaded.modality,
            "patient": loaded.patient,
        }
        report["shape"] = list(loaded.shape)
        report["spacing"] = list(loaded.spacing)
        report["steps"].append("load_series_to_runtime")

        volume = np.load(loaded.volume_path, mmap_mode="r")
        center, width = auto_window(volume)
        report["window"] = {"center": float(center), "width": float(width)}

        # Core views
        mid_z = int(volume.shape[0] // 2)
        axial = get_slice(volume, "axial", mid_z)
        axial8 = window_to_uint8(axial, center, width)
        report["axial_preview"] = {"shape": list(axial8.shape), "dtype": str(axial8.dtype)}
        report["steps"].append("2d_window")

        # MPR and projections
        projections: dict[str, Any] = {}
        for mode in ("MIP", "MinIP", "AvgIP"):
            arr = projection(volume, mode, axis=0)
            projections[mode] = {"shape": list(arr.shape), "min": float(np.nanmin(arr)), "max": float(np.nanmax(arr))}
        report["projections"] = projections
        report["steps"].append("mpr_projections")

        # Segmentation smoke checks
        spacing = tuple(float(x) for x in loaded.spacing)
        seg_report = {}
        for name, func in (
            ("bones", segment_bones),
            ("lungs", segment_lungs),
            ("vessels", segment_vessels),
        ):
            try:
                result = func(volume, spacing)
                seg_report[name] = {
                    "voxel_count": result.voxel_count,
                    "volume_ml": result.volume_ml,
                    "threshold": result.threshold,
                }
            except Exception as exc:
                seg_report[name] = {"error": str(exc)}
                report["warnings"].append(f"Segmentation {name} failed: {exc}")
        report["segmentation"] = seg_report
        report["steps"].append("segmentation_basic")

        report["elapsed_sec"] = round(time.time() - started, 3)
        report["status"] = "ok"
    except Exception as exc:
        report["elapsed_sec"] = round(time.time() - started, 3)
        report["status"] = "failed"
        report["errors"].append(str(exc))
    finally:
        if output_path:
            out = Path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(_json_safe(report), ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            shutil.rmtree(temp_root, ignore_errors=True)
        except Exception:
            pass
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="DicomView PRO Clinic Test Harness")
    parser.add_argument("--input", required=True, help="DICOM folder, DICOMDIR location, or Data.zip")
    parser.add_argument("--output", default="diagnostics/clinic_test_report.json", help="Output JSON report path")
    parser.add_argument("--series-uid", default=None, help="Optional SeriesInstanceUID to test")
    args = parser.parse_args(argv)
    report = run_clinic_test(args.input, args.output, args.series_uid)
    print(json.dumps(_json_safe(report), ensure_ascii=False, indent=2))
    return 0 if report.get("status") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main())
