from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

MODULES = [
    "pydicom",
    "pylibjpeg",
    "pylibjpeg_libjpeg",
    "pylibjpeg_openjpeg",
    "gdcm",
    "vtkmodules",
    "trimesh",
    "pynetdicom",
    "imageio",
    "reportlab",
    "docx",
]


def check_module(name: str) -> dict:
    spec = importlib.util.find_spec(name)
    return {"module": name, "available": spec is not None, "origin": getattr(spec, "origin", None) if spec else None}


def main() -> int:
    report = {"python": sys.version, "modules": [check_module(m) for m in MODULES]}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
