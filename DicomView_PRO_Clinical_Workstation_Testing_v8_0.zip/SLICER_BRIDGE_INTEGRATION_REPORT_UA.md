# Slicer Bridge Integration

База: DicomView_PRO_MPR2D_FidelityScroll_TRIPLECHECK.

Додано/оновлено:
- пошук 3D Slicer у `_internal/slicer`, `_internal/tools/3d-slicer`, системних Program Files і `%LOCALAPPDATA%/slicer.org/3D Slicer 5.10.0`;
- керований запуск через `--python-script` і manifest JSON;
- передача DICOM-серії в 3D Slicer;
- запуск Segment Editor з поточною серією/volume;
- експорт поточного volume у NRRD;
- експорт маски у `.seg.nrrd`;
- папка результатів і імпорт останнього STL/OBJ/PLY/GLB/NIfTI/NRRD;
- placeholder для портативного Slicer у `_internal/slicer`.

Важливо: 3D Slicer не вшито фізично в ZIP, його треба окремо скопіювати в `_internal/slicer/`, щоб був `_internal/slicer/Slicer.exe`.
