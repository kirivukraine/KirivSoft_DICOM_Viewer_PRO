# DicomView PRO v7.6 — Trauma Protocol Edition

## Що додано

### 1. Classic CPU Trauma Protocol
Додано модуль:

`src/dicomview_pro/core/trauma_protocol.py`

Модуль працює без AI, CUDA та важких моделей. Використовує HU-пороги, 3D-морфологію та connected components.

Підсвічує як карту уваги для лікаря:

- кісткові структури;
- кортикальну кістку;
- щільні фрагменти / уламки;
- повітряні кандидати;
- HU-кандидати гематоми.

> Це не автоматичний діагноз і не остаточний детектор переломів. Лікар підтверджує знахідки на 2D/MPR.

### 2. Інтеграція у ClinicalProtocolEngine
Оновлено:

`src/dicomview_pro/core/clinical_protocol_engine.py`

Протокол `trauma` тепер використовує dedicated `TraumaProtocolAnalyzer`, а не простий bone-threshold stub.

### 3. Інтеграція у UI
Оновлено:

`src/dicomview_pro/ui/main_window.py`

Меню:

`Протоколи → Травма — кістки/переломи/гематоми`

тепер запускає прямий метод `run_protocol_trauma_ui()`.

### 4. Trauma 3D
При запуску протоколу Trauma програма автоматично перемикає 3D на:

`Trauma Cinematic`

Це використовує cinematic/fidelity 3D-пресет із v7.4.

### 5. Trauma Report
У вкладку `Звіт` додаються:

- загальний обʼєм attention-mask;
- розміри Z/Y/X;
- максимальний розмір;
- кількість компонентів;
- class_metrics:
  - bone_ml;
  - cortical_bone_ml;
  - dense_fragment_candidate_ml;
  - air_candidate_ml;
  - hematoma_candidate_ml.

## Перевірка

Потрійна перевірка виконана:

1. `compileall` по `src` і `tests` — OK.
2. `pytest` — 46 passed, 4 skipped.
3. ZIP integrity — No errors detected.

## Обмеження

- Протокол Trauma є класичним HU/morphology workflow, а не AI.
- Дрібні переломи при товстих зрізах 3–5 мм можуть не виділятися.
- Повітря та гематома підсвічуються як кандидати й потребують перевірки лікарем.
