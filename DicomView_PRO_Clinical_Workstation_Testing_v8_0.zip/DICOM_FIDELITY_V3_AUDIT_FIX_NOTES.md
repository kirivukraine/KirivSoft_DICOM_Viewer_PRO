# DicomView PRO — DICOM Fidelity / SmoothStack Audit Fix v3

Виправлення за аудитом v2:

- Об'єднано дубльований `keyPressEvent`: тепер працюють F11/Esc і PageUp/PageDown/Arrow scrolling.
- Runtime volume після `np.load(..., mmap_mode='r')` копіюється в RAM через `.copy()`, щоб temp-cleanup не ламав browsing.
- Додано `patient_name` у metadata і fallback на `patient` для USB/CD/DICOMDIR export.
- Якщо знайдено `DICOMDIR`, `scan_files()` більше не дублює обхід через `rglob()`.
- Для Cine/4D перехід тепер використовує явне посилання `self.tab_cine`, а не `cine_label.parentWidget()`.
- Multi-frame XA/XRF/RF не спотворює z-spacing через frame micro-offsets.
- `_largest_component_bbox()` використовує downscale для великих масок, щоб не фризити UI.
- Orthanc search має окреме поле `orthanc_patient`, не читає PACS field.
- `export_current_png()` прибрано подвійний `np.ascontiguousarray()`.
- При старті очищаються старі runtime session-папки старші за 24 години.

Перевірка:
- compileall: OK
- pytest: 24 passed, 1 skipped
- ZIP integrity: OK
