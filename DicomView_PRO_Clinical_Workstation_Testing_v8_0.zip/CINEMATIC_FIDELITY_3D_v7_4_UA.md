# DicomView PRO v7.4 — Cinematic / Fidelity 3D

## Що додано

- Новий модуль `rendering/cinematic_fidelity.py`.
- Кінематографічні VTK-presets без AI:
  - Classic Hospital
  - Classic Lung
  - Classic Bone
  - Classic Soft Tissue
  - Hemorrhage Focus
  - Trauma Cinematic
- Для 3D увімкнено/посилено:
  - `ShadeOn()`
  - `SetInterpolationTypeToLinear()`
  - gradient opacity
  - `SetScalarOpacityUnitDistance(...)`
  - адаптивний sample distance
  - jittering, якщо VTK mapper підтримує
- Live-зміна пресетів тепер також застосовує повний `vtkVolumeProperty`, а не тільки color/opacity.

## Що це має покращити

- глибину 3D-зображення;
- відчуття тіней і шарів;
- меншу “пластиковість”;
- кращі Classic Lung/Bone/Soft Tissue;
- кращу основу для Hemorrhage Focus і Trauma.

## Чесне обмеження

Це не OSPRay path tracing і не повний фотореалістичний cinematic rendering. Це безпечне VTK-only покращення для поточного PySide6/VTK застосунку, щоб не ламати слабкі лікарняні ПК.
