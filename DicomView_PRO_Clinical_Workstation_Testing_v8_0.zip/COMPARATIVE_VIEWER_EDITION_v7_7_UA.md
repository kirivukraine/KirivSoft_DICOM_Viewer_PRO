# DicomView PRO v7.7 — Comparative Viewer Edition

## Призначення

v7.7 додає базову CPU-only підсистему follow-up порівняння двох досліджень або двох результатів клінічного протоколу.

Це не автоматична діагностика. Це вимірювальна підказка для лікаря.

## Додано

- `src/dicomview_pro/core/comparison_engine.py`
- `ComparativeViewerEngine`
- `StudyMetrics`
- `ComparisonResult`
- `DifferenceOverlay`
- порівняння масок однакового shape/spacing
- порівняння результатів `ClinicalProtocolResult`
- розрахунок:
  - Δ volume ml
  - Δ volume %
  - Δ max dimension mm
  - Δ HU mean, якщо доступно
  - direction: збільшення / зменшення / стабільно
- overlay masks:
  - growth mask — червоний
  - shrink mask — синій
  - stable mask — сірий
- JSON/TXT експорт результату

## Безпечна поведінка

Якщо дослідження мають різний shape або spacing, voxel-wise overlay вимикається і записується попередження. Це зроблено навмисно: без реєстрації простору не можна удавати точне voxel-wise порівняння.

## Наступний етап

v8.0 має обʼєднати:

- Viewer Fidelity
- Scanner Intelligence
- Series Quality
- Hemorrhage Protocol
- Trauma Protocol
- Comparative Viewer
- Smart Report

і саме v8.0 буде основною версією для реального відеотестування на колекції DICOM-дисків.
