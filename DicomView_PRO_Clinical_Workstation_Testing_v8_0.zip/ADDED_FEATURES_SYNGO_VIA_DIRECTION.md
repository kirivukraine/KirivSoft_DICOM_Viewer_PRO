# DicomView PRO — напрям розвитку “Hospital Ready / syngo.via-like Lite”

Додано у цьому варіанті:

## Orthanc Integration
- вкладка **Orthanc**;
- перевірка доступності локального Orthanc REST API;
- перегляд списку досліджень;
- upload одного DICOM-файлу в Orthanc.

Це не замінює PACS, але дає простий шлях до локального DICOM-сервера/VNA для тестування.

## Reporting
- створення PDF-звіту;
- створення DOCX-звіту;
- у звіт потрапляють DICOM-метадані та останні вимірювання ROI/HU.

Якщо `reportlab` або `python-docx` недоступні, створюється TXT fallback, щоб функція не ламала програму.

## Radiomics Base
- вкладка **Radiomics**;
- безпечний NumPy-аналіз поточного обсягу або маски;
- count, volume_ml, mean, min, max, std, percentiles, histogram entropy;
- перевірка наявності повного `pyradiomics` для майбутнього розширення.

## Що залишено стабільним
- DICOM Open / Series Selector;
- 2D / MPR / Projection;
- Segmentation;
- 3D Safe Mode для старих ПК;
- PACS PRO;
- Cine PRO;
- Export / Anonymization.

Проєкт не є сертифікованим медичним виробом.
