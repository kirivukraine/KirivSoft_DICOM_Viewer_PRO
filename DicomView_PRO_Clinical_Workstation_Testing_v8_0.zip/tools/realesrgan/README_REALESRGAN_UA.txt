Real-ESRGAN для DicomView PRO
===============================

Куди копіювати офіційний portable Real-ESRGAN ncnn-vulkan:

  DicomView_PRO\_internal\tools\realesrgan\

У цій папці має бути:

  realesrgan-ncnn-vulkan.exe
  models\*.bin
  models\*.param

Рекомендований офіційний пакет: Real-ESRGAN ncnn-vulkan release.
DicomView PRO не вшиває цей EXE через окрему ліцензію і великий розмір.

У програмі використання:
  AI -> Real-ESRGAN AI Zoom x2
  AI -> Real-ESRGAN AI Zoom x4

УВАГА: це тільки preview/enhancement, не діагностична реконструкція.
Real-ESRGAN може домальовувати деталі, тому не використовуйте результат для клінічного висновку.
