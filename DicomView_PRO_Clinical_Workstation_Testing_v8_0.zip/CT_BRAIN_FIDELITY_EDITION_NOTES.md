# DicomView PRO CT Brain Fidelity Edition

Фокус збірки: стабілізація 2D CT Brain без змін у 3D/MPR/VTK.

## Головні зміни
- Додано HU-level edge-preserving denoise до Window/Level: `ITK Anisotropic CT Brain`.
- SimpleITK Curvature Anisotropic Diffusion використовується, якщо пакет доступний; якщо ні — безпечний NumPy fallback.
- Для CT Brain Hr64/H60/H70/Sharp/High Resolution автоматично вмикається:
  - Brain Soft W100 C35
  - Cubic/Smooth soft tissue
  - ITK Anisotropic CT Brain
  - Fit-to-window
- Додано `ITK Anisotropic Strong` для ручного тесту на дуже шумних серіях.
- Додано CLAHE Low / Medium / Angio для XA/XRF/CR/DX у 2D pipeline.
- Lanczos залишено для Bone/detail, але не як дефолт для мозкової тканини.
- Auto-crop не є дефолтом; Fit-to-window лишається базовим режимом.

## Що не змінювалось
- 3D Volume / VTK
- MPR core
- STL/OBJ/PLY export
- VMTK/Slicer bridge

## Рекомендований режим для Siemens/SOMATOM CT Brain Hr64
- Preset: Brain Soft W100 C35
- Interpolation: Cubic/Smooth (soft tissue)
- Display: Fit-to-window
- Processing: ITK Anisotropic CT Brain

## Примітка
Усі фільтри застосовуються тільки до display-зображення. HU/ROI/вимірювання працюють по оригінальних даних.
