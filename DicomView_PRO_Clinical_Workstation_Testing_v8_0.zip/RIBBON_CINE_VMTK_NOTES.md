# DicomView PRO — Ribbon / Cine / VMTK Bridge notes

## Compact ribbon
This build shortens the central tab labels to preserve viewer space:
2D, Cine, MPR, MIP, Seg, 3D, Tags, Log, PACS, Orthanc, Report, Rad, Cases, Vessel, Angio 3D, 4D, AI, Clinical, Slicer/VMTK.

The viewer core is not changed. This is UI-only compaction.

## Coronary / contrast angiography plan
The stable path is:
1. XA/XRF multi-frame DICOM detection.
2. Cine playback with FPS / frame slider / loop.
3. DSA subtraction preview for contrast vessels.
4. Vessel analysis and stenosis tools.
5. 3D/4D only when input data contains real volumetric or rotational angiography geometry.

## VMTK integration status
VMTK is **not embedded** into DicomView PRO. It is integrated safely through **3D Slicer Bridge PRO**.

Recommended workflow:
1. Install 3D Slicer.
2. Install the SlicerVMTK extension from Slicer Extension Manager.
3. Open DICOM/NRRD/mask from DicomView PRO in Slicer.
4. Run VMTK centerline/vessel tools in Slicer.
5. Export STL/OBJ/PLY and import it back into DicomView PRO.

This avoids crashing old hospital PCs because VMTK/VTK-heavy operations run outside the main DicomView process.
