# DicomView PRO — 3D/2D usability patch

Виправлено та додано:

- 3D VTK: коректніша анатомічна геометрія для axial/coronal/sagittal серій через розрахунок позиції зрізу по нормалі `ImageOrientationPatient`, а не тільки по `ImagePositionPatient[2]`.
- 3D VTK: у статусі показується реальний spacing `z/y/x`, щоб легше діагностувати сплющення/розтягнення.
- 3D VTK: додані кольорові пресети `Bone Color`, `Angio Color`, `Color anatomy`.
- 2D/MPR/Cine/Projection: масштабування колесом миші, скидання масштабу подвійним кліком, pan правою або середньою кнопкою миші.
- Повноекранний режим: меню `Файл → Повноекранний режим`, клавіша `F11`, вихід через `Esc`.
- Window/Level: стандартні стартові значення за типом серії: brain/lung/bone/soft tissue.
- Segmentation Basic: стандартні пороги за замовчуванням для кісток, легень і судин/контрасту.

Збірка EXE:

```bat
build_exe.bat
```
