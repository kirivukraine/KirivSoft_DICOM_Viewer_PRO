from __future__ import annotations
import json, logging, os, subprocess, sys, shutil, platform
from datetime import datetime
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt, QTimer, QEvent, QThread, Signal
from PySide6.QtGui import QAction, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QComboBox, QSlider, QSpinBox, QTabWidget, QTextEdit, QMessageBox,
    QProgressBar, QGroupBox, QFormLayout, QSplitter, QGridLayout, QDoubleSpinBox, QLineEdit, QCheckBox,
    QFrame, QTreeWidget, QTreeWidgetItem, QScrollArea, QApplication, QInputDialog
)
from dicomview_pro.core.mpr_fidelity_engine import extract_mpr_slice, extract_mpr_mask_slice, display_crosshair_for_mpr, MPRFidelityCache, estimate_mpr_cache_items
from dicomview_pro.core.image_ops import auto_window, window_to_uint8, get_slice, projection, diagnostic_content_bbox
from dicomview_pro.core.hardware_profile import detect_hardware_profile
from dicomview_pro.core.measurements import roi_stats_hu, circle_roi_stats_hu, polygon_roi_stats_hu
from dicomview_pro.core.segmentation import segment_bones, segment_lungs, segment_vessels, mask_projection
from dicomview_pro.core.volume_cleaner import auto_clean_volume_for_3d
from dicomview_pro.core.export_models import export_mask
from dicomview_pro.core.anonymizer import anonymize_to_zip
from dicomview_pro.core.media_export import export_series_to_usb, create_cd_dvd_ready_folder, create_dicomdir_ready_folder, list_windows_drives
from dicomview_pro.core.dicom_special_objects import inspect_folder, sr_plain_text, seg_summary_table, rt_summary_table
from dicomview_pro.core.dicomweb_client import DicomWebConfig, qido_studies, stow_instances, wado_retrieve_series_raw
from dicomview_pro.core.dicomizer import dicomize_file
from dicomview_pro.core.frame_sync import sync_report
from dicomview_pro.core.cine_export import export_cine_gif, export_cine_mp4
from dicomview_pro.core.pacs_client import PacsConfig, echo as pacs_echo, find_studies as pacs_find_studies, store_file as pacs_store_file, write_pacs_audit
from dicomview_pro.core.orthanc_client import OrthancConfig, OrthancClient
from dicomview_pro.core.reporting import create_pdf_report, create_docx_report
from dicomview_pro.core.classic_ct_diagnostics import ClassicHemorrhageConfig, Hemorrhage3DClassicAnalyzer, DicomViewDiagnosticsClassic, save_classic_result_json
from dicomview_pro.core.clinical_protocol_engine import ClinicalProtocolEngine, protocol_pretty_text
from dicomview_pro.core.scanner_profile_engine import analyze_scanner_profile, ScannerProfile
# Lite build: keep Enterprise/AI/Slicer/Radiomics modules out of startup imports.
# All optional features are routed through plugins/external runtimes in Enterprise builds only.
def _lite_disabled(*args, **kwargs):
    raise RuntimeError("Цей модуль вимкнений у DicomView PRO Lite. Використайте Enterprise/plugin runtime.")

def _lite_status(*args, **kwargs):
    return {"available": False, "message": "Disabled in Lite"}

basic_radiomics = _lite_disabled
def pyradiomics_available(): return False
class CaseManager:
    def __init__(self, *args, **kwargs): pass

analyze_vessels = vessel_mip = _lite_disabled
inspect_angio_metadata = temporal_max_projection = pseudo_3d_angio_preview = _lite_disabled
dsa_frame = dsa_subtract = contrast_enhance_frame = temporal_projection = export_png_sequence = _lite_disabled
def detect_angio_cine_profile(*args, **kwargs): return None
def profile_to_text(*args, **kwargs): return "Angio disabled in Lite"
inspect_4d = _lite_disabled
ai_environment = ai_engine_status = realesrgan_status = _lite_status
def fallback_lung_mask(*args, **kwargs): return None
def fallback_bone_mask(*args, **kwargs): return None
class SegmentResult:
    pass
def mobile_sam_segment_slice(*args, **kwargs):
    return SegmentResult()
MobileSAMWorker = None
def default_sam_model_path(*args, **kwargs): return None
def warm_mobile_sam_sessions(*args, **kwargs): return None
def denoise_slice(img, *args, **kwargs):
    class R: pass
    r=R(); r.ok=False; r.message="AI denoise disabled in Lite"; r.details={}; r.image2d=img; return r
def superres_slice(img, *args, **kwargs):
    class R: pass
    r=R(); r.ok=False; r.message="AI superres disabled in Lite"; r.details={}; r.image2d=img; return r
def organ_ai_status(*args, **kwargs):
    class S:
        def to_dict(self): return {"available": False, "message": "Organ AI disabled in Lite"}
    return S()
build_organ_segmentation_plan = write_plan_manifest = discover_organ_meshes = _lite_disabled
def clinical_foundation_report(*args, **kwargs):
    return "Clinical extras disabled in Lite"
def find_slicer(*args, **kwargs):
    class R:
        ok=False; path=""; message="Slicer Bridge disabled in Lite"
        def to_dict(self): return self.__dict__
    return R()
export_volume_nrrd = export_mask_nrrd = launch_slicer = open_folder_in_slicer = default_work_dir = write_bridge_manifest = launch_bridge_payload = send_dicom_series = _lite_disabled
def vmtk_available_in_python(): return False
create_vmtk_slicer_script = run_vmtk_bridge_in_slicer = _lite_disabled
from dicomview_pro.runtime.controller import Controller, LoadThread, ScanThread, LoadResult
from dicomview_pro.runtime.logging_setup import log_path
from dicomview_pro.runtime.runtime_paths import data_dir, cleanup_old_runtime_dirs
from .image_label import ImageLabel
from .vtk_viewer import VtkVolumeViewer
# Lite build: OrganSegmentationPanel is an Enterprise plugin and must not be imported at startup.
OrganSegmentationPanel = None
from dicomview_pro.resources import icon_path, icon_png_path

log = logging.getLogger(__name__)
LITE_MODE = True
LITE_DISABLED_TABS = {"Organ 3D", "Radiomics", "Cases", "Vessel", "Angio 3D", "4D", "AI", "Slicer/VMTK"}

STYLE = """
QMainWindow, QWidget { background:#061525; color:#e8f4ff; font-family: Segoe UI; font-size: 9.5pt; }
QMenuBar { background:#071b31; color:#e8f4ff; padding:3px; }
QMenuBar::item:selected, QMenu::item:selected { background:#164a7a; border-radius:5px; }
QMenu { background:#0b2038; color:#e8f4ff; border:1px solid #1a507c; }
QPushButton { background:#145c9e; color:#ffffff; border:none; padding:3px 8px; border-radius:7px; font-weight:600; min-height:20px; max-height:28px; }
QPushButton:hover { background:#1d75c5; }
QPushButton:checked { background:#21a366; color:#ffffff; }
QCheckBox { color:#e8f4ff; spacing:6px; }
QPushButton[modeButton="true"] { background:#0d2f52; border:1px solid #1e5b8e; padding:3px 8px; border-radius:8px; min-height:20px; max-height:28px; }
QPushButton[modeButton="true"]:hover { background:#155f9f; }
QFrame#TopBar { background:#071b31; border:1px solid #245981; border-radius:14px; }
QFrame#InspectorCard { background:#071b31; border:1px solid #245981; border-radius:12px; }
QFrame#ViewerSurface { background:#050d18; border:1px solid #1f4e73; border-radius:12px; }
QFrame#StatusBar { background:#06111f; border:1px solid #183b5a; border-radius:10px; }
QTreeWidget { background:#07111e; color:#e8f4ff; border:1px solid #1e4c73; border-radius:8px; padding:4px; }
QTreeWidget::item:selected { background:#1a6fb5; border-radius:5px; }
QPushButton:disabled { background:#26384b; color:#9baabd; }
QTabWidget::pane { border:1px solid #1f4e73; border-radius:10px; padding:4px; background:#081a2d; }
QTabBar::tab { background:#0b2946; color:#d8ecff; padding:4px 8px; border-top-left-radius:7px; border-top-right-radius:7px; margin-right:1px; }
QTabBar::tab:selected { background:#1a6fb5; color:white; }
QGroupBox { border:1px solid #1e4c73; border-radius:9px; margin-top:6px; padding:6px; font-weight:600; }
QGroupBox::title { subcontrol-origin: margin; left:10px; padding:0 4px; }
QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit { background:#07111e; color:#e8f4ff; border:1px solid #1e4c73; border-radius:6px; padding:2px; min-height:20px; }
QSpinBox, QDoubleSpinBox { min-width:74px; max-width:100px; padding-right:16px; }
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button { width:15px; }
QLabel#SmallLabel { color:#d7efff; }
QSlider::groove:horizontal { height:5px; background:#0b2946; border-radius:3px; }
QSlider::handle:horizontal { background:#31a8ff; width:13px; margin:-5px 0; border-radius:7px; }
QProgressBar { border:1px solid #1e4c73; border-radius:7px; text-align:center; background:#07111e; }
QProgressBar::chunk { background:#1a6fb5; border-radius:7px; }
QScrollArea { border:none; background:#061525; }
QLabel#AppTitle { font-size:18px; font-weight:800; color:#ffffff; }
QLabel#AppSubtitle { color:#9fcfff; }
QLabel#PatientHeader { background:#0a2743; border:1px solid #245981; border-radius:12px; padding:10px; color:#d7efff; }
QLabel#InfoText { color:#bfe6ff; }
"""

LIGHT_STYLE = """
QMainWindow, QWidget { background:#f3f7fb; color:#102033; font-family: Segoe UI; font-size: 9.5pt; }
QMenuBar { background:#e7eef7; color:#102033; padding:3px; border-bottom:1px solid #c9d6e4; }
QMenuBar::item:selected, QMenu::item:selected { background:#d2e7ff; border-radius:5px; }
QMenu { background:#ffffff; color:#102033; border:1px solid #b8c9da; }
QPushButton { background:#1976c9; color:#ffffff; border:none; padding:3px 8px; border-radius:7px; font-weight:600; min-height:20px; max-height:28px; }
QPushButton:hover { background:#2389e6; }
QPushButton:checked { background:#138a45; color:#ffffff; }
QCheckBox { color:#102033; spacing:6px; }
QPushButton[modeButton="true"] { background:#e7f2ff; color:#10314f; border:1px solid #9ec8ee; padding:3px 8px; border-radius:8px; min-height:20px; max-height:28px; }
QPushButton[modeButton="true"]:hover { background:#d6ebff; }
QFrame#TopBar { background:#ffffff; border:1px solid #b8c9da; border-radius:14px; }
QFrame#InspectorCard { background:#ffffff; border:1px solid #b8c9da; border-radius:12px; }
QFrame#ViewerSurface { background:#ffffff; border:1px solid #b8c9da; border-radius:12px; }
QFrame#StatusBar { background:#ffffff; border:1px solid #c9d6e4; border-radius:10px; }
QTreeWidget { background:#ffffff; color:#102033; border:1px solid #b8c9da; border-radius:8px; padding:4px; }
QTreeWidget::item:selected { background:#cfe7ff; color:#102033; border-radius:5px; }
QPushButton:disabled { background:#d8e0e8; color:#7a8794; }
QTabWidget::pane { border:1px solid #b8c9da; border-radius:10px; padding:4px; background:#ffffff; }
QTabBar::tab { background:#e6eef7; color:#102033; padding:4px 8px; border-top-left-radius:7px; border-top-right-radius:7px; margin-right:1px; }
QTabBar::tab:selected { background:#1976c9; color:white; }
QGroupBox { border:1px solid #b8c9da; border-radius:9px; margin-top:6px; padding:6px; font-weight:600; background:#ffffff; }
QGroupBox::title { subcontrol-origin: margin; left:10px; padding:0 4px; background:#ffffff; }
QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit { background:#ffffff; color:#102033; border:1px solid #b8c9da; border-radius:6px; padding:2px; min-height:20px; }
QSpinBox, QDoubleSpinBox { min-width:74px; max-width:100px; padding-right:16px; }
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button { width:15px; }
QLabel#SmallLabel { color:#102033; }
QSlider::groove:horizontal { height:5px; background:#d3e3f2; border-radius:3px; }
QSlider::handle:horizontal { background:#1976c9; width:13px; margin:-5px 0; border-radius:7px; }
QProgressBar { border:1px solid #b8c9da; border-radius:7px; text-align:center; background:#ffffff; }
QProgressBar::chunk { background:#1976c9; border-radius:7px; }
QScrollArea { border:none; background:#f3f7fb; }
QLabel#AppTitle { font-size:18px; font-weight:800; color:#0d2035; }
QLabel#AppSubtitle { color:#245981; }
QLabel#PatientHeader { background:#ffffff; border:1px solid #8eb6d8; border-radius:12px; padding:10px; color:#0d2035; }
QLabel#InfoText { color:#15304a; }
"""


class BackgroundTask(QThread):
    finished_ok = Signal(object)
    failed = Signal(str)

    def __init__(self, func, *args, parent=None, **kwargs):
        super().__init__(parent)
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            self.finished_ok.emit(self.func(*self.args, **self.kwargs))
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.controller = Controller()
        try:
            cleanup_old_runtime_dirs(24)
        except Exception:
            pass
        self.setWindowTitle("DicomView PRO — автор Іван Кіранчук, компанія KirivSoft")
        self.icon_path = icon_png_path()
        self.window_icon_path = icon_path()
        if self.window_icon_path.exists():
            self.setWindowIcon(QIcon(str(self.window_icon_path)))
        self.ui_settings = self._load_ui_settings()
        self.ui_language = self.ui_settings.get("language", "uk")
        self.ui_theme = self.ui_settings.get("theme", "dark")
        self.show_crosshair_lines = bool(self.ui_settings.get("show_crosshair_lines", True))
        self.auto_preload_ai = False  # Lite: AI preload disabled; heavy modules are plugins only
        self.setStyleSheet(self._style_for_theme(self.ui_theme))
        self._background_tasks = []
        self.volume: np.ndarray | None = None
        self.metadata: dict = {}
        self._smoothstack_bboxes: dict[str, tuple[int, int, int, int]] = {}
        self._series_display_profiles: dict[str, dict] = {}
        self._mpr_cache = MPRFidelityCache(max_items=192)
        self._current_series_key: str = ""
        self.current_slice: np.ndarray | None = None
        self.current_mask: np.ndarray | None = None
        self.show_protocol_2d_overlay = True
        self.protocol_overlay_alpha = 120
        self.current_path = ""
        self.center = 40.0
        self.width = 400.0
        self.render_quality = "cubic"
        self.fit_mode = "fit_window"
        self.invert_display = False
        self.sharpen_mode = "brain_fidelity_pro"
        self.cross_z = 0
        self.cross_y = 0
        self.cross_x = 0
        self.hardware_profile = detect_hardware_profile()
        self.scanner_profile: ScannerProfile | None = None
        self.case_manager = CaseManager(data_dir() / "cases.sqlite3")
        self.external_model_path = ""
        self.sam_click_enabled = False
        self.sam_worker = None
        self.sam_model_path = default_sam_model_path()
        self._sam_previous_measure_mode = "distance"
        self.scan_thread = None
        self.load_thread = None
        self.cine_timer = QTimer(self)
        self.cine_timer.timeout.connect(self.next_cine_frame)
        self.cine_frame = 0
        self.measure_history: list[str] = []
        self.mode_buttons: list[QPushButton] = []
        self._build_ui()
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
        self._apply_startup_diagnostic_layout()
        if False:
            QTimer.singleShot(1200, self.auto_preload_ai_runtime)  # Lite disabled

    def _settings_path(self) -> Path:
        return data_dir() / "ui_settings.json"

    def _load_ui_settings(self) -> dict:
        try:
            path = self._settings_path()
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return {"language": "uk", "theme": "dark", "auto_preload_ai": False}

    def _save_ui_settings(self) -> None:
        try:
            path = self._settings_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({"language": self.ui_language, "theme": self.ui_theme, "show_crosshair_lines": bool(self.show_crosshair_lines), "auto_preload_ai": bool(self.auto_preload_ai)}, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _style_for_theme(self, theme: str) -> str:
        return LIGHT_STYLE if theme == "light" else STYLE

    def _apply_theme_runtime_styles(self) -> None:
        """Fix hard-coded clinical labels/cards after changing dark/light theme."""
        light = getattr(self, "ui_theme", "dark") == "light"
        info = "#15304a" if light else "#bfe6ff"
        status_bg = "#ffffff" if light else "#06111f"
        status_border = "#b8c9da" if light else "#183b5a"
        for name in ("ui_patient_card", "ui_hardware_card", "ui_diag_card", "seg_preset_info"):
            w = getattr(self, name, None)
            if w is not None:
                try: w.setStyleSheet(f"color:{info};")
                except Exception: pass
        if hasattr(self, "system_status"):
            self.system_status.setStyleSheet(f"background:{status_bg}; border:1px solid {status_border}; border-radius:10px; padding:7px; color:{info};")

    def set_ui_theme(self, theme: str) -> None:
        self.ui_theme = "light" if theme == "light" else "dark"
        self.setStyleSheet(self._style_for_theme(self.ui_theme))
        self._apply_theme_runtime_styles()
        if hasattr(self, "theme_combo"):
            idx = 1 if self.ui_theme == "light" else 0
            if self.theme_combo.currentIndex() != idx:
                self.theme_combo.setCurrentIndex(idx)
        self._save_ui_settings()
        if hasattr(self, "log_ui"):
            self.log_ui("UI theme changed: " + self.ui_theme)

    def set_ui_language(self, language: str) -> None:
        self.ui_language = "en" if language == "en" else "uk"
        if hasattr(self, "language_combo"):
            idx = 1 if self.ui_language == "en" else 0
            if self.language_combo.currentIndex() != idx:
                self.language_combo.setCurrentIndex(idx)
        self._apply_language_runtime()
        self._save_ui_settings()
        if hasattr(self, "log_ui"):
            self.log_ui("UI language changed: " + self.ui_language)

    def _apply_language_runtime(self) -> None:
        en = getattr(self, "ui_language", "uk") == "en"
        if hasattr(self, "menu_file"):
            self.menu_file.setTitle("File" if en else "Файл")
        if hasattr(self, "menu_media"):
            self.menu_media.setTitle("Export / media" if en else "Експорт / носій")
        if hasattr(self, "menu_view"):
            self.menu_view.setTitle("View" if en else "Перегляд")
        if hasattr(self, "menu_settings"):
            self.menu_settings.setTitle("Settings" if en else "Налаштування")
        if hasattr(self, "menu_compat"):
            self.menu_compat.setTitle("Compatibility" if en else "Сумісність")
        if hasattr(self, "menu_help"):
            self.menu_help.setTitle("Help" if en else "Довідка")
        if hasattr(self, "settings_hint"):
            self.settings_hint.setText("Settings are saved automatically. Language and theme are applied immediately." if en else "Налаштування зберігаються автоматично. Мова і тема застосовуються одразу.")
        if hasattr(self, "b_2d_ruler"):
            self.b_2d_ruler.setText("2D ruler" if en else "2D лінійка")
        if hasattr(self, "b_crosshair_main"):
            self.b_crosshair_main.setText(("Yellow crosshair: ON" if self.show_crosshair_lines else "Yellow crosshair: OFF") if en else ("Жовті лінії: ON" if self.show_crosshair_lines else "Жовті лінії: OFF"))
        if hasattr(self, "vtk_ruler_check"):
            self.vtk_ruler_check.setText("3D ruler" if en else "3D лінійка")
        if hasattr(self, "measure_combo"):
            self.measure_combo.setToolTip("Measurement mode: choose ruler, ROI, angle or HU." if en else "Режим вимірювання: лінійка, ROI, кут або HU.")
        if hasattr(self, "tabs"):
            en_tabs = {"Cine":"Cine", "MPR":"MPR", "MIP":"MIP", "Seg":"Seg", "3D":"3D", "Tags":"Tags", "Log":"Log", "PACS":"PACS", "Orthanc":"Orthanc", "Report":"Report", "Radiomics":"Radiomics", "Cases":"Cases", "Vessel":"Vessel", "Angio 3D":"Angio 3D", "4D":"4D", "AI":"AI", "Налаштування":"Settings", "Settings":"Settings", "Clinical":"Clinical", "Slicer/VMTK":"Slicer/VMTK"}
            uk_tabs = {"Cine":"Cine", "MPR":"MPR", "MIP":"MIP", "Seg":"Seg", "3D":"3D", "Tags":"Теги", "Log":"Лог", "PACS":"PACS", "Orthanc":"Orthanc", "Report":"Звіт", "Radiomics":"Radiomics", "Cases":"Кейси", "Vessel":"Судини", "Angio 3D":"Angio 3D", "4D":"4D", "AI":"AI", "Settings":"Налаштування", "Налаштування":"Налаштування", "Clinical":"Clinical", "Slicer/VMTK":"Slicer/VMTK"}
            mapping = en_tabs if en else uk_tabs
            for i in range(self.tabs.count()):
                txt = self.tabs.tabText(i)
                if txt in mapping:
                    self.tabs.setTabText(i, mapping[txt])

    def set_crosshair_visible(self, visible: bool) -> None:
        self.show_crosshair_lines = bool(visible)
        for name in ("img2d", "axial_label", "coronal_label", "sagittal_label", "proj_label", "cine_label", "ai_preview", "seg_preview"):
            lab = getattr(self, name, None)
            if lab is not None and hasattr(lab, "show_crosshair"):
                lab.show_crosshair = self.show_crosshair_lines
                try:
                    lab._update_pixmap()
                except Exception:
                    pass
        if hasattr(self, "crosshair_check") and self.crosshair_check.isChecked() != self.show_crosshair_lines:
            self.crosshair_check.blockSignals(True); self.crosshair_check.setChecked(self.show_crosshair_lines); self.crosshair_check.blockSignals(False)
        if hasattr(self, "a_crosshair") and self.a_crosshair.isChecked() != self.show_crosshair_lines:
            self.a_crosshair.blockSignals(True); self.a_crosshair.setChecked(self.show_crosshair_lines); self.a_crosshair.blockSignals(False)
        if hasattr(self, "b_crosshair_main"):
            en = getattr(self, "ui_language", "uk") == "en"
            self.b_crosshair_main.blockSignals(True); self.b_crosshair_main.setChecked(self.show_crosshair_lines); self.b_crosshair_main.blockSignals(False)
            self.b_crosshair_main.setText(("Yellow crosshair: ON" if self.show_crosshair_lines else "Yellow crosshair: OFF") if en else ("Жовті лінії: ON" if self.show_crosshair_lines else "Жовті лінії: OFF"))
        self._save_ui_settings()
        if hasattr(self, "log_ui"):
            self.log_ui("Crosshair lines " + ("enabled" if self.show_crosshair_lines else "disabled"))

    def set_auto_preload_ai(self, enabled: bool) -> None:
        self.auto_preload_ai = bool(enabled)
        self._save_ui_settings()
        if enabled:
            self.auto_preload_ai_runtime()

    def auto_preload_ai_runtime(self) -> None:
        """Lite: AI preload is disabled so startup never imports or waits for ONNX/AI runtimes."""
        self.log_ui("Lite: AI preload skipped; Enterprise plugins load externally only.")
        return

    def on_ai_preload_ready(self, info) -> None:
        try:
            text = json.dumps(info, ensure_ascii=False, indent=2)
        except Exception:
            text = str(info)
        if hasattr(self, "ai_output"):
            self.ai_output.setPlainText("AI preload result:\n" + text)
        ok = bool(info.get("ok")) if isinstance(info, dict) else False
        self.log_ui("AI preload " + ("ready" if ok else "fallback/not ready"))

    def apply_3d_transfer_preset(self, preset: str) -> None:
        """Apply 3D HU transfer function preset without rebuilding volume."""
        if hasattr(self, "vtk_viewer"):
            ok = self.vtk_viewer.apply_transfer_preset(str(preset))
            if not ok:
                self.log_ui("3D transfer preset pending until Volume Rendering is built: " + str(preset))

    def toggle_3d_ruler(self, enabled: bool) -> None:
        if hasattr(self, "vtk_viewer"):
            ok = self.vtk_viewer.enable_distance_measurement(bool(enabled))
            if enabled and not ok and hasattr(self, "vtk_ruler_check"):
                self.vtk_ruler_check.blockSignals(True); self.vtk_ruler_check.setChecked(False); self.vtk_ruler_check.blockSignals(False)

    def toggle_3d_clip_box(self, enabled: bool) -> None:
        if hasattr(self, "vtk_viewer"):
            ok = self.vtk_viewer.enable_clip_box(bool(enabled))
            if enabled and not ok and hasattr(self, "vtk_clip_check"):
                self.vtk_clip_check.blockSignals(True); self.vtk_clip_check.setChecked(False); self.vtk_clip_check.blockSignals(False)


    def toggle_3d_clip_navigate(self, enabled: bool) -> None:
        if hasattr(self, "vtk_viewer"):
            ok = self.vtk_viewer.enable_clip_navigate(bool(enabled), axis="CAMERA")
            if enabled and not ok and hasattr(self, "vtk_clip_nav_check"):
                self.vtk_clip_nav_check.blockSignals(True); self.vtk_clip_nav_check.setChecked(False); self.vtk_clip_nav_check.blockSignals(False)

    def update_3d_clip_depth(self, value: int) -> None:
        if hasattr(self, "vtk_clip_depth_label"):
            self.vtk_clip_depth_label.setText(f"Clip depth: {int(value)}%")
        if hasattr(self, "vtk_viewer") and hasattr(self, "vtk_clip_nav_check") and self.vtk_clip_nav_check.isChecked():
            self.vtk_viewer.set_clip_depth_percent(float(value))

    def reset_3d_clip(self) -> None:
        if hasattr(self, "vtk_viewer"):
            self.vtk_viewer.enable_clip_navigate(False)
            self.vtk_viewer.enable_clip_box(False)
        for w in (getattr(self, "vtk_clip_nav_check", None), getattr(self, "vtk_clip_check", None)):
            if w is not None:
                w.blockSignals(True); w.setChecked(False); w.blockSignals(False)
        if hasattr(self, "vtk_clip_depth"):
            self.vtk_clip_depth.blockSignals(True); self.vtk_clip_depth.setValue(50); self.vtk_clip_depth.blockSignals(False)
        if hasattr(self, "vtk_clip_depth_label"):
            self.vtk_clip_depth_label.setText("Clip depth: 50%")
        self.update_system_status("3D Clip скинуто")

    def toggle_3d_mip(self, enabled: bool) -> None:
        if hasattr(self, "vtk_viewer"):
            ok = self.vtk_viewer.set_mip_blend(bool(enabled))
            if enabled and not ok and hasattr(self, "vtk_mip_btn"):
                self.vtk_mip_btn.blockSignals(True); self.vtk_mip_btn.setChecked(False); self.vtk_mip_btn.blockSignals(False)

    def apply_3d_sub_tissue(self) -> None:
        """One-click surgical view: hide skin/fat/low-density tissue and keep inner structures."""
        if hasattr(self, "vtk_threshold"):
            self.vtk_threshold.setValue(200)
        if hasattr(self, "vtk_viewer"):
            self.vtk_viewer.update_opacity_threshold(200)
        self.log_ui("3D Sub-Tissue preset: Density Threshold set to +200 HU.")

    def update_3d_threshold(self, value: int) -> None:
        if hasattr(self, "vtk_threshold_label"):
            self.vtk_threshold_label.setText(f"Density: {int(value):+d} HU")
        if hasattr(self, "vtk_viewer"):
            self.vtk_viewer.update_opacity_threshold(float(value))

    def on_main_tab_changed(self, idx: int) -> None:
        try:
            if self.tabs.tabText(idx) == "3D" and self.volume is not None:
                if not getattr(self, "_auto_3d_built_for_shape", None) == tuple(self.volume.shape):
                    self.build_3d()
                    self._auto_3d_built_for_shape = tuple(self.volume.shape)
        except Exception as exc:
            self.log_ui("Auto 3D start error: " + str(exc))

    def _build_ui(self):
        mb = self.menuBar()
        self.menu_file = filem = mb.addMenu("Файл")
        a_open = QAction("Відкрити DICOM файл/папку", self); a_open.triggered.connect(self.choose_path); filem.addAction(a_open)
        a_export = QAction("Експортувати поточний кадр PNG", self); a_export.triggered.connect(self.export_current_png); filem.addAction(a_export)
        a_anon = QAction("Створити анонімний ZIP поточної серії", self); a_anon.triggered.connect(self.anonymize_current_series); filem.addAction(a_anon)
        self.menu_media = media_menu = mb.addMenu("Експорт / носій")
        a_usb = QAction("Зберегти поточну серію на USB флешку", self); a_usb.triggered.connect(self.export_current_series_to_usb); media_menu.addAction(a_usb)
        a_cd = QAction("Підготувати папку для CD/DVD", self); a_cd.triggered.connect(self.export_current_series_for_cd_dvd); media_menu.addAction(a_cd)
        a_dicomdir = QAction("Створити DICOMDIR + стартовий носій", self); a_dicomdir.triggered.connect(self.export_current_series_dicomdir_ready); media_menu.addAction(a_dicomdir)
        a_log = QAction("Відкрити лог", self); a_log.triggered.connect(self.open_log); filem.addAction(a_log)
        a_logs_dir = QAction("Відкрити папку логів", self); a_logs_dir.triggered.connect(self.open_logs_dir); filem.addAction(a_logs_dir)
        a_make_diag = QAction("Створити тестовий діагностичний лог", self); a_make_diag.triggered.connect(self.create_test_diagnostic_log); filem.addAction(a_make_diag)
        a_save_log = QAction("Зберегти лог як...", self); a_save_log.triggered.connect(self.save_log_as); filem.addAction(a_save_log)
        a_classic = QAction("Classic CPU: крововилив + асиметрія", self); a_classic.triggered.connect(self.run_classic_ct_diagnostics_ui); filem.addAction(a_classic)
        a_full = QAction("Повноекранний режим (F11 / Esc)", self); a_full.triggered.connect(self.toggle_fullscreen); filem.addAction(a_full)
        self.menu_view = viewm = mb.addMenu("Перегляд")
        a_fit = QAction("Fit-to-window", self); a_fit.triggered.connect(lambda: self.set_fit_mode("fit_window")); viewm.addAction(a_fit)
        a_one = QAction("1:1 піксель", self); a_one.triggered.connect(lambda: self.set_fit_mode("one_to_one")); viewm.addAction(a_one)
        a_quality = QAction("Максимальна якість Lanczos", self); a_quality.triggered.connect(lambda: self.set_render_quality("lanczos")); viewm.addAction(a_quality)
        self.a_crosshair = QAction("Показувати жовті лінії центрування", self); self.a_crosshair.setCheckable(True); self.a_crosshair.setChecked(bool(self.show_crosshair_lines)); self.a_crosshair.triggered.connect(lambda checked: self.set_crosshair_visible(bool(checked))); viewm.addAction(self.a_crosshair)
        self.menu_protocols = protom = mb.addMenu("Протоколи")
        a_proto_hemo = QAction("Гемораж — кров/гематома/крововилив", self); a_proto_hemo.triggered.connect(self.run_protocol_hemorrhage_ui); protom.addAction(a_proto_hemo)
        a_proto_trauma = QAction("Травма — кістки/переломи/гематоми", self); a_proto_trauma.triggered.connect(self.run_protocol_trauma_ui); protom.addAction(a_proto_trauma)
        a_proto_ischemia = QAction("Ішемія — гіподенсність/асиметрія", self); a_proto_ischemia.triggered.connect(lambda: self.run_protocol_stub_ui("Ішемія")); protom.addAction(a_proto_ischemia)
        a_proto_onco = QAction("Онко — атипова тканина/мас-ефект", self); a_proto_onco.triggered.connect(lambda: self.run_protocol_stub_ui("Онко")); protom.addAction(a_proto_onco)
        a_proto_infl = QAction("Запалення — абсцес/інфільтрат/рідина", self); a_proto_infl.triggered.connect(lambda: self.run_protocol_stub_ui("Запалення")); protom.addAction(a_proto_infl)
        protom.addSeparator()
        a_proto_report = QAction("Відкрити вкладку Звіт", self); a_proto_report.triggered.connect(lambda: self.switch_tab("Звіт")); protom.addAction(a_proto_report)
        self.menu_settings = settings_menu = mb.addMenu("Налаштування")
        a_lang_uk = QAction("Мова: Українська", self); a_lang_uk.triggered.connect(lambda: self.set_ui_language("uk")); settings_menu.addAction(a_lang_uk)
        a_lang_en = QAction("Language: English", self); a_lang_en.triggered.connect(lambda: self.set_ui_language("en")); settings_menu.addAction(a_lang_en)
        settings_menu.addSeparator()
        a_theme_dark = QAction("Тема: Темна", self); a_theme_dark.triggered.connect(lambda: self.set_ui_theme("dark")); settings_menu.addAction(a_theme_dark)
        a_theme_light = QAction("Theme: Light", self); a_theme_light.triggered.connect(lambda: self.set_ui_theme("light")); settings_menu.addAction(a_theme_light)
        a_exit = QAction("Вихід", self); a_exit.triggered.connect(self.close); filem.addAction(a_exit)
        compat_menu = mb.addMenu("Сумісність")
        a_inspect = QAction("Weasis-style: SR/SEG/RT/ECG аналіз папки", self); a_inspect.triggered.connect(self.weasis_inspect_current_folder); compat_menu.addAction(a_inspect)
        a_sr = QAction("SR Viewer: відкрити DICOM SR", self); a_sr.triggered.connect(self.sr_viewer_dialog); compat_menu.addAction(a_sr)
        a_seg = QAction("SEG/RT summary: відкрити SEG або RT", self); a_seg.triggered.connect(self.seg_rt_summary_dialog); compat_menu.addAction(a_seg)
        a_dicomizer = QAction("Dicomizer: імпорт JPG/PNG/PDF/STL/OBJ/PLY у DICOM", self); a_dicomizer.triggered.connect(self.dicomizer_import_dialog); compat_menu.addAction(a_dicomizer)
        a_sync = QAction("FrameOfReference sync report", self); a_sync.triggered.connect(self.frame_sync_report_dialog); compat_menu.addAction(a_sync)
        self.menu_help = helpm = mb.addMenu("Довідка")
        about = QAction("Про програму", self); about.triggered.connect(self.about); helpm.addAction(about)

        root = QWidget(); self.setCentralWidget(root); main = QVBoxLayout(root)
        main.setContentsMargins(10, 10, 10, 10)
        main.setSpacing(8)

        topbar = QFrame(); self.topbar = topbar; topbar.setObjectName("TopBar")
        top_l = QHBoxLayout(topbar); top_l.setContentsMargins(10, 6, 10, 6); top_l.setSpacing(8)
        icon_label = QLabel()
        if self.icon_path.exists():
            pix = QPixmap(str(self.icon_path))
            if not pix.isNull():
                icon_label.setPixmap(pix.scaled(36, 36, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        icon_label.setFixedSize(42, 42)
        icon_label.setStyleSheet("background:#0b2038; border:1px solid #1f4e73; border-radius:14px; padding:5px;")
        title_box = QVBoxLayout()
        title = QLabel("DicomView PRO")
        self.ui_title_label = title
        title.setObjectName("AppTitle")
        subtitle = QLabel("Автор Іван Кіранчук · KirivSoft · Advanced Clinical Workstation")
        self.ui_subtitle_label = subtitle
        subtitle.setObjectName("AppSubtitle")
        title_box.addWidget(title); title_box.addWidget(subtitle)
        top_l.addWidget(icon_label); top_l.addLayout(title_box, 1)
        self.header_progress = QProgressBar()
        self.header_progress.setRange(0, 0)
        self.header_progress.setFixedWidth(260)
        self.header_progress.setTextVisible(True)
        self.header_progress.setFormat("Завантаження DICOM…")
        self.header_progress.setStyleSheet("QProgressBar{border:1px solid #1f6b3a;border-radius:7px;background:#06111f;color:#d8ffe4;padding:1px;} QProgressBar::chunk{background:#00b050;border-radius:6px;}")
        self.header_progress.hide()
        top_l.addWidget(self.header_progress)
        self.patient_header = QLabel("Пацієнт: —   |   Серія: —   |   Режим: Safe")
        self.patient_header.setObjectName("PatientHeader")
        self.patient_header.setMinimumWidth(360)
        top_l.addWidget(self.patient_header)
        main.addWidget(topbar)

        self.mode_bar = QWidget()
        mode_row = QHBoxLayout(self.mode_bar); mode_row.setContentsMargins(0,0,0,0); mode_row.setSpacing(8)
        mode_row.addWidget(QLabel("Режими:"))
        for text, tab in [("2D", "2D"), ("MPR", "MPR PRO"), ("3D", "3D VTK"), ("Звіт", "Звіт")]:
            btn = QPushButton(text); btn.setProperty("modeButton", True)
            btn.clicked.connect(lambda _=False, name=tab: self.switch_tab(name))
            self.mode_buttons.append(btn)
            mode_row.addWidget(btn)
        mode_row.addStretch(1)
        self.left_panel_visible = True
        self.right_panel_visible = True
        b_left = QPushButton("◀ Навігатор")
        b_left.setProperty("modeButton", True)
        b_left.clicked.connect(lambda: self.toggle_side_panel("left"))
        b_right = QPushButton("Інструменти ▶")
        b_right.setProperty("modeButton", True)
        b_right.clicked.connect(lambda: self.toggle_side_panel("right"))
        mode_row.addWidget(b_left); mode_row.addWidget(b_right)
        main.addWidget(self.mode_bar)

        splitter = QSplitter(Qt.Horizontal); self.main_splitter = splitter; main.addWidget(splitter, 1)

        left = QWidget(); left.setMaximumWidth(330); left.setMinimumWidth(255); left_l = QVBoxLayout(left); left_l.setContentsMargins(4, 0, 4, 0); left_l.setSpacing(4)
        self.open_btn = QPushButton("Відкрити DICOM файл / папку"); self.open_btn.clicked.connect(self.choose_path); left_l.addWidget(self.open_btn)
        self.series_combo = QComboBox(); self.series_combo.currentIndexChanged.connect(self.series_changed); left_l.addWidget(QLabel("Series Selector:")); left_l.addWidget(self.series_combo)
        self.load_series_btn = QPushButton("Завантажити вибрану серію"); self.load_series_btn.clicked.connect(self.load_selected_series); self.load_series_btn.setEnabled(False); left_l.addWidget(self.load_series_btn)
        self.navigator = QTreeWidget()
        self.navigator.setHeaderLabels(["Навігатор дослідження"])
        self.navigator.itemDoubleClicked.connect(self.navigator_activated)
        self.navigator.setMinimumHeight(85); self.navigator.setMaximumHeight(125)
        left_l.addWidget(self.navigator)
        self.status = QLabel("Очікування відкриття DICOM..."); self.status.setWordWrap(True); self.status.setMaximumHeight(70); left_l.addWidget(self.status)
        self.hardware_status = QLabel(f"Рекомендований 3D режим: {self.hardware_profile.recommended_3d_mode}. {self.hardware_profile.note}"); self.hardware_status.setWordWrap(True); self.hardware_status.setMaximumHeight(70); left_l.addWidget(self.hardware_status)
        self.series_quality_status = QLabel("Series Quality: очікування DICOM…")
        self.series_quality_status.setObjectName("InfoText")
        self.series_quality_status.setWordWrap(True)
        self.series_quality_status.setMaximumHeight(92)
        self.series_quality_status.setToolTip("Автоматичний аналіз апарата, товщини зрізів, spacing і профілю візуалізації")
        left_l.addWidget(self.series_quality_status)
        self.progress = QProgressBar(); self.progress.setRange(0,0); self.progress.setFormat("Завантаження DICOM…"); self.progress.hide(); left_l.addWidget(self.progress)

        wg = QGroupBox("Window / Level"); fl = QFormLayout(wg)
        self.center_spin = QSpinBox(); self.center_spin.setRange(-5000, 10000); self.center_spin.setValue(40); self.center_spin.valueChanged.connect(self.on_window)
        self.width_spin = QSpinBox(); self.width_spin.setRange(1, 20000); self.width_spin.setValue(400); self.width_spin.valueChanged.connect(self.on_window)
        self.preset_combo = QComboBox(); self.preset_combo.addItems(["Auto", "Brain Soft W100 C35", "Brain W80 C35", "Stroke W40 C40", "Bone W2000 C500", "Lung W1500 C-600", "Mediastinum W400 C40", "Angio W700 C250"]); self.preset_combo.currentTextChanged.connect(self.apply_window_preset)
        fl.addRow("Preset", self.preset_combo)
        fl.addRow("Center", self.center_spin); fl.addRow("Width", self.width_spin); left_l.addWidget(wg)

        qg = QGroupBox("Якість 2D")
        ql = QFormLayout(qg)
        self.quality_combo = QComboBox(); self.quality_combo.addItems(["Fidelity Max (MPR/Protocol)", "Cubic/Smooth (soft tissue)", "Linear/Bilinear soft", "Lanczos (bone/detail)", "Nearest"])
        self.quality_combo.setCurrentIndex(0); self.quality_combo.currentTextChanged.connect(lambda t: self.set_render_quality(t))
        self.protocol_overlay_check = QCheckBox("Показувати маску протоколу на 2D/MPR")
        self.protocol_overlay_check.setChecked(True)
        self.protocol_overlay_check.toggled.connect(lambda v: (setattr(self, "show_protocol_2d_overlay", bool(v)), self.update_views()))
        self.fit_combo = QComboBox(); self.fit_combo.addItems(["Fit-to-window", "Fit anatomy (manual)", "1:1 pixel", "Fit no crop"]); self.fit_combo.currentTextChanged.connect(self.on_fit_combo)
        self.fit_combo.setCurrentIndex(0)
        self.sharp_combo = QComboBox(); self.sharp_combo.addItems(["Brain Fidelity PRO", "Brain Fidelity Ultra", "Brain Bilateral PRO", "ITK Anisotropic CT Brain", "ITK Anisotropic Strong", "Syngo soft brain (max)", "CT Brain fidelity (strong)", "Brain smooth (less noise)", "CLAHE Low", "CLAHE Medium", "CLAHE Angio", "Off / raw diagnostic", "Low medical sharpen", "Medium"]); self.sharp_combo.currentTextChanged.connect(self.on_sharpen_combo)
        ql.addRow("Interpolation", self.quality_combo); ql.addRow("Display", self.fit_combo); ql.addRow("Sharpness", self.sharp_combo); ql.addRow("Protocol overlay", self.protocol_overlay_check)
        left_l.addWidget(qg)

        mg = QGroupBox("Measurements")
        ml = QFormLayout(mg)
        self.measure_combo = QComboBox(); self.measure_combo.addItems(["ruler", "distance", "angle", "rect_roi", "circle_roi", "polygon_roi", "hu", "none"]); self.measure_combo.currentTextChanged.connect(self.set_measure_mode)
        self.measure_result = QLabel("Лінійка/ruler: 2 кліки у 2D/MPR. ROI: rect/circle — 2 кліки, polygon — 4 кліки."); self.measure_result.setWordWrap(True)
        ml.addRow("Mode", self.measure_combo); ml.addRow("Result", self.measure_result); left_l.addWidget(mg)

        sg = QGroupBox("Segmentation Basic")
        sl = QVBoxLayout(sg)
        self.seg_min = QSpinBox(); self.seg_min.setRange(-2000, 4000); self.seg_min.setValue(300); self.seg_min.setMinimumWidth(92); self.seg_min.setToolTip("Нижня межа сегментації в HU")
        self.seg_max = QSpinBox(); self.seg_max.setRange(-2000, 4000); self.seg_max.setValue(3000); self.seg_max.setMinimumWidth(92); self.seg_max.setToolTip("Верхня межа сегментації в HU")
        seg_grid = QGridLayout(); seg_grid.setHorizontalSpacing(8); seg_grid.setVerticalSpacing(4)
        lab_min = QLabel("Min HU"); lab_min.setObjectName("SmallLabel")
        lab_max = QLabel("Max HU"); lab_max.setObjectName("SmallLabel")
        seg_grid.addWidget(lab_min, 0, 0); seg_grid.addWidget(self.seg_min, 0, 1)
        seg_grid.addWidget(lab_max, 1, 0); seg_grid.addWidget(self.seg_max, 1, 1)
        seg_grid.setColumnStretch(2, 1)
        sl.addLayout(seg_grid)
        b1=QPushButton("Кістки"); b1.clicked.connect(lambda: (self._apply_segmentation_defaults("bones"), self.run_segmentation("bones"))); sl.addWidget(b1)
        b2=QPushButton("Легені"); b2.clicked.connect(lambda: (self._apply_segmentation_defaults("lungs"), self.run_segmentation("lungs"))); sl.addWidget(b2)
        b3=QPushButton("Судини/контраст"); b3.clicked.connect(lambda: (self._apply_segmentation_defaults("vessels"), self.run_segmentation("vessels"))); sl.addWidget(b3)
        b_stl=QPushButton("Експорт маски STL"); b_stl.clicked.connect(lambda: self.export_mask_model("stl")); sl.addWidget(b_stl)
        b_obj=QPushButton("Експорт маски OBJ / PLY / GLB"); b_obj.clicked.connect(lambda: self.export_mask_model("auto")); sl.addWidget(b_obj)
        b_anon=QPushButton("Анонімний ZIP серії"); b_anon.clicked.connect(self.anonymize_current_series); sl.addWidget(b_anon)
        self.seg_preset_info = QLabel("Поточний пресет: кістки 300…3000 HU")
        self.seg_preset_info.setWordWrap(True); self.seg_preset_info.setObjectName("InfoText")
        sl.addWidget(self.seg_preset_info)
        self.seg_info = QLabel("Маска ще не створена."); self.seg_info.setWordWrap(True); sl.addWidget(self.seg_info)
        left_l.addWidget(sg)

        log_group = QGroupBox("Системний журнал")
        log_layout = QVBoxLayout(log_group); log_layout.setContentsMargins(6, 5, 6, 5); log_layout.setSpacing(3)
        self.log_small = QTextEdit(); self.log_small.setReadOnly(True); self.log_small.setMinimumHeight(88); self.log_small.setMaximumHeight(118); self.log_small.setLineWrapMode(QTextEdit.WidgetWidth)
        log_layout.addWidget(self.log_small)
        left_l.addWidget(log_group)
        left_l.addStretch(1)
        left_scroll = QScrollArea(); left_scroll.setWidgetResizable(True); left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); left_scroll.setWidget(left)
        left_scroll.setMaximumWidth(365); left_scroll.setMinimumWidth(295)
        splitter.addWidget(left_scroll)
        self.left_panel = left_scroll

        self.tabs = QTabWidget(); self.tabs.setMinimumWidth(900); self.tabs.setUsesScrollButtons(True); self.tabs.setElideMode(Qt.ElideNone); self.tabs.currentChanged.connect(self.on_main_tab_changed); splitter.addWidget(self.tabs)

        right = QWidget(); right.setMaximumWidth(260); right.setMinimumWidth(210); right_l = QVBoxLayout(right)
        right_l.setContentsMargins(6, 0, 0, 0)
        right_l.setSpacing(8)
        def _card(title_text: str):
            frame = QFrame(); frame.setObjectName("InspectorCard")
            lay = QVBoxLayout(frame); lay.setContentsMargins(9, 7, 9, 7); lay.setSpacing(4)
            h = QLabel(title_text); h.setObjectName("AppTitle"); h.setStyleSheet("font-size:11pt; font-weight:800;")
            lay.addWidget(h)
            return frame, lay

        card1, card1_l = _card("Стан дослідження")
        self.ui_patient_card = QLabel("Пацієнт: —\nСерія: —\nОб’єм: —")
        self.ui_patient_card.setWordWrap(True)
        self.ui_patient_card.setObjectName("InfoText")
        card1_l.addWidget(self.ui_patient_card)
        right_l.addWidget(card1)

        card2, card2_l = _card("Швидкі клінічні інструменти")
        for text, target in [("ROI / HU", "MIP / MinIP / AvgIP"), ("Report", "Звіти"), ("3D", "3D VTK"), ("Cine", "Cine")]:
            b = QPushButton(text); b.setProperty("modeButton", True)
            b.clicked.connect(lambda _=False, name=target: self.switch_tab(name))
            card2_l.addWidget(b)
        right_l.addWidget(card2)

        card3, card3_l = _card("Адаптація під ПК")
        self.ui_hardware_card = QLabel(f"3D режим: {self.hardware_profile.recommended_3d_mode}\n{self.hardware_profile.note}")
        self.ui_hardware_card.setWordWrap(True)
        self.ui_hardware_card.setObjectName("InfoText")
        card3_l.addWidget(self.ui_hardware_card)
        right_l.addWidget(card3)

        card4, card4_l = _card("Системна діагностика")
        self.ui_diag_card = QLabel("Логи: активні\nFallback: увімкнено\nVTK: lazy-start")
        self.ui_diag_card.setWordWrap(True)
        self.ui_diag_card.setObjectName("InfoText")
        card4_l.addWidget(self.ui_diag_card)
        right_l.addWidget(card4)
        right_l.addStretch(1)
        right_scroll = QScrollArea(); right_scroll.setWidgetResizable(True); right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); right_scroll.setWidget(right)
        right_scroll.setMaximumWidth(275); right_scroll.setMinimumWidth(215)
        splitter.addWidget(right_scroll)
        self.right_panel = right_scroll
        splitter.setStretchFactor(0, 0); splitter.setStretchFactor(1, 10); splitter.setStretchFactor(2, 0); splitter.setSizes([270, 1500, 240])

        self.img2d = ImageLabel(); self.img2d.plane="axial"; self._wire_label(self.img2d); self.img2d.on_slice_step = self.step_active_2d_plane
        t2 = QWidget(); l2=QVBoxLayout(t2)
        self.slice_slider=QSlider(Qt.Horizontal); self.slice_slider.valueChanged.connect(self.on_primary_slice_slider)
        ruler_row = QHBoxLayout()
        self.primary_plane_combo = QComboBox(); self.primary_plane_combo.addItems(["Axial", "Coronal", "Sagittal"])
        self.primary_plane_combo.currentTextChanged.connect(lambda _t: self.on_primary_plane_changed())
        ruler_row.addWidget(QLabel("Площина 2D")); ruler_row.addWidget(self.primary_plane_combo)
        self.b_2d_ruler = QPushButton("2D лінійка"); self.b_2d_ruler.setCheckable(True)
        self.b_2d_ruler.clicked.connect(lambda checked: self.activate_2d_ruler(bool(checked)))
        self.b_crosshair_main = QPushButton("Жовті лінії: ON" if self.show_crosshair_lines else "Жовті лінії: OFF"); self.b_crosshair_main.setCheckable(True); self.b_crosshair_main.setChecked(bool(self.show_crosshair_lines))
        self.b_crosshair_main.clicked.connect(lambda checked: self.set_crosshair_visible(bool(checked)))
        self.viewer_measure_status = QLabel("Лінійка: натисніть кнопку і поставте 2 точки на знімку.")
        self.viewer_measure_status.setWordWrap(True)
        ruler_row.addWidget(self.b_2d_ruler); ruler_row.addWidget(self.b_crosshair_main); ruler_row.addWidget(self.viewer_measure_status, 1)
        l2.addWidget(self.slice_slider); l2.addLayout(ruler_row); l2.addWidget(self.img2d,1); self.tabs.addTab(t2,"2D")

        tc = QWidget(); self.tab_cine = tc; lc = QVBoxLayout(tc)
        cine_row = QHBoxLayout()
        self.cine_play_btn = QPushButton("▶ Play")
        self.cine_play_btn.clicked.connect(self.toggle_cine)
        self.cine_prev_btn = QPushButton("◀ Кадр")
        self.cine_prev_btn.clicked.connect(lambda: self.step_cine(-1))
        self.cine_next_btn = QPushButton("Кадр ▶")
        self.cine_next_btn.clicked.connect(lambda: self.step_cine(1))
        self.cine_fps = QDoubleSpinBox(); self.cine_fps.setRange(1.0, 60.0); self.cine_fps.setValue(15.0); self.cine_fps.setSuffix(" fps")
        self.cine_loop = QCheckBox("Loop"); self.cine_loop.setChecked(True)
        self.cine_lock_view = QCheckBox("Lock viewport"); self.cine_lock_view.setChecked(True)
        self.cine_info = QLabel("Cine/Angio: відкрийте XA/XRF/RF multi-frame DICOM або ангіографічну серію.")
        cine_row.addWidget(self.cine_play_btn); cine_row.addWidget(self.cine_prev_btn); cine_row.addWidget(self.cine_next_btn); cine_row.addWidget(QLabel("FPS")); cine_row.addWidget(self.cine_fps); cine_row.addWidget(self.cine_loop); cine_row.addWidget(self.cine_lock_view); cine_row.addWidget(self.cine_info,1)
        cine_tools = QHBoxLayout(); cine_tools.setSpacing(6)
        self.cine_mask_frame = QSpinBox(); self.cine_mask_frame.setRange(1, 99999); self.cine_mask_frame.setValue(1); self.cine_mask_frame.setToolTip("Кадр-маска для DSA subtraction")
        self.cine_dsa_check = QCheckBox("DSA")
        self.cine_enhance_check = QCheckBox("Enhance")
        self.cine_profile_btn = QPushButton("Analyze XA/XRF") ; self.cine_profile_btn.clicked.connect(self.cine_profile_ui)
        self.cine_png_btn = QPushButton("Export PNG seq") ; self.cine_png_btn.clicked.connect(self.export_cine_png_sequence_ui)
        self.cine_gif_btn = QPushButton("Export GIF"); self.cine_gif_btn.clicked.connect(lambda: self.export_cine("gif"))
        self.cine_mp4_btn = QPushButton("Export MP4"); self.cine_mp4_btn.clicked.connect(lambda: self.export_cine("mp4"))
        for w in [QLabel("Mask"), self.cine_mask_frame, self.cine_dsa_check, self.cine_enhance_check, self.cine_profile_btn, self.cine_png_btn, self.cine_gif_btn, self.cine_mp4_btn]:
            cine_tools.addWidget(w)
        cine_tools.addStretch(1)
        self.cine_slider = QSlider(Qt.Horizontal); self.cine_slider.valueChanged.connect(self.set_cine_frame)
        self.cine_label = ImageLabel(); self.cine_label.plane="cine"; self._wire_label(self.cine_label); self.cine_label.on_slice_step = self.step_slice
        lc.addLayout(cine_row); lc.addLayout(cine_tools); lc.addWidget(self.cine_slider); lc.addWidget(self.cine_label, 1)
        self.tabs.addTab(tc, "Cine")

        tm = QWidget(); lm = QGridLayout(tm)
        self.axial_label = ImageLabel(); self.axial_label.plane="axial"
        self.coronal_label = ImageLabel(); self.coronal_label.plane="coronal"
        self.sagittal_label = ImageLabel(); self.sagittal_label.plane="sagittal"
        for lab in (self.axial_label, self.coronal_label, self.sagittal_label):
            self._wire_label(lab)
            lab.on_slice_step = (lambda step, plane=lab.plane: self.step_slice_plane(plane, step))
            lab.on_view_double_click = self.promote_mpr_plane_to_2d
            lab.setMinimumSize(420, 420)
        self.axial_slider = QSlider(Qt.Horizontal); self.coronal_slider = QSlider(Qt.Horizontal); self.sagittal_slider = QSlider(Qt.Horizontal)
        self.axial_slider.valueChanged.connect(self.on_axial_mpr_slider)
        self.coronal_slider.valueChanged.connect(self.on_coronal_mpr_slider)
        self.sagittal_slider.valueChanged.connect(self.on_sagittal_mpr_slider)
        lm.addWidget(QLabel("Axial"),0,0); lm.addWidget(QLabel("Coronal"),0,1); lm.addWidget(QLabel("Sagittal"),0,2)
        lm.addWidget(self.axial_label,1,0); lm.addWidget(self.coronal_label,1,1); lm.addWidget(self.sagittal_label,1,2)
        lm.addWidget(self.axial_slider,2,0); lm.addWidget(self.coronal_slider,2,1); lm.addWidget(self.sagittal_slider,2,2)
        lm.setColumnStretch(0, 1); lm.setColumnStretch(1, 1); lm.setColumnStretch(2, 1); lm.setRowStretch(1, 1)
        self.tabs.addTab(tm,"MPR")

        self.proj_label = ImageLabel(); self.proj_label.plane="projection"; self._wire_label(self.proj_label)
        self.proj_combo=QComboBox(); self.proj_combo.addItems(["MIP","MinIP","AvgIP"]); self.proj_combo.currentTextChanged.connect(self.update_projection)
        self.proj_axis=QComboBox(); self.proj_axis.addItems(["axial","coronal","sagittal"]); self.proj_axis.currentTextChanged.connect(self.update_projection)
        tp=QWidget(); lp=QVBoxLayout(tp); pr=QHBoxLayout(); pr.addWidget(QLabel("Projection")); pr.addWidget(self.proj_combo); pr.addWidget(QLabel("Axis")); pr.addWidget(self.proj_axis); lp.addLayout(pr); lp.addWidget(self.proj_label,1); self.tabs.addTab(tp,"MIP")

        ts = QWidget(); tls=QVBoxLayout(ts); self.seg_preview = ImageLabel(); self.seg_preview.plane="segmentation"; tls.addWidget(self.seg_preview, 1); self.tabs.addTab(ts, "Seg")

        t3 = QWidget(); l3=QVBoxLayout(t3)
        row3 = QHBoxLayout()
        self.vtk_mode = QComboBox(); self.vtk_mode.addItems(["Legacy Head/Face 3D (old)", "Modern VTK Volume Rendering", "VTK Volume Rendering", "VTK Surface Safe", "Auto Safe / старий ПК", "MIP Preview без OpenGL"])
        # Lite keeps two workflows: Legacy Head/Face uses the proven older visual
        # look, while Modern keeps ruler/knife/clip controls.  Both are still the
        # same core VTK viewer; no AI/Enterprise runtime is imported.
        self.vtk_mode.setCurrentText("Legacy Head/Face 3D (old)")
        self.vtk_preset = QComboBox(); self.vtk_preset.addItems(["Classic Hospital", "Classic Lung", "Classic Lung Fidelity", "Classic Bone", "Classic Soft Tissue", "Classic Anatomy", "Bone Ultra", "Brain Hemorrhage", "Brain Transparent", "Color anatomy", "Skin_Muscle", "Soft tissue", "Lung", "Air", "Bone", "Bone Color", "Angio_MIP", "Vessel Ultra", "MIP", "Vessel", "Tumor Ultra", "Fracture Ultra"])
        self.vtk_preset.currentTextChanged.connect(self.apply_3d_transfer_preset)
        self.vtk_threshold = QSlider(Qt.Horizontal); self.vtk_threshold.setRange(-1000, 1500); self.vtk_threshold.setValue(200); self.vtk_threshold.setMinimumWidth(190); self.vtk_threshold.valueChanged.connect(self.update_3d_threshold)
        self.vtk_threshold_label = QLabel("Density: +200 HU")
        build3=QPushButton("Побудувати / оновити 3D")
        build3.clicked.connect(self.build_3d)
        self.vtk_mip_btn = QPushButton("MIP судини") ; self.vtk_mip_btn.setCheckable(True); self.vtk_mip_btn.toggled.connect(self.toggle_3d_mip)
        self.vtk_sub_btn = QPushButton("Sub-Tissue +200 HU") ; self.vtk_sub_btn.clicked.connect(self.apply_3d_sub_tissue)
        self.vtk_clip_check = QCheckBox("Clip Box / 3D ніж"); self.vtk_clip_check.toggled.connect(self.toggle_3d_clip_box)
        self.vtk_clip_nav_check = QCheckBox("Clip Navigate")
        self.vtk_clip_nav_check.setToolTip("Одна площина відсікання: колесо миші або повзунок рухають зріз всередину черепа/грудної клітки без zoom-конфлікту.")
        self.vtk_clip_nav_check.toggled.connect(self.toggle_3d_clip_navigate)
        self.vtk_clip_reset_btn = QPushButton("Reset Clip"); self.vtk_clip_reset_btn.clicked.connect(self.reset_3d_clip)
        self.vtk_ruler_check = QCheckBox("3D лінійка")
        self.vtk_ruler_check.toggled.connect(self.toggle_3d_ruler)
        row3.addWidget(QLabel("3D режим")); row3.addWidget(self.vtk_mode)
        row3.addWidget(QLabel("Preset")); row3.addWidget(self.vtk_preset)
        row3.addWidget(build3); row3.addWidget(self.vtk_mip_btn); row3.addWidget(self.vtk_sub_btn); row3.addWidget(self.vtk_clip_check); row3.addWidget(self.vtk_clip_nav_check); row3.addWidget(self.vtk_clip_reset_btn); row3.addWidget(self.vtk_ruler_check); l3.addLayout(row3)
        row3b = QHBoxLayout(); row3b.addWidget(QLabel("Density Threshold / прозорість по HU")); row3b.addWidget(self.vtk_threshold); row3b.addWidget(self.vtk_threshold_label); l3.addLayout(row3b)
        row3clip = QHBoxLayout()
        self.vtk_clip_depth = QSlider(Qt.Horizontal); self.vtk_clip_depth.setRange(0,100); self.vtk_clip_depth.setValue(50); self.vtk_clip_depth.valueChanged.connect(self.update_3d_clip_depth)
        self.vtk_clip_depth_label = QLabel("Clip depth: 50%")
        row3clip.addWidget(QLabel("Плавний 3D ніж / глибина всередину")); row3clip.addWidget(self.vtk_clip_depth); row3clip.addWidget(self.vtk_clip_depth_label)
        l3.addLayout(row3clip)
        row3slab = QHBoxLayout()
        self.vtk_slab_mode = QComboBox(); self.vtk_slab_mode.addItems(["Off", "MIP", "MinIP", "Average"])
        self.vtk_slab_thick = QDoubleSpinBox(); self.vtk_slab_thick.setRange(0.5, 50.0); self.vtk_slab_thick.setValue(1.0); self.vtk_slab_thick.setSuffix(" mm")
        self.vtk_slab_status = QLabel("Slab: Off")
        self.vtk_slab_mode.currentTextChanged.connect(self.update_3d_slab_settings)
        self.vtk_slab_thick.valueChanged.connect(lambda _v: self.update_3d_slab_settings())
        row3slab.addWidget(QLabel("Slab MPR")); row3slab.addWidget(self.vtk_slab_mode); row3slab.addWidget(QLabel("Thickness")); row3slab.addWidget(self.vtk_slab_thick); row3slab.addWidget(self.vtk_slab_status, 1)
        l3.addLayout(row3slab)
        row3clean = QHBoxLayout()
        self.clean_3d_apply_btn = QPushButton("Очистити від артефактів")
        self.clean_3d_apply_btn.setToolTip("Після побудови 3D створює тільки маску зовнішніх артефактів. Оригінальний Volume Rendering не змінюється.")
        self.clean_3d_apply_btn.clicked.connect(self.apply_post_3d_artifact_cleaner)
        self.clean_3d_restore_btn = QPushButton("Відновити оригінал")
        self.clean_3d_restore_btn.clicked.connect(self.restore_original_3d_model)
        self.clean_3d_strength = QSlider(Qt.Horizontal); self.clean_3d_strength.setRange(0, 100); self.clean_3d_strength.setValue(45); self.clean_3d_strength.setMaximumWidth(150)
        self.clean_3d_strength_label = QLabel("Сила 45%")
        self.clean_3d_strength.valueChanged.connect(lambda v: self.clean_3d_strength_label.setText(f"Сила {int(v)}%"))
        self.clean_3d_mode = QComboBox(); self.clean_3d_mode.addItems(["Mask-only external", "Conservative skull", "Body/table edge"])
        self.clean_3d_threshold = QSpinBox(); self.clean_3d_threshold.setRange(-1000, 3000); self.clean_3d_threshold.setValue(180); self.clean_3d_threshold.setSuffix(" HU")
        self.clean_3d_min_vox = QSpinBox(); self.clean_3d_min_vox.setRange(1, 10000000); self.clean_3d_min_vox.setValue(1500); self.clean_3d_min_vox.setToolTip("Мінімальний розмір зовнішнього компонента")
        self.clean_3d_status = QLabel("Artifact Clean OFF: оригінальна 3D модель")
        row3clean.addWidget(self.clean_3d_apply_btn); row3clean.addWidget(self.clean_3d_strength); row3clean.addWidget(self.clean_3d_strength_label)
        row3clean.addWidget(self.clean_3d_restore_btn); row3clean.addWidget(QLabel("Mode")); row3clean.addWidget(self.clean_3d_mode); row3clean.addWidget(QLabel("Threshold")); row3clean.addWidget(self.clean_3d_threshold); row3clean.addWidget(QLabel("Min vox")); row3clean.addWidget(self.clean_3d_min_vox); row3clean.addWidget(self.clean_3d_status, 1)
        l3.addLayout(row3clean)
        self.vtk_viewer = VtkVolumeViewer(); l3.addWidget(self.vtk_viewer,1); self.tabs.addTab(t3,"3D")

        row3ai = QHBoxLayout()
        self.ai_analyze_btn = QPushButton("AI Analyze Study")
        self.ai_analyze_btn.setToolTip("Запускає Hemorrhage, Fracture, Vessel, Tumor, Stroke, Organ PRO та додає 3D overlay-и.")
        self.ai_analyze_btn.clicked.connect(self.run_enterprise_ai_suite_ui)
        self.ai_overlay_btn = QPushButton("Показати AI 3D overlay")
        self.ai_overlay_btn.clicked.connect(self.show_ai_overlays_3d_ui)
        self.ai_export_btn = QPushButton("Export AI STL/PLY/OBJ")
        self.ai_export_btn.clicked.connect(self.export_ai_meshes_ui)
        self.bone_ultra_btn = QPushButton("Bone Ultra Quality")
        self.bone_ultra_btn.clicked.connect(self.apply_bone_ultra_3d_ui)
        self.ai_summary_label = QLabel("AI Suite: не запущено")
        self.ai_summary_label.setWordWrap(True)
        for _w in (self.ai_analyze_btn, self.ai_overlay_btn, self.ai_export_btn, self.bone_ultra_btn, self.ai_summary_label):
            row3ai.addWidget(_w)
        row3ai.addStretch(1)
        # v7.2 Visualization Upgrade: remove the old bottom AI/test command row from the 3D viewport.
        # Protocols and overlays are launched from the top menu/right report panel, so the lower
        # part of the 3D scene stays free for visualization.
        for _w in (self.ai_analyze_btn, self.ai_overlay_btn, self.ai_export_btn, self.bone_ultra_btn, self.ai_summary_label):
            _w.hide()
        # row3ai is intentionally not added to l3.

        # RC5: separate Legacy 3D tab using old-style renderer, isolated from ruler/knife/masks.
        tleg = QWidget(); lleg = QVBoxLayout(tleg)
        rowleg = QHBoxLayout()
        self.legacy3d_build_btn = QPushButton("Побудувати Legacy 3D / old render")
        self.legacy3d_build_btn.clicked.connect(self.build_legacy_3d)
        self.legacy3d_status = QLabel("Legacy 3D: старий Head/Face рендер без ножа, масок і агресивної фільтрації")
        self.legacy3d_status.setWordWrap(True)
        rowleg.addWidget(self.legacy3d_build_btn); rowleg.addWidget(self.legacy3d_status, 1)
        lleg.addLayout(rowleg)
        self.legacy_vtk_viewer = VtkVolumeViewer(); lleg.addWidget(self.legacy_vtk_viewer, 1)
        self._legacy3d_tab = tleg  # hidden in v7: use 3D -> Legacy Head/Face 3D (old) instead of duplicate tab

        # Lite: Organ 3D / TotalSegmentator panel is external plugin-only.
        self.organ_seg_panel = None

        self.tags = QTextEdit(); self.tags.setReadOnly(True); self.tabs.addTab(self.tags,"Tags")
        self.logs = QTextEdit(); self.logs.setReadOnly(True); self.tabs.addTab(self.logs,"Log")

        tpacs = QWidget(); lpacs = QVBoxLayout(tpacs)
        pf = QFormLayout()
        self.pacs_ae = QLineEdit("DICOMVIEW")
        self.pacs_peer = QLineEdit("ANY-SCP")
        self.pacs_host = QLineEdit("127.0.0.1")
        self.pacs_port = QSpinBox(); self.pacs_port.setRange(1, 65535); self.pacs_port.setValue(104)
        self.pacs_patient = QLineEdit("*")
        pf.addRow("Local AE", self.pacs_ae); pf.addRow("PACS AE", self.pacs_peer); pf.addRow("Host", self.pacs_host); pf.addRow("Port", self.pacs_port); pf.addRow("Patient", self.pacs_patient)
        lpacs.addLayout(pf)
        prow = QHBoxLayout()
        b_echo = QPushButton("C-ECHO") ; b_echo.clicked.connect(self.pacs_echo_ui)
        b_find = QPushButton("C-FIND Studies") ; b_find.clicked.connect(self.pacs_find_ui)
        b_store = QPushButton("C-STORE файл") ; b_store.clicked.connect(self.pacs_store_ui)
        prow.addWidget(b_echo); prow.addWidget(b_find); prow.addWidget(b_store); prow.addStretch(1)
        lpacs.addLayout(prow)
        self.pacs_output = QTextEdit(); self.pacs_output.setReadOnly(True); lpacs.addWidget(self.pacs_output, 1)
        self.tabs.addTab(tpacs, "PACS")


        torth = QWidget(); lorth = QVBoxLayout(torth)
        of = QFormLayout()
        self.orthanc_url = QLineEdit("http://127.0.0.1:8042")
        self.orthanc_user = QLineEdit("")
        self.orthanc_pass = QLineEdit(""); self.orthanc_pass.setEchoMode(QLineEdit.Password)
        self.orthanc_patient = QLineEdit("*")
        of.addRow("Orthanc URL", self.orthanc_url); of.addRow("User", self.orthanc_user); of.addRow("Password", self.orthanc_pass); of.addRow("Patient search", self.orthanc_patient)
        lorth.addLayout(of)
        orow = QHBoxLayout()
        b_osys = QPushButton("Перевірити Orthanc"); b_osys.clicked.connect(self.orthanc_check_ui)
        b_ostu = QPushButton("Список досліджень"); b_ostu.clicked.connect(self.orthanc_studies_ui)
        b_osearch = QPushButton("Пошук пацієнта"); b_osearch.clicked.connect(self.orthanc_search_ui)
        b_odl = QPushButton("Download Series ZIP"); b_odl.clicked.connect(self.orthanc_download_series_ui)
        b_oup = QPushButton("Upload DICOM файл"); b_oup.clicked.connect(self.orthanc_upload_ui)
        orow.addWidget(b_osys); orow.addWidget(b_ostu); orow.addWidget(b_osearch); orow.addWidget(b_odl); orow.addWidget(b_oup); orow.addStretch(1)
        lorth.addLayout(orow)
        self.orthanc_output = QTextEdit(); self.orthanc_output.setReadOnly(True); lorth.addWidget(self.orthanc_output, 1)
        self.tabs.addTab(torth, "Orthanc")

        trep = QWidget(); lrep = QVBoxLayout(trep)
        self.report_info = QLabel("Звіт бере поточні DICOM-метадані, вимірювання ROI/HU і коротку інформацію про серію.")
        self.report_info.setWordWrap(True); lrep.addWidget(self.report_info)
        rrow = QHBoxLayout()
        b_pdf = QPushButton("Створити PDF звіт"); b_pdf.clicked.connect(lambda: self.create_report_ui("pdf"))
        b_docx = QPushButton("Створити DOCX звіт"); b_docx.clicked.connect(lambda: self.create_report_ui("docx"))
        b_json = QPushButton("Зберегти JSON протоколу"); b_json.clicked.connect(self.save_protocol_json_ui)
        b_txt = QPushButton("Зберегти TXT протоколу"); b_txt.clicked.connect(self.save_protocol_txt_ui)
        rrow.addWidget(b_pdf); rrow.addWidget(b_docx); rrow.addWidget(b_json); rrow.addWidget(b_txt); rrow.addStretch(1)
        lrep.addLayout(rrow)
        self.report_output = QTextEdit(); self.report_output.setReadOnly(True); lrep.addWidget(self.report_output, 1)
        self.tabs.addTab(trep, "Звіт")

        # Lite: Radiomics, Cases, Vessel Analysis, Angio 3D and 4D are Enterprise plugins.
        # Lite: AI tab is disabled. Heavy AI runtimes load only via external plugins.
        self.ai_output = QTextEdit(); self.ai_output.setReadOnly(True)
        self.ai_preview = None
        tsettings = QWidget(); lsettings = QVBoxLayout(tsettings)
        settings_title = QLabel("Налаштування інтерфейсу / Interface Settings")
        settings_title.setStyleSheet("font-size:13pt; font-weight:800;")
        lsettings.addWidget(settings_title)
        form_settings = QFormLayout()
        self.language_combo = QComboBox(); self.language_combo.addItem("Українська", "uk"); self.language_combo.addItem("English", "en")
        self.theme_combo = QComboBox(); self.theme_combo.addItem("Темна / Dark", "dark"); self.theme_combo.addItem("Світла / Light", "light")
        self.language_combo.setCurrentIndex(0 if self.ui_language == "uk" else 1)
        self.theme_combo.setCurrentIndex(0 if self.ui_theme == "dark" else 1)
        self.language_combo.currentIndexChanged.connect(lambda: self.set_ui_language(self.language_combo.currentData()))
        self.theme_combo.currentIndexChanged.connect(lambda: self.set_ui_theme(self.theme_combo.currentData()))
        self.crosshair_check = QCheckBox("Показувати жовті лінії центрування / Show yellow crosshair")
        self.crosshair_check.setChecked(bool(self.show_crosshair_lines))
        self.crosshair_check.toggled.connect(self.set_crosshair_visible)
        form_settings.addRow("Мова / Language", self.language_combo)
        form_settings.addRow("Тема / Theme", self.theme_combo)
        form_settings.addRow("Центрування", self.crosshair_check)
        lsettings.addLayout(form_settings)
        self.settings_hint = QLabel("Налаштування зберігаються автоматично. Частина підписів оновлюється одразу, повний переклад застосовується після перезапуску програми.")
        self.settings_hint.setWordWrap(True)
        lsettings.addWidget(self.settings_hint)
        lsettings.addStretch(1)
        self.tabs.addTab(tsettings, "Налаштування")

        tfound = QWidget(); lfound = QVBoxLayout(tfound)
        self.foundation_output = QTextEdit(); self.foundation_output.setReadOnly(True)
        self.foundation_output.setPlainText(clinical_foundation_report(self.hardware_profile.note))
        b_found_refresh = QPushButton("Оновити статус модулів")
        b_found_refresh.clicked.connect(lambda: self.foundation_output.setPlainText(clinical_foundation_report(self.hardware_profile.note)))
        lfound.addWidget(QLabel("Стабільна основа клінічних модулів із fallback для старих ПК"))
        lfound.addWidget(b_found_refresh)
        lfound.addWidget(self.foundation_output, 1)

        hem_box = QGroupBox("Hemorrhage 3D PRO / Крововилив КТ голови")
        hem_l = QVBoxLayout(hem_box)
        hem_row = QHBoxLayout()
        self.hem_hu_min = QDoubleSpinBox(); self.hem_hu_min.setRange(20, 130); self.hem_hu_min.setValue(45); self.hem_hu_min.setSuffix(" HU")
        self.hem_hu_max = QDoubleSpinBox(); self.hem_hu_max.setRange(50, 180); self.hem_hu_max.setValue(95); self.hem_hu_max.setSuffix(" HU")
        self.hem_detect_btn = QPushButton("Auto Hemorrhage Detection")
        self.hem_detect_btn.clicked.connect(self.run_hemorrhage_detection_ui)
        self.hem_ghost_btn = QPushButton("Ghost Skull / Brain Hemorrhage 3D")
        self.hem_ghost_btn.clicked.connect(self.show_hemorrhage_3d_ui)
        self.hem_export_btn = QPushButton("Export hemorrhage STL/PLY/OBJ")
        self.hem_export_btn.clicked.connect(self.export_hemorrhage_mesh_ui)
        self.classic_ct_btn = QPushButton("Classic CPU Analyze")
        self.classic_ct_btn.setToolTip("Детермінований CPU-only аналіз: HU крові, 3D морфологія, компоненти, асиметрія мозку.")
        self.classic_ct_btn.clicked.connect(self.run_classic_ct_diagnostics_ui)
        self.classic_ct_3d_btn = QPushButton("Classic Hemorrhage 3D")
        self.classic_ct_3d_btn.clicked.connect(self.show_classic_hemorrhage_3d_ui)
        self.classic_ct_json_btn = QPushButton("Save Classic JSON")
        self.classic_ct_json_btn.clicked.connect(self.save_classic_ct_json_ui)
        hem_row.addWidget(QLabel("Blood HU")); hem_row.addWidget(self.hem_hu_min); hem_row.addWidget(self.hem_hu_max); hem_row.addWidget(self.hem_detect_btn); hem_row.addWidget(self.hem_ghost_btn); hem_row.addWidget(self.hem_export_btn); hem_row.addWidget(self.classic_ct_btn); hem_row.addWidget(self.classic_ct_3d_btn); hem_row.addWidget(self.classic_ct_json_btn)
        hem_l.addLayout(hem_row)
        self.hem_info = QLabel("Volume: — ml | Midline shift: — mm | Confidence: —")
        self.hem_info.setWordWrap(True)
        self.hem_output = QTextEdit(); self.hem_output.setReadOnly(True); self.hem_output.setMaximumHeight(140)
        hem_l.addWidget(self.hem_info); hem_l.addWidget(self.hem_output)
        ai_box = QGroupBox("Enterprise AI Diagnostics Suite v5")
        ai_l = QVBoxLayout(ai_box)
        ai_row = QHBoxLayout()
        self.clinical_ai_analyze_btn = QPushButton("AI Analyze Study")
        self.clinical_ai_analyze_btn.clicked.connect(self.run_enterprise_ai_suite_ui)
        self.clinical_ai_3d_btn = QPushButton("3D Overlay")
        self.clinical_ai_3d_btn.clicked.connect(self.show_ai_overlays_3d_ui)
        self.clinical_ai_export_btn = QPushButton("Export AI meshes")
        self.clinical_ai_export_btn.clicked.connect(self.export_ai_meshes_ui)
        ai_row.addWidget(self.clinical_ai_analyze_btn); ai_row.addWidget(self.clinical_ai_3d_btn); ai_row.addWidget(self.clinical_ai_export_btn); ai_row.addStretch(1)
        ai_l.addLayout(ai_row)
        self.ai_diagnostics_output = QTextEdit(); self.ai_diagnostics_output.setReadOnly(True); self.ai_diagnostics_output.setMaximumHeight(210)
        self.ai_diagnostics_output.setPlainText("Натисніть AI Analyze Study після відкриття DICOM-серії. Модулі працюють у safe fallback без AI-моделей і автоматично використовують SciPy/skimage, якщо вони встановлені.")
        ai_l.addWidget(self.ai_diagnostics_output)
        lfound.addWidget(hem_box)
        lfound.addWidget(ai_box)
        self.tabs.addTab(tfound, "Clinical")

        tplugins = QWidget(); lplugins = QVBoxLayout(tplugins)
        info = QLabel("Lite ядро працює без важких модулів. AI / Slicer / Radiomics / VMTK / TotalSegmentator підключаються як зовнішні plugins і не імпортуються при старті.")
        info.setWordWrap(True)
        lplugins.addWidget(info)
        self.plugin_status_output = QTextEdit(); self.plugin_status_output.setReadOnly(True)
        self.plugin_status_output.setPlainText("AI Diagnostics Suite v5: integrated / ready\nHemorrhage3D PRO: integrated / ready\nFracture/CTA/Tumor/Stroke/Organ PRO: fallback mode ready\nSlicerBridge/VMTK/TotalSegmentator: optional external acceleration")
        lplugins.addWidget(self.plugin_status_output, 1)
        self.tabs.addTab(tplugins, "Plugins")

        # Lite: Slicer/VMTK bridge is optional external plugin; no startup import/UI.
        self.slicer_output = QTextEdit(); self.slicer_output.setReadOnly(True)
        self.system_status = QLabel()
        self.status_label = self.system_status  # Lite/Core background status target
        self.system_status.setWordWrap(True)
        self.system_status.setStyleSheet("background:#06111f; border:1px solid #183b5a; border-radius:10px; padding:7px; color:#bfe6ff;")
        main.addWidget(self.system_status)
        self.update_system_status("Готово")
        self._apply_theme_runtime_styles()
        self._apply_language_runtime()

    def toggle_side_panel(self, side: str):
        """Show/hide side panels without touching clinical logic."""
        if side == "left" and hasattr(self, "left_panel"):
            self.left_panel_visible = not self.left_panel_visible
            self.left_panel.setVisible(self.left_panel_visible)
        elif side == "right" and hasattr(self, "right_panel"):
            self.right_panel_visible = not self.right_panel_visible
            self.right_panel.setVisible(self.right_panel_visible)
        self.update_system_status("Viewer layout оновлено")

    def _apply_startup_diagnostic_layout(self):
        """Start in a clean diagnostic viewer layout.

        Side panels stay available through the Navigator/Tools buttons, but the
        first screen gives most of the space to the image viewer, matching older
        diagnostic workstations more closely.
        """
        if hasattr(self, "left_panel"):
            self.left_panel_visible = False
            self.left_panel.setVisible(False)
        if hasattr(self, "right_panel"):
            self.right_panel_visible = False
            self.right_panel.setVisible(False)
        self.update_system_status("Diagnostic View: панелі приховані, Viewer максимум")

    def switch_tab(self, title: str):
        """UI-only mode switcher. Does not change processing logic."""
        aliases = {
            "Cine / Angio": "Cine",
            "MPR PRO": "MPR",
            "MIP / MinIP / AvgIP": "MIP",
            "Segmentation": "Seg",
            "3D VTK": "3D",
            "DICOM теги": "Tags",
            "Логи": "Log",
            "PACS PRO": "PACS",
            "Звіти": "Звіт",
            "Report": "Звіт",
            "Case Manager": "Cases",
            "Vessel Analysis": "Vessel",
            "3D Angio": "Angio 3D",
            "4D Cardiac": "4D",
            "AI / MONAI": "AI",
            "Clinical Foundation": "Clinical",
            "Slicer Bridge": "Slicer/VMTK",
        }
        wanted = aliases.get(title, title)
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == wanted:
                self.tabs.setCurrentIndex(i)
                self.update_system_status(f"Режим: {wanted}")
                return

    def update_system_status(self, prefix: str = ""):
        hp = self.hardware_profile
        info = []
        if prefix:
            info.append(prefix)
        info.append(f"3D: {hp.recommended_3d_mode}")
        info.append(f"Дані: {data_dir()}")
        info.append(f"Лог: {log_path()}")
        text = "  |  ".join(info)
        if hasattr(self, "system_status"):
            self.system_status.setText(text)
        if hasattr(self, "ui_diag_card"):
            self.ui_diag_card.setText(f"{prefix or 'Готово'}\nДані: {data_dir()}\nЛог: {log_path()}\nFallback: активний")

    def _first_metadata_value(self, *keys: str) -> str:
        """Return first non-empty metadata value from direct keys or DICOM tag names."""
        if not self.metadata:
            return ""
        tags = self.metadata.get("tags", {}) or {}
        for key in keys:
            v = self.metadata.get(key)
            if v not in (None, ""):
                return str(v)
            for tk, tv in tags.items():
                # Match both keyword-like and human DICOM names, e.g. PatientName / Patient's Name.
                if key.lower().replace("_", "") in str(tk).lower().replace(" ", "").replace("'", ""):
                    if tv not in (None, ""):
                        return str(tv)
        return ""

    def update_patient_header(self):
        if not hasattr(self, "patient_header"):
            return
        patient = self._first_metadata_value("patient_name", "patient", "PatientName", "Patient's Name") or "—"
        patient_id = self._first_metadata_value("patient_id", "PatientID", "ID")
        sex = self._first_metadata_value("patient_sex", "PatientSex")
        age = self._first_metadata_value("patient_age", "PatientAge")
        modality = self.metadata.get("modality", "—") if self.metadata else "—"
        desc = self.metadata.get("series_description", "—") if self.metadata else "—"
        shape = "×".join(str(x) for x in self.volume.shape) if self.volume is not None else "—"
        patient_block = patient
        extras = [x for x in (f"ID:{patient_id}" if patient_id else "", sex, age) if x]
        if extras:
            patient_block += " (" + ", ".join(extras) + ")"
        text = f"Пацієнт: {patient_block}   |   {modality}   |   {desc}   |   {shape}"
        self.patient_header.setText(text)
        if hasattr(self, "ui_patient_card"):
            self.ui_patient_card.setText(
                f"Пацієнт: {patient}\n"
                f"ID: {patient_id or '—'}\n"
                f"Стать/вік: {' / '.join([x for x in (sex, age) if x]) or '—'}\n"
                f"Модальність: {modality}\n"
                f"Серія: {desc}\n"
                f"Об’єм: {shape}"
            )

    def update_navigator_tree(self, series: list[dict] | None = None):
        if not hasattr(self, "navigator"):
            return
        self.navigator.clear()
        root = QTreeWidgetItem(["DicomView PRO"])
        self.navigator.addTopLevelItem(root)
        if series:
            study = QTreeWidgetItem([f"Дослідження: {Path(self.current_path).name or self.current_path}"])
            root.addChild(study)
            for s in series:
                label = f"{s.get('modality','')} · {s.get('description','')} · {s.get('count',0)} зрізів"
                item = QTreeWidgetItem([label])
                item.setData(0, Qt.UserRole, s.get("uid"))
                study.addChild(item)
            self.navigator.expandAll()
        elif self.metadata:
            study = QTreeWidgetItem([self.metadata.get("study_description", "Поточне дослідження") or "Поточне дослідження"])
            root.addChild(study)
            item = QTreeWidgetItem([f"{self.metadata.get('modality','')} · {self.metadata.get('series_description','')} · {self.volume.shape[0] if self.volume is not None else 0} зрізів"])
            item.setData(0, Qt.UserRole, self.metadata.get("series_uid", ""))
            study.addChild(item)
            self.navigator.expandAll()
        else:
            root.addChild(QTreeWidgetItem(["Відкрийте DICOM файл або папку"])); self.navigator.expandAll()

    def navigator_activated(self, item: QTreeWidgetItem, column: int):
        uid = item.data(0, Qt.UserRole)
        if uid and self.current_path:
            idx = self.series_combo.findData(uid)
            if idx >= 0:
                self.series_combo.setCurrentIndex(idx)
            else:
                self.start_load(self.current_path, uid)

    def _show_distance_result(self, mm: float) -> None:
        text = f"Лінійка: {mm:.2f} мм"
        if hasattr(self, "measure_result"):
            self.measure_result.setText(text)
        if hasattr(self, "viewer_measure_status"):
            self.viewer_measure_status.setText(text)
        self.measure_history.append(text)

    def _wire_label(self, label: ImageLabel):
        label.measure_mode = self.measure_combo.currentText() if hasattr(self, "measure_combo") else "distance"
        label.on_distance = lambda mm: self._show_distance_result(mm)
        label.on_angle = lambda deg: self.measure_result.setText(f"Кут: {deg:.2f}°")
        label.on_hu = lambda hu, pt: self.measure_result.setText(f"HU у точці {pt}: {hu:.1f}")
        label.on_roi = self.on_roi_measure
        label.on_point = self.on_image_point
        label.show_crosshair = bool(getattr(self, "show_crosshair_lines", True))

    def activate_2d_ruler(self, enabled: bool = True) -> None:
        if enabled:
            if hasattr(self, "measure_combo"):
                self.measure_combo.blockSignals(True); self.measure_combo.setCurrentText("ruler"); self.measure_combo.blockSignals(False)
            self.set_measure_mode("ruler")
            if hasattr(self, "viewer_measure_status"):
                self.viewer_measure_status.setText("2D лінійка увімкнена: поставте дві точки на знімку.")
        else:
            if hasattr(self, "measure_combo"):
                self.measure_combo.blockSignals(True); self.measure_combo.setCurrentText("none"); self.measure_combo.blockSignals(False)
            self.set_measure_mode("none")
            if hasattr(self, "viewer_measure_status"):
                self.viewer_measure_status.setText("2D лінійка вимкнена.")

    def set_measure_mode(self, mode: str):
        self.sam_click_enabled = False
        if hasattr(self, "b_ai_sam_click"):
            self.b_ai_sam_click.setChecked(False)
            self.b_ai_sam_click.setText("Smart Click ROI: OFF")
        if hasattr(self, "b_2d_ruler") and self.b_2d_ruler.isChecked() != (mode == "ruler"):
            self.b_2d_ruler.blockSignals(True); self.b_2d_ruler.setChecked(mode == "ruler"); self.b_2d_ruler.blockSignals(False)
        for lab in [self.img2d, self.axial_label, self.coronal_label, self.sagittal_label, self.proj_label]:
            lab.measure_mode = mode
            lab.points.clear()
            lab._update_pixmap()

    def _slice_for_plane(self, plane: str):
        if self.volume is None:
            return None, (1.0, 1.0)
        spacing = self.metadata.get("spacing", [1, 1, 1])
        p = (plane or "axial").lower()
        try:
            if p in ("axial", "2d", "cine"):
                mpr = extract_mpr_slice(self.volume, "axial", self.cross_z, spacing, cubic=True)
            elif p == "coronal":
                mpr = extract_mpr_slice(self.volume, "coronal", self.cross_y, spacing, cubic=True)
            elif p == "sagittal":
                mpr = extract_mpr_slice(self.volume, "sagittal", self.cross_x, spacing, cubic=True)
            else:
                mpr = extract_mpr_slice(self.volume, "axial", self.cross_z, spacing, cubic=True)
            return np.asarray(mpr.image), mpr.pixel_spacing
        except Exception:
            try:
                if p in ("axial", "2d", "cine"):
                    return np.asarray(self.volume[self.cross_z]), (float(spacing[1]), float(spacing[2]))
                if p == "coronal":
                    return get_slice(self.volume, "coronal", self.cross_y), (float(spacing[0]), float(spacing[2]))
                if p == "sagittal":
                    return get_slice(self.volume, "sagittal", self.cross_x), (float(spacing[0]), float(spacing[1]))
            except Exception:
                pass
        return self.current_slice, (float(spacing[1]), float(spacing[2]))

    def on_roi_measure(self, points, roi_mode="rect_roi", plane="axial"):
        source, spacing_rc = self._slice_for_plane(plane)
        if source is None:
            return
        try:
            if roi_mode == "circle_roi":
                stats = circle_roi_stats_hu(source, points[0], points[1], spacing_rc)
                name = "Circle ROI"
            elif roi_mode == "polygon_roi":
                stats = polygon_roi_stats_hu(source, points, spacing_rc)
                name = "Polygon ROI"
            else:
                stats = roi_stats_hu(source, points[0], points[1], spacing_rc)
                name = "Rectangle ROI"
            text = (
                f"{name}: n={stats.count}, area={stats.area_mm2:.1f} мм² ({stats.area_mm2/100.0:.2f} см²), "
                f"mean={stats.mean_hu:.1f} HU, min={stats.min_hu:.1f}, max={stats.max_hu:.1f}, std={stats.std_hu:.1f}"
            )
            self.measure_result.setText(text)
            self.measure_history.append(text)
        except Exception as exc:
            self.measure_result.setText("ROI error: " + str(exc))

    def on_image_point(self, pt, plane="axial"):
        if self.volume is None:
            return
        if self.sam_click_enabled and plane in ("axial", "2d"):
            self.start_sam_click_segmentation(pt)
            return
        if plane in ("axial", "2d", "cine"):
            self.cross_x, self.cross_y = pt
        elif plane == "coronal":
            self.cross_x, self.cross_z = pt
        elif plane == "sagittal":
            self.cross_y, self.cross_z = pt
        else:
            return
        self.set_cross(self.cross_z, self.cross_y, self.cross_x)

    def log_ui(self, msg):
        self.log_small.append(msg); self.logs.append(msg); log.info(msg)

    def choose_path(self):
        # Основний сценарій для DICOM-досліджень — вибір цілої папки.
        # Якщо користувач натиснув Cancel, даємо можливість вибрати одиночний файл.
        path = QFileDialog.getExistingDirectory(self, "Відкрити DICOM папку / дослідження")
        if not path:
            file, _ = QFileDialog.getOpenFileName(self, "Відкрити один DICOM файл", "", "DICOM (*.dcm *.dicom *.ima);;All files (*)")
            if not file:
                return
            path = file
        self.current_path = path
        self.start_scan(path)

    def start_scan(self, path):
        self.progress.show();
        if hasattr(self, "header_progress"): self.header_progress.show()
        self.status.setText("Сканування серій..."); self.open_btn.setEnabled(False)
        try:
            QApplication.processEvents()
        except Exception:
            pass
        self._suppress_series_autoload = True
        self.scan_thread = ScanThread(path); self.scan_thread.done.connect(self.on_scan_done); self.scan_thread.start()

    def on_scan_done(self, res: LoadResult):
        if not res.ok:
            self.progress.hide();
            if hasattr(self, "header_progress"): self.header_progress.hide()
            self.open_btn.setEnabled(True); QMessageBox.critical(self,"DICOM",res.error); return
        series = res.data.get("series", [])
        self.series_combo.blockSignals(True); self.series_combo.clear()
        for s in series:
            label = f"{s.get('modality','')} | {s.get('description','')} | {s.get('count',0)} зрізів | {s.get('uid','')[:12]}"
            self.series_combo.addItem(label, s.get("uid"))
        self.series_combo.blockSignals(False)
        self._suppress_series_autoload = False
        if hasattr(self, "load_series_btn"):
            self.load_series_btn.setEnabled(bool(series))
        self.update_navigator_tree(series)
        # Lite Fast Folder Scanner rule:
        # Opening the patient/study folder must scan metadata only and then wait
        # for explicit series selection.  Do NOT decode PixelData for all nested
        # series automatically.  This fixes long freezes when a patient folder
        # contains several CT/XA/MR series.  A single-series folder is loaded
        # immediately for convenience.
        if len(series) == 1:
            self.start_load(self.current_path, series[0].get("uid"))
        elif series:
            self.progress.hide()
            if hasattr(self, "header_progress"):
                self.header_progress.hide()
            self.open_btn.setEnabled(True)
            self.status.setText(f"Знайдено {len(series)} серій. Оберіть потрібну в Series Selector або натисніть 'Завантажити вибрану серію'.")
            self.update_system_status(f"Fast scan OK: {len(series)} серій, PixelData не декодовано.")
            self.log_ui(f"Fast scan metadata-only: {len(series)} series. Waiting for explicit selection.")
        else:
            self.progress.hide()
            if hasattr(self, "header_progress"):
                self.header_progress.hide()
            self.open_btn.setEnabled(True)
            if hasattr(self, "load_series_btn"):
                self.load_series_btn.setEnabled(False)
            self.status.setText("DICOM серії не знайдено.")
            self.update_system_status("Fast scan: серії не знайдено.")

    def load_selected_series(self):
        uid = self.series_combo.currentData() if hasattr(self, "series_combo") else None
        if self.current_path and uid:
            self.start_load(self.current_path, uid)

    def series_changed(self):
        # Do not auto-load while filling after a fast metadata scan.  User changes
        # should load immediately; the explicit button also handles the first item.
        if getattr(self, "_suppress_series_autoload", False):
            return
        if self.current_path and self.series_combo.currentData(): self.start_load(self.current_path, self.series_combo.currentData())

    def start_load(self, path, uid=None):
        self._reset_series_isolation_state("start_load")
        self.progress.show();
        if hasattr(self, "header_progress"): self.header_progress.show()
        self.status.setText("Завантаження DICOM..."); self.open_btn.setEnabled(False)
        try:
            QApplication.processEvents()
        except Exception:
            pass
        self.load_thread = LoadThread(path, uid); self.load_thread.done.connect(self.on_load_done); self.load_thread.start()


    def _reset_series_isolation_state(self, reason: str = "new series") -> None:
        """Hard reset all per-series state before loading another DICOM package.

        Prevents leakage of crop/zoom/pan/LUT/Cine/segmentation/cache values from
        the previously opened series.  This is intentionally UI-only and does not
        touch user preferences such as preferred interpolation quality.
        """
        try:
            if self.cine_timer.isActive():
                self.cine_timer.stop()
                if hasattr(self, "cine_play_btn"):
                    self.cine_play_btn.setText("▶ Play")
        except Exception:
            pass
        self.volume = None
        self.metadata = {}
        self.current_slice = None
        self.current_mask = None
        self._smoothstack_bboxes = {}
        self.cross_z = self.cross_y = self.cross_x = 0
        self.cine_frame = 0
        self.invert_display = False
        self.center = 40.0
        self.width = 400.0
        self.sharpen_mode = "off"
        self._current_series_key = ""
        self.measure_history.clear()
        for lab in self._all_image_labels():
            try:
                lab.clear_series_state()
                lab.set_interpolation(self.render_quality)
                lab.set_fit_mode(self.fit_mode)
            except Exception:
                pass
        for slider in [getattr(self, "slice_slider", None), getattr(self, "axial_slider", None), getattr(self, "coronal_slider", None), getattr(self, "sagittal_slider", None), getattr(self, "cine_slider", None)]:
            if slider is not None:
                try:
                    slider.blockSignals(True); slider.setRange(0, 0); slider.setValue(0); slider.blockSignals(False)
                except Exception:
                    pass
        try:
            self.tags.clear(); self.log_ui(f"Series isolation reset: {reason}")
        except Exception:
            pass


    def _all_image_labels(self):
        return [x for x in [getattr(self, "img2d", None), getattr(self, "axial_label", None), getattr(self, "coronal_label", None), getattr(self, "sagittal_label", None), getattr(self, "proj_label", None), getattr(self, "seg_preview", None), getattr(self, "cine_label", None), getattr(self, "vessel_preview", None), getattr(self, "angio_preview", None)] if x is not None]

    def set_render_quality(self, text: str):
        low = (text or "").lower()
        if "fidelity max" in low or "protocol" in low:
            mode = "cubic"
            self.sharpen_mode = "mpr_fidelity_max"
        elif "nearest" in low:
            mode = "nearest"
        elif "linear" in low:
            mode = "linear"
        elif "cubic" in low or "smooth" in low:
            mode = "cubic"
        else:
            mode = "lanczos"
        self.render_quality = mode
        self._save_current_series_display_profile()
        for lab in self._all_image_labels():
            try:
                lab.set_interpolation(mode)
            except Exception:
                pass
        self.update_system_status(f"2D якість: {mode}")


    def on_fit_combo(self, text: str):
        low = (text or "").lower()
        if "1:1" in low:
            self.set_fit_mode("one_to_one")
        elif "no crop" in low:
            self.set_fit_mode("no_crop")
        elif "anatomy" in low:
            self.set_fit_mode("fit_content")
        else:
            self.set_fit_mode("fit_window")

    def on_sharpen_combo(self, text: str):
        low = (text or "").lower()
        if "ultra" in low:
            self.sharpen_mode = "brain_fidelity_ultra"
        elif "fidelity pro" in low:
            self.sharpen_mode = "brain_fidelity_pro"
        elif "bilateral" in low:
            self.sharpen_mode = "brain_bilateral_pro"
        elif "itk" in low and "strong" in low:
            self.sharpen_mode = "itk_anisotropic_strong"
        elif "itk" in low:
            self.sharpen_mode = "itk_anisotropic_ct_brain"
        elif "clahe" in low and "angio" in low:
            self.sharpen_mode = "clahe_angio"
        elif "clahe" in low and "medium" in low:
            self.sharpen_mode = "clahe_medium"
        elif "clahe" in low:
            self.sharpen_mode = "clahe_low"
        elif "syngo" in low:
            self.sharpen_mode = "syngo_soft_max"
        elif "strong" in low:
            self.sharpen_mode = "ct_brain_strong"
        elif "smooth" in low:
            self.sharpen_mode = "brain_smooth"
        elif "medium" in low:
            self.sharpen_mode = "medium"
        elif "low" in low:
            self.sharpen_mode = "low"
        else:
            self.sharpen_mode = "off"
        self._save_current_series_display_profile()
        self.update_views(); self.update_projection(); self.update_cine()
        self.update_system_status(f"2D display filter: {self.sharpen_mode}")

    def set_fit_mode(self, mode: str):
        self.fit_mode = mode
        self._save_current_series_display_profile()
        for lab in self._all_image_labels():
            try:
                lab.set_fit_mode(mode)
            except Exception:
                pass
        self.update_system_status({"fit_content":"Fit anatomy", "fit_window":"Fit-to-window", "one_to_one":"1:1 pixel", "no_crop":"Fit no crop"}.get(mode, mode))

    def step_slice(self, step: int):
        if self.volume is None:
            return
        self.set_cross(z=self.cross_z + int(step))

    def step_slice_plane(self, plane: str, step: int):
        """Scroll the requested MPR plane with mouse wheel/sliders."""
        if self.volume is None:
            return
        plane = (plane or "axial").lower()
        if plane == "coronal":
            self.set_cross(y=self.cross_y + int(step))
        elif plane == "sagittal":
            self.set_cross(x=self.cross_x + int(step))
        else:
            self.set_cross(z=self.cross_z + int(step))

    def step_active_2d_plane(self, step: int):
        plane = "axial"
        try:
            plane = self.primary_plane_combo.currentText().lower()
        except Exception:
            pass
        self.step_slice_plane(plane, step)

    def apply_window_preset(self, preset: str):
        if not preset or preset == "Auto":
            return
        vals = {
            "Brain Soft W100 C35": (35, 100),
            "Brain W80 C35": (35, 80),
            "Stroke W40 C40": (40, 40),
            "Bone W2000 C500": (500, 2000),
            "Lung W1500 C-600": (-600, 1500),
            "Mediastinum W400 C40": (40, 400),
            "Angio W700 C250": (250, 700),
        }
        if preset in vals:
            c, w = vals[preset]
            self.center_spin.blockSignals(True); self.width_spin.blockSignals(True)
            self.center_spin.setValue(int(c)); self.width_spin.setValue(int(w))
            self.center_spin.blockSignals(False); self.width_spin.blockSignals(False)
            self.center = float(c); self.width = float(w)
            self._save_current_series_display_profile()
            self.update_views(); self.update_projection(); self.update_cine()

    def _default_window_for_series(self) -> tuple[float, float]:
        modality = str(self.metadata.get("modality", "")).upper()
        desc = str(self.metadata.get("series_description", "")).lower()
        # First use DICOM-provided VOI window when available for non-CT and unknown
        # modalities. MR/US/NM do not use HU and percentile auto-window can look
        # over-contrasted or burned out.
        try:
            dc = self.metadata.get("dicom_window_center", None)
            dw = self.metadata.get("dicom_window_width", None)
            if dc is not None and dw is not None and float(dw) > 1 and modality != "CT":
                return float(dc), float(dw)
        except Exception:
            pass
        if modality == "CT":
            # Diagnostic priority: brain/head first.  Some CT brain series contain
            # "Hr" / high-resolution words that must not force a bone window.
            if any(k in desc for k in ("brain", "head", "cerebr", "cran", "skull base")):
                if any(k in desc for k in ("hr", "high", "sharp", "h64", "hr64", "kernel")):
                    return 35.0, 100.0
                return 35.0, 80.0
            if any(k in desc for k in ("lung", "thorax", "chest")):
                return -600.0, 1500.0
            if any(k in desc for k in ("bone", "skull")):
                return 500.0, 2000.0
            if any(k in desc for k in ("abdomen", "abdominal", "liver", "pelvis")):
                return 50.0, 350.0
            try:
                dc = self.metadata.get("dicom_window_center", None)
                dw = self.metadata.get("dicom_window_width", None)
                if dc is not None and dw is not None and float(dw) > 1:
                    return float(dc), float(dw)
            except Exception:
                pass
            return 40.0, 400.0
        vol = np.asarray(self.volume)
        # Non-CT modalities are not HU-based. Use current slice for default
        # windowing so bright artifacts on other slices do not destroy contrast.
        try:
            if vol.ndim == 3:
                idx = int(np.clip(getattr(self, "cross_z", 0), 0, vol.shape[0] - 1))
                cur = vol[idx]
            else:
                cur = vol
        except Exception:
            cur = vol
        if modality == "MR":
            return auto_window(cur, 2, 98)
        if modality in ("US", "NM"):
            return auto_window(cur, 5, 95)
        return auto_window(cur, 1, 99)

    def _series_key(self) -> str:
        """Stable key for keeping independent 2D display settings per series."""
        try:
            return str(self.metadata.get("series_uid") or self.metadata.get("SeriesInstanceUID") or self.series_combo.currentData() or self.metadata.get("series_description") or "")
        except Exception:
            return ""

    def _save_current_series_display_profile(self) -> None:
        key = getattr(self, "_current_series_key", "") or self._series_key()
        if not key:
            return
        try:
            self._series_display_profiles[key] = {
                "center": float(self.center),
                "width": float(self.width),
                "render_quality": str(self.render_quality),
                "fit_mode": str(self.fit_mode),
                "sharpen_mode": str(self.sharpen_mode),
            }
        except Exception:
            pass

    def _restore_series_display_profile(self) -> bool:
        key = self._series_key()
        self._current_series_key = key
        prof = self._series_display_profiles.get(key) if key else None
        if not prof:
            return False
        try:
            self.center = float(prof.get("center", self.center))
            self.width = float(prof.get("width", self.width))
            self.render_quality = str(prof.get("render_quality", self.render_quality))
            self.fit_mode = str(prof.get("fit_mode", self.fit_mode))
            self.sharpen_mode = str(prof.get("sharpen_mode", self.sharpen_mode))
            return True
        except Exception:
            return False

    def _set_quality_combo_text(self, text: str) -> None:
        if hasattr(self, "quality_combo"):
            self.quality_combo.blockSignals(True); self.quality_combo.setCurrentText(text); self.quality_combo.blockSignals(False)

    def _set_sharp_combo_text(self, text: str) -> None:
        if hasattr(self, "sharp_combo"):
            self.sharp_combo.blockSignals(True); self.sharp_combo.setCurrentText(text); self.sharp_combo.blockSignals(False)

    def _sync_2d_profile_ui(self) -> None:
        qmap = {"cubic": "Cubic/Smooth (soft tissue)", "linear": "Linear/Bilinear soft", "lanczos": "Lanczos (bone/detail)", "nearest": "Nearest"}
        smap = {
            "brain_fidelity_pro": "Brain Fidelity PRO",
            "brain_fidelity_ultra": "Brain Fidelity Ultra",
            "brain_bilateral_pro": "Brain Bilateral PRO",
            "itk_anisotropic_ct_brain": "ITK Anisotropic CT Brain",
            "itk_anisotropic_strong": "ITK Anisotropic Strong",
            "syngo_soft_max": "Syngo soft brain (max)",
            "ct_brain_strong": "CT Brain fidelity (strong)",
            "brain_smooth": "Brain smooth (less noise)",
            "clahe_low": "CLAHE Low",
            "clahe_medium": "CLAHE Medium",
            "clahe_angio": "CLAHE Angio",
            "off": "Off / raw diagnostic",
            "low": "Low medical sharpen",
            "medium": "Medium",
        }
        self._set_quality_combo_text(qmap.get(str(self.render_quality), "Cubic/Smooth (soft tissue)"))
        self._set_sharp_combo_text(smap.get(str(self.sharpen_mode), "Off / raw diagnostic"))
        if hasattr(self, "fit_combo"):
            fmap = {"fit_window": "Fit-to-window", "fit_content": "Fit anatomy (manual)", "one_to_one": "1:1 pixel", "no_crop": "Fit no crop"}
            self.fit_combo.blockSignals(True); self.fit_combo.setCurrentText(fmap.get(str(self.fit_mode), "Fit-to-window")); self.fit_combo.blockSignals(False)

    def _is_ct_brain_series(self) -> bool:
        modality = str(self.metadata.get("modality", "")).upper()
        text = " ".join(str(self.metadata.get(k, "")) for k in ("series_description", "protocol_name", "body_part", "convolution_kernel", "manufacturer", "model_name")).lower()
        return modality == "CT" and any(k in text for k in ("brain", "head", "cerebr", "cran", "skull base"))

    def _ct_kernel_text(self) -> str:
        return " ".join(str(self.metadata.get(k, "")) for k in ("series_description", "protocol_name", "body_part", "convolution_kernel", "manufacturer", "model_name")).lower()

    def _is_sharp_ct_kernel(self) -> bool:
        text = self._ct_kernel_text()
        sharp_terms = ("hr", "hr64", "h60", "h70", "h80", "h90", "u90", "sharp", "edge", "high resolution")
        return any(k in text for k in sharp_terms)

    def _apply_adaptive_2d_profile(self) -> None:
        """Select safe display defaults per modality without touching 3D/MPR/VTK."""
        modality = str(self.metadata.get("modality", "")).upper()
        if self._restore_series_display_profile():
            self._sync_2d_profile_ui()
            return
        if self._is_ct_brain_series():
            # CT Brain Fidelity PRO: HU-domain edge-preserving denoise before windowing,
            # soft interpolation, no automatic crop.  Ultra is reserved for very sharp kernels.
            self.sharpen_mode = "brain_fidelity_ultra" if self._is_sharp_ct_kernel() else "brain_fidelity_pro"
            self.render_quality = "cubic"
            self.fit_mode = "fit_window"
            self._sync_2d_profile_ui()
        elif modality in ("XA", "XRF", "RF", "CR", "DX", "MG"):
            self.sharpen_mode = "clahe_angio" if modality in ("XA", "XRF", "RF") else "clahe_low"
            self.render_quality = "linear"
            self.fit_mode = "fit_window"
            self._sync_2d_profile_ui()
        else:
            # Non-CT modalities are not HU-based. Never carry CT Brain
            # HU-domain filters into MR/US/NM/unknown series.
            self.sharpen_mode = "off"
            self.render_quality = "cubic"
            self.fit_mode = "fit_window"
            self._sync_2d_profile_ui()

    def _apply_segmentation_defaults(self, mode: str = "bones") -> None:
        self.seg_min.blockSignals(True); self.seg_max.blockSignals(True)
        if mode == "lungs":
            self.seg_min.setValue(-1000); self.seg_max.setValue(-350)
            label = "легені -1000…-350 HU"
        elif mode == "vessels":
            self.seg_min.setValue(180); self.seg_max.setValue(1000)
            label = "судини/контраст 180…1000 HU"
        else:
            self.seg_min.setValue(300); self.seg_max.setValue(3000)
            label = "кістки 300…3000 HU"
        self.seg_min.blockSignals(False); self.seg_max.blockSignals(False)
        if hasattr(self, "seg_preset_info"):
            self.seg_preset_info.setText(f"Поточний пресет: {label}")

    def _compute_smoothstack_bboxes(self) -> None:
        """Compute one stable display bbox per plane/series for smooth scrolling.

        Auto-crop per individual slice causes Cine and stack browsing to jump in
        apparent size.  We render representative middle slices once, find their
        anatomical bboxes, then lock these bboxes for all frames in that plane.
        """
        self._smoothstack_bboxes = {}
        if self.volume is None:
            return
        try:
            z, y, x = self.volume.shape
            samples = {
                "axial": get_slice(self.volume, "axial", z // 2),
                "coronal": get_slice(self.volume, "coronal", y // 2),
                "sagittal": get_slice(self.volume, "sagittal", x // 2),
            }
            for plane, src in samples.items():
                try:
                    rendered = self.render_slice_u8(src)
                    bbox = diagnostic_content_bbox(rendered)
                    if bbox is not None:
                        self._smoothstack_bboxes[plane] = bbox
                except Exception:
                    continue
            axial_bbox = self._smoothstack_bboxes.get("axial")
            for lab in [self.img2d, self.axial_label, self.cine_label, self.proj_label, self.seg_preview]:
                lab.set_locked_crop_bbox(axial_bbox)
            self.coronal_label.set_locked_crop_bbox(self._smoothstack_bboxes.get("coronal"))
            self.sagittal_label.set_locked_crop_bbox(self._smoothstack_bboxes.get("sagittal"))
        except Exception as exc:
            self.log_ui("SmoothStack bbox warning: " + str(exc))

    def _apply_scanner_profile_to_ui(self) -> None:
        """Analyze DICOM metadata and apply display-only scanner recommendations."""
        try:
            shape = tuple(self.volume.shape) if self.volume is not None else None
            profile = analyze_scanner_profile(self.metadata or {}, shape)
            self.scanner_profile = profile
            self.metadata["scanner_profile"] = profile.to_dict()
            if hasattr(self, "series_quality_status"):
                self.series_quality_status.setText("Series Quality: " + profile.short_text_ua())
                self.series_quality_status.setToolTip(profile.detail_text_ua())
            # Display-only auto tuning.  Measurements and HU values stay untouched.
            self.center = float(profile.recommended_window_center)
            self.width = float(profile.recommended_window_width)
            try:
                if hasattr(self, "quality_combo"):
                    self.quality_combo.blockSignals(True)
                    if profile.quality_score < 55:
                        self.quality_combo.setCurrentText("Cubic/Smooth (soft tissue)")
                    else:
                        self.quality_combo.setCurrentText("Fidelity Max (MPR/Protocol)")
                    self.quality_combo.blockSignals(False)
                if hasattr(self, "sharp_combo"):
                    self.sharp_combo.blockSignals(True)
                    vsh = str(getattr(profile, "vendor_suggested_sharpen", "") or "").lower()
                    if "anisotropic" in vsh or getattr(profile, "vendor_kernel_category", "") == "ultra_sharp":
                        self.sharp_combo.setCurrentText("ITK Anisotropic Strong")
                    elif "ultra" in vsh or getattr(profile, "vendor_kernel_category", "") == "sharp":
                        self.sharp_combo.setCurrentText("Brain Fidelity Ultra")
                    elif "bilateral" in vsh or getattr(profile, "vendor_kernel_category", "") == "soft":
                        self.sharp_combo.setCurrentText("Brain Bilateral PRO")
                    elif profile.anatomy_profile == "Brain CT":
                        self.sharp_combo.setCurrentText("Brain Fidelity PRO")
                    elif profile.quality_score < 55:
                        self.sharp_combo.setCurrentText("Brain smooth (less noise)")
                    self.sharp_combo.blockSignals(False)
                if hasattr(self, "vtk_preset"):
                    txt = profile.recommended_3d_preset.lower()
                    if "lung fidelity" in txt:
                        self.vtk_preset.setCurrentText("Classic Lung Fidelity")
                    elif "lung" in txt:
                        self.vtk_preset.setCurrentText("Classic Lung Fidelity")
                    elif "trauma" in txt:
                        self.vtk_preset.setCurrentText("Trauma Cinematic")
                    elif "bone" in txt:
                        self.vtk_preset.setCurrentText("Classic Bone")
                    elif "angio" in txt:
                        self.vtk_preset.setCurrentText("Angio_MIP")
            except Exception:
                pass
            self.log_ui("Scanner profile: " + profile.short_text_ua())
        except Exception as exc:
            self.scanner_profile = None
            if hasattr(self, "series_quality_status"):
                self.series_quality_status.setText("Series Quality: не вдалося оцінити")
            self.log_ui("Scanner profile error: " + str(exc))

    def on_load_done(self, res: LoadResult):
        self.progress.hide();
        if hasattr(self, "header_progress"): self.header_progress.hide()
        self.open_btn.setEnabled(True)
        if not res.ok:
            QMessageBox.critical(self,"Помилка відкриття DICOM",res.error); self.log_ui("ERROR: "+res.error); return
        volinfo = res.data["volume"]
        # Copy runtime volume into RAM and explicitly drop the mmap object.
        # On Windows this prevents active_volume.npy from staying locked after load.
        volume_mmap = np.load(volinfo["volume_path"], mmap_mode="r")
        try:
            self.volume = np.asarray(volume_mmap).copy()
        finally:
            del volume_mmap
        self.metadata = json.loads(Path(volinfo["metadata_path"]).read_text(encoding="utf-8"))
        try:
            budget_mb = float(self.metadata.get("cache_budget_mb", 512) or 512)
            self._mpr_cache = MPRFidelityCache(max_items=estimate_mpr_cache_items(self.volume.shape, budget_mb))
        except Exception:
            self._mpr_cache = MPRFidelityCache(max_items=192)
        self._smoothstack_bboxes = {}
        self.invert_display = bool(self.metadata.get("invert_display", False))
        self.center, self.width = self._default_window_for_series()
        self._apply_scanner_profile_to_ui()
        self._apply_adaptive_2d_profile()
        # Keep UI preset in sync when auto brain window is chosen.
        if int(self.center) == 35 and int(self.width) == 100:
            self.preset_combo.blockSignals(True); self.preset_combo.setCurrentText("Brain Soft W100 C35"); self.preset_combo.blockSignals(False)
        elif int(self.center) == 35 and int(self.width) == 80:
            self.preset_combo.blockSignals(True); self.preset_combo.setCurrentText("Brain W80 C35"); self.preset_combo.blockSignals(False)
        self.center_spin.blockSignals(True); self.width_spin.blockSignals(True)
        self.center_spin.setValue(int(self.center)); self.width_spin.setValue(max(1,int(self.width)))
        self.center_spin.blockSignals(False); self.width_spin.blockSignals(False)
        z, y, x = self.volume.shape
        self.cross_z, self.cross_y, self.cross_x = z//2, y//2, x//2
        for slider, maximum, value in [(self.slice_slider,z-1,self.cross_z),(self.axial_slider,z-1,self.cross_z),(self.coronal_slider,y-1,self.cross_y),(self.sagittal_slider,x-1,self.cross_x)]:
            slider.blockSignals(True); slider.setRange(0,max(0,maximum)); slider.setValue(value); slider.blockSignals(False)
        self.on_primary_plane_changed()
        self.cine_frame = self.cross_z
        self.cine_slider.blockSignals(True); self.cine_slider.setRange(0, max(0, z-1)); self.cine_slider.setValue(self.cine_frame); self.cine_slider.blockSignals(False)
        fps = float(self.metadata.get("cine_fps", 0.0) or 0.0)
        if fps > 0:
            self.cine_fps.setValue(max(1.0, min(60.0, fps)))
        self.cine_info.setText(f"Cine: {z} кадрів" + (f" · {fps:.1f} fps" if fps > 0 else ""))
        spacing = self.metadata.get("spacing", [1,1,1])
        rowcol = (float(spacing[1]), float(spacing[2]))
        for lab in [self.img2d, self.axial_label, self.proj_label, self.seg_preview, self.cine_label]: lab.pixel_spacing = rowcol
        self.coronal_label.pixel_spacing = (float(spacing[0]), float(spacing[2]))
        self.sagittal_label.pixel_spacing = (float(spacing[0]), float(spacing[1]))
        for lab in [self.img2d, self.axial_label, self.coronal_label, self.sagittal_label, self.proj_label, self.seg_preview, self.cine_label]:
            lab.set_interpolation(self.render_quality)
            lab.set_fit_mode(self.fit_mode)
            lab.reset_view()
        self._compute_smoothstack_bboxes()
        self._apply_segmentation_defaults("bones")
        self._auto_3d_built_for_shape = None
        cache_text = str(self.metadata.get("cache_budget_text") or "auto")
        qtext = self.scanner_profile.quality_label if getattr(self, "scanner_profile", None) else "auto"
        self.status.setText(f"Завантажено: {self.volume.shape} | spacing={spacing} | quality={qtext} | cache={cache_text} | {self.metadata.get('modality','')} | {self.metadata.get('series_description','')}")
        self.update_patient_header(); self.update_navigator_tree(); self.update_system_status(f"Серію завантажено · RAM cache budget: {cache_text}")
        self.fill_tags(); self.update_views(); self.update_projection(); self.update_cine(); self.log_ui("DICOM loaded successfully")

    def fill_tags(self):
        tags = self.metadata.get("tags", {})
        self.tags.setPlainText("\n".join(f"{k}: {v}" for k,v in tags.items()))


    def on_primary_plane_changed(self):
        """Update the large 2D slider for the selected plane and redraw."""
        if self.volume is None:
            self.update_views()
            return
        try:
            z, y, x = self.volume.shape
            plane = self.primary_plane_combo.currentText().lower() if hasattr(self, "primary_plane_combo") else "axial"
            if plane == "coronal":
                maximum, value = y - 1, self.cross_y
            elif plane == "sagittal":
                maximum, value = x - 1, self.cross_x
            else:
                maximum, value = z - 1, self.cross_z
            self.slice_slider.blockSignals(True)
            self.slice_slider.setRange(0, max(0, int(maximum)))
            self.slice_slider.setValue(int(value))
            self.slice_slider.blockSignals(False)
        except Exception:
            pass
        self.update_views()

    def on_primary_slice_slider(self, value):
        """Scroll the large 2D view in its active Axial/Coronal/Sagittal plane."""
        if self.volume is None:
            return
        plane = self.primary_plane_combo.currentText().lower() if hasattr(self, "primary_plane_combo") else "axial"
        if plane == "coronal":
            self.set_cross(y=value)
        elif plane == "sagittal":
            self.set_cross(x=value)
        else:
            self.set_cross(z=value)

    def on_axial_mpr_slider(self, value):
        """Axial MPR slider scrolls axial slices, never zoom/crosshair-only."""
        self.set_cross(z=value)

    def on_coronal_mpr_slider(self, value):
        """Coronal MPR slider scrolls coronal slices along the Y axis."""
        self.set_cross(y=value)

    def on_sagittal_mpr_slider(self, value):
        """Sagittal MPR slider scrolls sagittal slices along the X axis."""
        self.set_cross(x=value)

    def on_window(self):
        self.center=float(self.center_spin.value()); self.width=float(self.width_spin.value()); self._save_current_series_display_profile(); self.update_views(); self.update_projection(); self.update_cine()

    def on_axial_slider(self, value):
        self.set_cross(z=value)

    def set_cross(self, z=None, y=None, x=None):
        if self.volume is None: return
        zz, yy, xx = self.volume.shape
        if z is not None: self.cross_z = int(np.clip(z, 0, zz-1))
        if y is not None: self.cross_y = int(np.clip(y, 0, yy-1))
        if x is not None: self.cross_x = int(np.clip(x, 0, xx-1))
        # MPR sliders always track their own anatomical axes.  The large 2D
        # slider tracks the currently selected 2D plane, not axial only.
        active_plane = self.primary_plane_combo.currentText().lower() if hasattr(self, "primary_plane_combo") else "axial"
        active_value = self.cross_z if active_plane == "axial" else (self.cross_y if active_plane == "coronal" else self.cross_x)
        for slider, value in [(self.slice_slider, active_value),(self.axial_slider,self.cross_z),(self.coronal_slider,self.cross_y),(self.sagittal_slider,self.cross_x)]:
            if slider.value() != value:
                slider.blockSignals(True); slider.setValue(value); slider.blockSignals(False)
        self.update_views()


    def render_slice_u8(self, arr: np.ndarray) -> np.ndarray:
        return window_to_uint8(arr, self.center, self.width, invert=self.invert_display, sharpen=self.sharpen_mode)

    def render_mpr_slice_u8(self, arr: np.ndarray, plane: str) -> np.ndarray:
        """Display-only MPR Fidelity path for reconstructed coronal/sagittal.

        Measurements still use the original HU source slice.  This function only
        reduces stair-step noise and quantum grain in the 8-bit presentation,
        which is the defect seen in coronal/sagittal screenshots.
        """
        mode = str(getattr(self, "sharpen_mode", "brain_fidelity_pro"))
        p = (plane or "").lower()
        if p in {"coronal", "sagittal"} and mode in {"off", "low", "medium", "brain_smooth"}:
            mode = "brain_fidelity_pro"
        elif p in {"coronal", "sagittal"} and mode in {"brain_fidelity_pro", "brain_bilateral_pro"}:
            mode = "mpr_fidelity_max"
        return window_to_uint8(arr, self.center, self.width, invert=self.invert_display, sharpen=mode)

    def _protocol_overlay_color(self) -> tuple[int, int, int]:
        try:
            result = getattr(self, "_last_protocol_result", None)
            if result is not None and hasattr(result.protocol, "color_rgb"):
                r, g, b = result.protocol.color_rgb
                return (int(r * 255) if r <= 1 else int(r), int(g * 255) if g <= 1 else int(g), int(b * 255) if b <= 1 else int(b))
        except Exception:
            pass
        return (255, 0, 0)

    def _make_protocol_mask_overlays(self, spacing, cor_factor: float, sag_factor: float) -> dict[str, np.ndarray] | None:
        """Build display-space 2D/MPR overlays for the active clinical protocol mask."""
        mask = getattr(self, "current_mask", None)
        if mask is None or not bool(getattr(self, "show_protocol_2d_overlay", True)):
            return None
        try:
            m = np.asarray(mask).astype(bool)
            if self.volume is None or m.shape != self.volume.shape or not np.any(m):
                return None
            return {
                "axial": extract_mpr_mask_slice(m, "axial", self.cross_z, spacing, slab_slices=1),
                "coronal": extract_mpr_mask_slice(m, "coronal", self.cross_y, spacing, slab_slices=int(getattr(getattr(self, "scanner_profile", None), "recommended_slab_slices", 3) or 3)),
                "sagittal": extract_mpr_mask_slice(m, "sagittal", self.cross_x, spacing, slab_slices=int(getattr(getattr(self, "scanner_profile", None), "recommended_slab_slices", 3) or 3)),
            }
        except Exception as exc:
            self.log_ui("Protocol 2D overlay skipped: " + str(exc))
            return None

    def _apply_protocol_overlays_to_views(self, overlays: dict[str, np.ndarray] | None, main_plane: str) -> None:
        color = self._protocol_overlay_color()
        alpha = int(getattr(self, "protocol_overlay_alpha", 120))
        pairs = [(self.axial_label, "axial"), (self.coronal_label, "coronal"), (self.sagittal_label, "sagittal")]
        if hasattr(self, "img2d"):
            pairs.append((self.img2d, main_plane))
        for lab, plane in pairs:
            try:
                if overlays and plane in overlays:
                    lab.set_mask_overlay(overlays[plane], color=color, alpha=alpha)
                else:
                    lab.clear_mask_overlay()
            except Exception:
                pass

    def update_views(self):
        if self.volume is None:
            return
        try:
            spacing = self.metadata.get("spacing", [1, 1, 1]) if self.metadata else [1, 1, 1]
            cache = getattr(self, "_mpr_cache", None)
            if cache is None:
                cache = MPRFidelityCache(max_items=192)
                self._mpr_cache = cache
            slab_slices = int(getattr(getattr(self, "scanner_profile", None), "recommended_slab_slices", 3) or 3)
            axial_mpr = cache.get(self.volume, "axial", self.cross_z, spacing, cubic=True)
            cor_mpr = cache.get(self.volume, "coronal", self.cross_y, spacing, cubic=True, slab_slices=slab_slices)
            sag_mpr = cache.get(self.volume, "sagittal", self.cross_x, spacing, cubic=True, slab_slices=slab_slices)
            axial, cor, sag = axial_mpr.image, cor_mpr.image, sag_mpr.image
        except Exception as exc:
            # Never leave the 2D workspace blank.  If high-fidelity MPR fails
            # because SciPy/Pillow/metadata is missing in a portable EXE, fall
            # back to raw NumPy planes and log the real cause.
            self.log_ui("MPR Fidelity fallback: " + str(exc))
            spacing = self.metadata.get("spacing", [1, 1, 1]) if self.metadata else [1, 1, 1]
            try:
                zsp, ysp, xsp = [float(v) for v in spacing]
            except Exception:
                zsp, ysp, xsp = 1.0, 1.0, 1.0
            axial = np.asarray(get_slice(self.volume, "axial", self.cross_z), dtype=np.float32)
            cor = np.asarray(get_slice(self.volume, "coronal", self.cross_y), dtype=np.float32)
            sag = np.asarray(get_slice(self.volume, "sagittal", self.cross_x), dtype=np.float32)
            class _RawMPR:
                def __init__(self, image, pixel_spacing, factor=1.0):
                    self.image = image; self.pixel_spacing = pixel_spacing; self.resample_factor = factor
            axial_mpr = _RawMPR(axial, (ysp, xsp), 1.0)
            cor_mpr = _RawMPR(cor, (zsp, xsp), 1.0)
            sag_mpr = _RawMPR(sag, (zsp, ysp), 1.0)

        try:
            self.axial_label.pixel_spacing = axial_mpr.pixel_spacing
            self.coronal_label.pixel_spacing = cor_mpr.pixel_spacing
            self.sagittal_label.pixel_spacing = sag_mpr.pixel_spacing

            plane = (self.primary_plane_combo.currentText().lower() if hasattr(self, "primary_plane_combo") else "axial")
            if plane == "coronal":
                main_img, main_src = cor, cor
                self.img2d.plane = "coronal"
                self.img2d.pixel_spacing = cor_mpr.pixel_spacing
                self.img2d.crosshair = display_crosshair_for_mpr("coronal", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, cor_mpr.resample_factor)
            elif plane == "sagittal":
                main_img, main_src = sag, sag
                self.img2d.plane = "sagittal"
                self.img2d.pixel_spacing = sag_mpr.pixel_spacing
                self.img2d.crosshair = display_crosshair_for_mpr("sagittal", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, sag_mpr.resample_factor)
            else:
                main_img, main_src = axial, axial
                self.img2d.plane = "axial"
                self.img2d.pixel_spacing = axial_mpr.pixel_spacing
                self.img2d.crosshair = display_crosshair_for_mpr("axial", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, 1.0)
            self.current_slice = np.asarray(main_src)
            self.axial_label.crosshair = display_crosshair_for_mpr("axial", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, 1.0)
            self.coronal_label.crosshair = display_crosshair_for_mpr("coronal", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, cor_mpr.resample_factor)
            self.sagittal_label.crosshair = display_crosshair_for_mpr("sagittal", self.cross_z, self.cross_y, self.cross_x, self.volume.shape, sag_mpr.resample_factor)
            main_plane = getattr(self.img2d, "plane", "axial")
            overlays = self._make_protocol_mask_overlays(spacing, getattr(cor_mpr, "resample_factor", 1.0), getattr(sag_mpr, "resample_factor", 1.0))
            self.img2d.set_image(self.render_mpr_slice_u8(main_img, main_plane), main_src)
            self.axial_label.set_image(self.render_slice_u8(axial), axial)
            self.coronal_label.set_image(self.render_mpr_slice_u8(cor, "coronal"), cor)
            self.sagittal_label.set_image(self.render_mpr_slice_u8(sag, "sagittal"), sag)
            self._apply_protocol_overlays_to_views(overlays, main_plane)
        except Exception as exc:
            self.log_ui("MPR/2D display error: "+str(exc))

    def promote_mpr_plane_to_2d(self, plane: str) -> None:
        """Double-click in MPR sends that plane to the large 2D diagnostic viewer."""
        try:
            name = {"axial":"Axial", "coronal":"Coronal", "sagittal":"Sagittal"}.get(str(plane).lower(), "Axial")
            if hasattr(self, "primary_plane_combo"):
                self.primary_plane_combo.setCurrentText(name)
            self.switch_tab("2D")
            self.update_views()
            self.update_system_status(f"MPR площина {name} відкрита на головному 2D екрані")
        except Exception as exc:
            self.log_ui("MPR promote error: " + str(exc))

    def update_mpr(self):
        self.update_views()

    def update_projection(self):
        if self.volume is None: return
        try:
            axis = {"axial":0,"coronal":1,"sagittal":2}[self.proj_axis.currentText()]
            img=projection(self.volume,self.proj_combo.currentText(),axis=axis)
            self.proj_label.set_image(self.render_slice_u8(img), img)
        except Exception as exc:
            self.log_ui("Projection error: "+str(exc))

    def run_segmentation(self, mode: str):
        if self.volume is None:
            QMessageBox.warning(self, "Segmentation", "Спочатку відкрийте DICOM серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            vol = np.asarray(self.volume)
            if mode == "bones":
                res = segment_bones(vol, spacing, float(self.seg_min.value()))
            elif mode == "lungs":
                res = segment_lungs(vol, spacing, -1000.0, float(self.seg_max.value()))
            else:
                res = segment_vessels(vol, spacing, float(self.seg_min.value()))
            self.current_mask = res.mask
            self.seg_info.setText(f"{res.mode}: {res.threshold}; voxels={res.voxel_count}; volume={res.volume_ml:.2f} мл")
            self.seg_preview.set_image(mask_projection(res.mask))
            self.tabs.setCurrentWidget(self.seg_preview.parentWidget())
            self.log_ui("Segmentation complete: " + self.seg_info.text())
        except Exception as exc:
            self.log_ui("Segmentation error: " + str(exc))
            QMessageBox.critical(self, "Segmentation", str(exc))

    def apply_post_3d_artifact_cleaner(self) -> None:
        if self.volume is None:
            QMessageBox.warning(self, "3D", "Спочатку відкрийте DICOM серію і побудуйте 3D."); return
        try:
            strength = int(self.clean_3d_strength.value()) if hasattr(self, "clean_3d_strength") else 45
            threshold = float(self.clean_3d_threshold.value()) if hasattr(self, "clean_3d_threshold") else 180.0
            min_vox = int(self.clean_3d_min_vox.value()) if hasattr(self, "clean_3d_min_vox") else 1500
            ok = self.vtk_viewer.apply_post_artifact_cleaner(strength_percent=strength, threshold_hu=threshold, min_component_voxels=min_vox)
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText(("3D Clean ON" if ok else "3D Clean не застосовано") + f" | сила {strength}% | threshold {threshold:g} HU")
            self.log_ui(f"Post 3D artifact cleaner: ok={ok}, strength={strength}, threshold={threshold:g}, min_vox={min_vox}")
        except Exception as exc:
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Artifact Clean error")
            self.log_ui("Post 3D artifact cleaner error: " + str(exc))

    def restore_original_3d_model(self) -> None:
        try:
            ok = self.vtk_viewer.restore_original_3d_volume()
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Artifact Clean OFF: відновлено оригінал" if ok else "Оригінал ще не збережено")
            self.log_ui(f"Restore original 3D model: ok={ok}")
        except Exception as exc:
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Restore 3D error")
            self.log_ui("Restore original 3D model error: " + str(exc))

    def _auto_clean_3d_volume_if_enabled(self, vol: np.ndarray) -> np.ndarray:
        """Return runtime-only cleaned volume for 3D, preserving original DICOM data."""
        if not getattr(self, "auto_clean_3d_check", None) or not self.auto_clean_3d_check.isChecked():
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Auto Clean 3D OFF")
            return vol
        try:
            mode_text = self.clean_3d_mode.currentText() if hasattr(self, "clean_3d_mode") else "Bone/Skull largest"
            if "Body" in mode_text:
                mode = "body_table"
            elif "Largest" in mode_text and "Bone" not in mode_text:
                mode = "largest_component"
            else:
                mode = "bone_largest"
            threshold = float(self.clean_3d_threshold.value()) if hasattr(self, "clean_3d_threshold") else 200.0
            min_vox = int(self.clean_3d_min_vox.value()) if hasattr(self, "clean_3d_min_vox") else 2500
            res = auto_clean_volume_for_3d(vol, mode=mode, threshold_hu=threshold, min_component_voxels=min_vox)
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText(("OK: " if res.ok else "Fallback: ") + f"kept {res.kept_voxels:,}, removed {res.removed_voxels:,}")
            self.current_mask = res.mask if res.ok else getattr(self, "current_mask", None)
            self.log_ui(res.message)
            return res.cleaned_volume
        except Exception as exc:
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Auto Clean error; original volume used")
            self.log_ui("Auto Clean 3D error: " + str(exc))
            return vol

    def update_3d_slab_settings(self):
        """Update modular SlabController settings used by Ctrl+Wheel / future thick MPR rendering."""
        try:
            ctrls = getattr(getattr(self, "vtk_viewer", None), "_deep3d_controllers", None)
            slab = getattr(ctrls, "slab", None) if ctrls is not None else None
            mode = self.vtk_slab_mode.currentText() if hasattr(self, "vtk_slab_mode") else "Off"
            thick = float(self.vtk_slab_thick.value()) if hasattr(self, "vtk_slab_thick") else 1.0
            if slab is not None:
                slab.set_mode(mode); slab.set_thickness_mm(thick)
            if hasattr(self, "vtk_slab_status"):
                self.vtk_slab_status.setText(f"Slab: {mode}, {thick:.1f} mm. Ctrl+Wheel змінює товщину.")
        except Exception as exc:
            if hasattr(self, "vtk_slab_status"):
                self.vtk_slab_status.setText("Slab setup error: " + str(exc))

    def build_legacy_3d(self):
        if self.volume is None:
            QMessageBox.warning(self, "Legacy 3D", "Спочатку відкрийте DICOM серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            vol = np.asarray(self.volume)
            self.legacy_vtk_viewer.set_legacy_headface_volume(vol, spacing)
            if hasattr(self, "legacy3d_status"):
                self.legacy3d_status.setText("Legacy 3D побудовано: старий стиль рендера, без Advanced-інструментів.")
            self.tabs.setCurrentWidget(self.legacy_vtk_viewer.parentWidget())
            self.log_ui(f"Legacy 3D built: shape={vol.shape}, spacing={spacing}")
        except Exception as exc:
            self.log_ui("Legacy 3D error: " + str(exc))
            QMessageBox.critical(self, "Legacy 3D", str(exc))

    def build_3d(self):
        if self.volume is None:
            QMessageBox.warning(self, "3D", "Спочатку відкрийте DICOM серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            vol = np.asarray(self.volume)
            # 3D Freeze principle: build the best original visualization first.
            # Artifact cleaning is now a separate post-build mask-only action.
            if hasattr(self, "clean_3d_status"):
                self.clean_3d_status.setText("Artifact Clean OFF: побудовано оригінальний 3D стан")
            mode = self.vtk_mode.currentText()
            preset = self.vtk_preset.currentText()
            if mode.startswith("Legacy Head/Face"):
                # RC4 Classic 3D: force the stable old-style anatomy preset unless
                # the user explicitly selected a clinical preset such as hemorrhage.
                if preset not in ("Brain Hemorrhage", "Bone", "Bone Color", "Angio_MIP", "Vessel", "Air"):
                    preset = "Classic Anatomy"
            elif mode.startswith("Modern"):
                mode = "VTK Volume Rendering"
            if vol.ndim != 3 or min(vol.shape) <= 0:
                raise RuntimeError("Немає коректного 3D обсягу для побудови")
            if mode.startswith("MIP") or mode.startswith("Auto"):
                # Default for old hospital PCs: CPU-only preview, no heavy OpenGL call.
                self.vtk_viewer.set_mip_preview(vol, spacing, preset)
            elif mode.startswith("VTK Surface"):
                threshold = 300.0 if "Bone" in preset or "Color" in preset else float(self.seg_min.value())
                self.vtk_viewer.set_surface(vol, spacing, threshold)
            else:
                self.vtk_viewer.set_volume(vol, spacing, preset)
                # Do not auto-apply the Density slider after build: it replaces the
                # clinical transfer function and changes the proven 3D appearance.
                # The slider still works when the user moves it manually.
                if hasattr(self, "vtk_mip_btn") and self.vtk_mip_btn.isChecked():
                    self.vtk_viewer.set_mip_blend(True)
            self.tabs.setCurrentWidget(self.vtk_viewer.parentWidget())
            self.log_ui(f"3D built: mode={mode}, preset={preset}, shape={vol.shape}, spacing={spacing}")
        except Exception as exc:
            self.log_ui("3D error: " + str(exc))
            QMessageBox.critical(self, "3D", str(exc))



    def _classic_spacing(self):
        return tuple(float(v) for v in self.metadata.get("spacing", [1, 1, 1]))

    def _classic_analyzer(self):
        return Hemorrhage3DClassicAnalyzer(ClassicHemorrhageConfig(
            min_hu=float(self.hem_hu_min.value()) if hasattr(self, "hem_hu_min") else 50.0,
            max_hu=float(self.hem_hu_max.value()) if hasattr(self, "hem_hu_max") else 95.0,
            min_component_ml=0.20,
            morphology_iterations=1,
            use_intracranial_mask=True,
        ))

    def run_classic_ct_diagnostics_ui(self):
        """Run deterministic CPU-only CT brain hemorrhage/asymmetry analysis on the loaded volume."""
        if self.volume is None:
            QMessageBox.warning(self, "Classic CT", "Спочатку відкрийте CT Brain серію."); return
        try:
            spacing = self._classic_spacing()
            analyzer = self._classic_analyzer()
            result = analyzer.detect_volume(np.asarray(self.volume), spacing)
            asymmetry = DicomViewDiagnosticsClassic.analyze_brain_asymmetry_volume(np.asarray(self.volume), threshold=35)
            self._classic_ct_result = result
            self._classic_ct_asymmetry = asymmetry
            self.current_mask = result.mask
            summary = Hemorrhage3DClassicAnalyzer.measurement_summary(result)
            if hasattr(self, "hem_info"):
                self.hem_info.setText(summary + f" | Confidence: {result.confidence:.2f}")
            payload = result.to_json_dict()
            payload["measurement_summary_ua"] = summary
            payload["asymmetry_nonzero_voxels"] = int(np.count_nonzero(asymmetry))
            payload["active_algorithm"] = "Classic CPU HU threshold + 3D morphology + connected components + bilateral asymmetry"
            if hasattr(self, "hem_output"):
                self.hem_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            if hasattr(self, "ai_diagnostics_output"):
                self.ai_diagnostics_output.setPlainText(
                    "Classic CPU Diagnostics completed\n\n" + json.dumps(payload, ensure_ascii=False, indent=2)
                )
            try:
                if np.any(result.mask):
                    self.seg_preview.set_image(mask_projection(result.mask))
                else:
                    self.seg_preview.set_image(DicomViewDiagnosticsClassic.max_projection_uint8(asymmetry))
            except Exception:
                pass
            self.log_ui(f"Classic CT Diagnostics: hemorrhage={result.volume_ml:.2f} ml, components={result.component_count}, asymmetry_voxels={int(np.count_nonzero(asymmetry))}")
        except Exception as exc:
            self.log_ui("Classic CT Diagnostics error: " + str(exc))
            QMessageBox.critical(self, "Classic CT Diagnostics", str(exc))

    def show_classic_hemorrhage_3d_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Classic Hemorrhage 3D", "Спочатку відкрийте CT Brain серію."); return
        try:
            if not hasattr(self, "_classic_ct_result"):
                self.run_classic_ct_diagnostics_ui()
            result = getattr(self, "_classic_ct_result", None)
            if result is None:
                return
            spacing = self._classic_spacing()
            metrics = result.to_json_dict()
            if not np.any(result.mask):
                QMessageBox.information(self, "Classic Hemorrhage 3D", "Маска крововиливу порожня. Спробуйте змінити Blood HU або перевірити серію.")
                return
            if hasattr(self.vtk_viewer, "set_hemorrhage_focus_volume"):
                ok = self.vtk_viewer.set_hemorrhage_focus_volume(np.asarray(self.volume), spacing, result.mask, metrics)
                self.log_ui("Classic Hemorrhage Focus 3D: " + ("OK" if ok else "FAILED"))
            else:
                self.vtk_preset.setCurrentText("Brain Hemorrhage") if hasattr(self, "vtk_preset") else None
                self.vtk_viewer.set_volume(np.asarray(self.volume), spacing, "Brain Hemorrhage")
            try:
                out_dir = data_dir() / "classic_ct"; out_dir.mkdir(parents=True, exist_ok=True)
                mesh_path = out_dir / "classic_hemorrhage.stl"
                from dicomview_pro.plugins.hemorrhage3d.kirivsoft_hemorrhage.mesh_export import export_mask_mesh
                export_mask_mesh(result.mask, spacing, mesh_path)
                self.log_ui("Classic hemorrhage STL saved: " + str(mesh_path))
            except Exception as mesh_exc:
                self.log_ui("Classic hemorrhage STL export skipped: " + str(mesh_exc))
            self.tabs.setCurrentWidget(self.vtk_viewer.parentWidget())
        except Exception as exc:
            self.log_ui("Classic Hemorrhage 3D error: " + str(exc))
            QMessageBox.critical(self, "Classic Hemorrhage 3D", str(exc))

    def save_classic_ct_json_ui(self):
        try:
            if not hasattr(self, "_classic_ct_result"):
                self.run_classic_ct_diagnostics_ui()
            result = getattr(self, "_classic_ct_result", None)
            if result is None:
                return
            default = str(data_dir() / "classic_ct" / "classic_ct_result.json")
            path, _ = QFileDialog.getSaveFileName(self, "Save Classic CT JSON", default, "JSON (*.json)")
            if not path:
                return
            save_classic_result_json(result, path)
            self.log_ui("Classic CT JSON saved: " + str(path))
            QMessageBox.information(self, "Classic CT JSON", "Збережено: " + str(path))
        except Exception as exc:
            self.log_ui("Classic CT JSON error: " + str(exc))
            QMessageBox.critical(self, "Classic CT JSON", str(exc))

    def _hemorrhage_plugin(self):
        try:
            from dicomview_pro.plugins.hemorrhage3d.kirivsoft_hemorrhage.config import HemorrhageConfig
            from dicomview_pro.plugins.hemorrhage3d.kirivsoft_hemorrhage.plugin_entry import Hemorrhage3DPlugin
            cfg = HemorrhageConfig(
                blood_hu_min=float(self.hem_hu_min.value()) if hasattr(self, "hem_hu_min") else 45.0,
                blood_hu_max=float(self.hem_hu_max.value()) if hasattr(self, "hem_hu_max") else 95.0,
            )
            pl = Hemorrhage3DPlugin(); pl.detector.config = cfg
            return pl
        except Exception as exc:
            raise RuntimeError("Hemorrhage3D PRO plugin unavailable: " + str(exc))

    def run_hemorrhage_detection_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Hemorrhage", "Спочатку відкрийте CT Brain серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            pl = self._hemorrhage_plugin()
            res = pl.analyze_volume(np.asarray(self.volume), spacing)
            self._hemorrhage_plugin_instance = pl
            self._hemorrhage_result = res
            self.current_mask = res.get("hemorrhage_mask")
            vol_ml = float(res.get("volume_ml", 0.0))
            shift = res.get("midline_shift", {}) or {}
            shift_mm = float(shift.get("shift_mm", 0.0)) if isinstance(shift, dict) else 0.0
            conf = float(res.get("confidence", 0.0))
            if hasattr(self, "hem_info"):
                self.hem_info.setText(f"Volume: {vol_ml:.2f} ml | Midline shift: {shift_mm:.2f} mm | Confidence: {conf:.2f}")
            if hasattr(self, "hem_output"):
                self.hem_output.setPlainText(json.dumps({
                    "volume_ml": round(vol_ml, 3),
                    "midline_shift": shift,
                    "components": res.get("components"),
                    "bbox_mm": res.get("bbox_mm"),
                    "notes": res.get("notes", []),
                    "warning": "Візуальна HU-маска, не автоматичний діагноз."
                }, ensure_ascii=False, indent=2))
            try:
                self.seg_preview.set_image(mask_projection(self.current_mask))
            except Exception:
                pass
            self.log_ui(f"Hemorrhage3D PRO: volume={vol_ml:.2f} ml, shift={shift_mm:.2f} mm, confidence={conf:.2f}")
        except Exception as exc:
            self.log_ui("Hemorrhage3D error: " + str(exc))
            QMessageBox.critical(self, "Hemorrhage3D", str(exc))

    def show_hemorrhage_3d_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Hemorrhage 3D", "Спочатку відкрийте CT Brain серію."); return
        try:
            if not hasattr(self, "_hemorrhage_result"):
                self.run_hemorrhage_detection_ui()
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            vol = np.asarray(self.volume)
            self.vtk_preset.setCurrentText("Brain Hemorrhage") if hasattr(self, "vtk_preset") else None
            self.vtk_viewer.set_volume(vol, spacing, "Brain Hemorrhage")
            # Add exact mask as red mesh if possible, so blood remains visible even when skull is semi-transparent.
            res = getattr(self, "_hemorrhage_result", None) or {}
            mask = res.get("hemorrhage_mask") if isinstance(res, dict) else None
            if mask is not None and np.any(mask):
                out_dir = data_dir() / "hemorrhage3d"; out_dir.mkdir(parents=True, exist_ok=True)
                mesh_path = out_dir / "hemorrhage_auto.stl"
                try:
                    from dicomview_pro.plugins.hemorrhage3d.kirivsoft_hemorrhage.mesh_export import export_mask_mesh
                    export_mask_mesh(mask, spacing, mesh_path)
                    self.vtk_viewer.add_organ_mesh(str(mesh_path), name="Hemorrhage", color=(1.0, 0.02, 0.02), opacity=0.96)
                except Exception as mesh_exc:
                    self.log_ui("Hemorrhage mesh overlay skipped: " + str(mesh_exc))
            self.tabs.setCurrentWidget(self.vtk_viewer.parentWidget())
        except Exception as exc:
            self.log_ui("Hemorrhage 3D render error: " + str(exc))
            QMessageBox.critical(self, "Hemorrhage 3D", str(exc))

    def export_hemorrhage_mesh_ui(self):
        try:
            if not hasattr(self, "_hemorrhage_result"):
                self.run_hemorrhage_detection_ui()
            res = getattr(self, "_hemorrhage_result", None) or {}
            mask = res.get("hemorrhage_mask") if isinstance(res, dict) else None
            if mask is None or not np.any(mask):
                QMessageBox.warning(self, "Hemorrhage export", "Немає маски крововиливу для експорту."); return
            path, _ = QFileDialog.getSaveFileName(self, "Export hemorrhage", "hemorrhage.stl", "3D model (*.stl *.ply *.obj)")
            if not path:
                return
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            from dicomview_pro.plugins.hemorrhage3d.kirivsoft_hemorrhage.mesh_export import export_mask_mesh
            export_mask_mesh(mask, spacing, path)
            self.log_ui("Hemorrhage mesh exported: " + str(path))
            QMessageBox.information(self, "Hemorrhage export", "Експортовано: " + str(path))
        except Exception as exc:
            self.log_ui("Hemorrhage export error: " + str(exc))
            QMessageBox.critical(self, "Hemorrhage export", str(exc))


    def _ai_suite_class(self):
        try:
            from dicomview_pro.plugins.ai_diagnostics.enterprise_ai_suite import EnterpriseAISuite
            return EnterpriseAISuite
        except Exception as exc:
            raise RuntimeError("AI Diagnostics Suite v5 недоступний: " + str(exc))

    def _ai_spacing(self):
        return tuple(float(v) for v in self.metadata.get("spacing", [1, 1, 1]))

    def _ai_color_tuple(self, result) -> tuple[float, float, float]:
        name = str(getattr(result, "name", "")).lower()
        ov = getattr(result, "overlays", {}) or {}
        txt = str(ov.get("color") or ov.get("tumor_color") or ov.get("ischemia_color") or "").lower()
        if "fracture" in name or "yellow" in txt:
            return (1.0, 0.85, 0.05)
        if "vessel" in name or "arter" in txt or "red" in txt:
            return (1.0, 0.05, 0.03)
        if "tumor" in name or "violet" in txt or "purple" in txt:
            return (0.72, 0.18, 1.0)
        if "stroke" in name or "ischemia" in txt or "blue" in txt:
            return (0.05, 0.35, 1.0)
        if "organ" in name or "green" in txt:
            return (0.05, 0.90, 0.35)
        return (1.0, 0.12, 0.05)

    def _ai_result_summary_text(self, data: dict) -> str:
        lines = ["DicomView PRO AI Diagnostics Suite v5 — результат safe fallback аналізу", ""]
        for m in data.get("modules", []):
            lines.append(f"• {m.get('name')}: {float(m.get('volume_ml', 0.0)):.2f} ml | confidence {float(m.get('confidence', 0.0)):.2f} | voxels {int(m.get('mask_voxels', 0))}")
            findings = m.get("findings") or []
            if findings:
                lines.append("  Findings: " + "; ".join(map(str, findings[:4])))
            notes = m.get("notes") or []
            if notes:
                lines.append("  Notes: " + "; ".join(map(str, notes[:3])))
        lines.append("")
        lines.append("Попередження: це допоміжна візуалізація/підсвічування, не автоматичний діагноз.")
        return "\n".join(lines)

    def run_enterprise_ai_suite_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "AI Diagnostics", "Спочатку відкрийте DICOM серію."); return
        try:
            Suite = self._ai_suite_class()
            suite = Suite()
            spacing = self._ai_spacing()
            data = suite.analyze_volume(np.asarray(self.volume), spacing)
            self._ai_suite_instance = suite
            self._ai_suite_results = suite.last_results
            self._ai_suite_data = data
            non_empty = [r for r in suite.last_results if np.any(r.mask)]
            if non_empty:
                best = max(non_empty, key=lambda r: float(getattr(r, "volume_ml", 0.0)))
                self.current_mask = best.mask
                try:
                    self.seg_preview.set_image(mask_projection(best.mask))
                except Exception:
                    pass
            txt = self._ai_result_summary_text(data)
            if hasattr(self, "ai_diagnostics_output"):
                self.ai_diagnostics_output.setPlainText(txt)
            if hasattr(self, "ai_summary_label"):
                self.ai_summary_label.setText("AI Suite: " + ", ".join(f"{r.name} {r.volume_ml:.1f} ml" for r in suite.last_results))
            self.plugin_status_output.setPlainText("AI Diagnostics Suite v5: loaded and analyzed current study\n" + txt) if hasattr(self, "plugin_status_output") else None
            self.log_ui("Enterprise AI Suite v5 complete")
            self.tabs.setCurrentWidget(self.ai_diagnostics_output.parentWidget().parentWidget() if hasattr(self, "ai_diagnostics_output") else self.tabs.currentWidget())
        except Exception as exc:
            self.log_ui("AI Diagnostics Suite error: " + str(exc))
            QMessageBox.critical(self, "AI Diagnostics", str(exc))

    def show_ai_overlays_3d_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "AI 3D Overlay", "Спочатку відкрийте DICOM серію."); return
        try:
            if not hasattr(self, "_ai_suite_results"):
                self.run_enterprise_ai_suite_ui()
            results = getattr(self, "_ai_suite_results", []) or []
            spacing = self._ai_spacing()
            vol = np.asarray(self.volume)
            self.vtk_preset.setCurrentText("Bone Ultra") if hasattr(self, "vtk_preset") else None
            self.vtk_viewer.set_volume(vol, spacing, "Bone Ultra")
            out_dir = data_dir() / "ai_diagnostics_meshes"; out_dir.mkdir(parents=True, exist_ok=True)
            added = 0
            from dicomview_pro.plugins.ai_diagnostics.common import export_mask_mesh
            for r in results:
                if not np.any(r.mask):
                    continue
                name = str(r.name).lower().replace(" ", "_").replace("/", "_")
                path = out_dir / f"{name}.stl"
                try:
                    export_mask_mesh(r.mask, spacing, path)
                    self.vtk_viewer.add_organ_mesh(str(path), name=str(r.name), color=self._ai_color_tuple(r), opacity=0.90)
                    added += 1
                except Exception as mesh_exc:
                    self.log_ui(f"AI overlay skipped {r.name}: {mesh_exc}")
            self.tabs.setCurrentWidget(self.vtk_viewer.parentWidget())
            self.log_ui(f"AI 3D overlays added: {added}")
        except Exception as exc:
            self.log_ui("AI 3D Overlay error: " + str(exc))
            QMessageBox.critical(self, "AI 3D Overlay", str(exc))

    def export_ai_meshes_ui(self):
        try:
            if not hasattr(self, "_ai_suite_results"):
                self.run_enterprise_ai_suite_ui()
            results = getattr(self, "_ai_suite_results", []) or []
            if not results:
                QMessageBox.warning(self, "AI export", "AI Suite ще не має результатів."); return
            folder = QFileDialog.getExistingDirectory(self, "Виберіть папку для AI STL/PLY/OBJ")
            if not folder:
                return
            fmt, ok = QInputDialog.getItem(self, "Формат", "Формат 3D-моделей", ["stl", "ply", "obj"], 0, False)
            if not ok:
                return
            from dicomview_pro.plugins.ai_diagnostics.common import export_mask_mesh
            spacing = self._ai_spacing()
            paths = []
            for r in results:
                if not np.any(r.mask):
                    continue
                name = str(r.name).lower().replace(" ", "_").replace("/", "_")
                p = Path(folder) / f"{name}.{fmt}"
                try:
                    export_mask_mesh(r.mask, spacing, p); paths.append(str(p))
                except Exception as exc:
                    self.log_ui(f"AI mesh export skipped {r.name}: {exc}")
            QMessageBox.information(self, "AI export", "Експортовано моделей: " + str(len(paths)))
            self.log_ui("AI meshes exported: " + "; ".join(paths))
        except Exception as exc:
            self.log_ui("AI mesh export error: " + str(exc))
            QMessageBox.critical(self, "AI export", str(exc))

    def apply_bone_ultra_3d_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Bone Ultra", "Спочатку відкрийте DICOM серію."); return
        try:
            if hasattr(self, "vtk_mode"):
                self.vtk_mode.setCurrentText("Modern VTK Volume Rendering")
            if hasattr(self, "vtk_preset"):
                self.vtk_preset.setCurrentText("Bone Ultra")
            self.vtk_viewer.set_volume(np.asarray(self.volume), self._ai_spacing(), "Bone Ultra")
            self.tabs.setCurrentWidget(self.vtk_viewer.parentWidget())
            self.log_ui("Bone Ultra 3D applied")
        except Exception as exc:
            self.log_ui("Bone Ultra error: " + str(exc))
            QMessageBox.critical(self, "Bone Ultra", str(exc))

    def set_cine_frame(self, value: int):
        if self.volume is None:
            return
        self.cine_frame = int(np.clip(value, 0, self.volume.shape[0]-1))
        self.update_cine()

    def step_cine(self, delta: int):
        if self.volume is None:
            return
        n = self.volume.shape[0]
        new_frame = self.cine_frame + int(delta)
        if getattr(self, "cine_loop", None) is not None and not self.cine_loop.isChecked():
            new_frame = max(0, min(n - 1, new_frame))
            if new_frame == self.cine_frame and self.cine_timer.isActive():
                self.cine_timer.stop(); self.cine_play_btn.setText("▶ Play")
        else:
            new_frame = new_frame % max(n, 1)
        self.cine_frame = new_frame
        self.cine_slider.blockSignals(True); self.cine_slider.setValue(self.cine_frame); self.cine_slider.blockSignals(False)
        self.update_cine()

    def next_cine_frame(self):
        self.step_cine(1)

    def toggle_cine(self):
        if self.volume is None:
            QMessageBox.warning(self, "Cine", "Спочатку відкрийте DICOM серію або multi-frame файл."); return
        if self.cine_timer.isActive():
            self.cine_timer.stop(); self.cine_play_btn.setText("▶ Play")
        else:
            interval = int(1000 / max(1.0, float(self.cine_fps.value())))
            self.cine_timer.start(interval); self.cine_play_btn.setText("⏸ Pause")

    def update_cine(self):
        if self.volume is None:
            return
        try:
            frame = np.asarray(self.volume[self.cine_frame], dtype=np.float32)
            if getattr(self, "cine_dsa_check", None) is not None and self.cine_dsa_check.isChecked():
                frame = dsa_frame(np.asarray(self.volume), self.cine_frame, int(self.cine_mask_frame.value()) - 1)
                c = float(np.mean(frame)); w = max(1.0, float(np.percentile(frame, 99) - np.percentile(frame, 1)))
                img = window_to_uint8(frame, c, w, invert=self.invert_display, sharpen="off")
            elif getattr(self, "cine_enhance_check", None) is not None and self.cine_enhance_check.isChecked():
                enhanced = contrast_enhance_frame(frame)
                img = window_to_uint8(enhanced, 127.0, 255.0, invert=False, sharpen="off")
            else:
                img = self.render_slice_u8(frame)
            self.cine_label.crosshair = None
            # Lock viewport in Cine to prevent scale jumps between frames.
            if getattr(self, "cine_lock_view", None) is not None and self.cine_lock_view.isChecked():
                try:
                    bbox = self._smoothstack_bboxes.get("cine") or self._smoothstack_bboxes.get("axial")
                    if bbox is not None:
                        self.cine_label.set_locked_crop_bbox(bbox)
                except Exception:
                    pass
            self.cine_label.set_image(img, frame)
            flags = []
            if getattr(self, "cine_dsa_check", None) is not None and self.cine_dsa_check.isChecked(): flags.append("DSA")
            if getattr(self, "cine_enhance_check", None) is not None and self.cine_enhance_check.isChecked(): flags.append("Enhance")
            suffix = " · " + "/".join(flags) if flags else ""
            self.cine_info.setText(f"Cine: кадр {self.cine_frame + 1}/{self.volume.shape[0]}{suffix}")
        except Exception as exc:
            self.log_ui("Cine error: " + str(exc))


    def cine_profile_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Cine/Angio", "Спочатку відкрийте DICOM серію або XA/XRF multi-frame файл.")
            return
        try:
            profile = detect_angio_cine_profile(self.metadata or {}, tuple(np.asarray(self.volume).shape))
            self.cine_fps.setValue(max(1.0, min(60.0, float(profile.fps))))
            # Apply angio W/L only for real XA/XRF; do not override CT brain presets.
            if profile.is_xa_xrf:
                self.center = profile.recommended_window_center
                self.width = max(1.0, profile.recommended_window_width)
                self.center_spin.blockSignals(True); self.width_spin.blockSignals(True)
                self.center_spin.setValue(int(round(self.center))); self.width_spin.setValue(int(round(self.width)))
                self.center_spin.blockSignals(False); self.width_spin.blockSignals(False)
                self.update_cine(); self.update_views(); self.update_projection()
            text = profile_to_text(profile)
            self.cine_info.setText(f"Cine: {profile.suggested_mode}; {profile.frames} кадрів; {profile.fps:.1f} fps")
            self.log_ui("Cine/Angio profile:\n" + text)
            QMessageBox.information(self, "Cine/Angio profile", text[:4000])
        except Exception as exc:
            self.log_ui("Cine/Angio profile error: " + str(exc))
            QMessageBox.critical(self, "Cine/Angio", str(exc))

    def export_cine_png_sequence_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Cine PNG", "Спочатку відкрийте cine / multi-frame DICOM або серію.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Папка для PNG sequence")
        if not folder:
            return
        try:
            fps = float(self.cine_fps.value())
            result = export_png_sequence(np.asarray(self.volume), folder, self.center, self.width, fps=fps)
            self.log_ui(f"Cine PNG sequence exported: {result.get('frames')} frames to {folder}")
            QMessageBox.information(self, "Cine PNG", f"Експортовано кадрів: {result.get('frames')}\n{folder}")
        except Exception as exc:
            self.log_ui("Cine PNG export error: " + str(exc))
            QMessageBox.critical(self, "Cine PNG", str(exc))

    def export_cine(self, fmt: str):
        if self.volume is None:
            QMessageBox.warning(self, "Cine export", "Спочатку відкрийте cine / multi-frame DICOM або серію.")
            return
        suffix = ".gif" if fmt.lower() == "gif" else ".mp4"
        title = "Зберегти Cine GIF" if fmt.lower() == "gif" else "Зберегти Cine MP4"
        filters = "GIF animation (*.gif)" if fmt.lower() == "gif" else "MP4 video (*.mp4)"
        path, _ = QFileDialog.getSaveFileName(self, title, "dicomview_cine" + suffix, filters)
        if not path:
            return
        try:
            fps = float(self.cine_fps.value())
            if fmt.lower() == "gif":
                result = export_cine_gif(np.asarray(self.volume), path, self.center, self.width, fps=fps)
            else:
                result = export_cine_mp4(np.asarray(self.volume), path, self.center, self.width, fps=fps)
            self.log_ui(f"Cine exported: {result.format} {result.path}; frames={result.frames}; fps={result.fps}")
            QMessageBox.information(self, "Cine export", f"Збережено {result.format}:\n{result.path}\nКадрів: {result.frames}")
        except Exception as exc:
            self.log_ui("Cine export error: " + str(exc))
            QMessageBox.critical(self, "Cine export", str(exc))

    def _pacs_cfg(self) -> PacsConfig:
        return PacsConfig(
            ae_title=self.pacs_ae.text().strip() or "DICOMVIEW",
            peer_ae_title=self.pacs_peer.text().strip() or "ANY-SCP",
            host=self.pacs_host.text().strip() or "127.0.0.1",
            port=int(self.pacs_port.value()),
        )

    def _pacs_log_result(self, event: str, result):
        text = json.dumps({"ok": result.ok, "message": result.message, "details": result.details}, ensure_ascii=False, indent=2)
        self.pacs_output.append(text)
        try:
            audit = write_pacs_audit(event, result, log_path().parent)
            self.log_ui(f"PACS {event}: {result.message}; audit={audit}")
        except Exception:
            self.log_ui(f"PACS {event}: {result.message}")

    def pacs_echo_ui(self):
        try:
            result = pacs_echo(self._pacs_cfg())
            self._pacs_log_result("C-ECHO", result)
            QMessageBox.information(self, "PACS", result.message)
        except Exception as exc:
            self.pacs_output.append("PACS C-ECHO error: " + str(exc))
            self.log_ui("PACS C-ECHO error: " + str(exc))
            QMessageBox.critical(self, "PACS", str(exc))

    def pacs_find_ui(self):
        try:
            result = pacs_find_studies(self._pacs_cfg(), self.pacs_patient.text().strip() or "*")
            self._pacs_log_result("C-FIND", result)
        except Exception as exc:
            self.pacs_output.append("PACS C-FIND error: " + str(exc))
            self.log_ui("PACS C-FIND error: " + str(exc))
            QMessageBox.critical(self, "PACS", str(exc))

    def pacs_store_ui(self):
        file, _ = QFileDialog.getOpenFileName(self, "Відправити DICOM файл на PACS", "", "DICOM (*.dcm *.dicom *.ima);;All files (*)")
        if not file:
            return
        try:
            result = pacs_store_file(self._pacs_cfg(), file)
            self._pacs_log_result("C-STORE", result)
            QMessageBox.information(self, "PACS", result.message)
        except Exception as exc:
            self.pacs_output.append("PACS C-STORE error: " + str(exc))
            self.log_ui("PACS C-STORE error: " + str(exc))
            QMessageBox.critical(self, "PACS", str(exc))


    def _orthanc_cfg(self) -> OrthancConfig:
        return OrthancConfig(
            url=self.orthanc_url.text().strip() or "http://127.0.0.1:8042",
            username=self.orthanc_user.text().strip(),
            password=self.orthanc_pass.text(),
        )

    def orthanc_check_ui(self):
        try:
            result = OrthancClient(self._orthanc_cfg()).system()
            self.orthanc_output.append(json.dumps({"ok": result.ok, "message": result.message, "data": result.data}, ensure_ascii=False, indent=2))
            self.log_ui("Orthanc check: " + result.message)
        except Exception as exc:
            self.orthanc_output.append("Orthanc error: " + str(exc)); self.log_ui("Orthanc error: " + str(exc))

    def orthanc_studies_ui(self):
        try:
            result = OrthancClient(self._orthanc_cfg()).studies()
            self.orthanc_output.append(json.dumps({"ok": result.ok, "message": result.message, "data": result.data}, ensure_ascii=False, indent=2)[:20000])
            self.log_ui("Orthanc studies: " + result.message)
        except Exception as exc:
            self.orthanc_output.append("Orthanc studies error: " + str(exc)); self.log_ui("Orthanc studies error: " + str(exc))

    def orthanc_upload_ui(self):
        file, _ = QFileDialog.getOpenFileName(self, "Відправити DICOM файл в Orthanc", "", "DICOM (*.dcm *.dicom *.ima);;All files (*)")
        if not file:
            return
        try:
            result = OrthancClient(self._orthanc_cfg()).upload_file(file)
            self.orthanc_output.append(json.dumps({"ok": result.ok, "message": result.message, "data": result.data}, ensure_ascii=False, indent=2))
            self.log_ui("Orthanc upload: " + result.message)
        except Exception as exc:
            self.orthanc_output.append("Orthanc upload error: " + str(exc)); self.log_ui("Orthanc upload error: " + str(exc))


    def _protocol_spacing(self) -> tuple[float, float, float]:
        sp = self.metadata.get("spacing_zyx_mm") or self.metadata.get("spacing") or (1.0, 1.0, 1.0)
        try:
            if len(sp) >= 3:
                return (float(sp[0]), float(sp[1]), float(sp[2]))
        except Exception:
            pass
        return (1.0, 1.0, 1.0)

    def _set_protocol_report(self, title: str, payload: dict) -> None:
        try:
            self.report_info.setText(f"Клінічний протокол: {title}. Дані є підказкою для лікаря, не автоматичним діагнозом.")
            self.report_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.switch_tab("Звіт")
            self.log_ui(f"Protocol report updated: {title}")
        except Exception as exc:
            self.log_ui("Protocol report update error: " + str(exc))

    def _clinical_protocol_engine(self) -> ClinicalProtocolEngine:
        engine = getattr(self, "_protocol_engine", None)
        if engine is None:
            engine = ClinicalProtocolEngine()
            self._protocol_engine = engine
        return engine

    def _apply_protocol_result_to_ui(self, result) -> None:
        """Apply protocol measurements, report and optional 3D overlay to the UI."""
        payload = result.to_json_dict()
        payload["doctor_note"] = "Програма лише підказує і візуалізує. Остаточний аналіз виконує лікар на оригінальних DICOM-зрізах."
        self._last_protocol_result = result
        self._last_protocol_payload = payload
        self.current_mask = result.mask.astype(bool)
        self.center = float(result.protocol.window_center)
        self.width = float(result.protocol.window_width)
        try:
            if hasattr(self, "center_spin"): self.center_spin.setValue(int(self.center))
            if hasattr(self, "width_spin"): self.width_spin.setValue(int(self.width))
            self.update_views()
        except Exception as exc:
            self.log_ui("Protocol WL/update skipped: " + str(exc))
        text = protocol_pretty_text(result)
        try:
            self.report_info.setText(f"Клінічний протокол: {result.protocol.title_ua}. Це підказка для лікаря, не автоматичний діагноз.")
            self.report_output.setPlainText(text)
        except Exception:
            pass
        try:
            self.status.setText(result.summary_ua())
        except Exception:
            pass
        try:
            if np.any(result.mask) and hasattr(self, "vtk_viewer"):
                # Keep the selected 3D workflow, but add a clear protocol overlay when supported.
                if hasattr(self, "vtk_preset") and result.protocol.key == "hemorrhage":
                    self.vtk_preset.setCurrentText("Brain Hemorrhage")
                if hasattr(self, "vtk_preset") and result.protocol.key == "trauma":
                    self.vtk_preset.setCurrentText("Trauma Cinematic")
                if result.protocol.key == "hemorrhage" and hasattr(self.vtk_viewer, "set_hemorrhage_focus_volume"):
                    self.vtk_viewer.set_hemorrhage_focus_volume(np.asarray(self.volume), result.spacing_zyx_mm, result.mask, payload.get("metrics", {}))
                elif result.protocol.key == "trauma":
                    self.vtk_viewer.set_volume(np.asarray(self.volume), result.spacing_zyx_mm, "Trauma Cinematic")
                else:
                    self.vtk_viewer.set_volume(np.asarray(self.volume), result.spacing_zyx_mm, "Soft Tissue")
        except Exception as viz_exc:
            self.log_ui("Protocol 3D overlay skipped: " + str(viz_exc))
        self.switch_tab("Звіт")
        self.log_ui("Clinical protocol completed: " + result.summary_ua())

    def run_clinical_protocol_ui(self, protocol_key: str):
        if self.volume is None:
            QMessageBox.warning(self, "Протокол", "Спочатку відкрийте DICOM/CT серію."); return
        try:
            spacing = self._protocol_spacing()
            result = self._clinical_protocol_engine().run(protocol_key, np.asarray(self.volume), spacing)
            self._apply_protocol_result_to_ui(result)
        except Exception as exc:
            self.log_ui(f"Protocol {protocol_key} error: {exc}")
            QMessageBox.critical(self, "Протокол", str(exc))

    def run_protocol_hemorrhage_ui(self):
        self.run_clinical_protocol_ui("hemorrhage")

    def run_protocol_trauma_ui(self):
        self.run_clinical_protocol_ui("trauma")

    def run_protocol_stub_ui(self, protocol_name: str):
        mapping = {"Травма": "trauma", "Ішемія": "ischemia", "Онко": "onco", "Запалення": "inflammation"}
        self.run_clinical_protocol_ui(mapping.get(protocol_name, "hemorrhage"))

    def save_protocol_json_ui(self):
        payload = getattr(self, "_last_protocol_payload", None)
        if not payload:
            QMessageBox.warning(self, "Звіт", "Спочатку запустіть клінічний протокол."); return
        path, _ = QFileDialog.getSaveFileName(self, "Зберегти JSON протоколу", "dicomview_protocol_report.json", "JSON (*.json)")
        if not path: return
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log_ui("Protocol JSON saved: " + path)

    def save_protocol_txt_ui(self):
        text = self.report_output.toPlainText() if hasattr(self, "report_output") else ""
        if not text.strip():
            QMessageBox.warning(self, "Звіт", "Немає тексту звіту для збереження."); return
        path, _ = QFileDialog.getSaveFileName(self, "Зберегти TXT протоколу", "dicomview_protocol_report.txt", "Text (*.txt)")
        if not path: return
        Path(path).write_text(text, encoding="utf-8")
        self.log_ui("Protocol TXT saved: " + path)

    def create_report_ui(self, fmt: str):
        if not self.metadata:
            QMessageBox.warning(self, "Звіт", "Спочатку відкрийте DICOM серію."); return
        if fmt == "pdf":
            path, _ = QFileDialog.getSaveFileName(self, "Зберегти PDF звіт", "dicomview_report.pdf", "PDF (*.pdf)")
            if not path: return
            result = create_pdf_report(path, self.metadata, self.measure_history)
        else:
            path, _ = QFileDialog.getSaveFileName(self, "Зберегти DOCX звіт", "dicomview_report.docx", "DOCX (*.docx)")
            if not path: return
            result = create_docx_report(path, self.metadata, self.measure_history)
        self.report_output.append(json.dumps(result.__dict__, ensure_ascii=False, indent=2))
        self.log_ui("Report: " + result.message)
        QMessageBox.information(self, "Звіт", f"{result.message}\n{result.path}")

    def radiomics_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Radiomics", "Спочатку відкрийте DICOM серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            mask = self.current_mask if (self.radiomics_mask_only.isChecked() and self.current_mask is not None) else None
            result = basic_radiomics(np.asarray(self.volume), mask, spacing)
            payload = {"pyradiomics_installed": pyradiomics_available(), "available": result.available, "message": result.message, "features": result.features}
            self.radiomics_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.log_ui("Radiomics: " + result.message)
        except Exception as exc:
            self.radiomics_output.setPlainText("Radiomics error: " + str(exc)); self.log_ui("Radiomics error: " + str(exc))

    def orthanc_search_ui(self):
        try:
            query = self.orthanc_patient.text().strip() or "*"
            result = OrthancClient(self._orthanc_cfg()).search_studies_by_patient_name(query)
            self.orthanc_output.append(json.dumps({"ok": result.ok, "message": result.message, "data": result.data}, ensure_ascii=False, indent=2)[:30000])
            self.log_ui("Orthanc search: " + result.message)
        except Exception as exc:
            self.orthanc_output.append("Orthanc search error: " + str(exc)); self.log_ui("Orthanc search error: " + str(exc))

    def orthanc_download_series_ui(self):
        try:
            series_id, ok = QInputDialog.getText(self, "Orthanc", "Введіть Orthanc Series ID для завантаження ZIP:")
            if not ok or not series_id.strip():
                return
            path, _ = QFileDialog.getSaveFileName(self, "Зберегти Orthanc Series ZIP", "orthanc_series.zip", "ZIP archive (*.zip)")
            if not path:
                return
            result = OrthancClient(self._orthanc_cfg()).download_series_zip(series_id.strip(), path)
            self.orthanc_output.append(json.dumps({"ok": result.ok, "message": result.message, "data": result.data}, ensure_ascii=False, indent=2))
            self.log_ui("Orthanc download: " + result.message)
            QMessageBox.information(self, "Orthanc", result.message) if result.ok else QMessageBox.warning(self, "Orthanc", result.message)
        except Exception as exc:
            self.orthanc_output.append("Orthanc download error: " + str(exc)); self.log_ui("Orthanc download error: " + str(exc))

    def case_add_current_ui(self):
        if not self.metadata:
            QMessageBox.warning(self, "Case Manager", "Спочатку відкрийте DICOM серію."); return
        try:
            cid = self.case_manager.add_from_metadata(self.metadata, self.current_path or "", "")
            self.case_output.append(f"Додано кейс ID={cid}")
            self.log_ui(f"Case Manager: added case {cid}")
        except Exception as exc:
            self.case_output.append("Case add error: " + str(exc)); self.log_ui("Case add error: " + str(exc))

    def case_list_ui(self):
        try:
            rows = self.case_manager.list_cases(200)
            self.case_output.setPlainText(json.dumps(rows, ensure_ascii=False, indent=2))
            self.log_ui(f"Case Manager: listed {len(rows)} cases")
        except Exception as exc:
            self.case_output.setPlainText("Case list error: " + str(exc)); self.log_ui("Case list error: " + str(exc))

    def case_search_ui(self):
        try:
            q = self.case_search_text.text().strip()
            rows = self.case_manager.search(q, 200) if q else self.case_manager.list_cases(200)
            self.case_output.setPlainText(json.dumps(rows, ensure_ascii=False, indent=2))
            self.log_ui(f"Case Manager: search '{q}' -> {len(rows)} cases")
        except Exception as exc:
            self.case_output.setPlainText("Case search error: " + str(exc)); self.log_ui("Case search error: " + str(exc))

    def case_export_ui(self):
        path, _ = QFileDialog.getSaveFileName(self, "Експорт Case Manager JSON", "dicomview_cases.json", "JSON (*.json)")
        if not path:
            return
        try:
            out = self.case_manager.export_json(path)
            self.case_output.append("Експортовано: " + out)
            self.log_ui("Case Manager exported: " + out)
        except Exception as exc:
            self.case_output.append("Case export error: " + str(exc)); self.log_ui("Case export error: " + str(exc))


    def vessel_analysis_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Vessel", "Спочатку відкрийте DICOM серію."); return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            result = analyze_vessels(np.asarray(self.volume), spacing, float(self.vessel_min.value()), float(self.vessel_max.value()))
            self.vessel_output.setPlainText(json.dumps(result.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Vessel Analysis: " + result.message)
        except Exception as exc:
            self.vessel_output.setPlainText("Vessel error: " + str(exc)); self.log_ui("Vessel error: " + str(exc))

    def vessel_mip_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Vessel MIP", "Спочатку відкрийте DICOM серію."); return
        try:
            img = vessel_mip(np.asarray(self.volume), float(self.vessel_min.value()))
            self.vessel_preview.set_image(self.render_slice_u8(img), img)
            self.tabs.setCurrentWidget(self.vessel_preview.parentWidget())
            self.log_ui("Vessel MIP preview updated")
        except Exception as exc:
            self.vessel_output.setPlainText("Vessel MIP error: " + str(exc)); self.log_ui("Vessel MIP error: " + str(exc))

    def angio_inspect_ui(self):
        try:
            result = inspect_angio_metadata(self.metadata or {})
            self.angio_output.setPlainText(json.dumps(result.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Angio inspect: " + result.message)
        except Exception as exc:
            self.angio_output.setPlainText("Angio inspect error: " + str(exc)); self.log_ui("Angio inspect error: " + str(exc))

    def angio_dsa_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "DSA", "Спочатку відкрийте XA/cine DICOM."); return
        try:
            mask_idx = int(getattr(self, "cine_mask_frame", None).value()) - 1 if getattr(self, "cine_mask_frame", None) is not None else 0
            dsa = dsa_subtract(np.asarray(self.volume), mask_frame=mask_idx)
            img = temporal_projection(dsa, "max")
            self.angio_preview.set_image(window_to_uint8(img, float(np.mean(img)), max(1.0, float(np.ptp(img))), invert=self.invert_display, sharpen="off"), img)
            self.angio_output.setPlainText(f"DSA preview створено з mask frame {mask_idx + 1}.")
            self.log_ui("DSA preview complete")
        except Exception as exc:
            self.angio_output.setPlainText("DSA error: " + str(exc)); self.log_ui("DSA error: " + str(exc))

    def angio_tmax_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Temporal Max", "Спочатку відкрийте DICOM серію."); return
        try:
            img = temporal_max_projection(np.asarray(self.volume))
            self.angio_preview.set_image(self.render_slice_u8(img), img)
            self.angio_output.setPlainText("Temporal Max Projection створено.")
            self.log_ui("Temporal Max Projection complete")
        except Exception as exc:
            self.angio_output.setPlainText("Temporal Max error: " + str(exc)); self.log_ui("Temporal Max error: " + str(exc))

    def angio_pseudo3d_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "3D Angio", "Спочатку відкрийте DICOM серію."); return
        try:
            mask = pseudo_3d_angio_preview(np.asarray(self.volume))
            self.current_mask = mask
            self.seg_preview.set_image(mask_projection(mask))
            self.angio_output.setPlainText("Pseudo 3D vessel mask створена і передана у Segmentation/Export. Це не діагностична 3D реконструкція.")
            self.tabs.setCurrentWidget(self.seg_preview.parentWidget())
            self.log_ui("Pseudo 3D Angio mask complete")
        except Exception as exc:
            self.angio_output.setPlainText("Pseudo 3D error: " + str(exc)); self.log_ui("Pseudo 3D error: " + str(exc))

    def cardiac4d_inspect_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "4D", "Спочатку відкрийте DICOM серію."); return
        try:
            info = inspect_4d(np.asarray(self.volume), self.metadata or {})
            self.cardiac4d_output.setPlainText(json.dumps(info.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("4D inspect: " + info.message)
        except Exception as exc:
            self.cardiac4d_output.setPlainText("4D error: " + str(exc)); self.log_ui("4D error: " + str(exc))

    def ai_env_ui(self):
        try:
            env = ai_environment()
            self.ai_output.setPlainText(json.dumps(env, ensure_ascii=False, indent=2))
            self.log_ui("AI env checked")
        except Exception as exc:
            self.ai_output.setPlainText("AI env error: " + str(exc)); self.log_ui("AI env error: " + str(exc))

    def ai_models_ui(self):
        try:
            status = ai_engine_status()
            self.ai_output.setPlainText(json.dumps({"environment": status.environment, "models": status.models}, ensure_ascii=False, indent=2))
            self.log_ui("AI models scanned")
        except Exception as exc:
            self.ai_output.setPlainText("AI models error: " + str(exc)); self.log_ui("AI models error: " + str(exc))

    def open_organ_segmentation_tab(self):
        """Lite stub: Organ Segmentation is an optional Enterprise plugin."""
        QMessageBox.information(self, "Organ Segmentation", "У Lite-версії Organ AI вимкнено. Підключіть Enterprise plugin / TotalSegmentator Runtime окремо.")
        try:
            self.tabs.setCurrentWidget(self.plugin_status_output.parentWidget())
        except Exception:
            pass

    def organ_ai_status_ui(self):
        """Check optional TotalSegmentator organ-segmentation runtime."""
        try:
            status = organ_ai_status()
            self.ai_output.setPlainText(json.dumps(status.to_dict(), ensure_ascii=False, indent=2))
            self.log_ui("Organ AI status checked: " + status.mode)
        except Exception as exc:
            self.ai_output.setPlainText("Organ AI status error: " + str(exc)); self.log_ui("Organ AI status error: " + str(exc))

    def organ_ai_prepare_plan_ui(self):
        """Prepare a safe manifest for optional DICOM -> NIfTI -> TotalSegmentator -> STL pipeline."""
        try:
            folder = getattr(self, "current_folder", None) or getattr(self, "folder_path", None)
            if not folder:
                folder = QFileDialog.getExistingDirectory(self, "Виберіть DICOM папку для Organ AI")
            if not folder:
                return
            work = data_dir() / "organ_ai_work"
            plan = build_organ_segmentation_plan(folder, work, fast=True)
            manifest = work / "organ_segmentation_plan.json"
            write_plan_manifest(plan, manifest)
            payload = {
                "status": organ_ai_status().to_dict(),
                "plan": plan.to_dict(),
                "manifest": str(manifest),
                "note": "This prepares the optional module. Install TotalSegmentator runtime to execute heavy segmentation.",
            }
            self.ai_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.log_ui("Organ AI plan prepared: " + str(manifest))
        except Exception as exc:
            self.ai_output.setPlainText("Organ AI plan error: " + str(exc)); self.log_ui("Organ AI plan error: " + str(exc))

    def _require_current_ai_slice(self) -> np.ndarray | None:
        if self.current_slice is None:
            QMessageBox.warning(self, "AI", "Спочатку відкрийте DICOM серію і виберіть 2D-зріз.")
            return None
        return np.asarray(self.current_slice)


    def toggle_sam_click_ui(self):
        enabled = bool(self.b_ai_sam_click.isChecked()) if hasattr(self, "b_ai_sam_click") else not self.sam_click_enabled
        self.sam_click_enabled = enabled
        if enabled:
            if self.current_slice is None:
                QMessageBox.warning(self, "MobileSAM", "Спочатку відкрийте DICOM серію і виберіть 2D-зріз.")
                self.sam_click_enabled = False
                self.b_ai_sam_click.setChecked(False)
                return
            self._sam_previous_measure_mode = self.measure_combo.currentText() if hasattr(self, "measure_combo") else "distance"
            self.img2d.measure_mode = "sam_click"
            self.img2d.points.clear()
            self.b_ai_sam_click.setText("Smart Click ROI: ON")
            self.tabs.setCurrentWidget(self.img2d.parentWidget())
            self.ai_output.setPlainText("MobileSAM Smart Click ROI активовано. Клацніть лівою кнопкою по структурі на вкладці 2D. Потрібні encoder+decoder ONNX у _internal/models/segmentation. Якщо моделей немає — буде safe fallback.")
            self.log_ui("MobileSAM Smart Click ROI enabled")
        else:
            self.img2d.measure_mode = self._sam_previous_measure_mode
            self.img2d.points.clear()
            self.img2d._update_pixmap()
            self.b_ai_sam_click.setText("Smart Click ROI: OFF")
            self.log_ui("MobileSAM Smart Click ROI disabled")

    def start_sam_click_segmentation(self, pt):
        if self.current_slice is None:
            return
        if self.sam_worker is not None and self.sam_worker.isRunning():
            self.ai_output.setPlainText("MobileSAM ще обробляє попередній клік. Дочекайтеся завершення або повторіть після повідомлення.")
            return
        x, y = int(pt[0]), int(pt[1])
        self.img2d.crosshair = (x, y)
        self.img2d._update_pixmap()
        self.ai_output.setPlainText(f"MobileSAM обробляє точку ({x}, {y}) на зрізі Z={self.cross_z}...")
        worker = MobileSAMWorker(np.asarray(self.current_slice), x, y, self.sam_model_path, self.center, self.width, self)
        self.sam_worker = worker
        worker.segmentation_success.connect(self.display_sam_result)
        worker.segmentation_failed.connect(self.handle_sam_worker_error)
        worker.finished.connect(lambda: self.log_ui("MobileSAM worker finished"))
        worker.start()

    def display_sam_result(self, result):
        if not isinstance(result, SegmentResult):
            self.ai_output.setPlainText("MobileSAM returned unexpected result")
            return
        self.ai_output.setPlainText(json.dumps({"ok": result.ok, "message": result.message, "details": result.details}, ensure_ascii=False, indent=2))
        if result.mask2d is not None:
            mask2d = np.asarray(result.mask2d, dtype=bool)
            if self.ai_preview is not None:
                self.ai_preview.set_image(mask2d.astype(np.uint8) * 255, mask2d) if getattr(self, "ai_preview", None) is not None else None
            if self.volume is not None:
                mask3d = np.zeros_like(np.asarray(self.volume), dtype=bool)
                mask3d[int(self.cross_z)] = mask2d
                self.current_mask = mask3d
                self.seg_preview.set_image(mask_projection(mask3d))
            area_text = ""
            try:
                spacing = self.metadata.get("spacing", [1, 1, 1])
                px_area = float(spacing[1]) * float(spacing[2])
                area_mm2 = float(np.count_nonzero(mask2d)) * px_area
                area_text = f"\nПлоща AI-маски: {area_mm2:.1f} мм² ({area_mm2/100.0:.2f} см²)."
            except Exception:
                pass
            self.ai_output.append(area_text)
            if self.ai_preview is not None:
                self.tabs.setCurrentWidget(self.ai_preview.parentWidget())
        self.log_ui("MobileSAM click segment: " + result.message)

    def handle_sam_worker_error(self, err: str):
        self.ai_output.setPlainText("MobileSAM worker error: " + str(err))
        self.log_ui("MobileSAM worker error: " + str(err))

    def ai_segment_current_slice_ui(self):
        img = self._require_current_ai_slice()
        if img is None:
            return
        try:
            h, w = img.shape[:2]
            result = mobile_sam_segment_slice(img, w // 2, h // 2, window_center=self.center, window_width=self.width)
            self.ai_output.setPlainText(json.dumps({"ok": result.ok, "message": result.message, "details": result.details}, ensure_ascii=False, indent=2))
            if result.mask2d is not None:
                mask2d = np.asarray(result.mask2d, dtype=bool)
                if self.ai_preview is not None:
                    self.ai_preview.set_image(mask2d.astype(np.uint8) * 255, mask2d) if getattr(self, "ai_preview", None) is not None else None
                if self.volume is not None:
                    mask3d = np.zeros_like(np.asarray(self.volume), dtype=bool)
                    mask3d[int(self.cross_z)] = mask2d
                    self.current_mask = mask3d
                    self.seg_preview.set_image(mask_projection(mask3d))
            self.log_ui("AI segment: " + result.message)
        except Exception as exc:
            self.ai_output.setPlainText("AI segment error: " + str(exc)); self.log_ui("AI segment error: " + str(exc))

    def ai_denoise_current_slice_ui(self):
        img = self._require_current_ai_slice()
        if img is None:
            return
        try:
            result = denoise_slice(img, "medium")
            self.ai_output.setPlainText(json.dumps({"ok": result.ok, "message": result.message, "details": result.details}, ensure_ascii=False, indent=2))
            if self.ai_preview is not None:
                self.ai_preview.set_image(self.render_slice_u8(result.image2d), result.image2d) if getattr(self, "ai_preview", None) is not None else None
            self.log_ui("AI denoise: " + result.message)
        except Exception as exc:
            self.ai_output.setPlainText("AI denoise error: " + str(exc)); self.log_ui("AI denoise error: " + str(exc))

    def ai_superres_current_slice_ui(self, scale: int = 2):
        img = self._require_current_ai_slice()
        if img is None:
            return
        try:
            result = superres_slice(img, scale)
            payload = {"ok": result.ok, "message": result.message, "details": result.details, "realesrgan_status": realesrgan_status()}
            self.ai_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            if self.ai_preview is not None:
                self.ai_preview.set_image(self.render_slice_u8(result.image2d), result.image2d) if getattr(self, "ai_preview", None) is not None else None
            self.log_ui("AI superres: " + result.message)
        except Exception as exc:
            self.ai_output.setPlainText("AI superres error: " + str(exc)); self.log_ui("AI superres error: " + str(exc))

    def ai_fallback_ui(self, mode: str):
        if self.volume is None:
            QMessageBox.warning(self, "AI", "Спочатку відкрийте DICOM серію."); return
        try:
            result = fallback_lung_mask(np.asarray(self.volume)) if mode == 'lungs' else fallback_bone_mask(np.asarray(self.volume))
            self.ai_output.setPlainText(json.dumps({"ok": result.ok, "message": result.message, "details": result.details}, ensure_ascii=False, indent=2))
            if result.mask is not None:
                self.current_mask = result.mask
                self.seg_preview.set_image(mask_projection(result.mask))
                self.tabs.setCurrentWidget(self.seg_preview.parentWidget())
            self.log_ui("AI fallback: " + result.message)
        except Exception as exc:
            self.ai_output.setPlainText("AI fallback error: " + str(exc)); self.log_ui("AI fallback error: " + str(exc))


    def _slicer_exe_text(self) -> str:
        return self.slicer_path.text().strip().strip('"') if hasattr(self, "slicer_path") else ""

    def _ensure_slicer_exe_ui(self) -> str:
        exe = self._slicer_exe_text()
        if exe:
            return exe
        res = find_slicer()
        if res.ok and res.path and hasattr(self, "slicer_path"):
            self.slicer_path.setText(res.path) if hasattr(self, "slicer_path") else None
            return res.path
        if hasattr(self, "slicer_output"):
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
        QMessageBox.warning(self, "Slicer Bridge", "3D Slicer не знайдено. Покладіть його у _internal/slicer або вкажіть шлях до Slicer.exe.")
        return ""

    def slicer_find_ui(self):
        try:
            res = find_slicer()
            if res.ok:
                self.slicer_path.setText(res.path) if hasattr(self, "slicer_path") else None
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Slicer Bridge: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("Slicer find error: " + str(exc)); self.log_ui("Slicer find error: " + str(exc))

    def slicer_open_dicom_ui(self):
        if not self.current_path:
            QMessageBox.warning(self, "Slicer Bridge", "Спочатку відкрийте DICOM серію або вкажіть шлях."); return
        try:
            exe = self._ensure_slicer_exe_ui()
            if not exe:
                return
            res = send_dicom_series(exe, self.current_path, command="load")
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Slicer open DICOM: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("Slicer open error: " + str(exc)); self.log_ui("Slicer open error: " + str(exc))

    def slicer_segment_editor_ui(self):
        if not self.current_path and self.volume is None:
            QMessageBox.warning(self, "Slicer Bridge", "Спочатку відкрийте DICOM серію або volume."); return
        try:
            exe = self._ensure_slicer_exe_ui()
            if not exe:
                return
            if self.current_path:
                res = send_dicom_series(exe, self.current_path, command="segment_editor")
            else:
                work = default_work_dir()
                out = work / "dicomview_current_volume.nrrd"
                spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
                export_res = export_volume_nrrd(np.asarray(self.volume), spacing, out, self.metadata or {})
                if not export_res.ok:
                    res = export_res
                else:
                    res = launch_bridge_payload(exe, {"command": "segment_editor", "volume_nrrd": export_res.path, "metadata": self.metadata, "source": self.current_path})
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Slicer Segment Editor: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("Slicer Segment Editor error: " + str(exc)); self.log_ui("Slicer Segment Editor error: " + str(exc))

    def slicer_export_nrrd_ui(self):
        if self.volume is None:
            QMessageBox.warning(self, "Slicer Bridge", "Спочатку відкрийте DICOM серію."); return
        try:
            work = default_work_dir()
            out = work / "dicomview_current_volume.nrrd"
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            res = export_volume_nrrd(np.asarray(self.volume), spacing, out, self.metadata or {})
            if res.ok:
                manifest = write_bridge_manifest(work, {"command": "load", "volume_nrrd": res.path, "metadata": self.metadata, "source": self.current_path})
                exe = self._ensure_slicer_exe_ui()
                if exe:
                    launch = launch_bridge_payload(exe, {"command": "load", "volume_nrrd": res.path, "metadata": self.metadata, "source": self.current_path, "work_dir": str(work)})
                    res.details = {**(res.details or {}), "manifest": str(manifest), "launch": launch.__dict__}
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Slicer NRRD export: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("Slicer NRRD error: " + str(exc)); self.log_ui("Slicer NRRD error: " + str(exc))

    def slicer_export_mask_ui(self):
        if self.current_mask is None:
            QMessageBox.warning(self, "Slicer Bridge", "Спочатку створіть маску сегментації."); return
        try:
            work = default_work_dir()
            out = work / "dicomview_current_mask.seg.nrrd"
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            res = export_mask_nrrd(np.asarray(self.current_mask), spacing, out)
            if res.ok:
                exe = self._ensure_slicer_exe_ui()
                if exe:
                    launch = launch_bridge_payload(exe, {"command": "load", "mask_nrrd": res.path, "metadata": self.metadata, "source": self.current_path, "work_dir": str(work)})
                    res.details = {**(res.details or {}), "launch": launch.__dict__}
            self.slicer_output.setPlainText(json.dumps(res.__dict__, ensure_ascii=False, indent=2))
            self.log_ui("Slicer mask export: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("Slicer mask error: " + str(exc)); self.log_ui("Slicer mask error: " + str(exc))

    def slicer_import_model_ui(self):
        file, _ = QFileDialog.getOpenFileName(self, "Імпорт STL/OBJ/PLY із 3D Slicer / Geomagic", "", "3D models (*.stl *.obj *.ply *.glb);;All files (*)")
        if not file:
            return
        try:
            self.external_model_path = file
            payload = {"imported_model": file, "note": "Файл збережено як зовнішній результат. Візуалізація поверх DICOM буде додана через mesh overlay module."}
            if hasattr(self, "slicer_output"):
                self.slicer_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.log_ui("Slicer/Geomagic model imported: " + file)
            QMessageBox.information(self, "Slicer Bridge", "3D-модель імпортовано як зовнішній результат:\n" + file)
        except Exception as exc:
            self.slicer_output.setPlainText("Import model error: " + str(exc)); self.log_ui("Import model error: " + str(exc))

    def slicer_import_latest_result_ui(self):
        try:
            results_dir = default_work_dir() / "results"
            suffixes = (".stl", ".obj", ".ply", ".glb", ".nii", ".nii.gz", ".nrrd", ".seg.nrrd")
            candidates = [p for p in results_dir.rglob("*") if p.is_file() and str(p).lower().endswith(suffixes)] if results_dir.exists() else []
            if not candidates:
                QMessageBox.information(self, "Slicer Bridge", "У папці результатів ще немає STL/OBJ/PLY/GLB/NIfTI/NRRD файлів.")
                return
            latest = max(candidates, key=lambda p: p.stat().st_mtime)
            self.external_model_path = str(latest)
            payload = {"imported_latest_result": str(latest), "results_dir": str(results_dir)}
            self.slicer_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.log_ui("Slicer latest result imported: " + str(latest))
        except Exception as exc:
            self.slicer_output.setPlainText("Import latest result error: " + str(exc)); self.log_ui("Import latest result error: " + str(exc))

    def slicer_open_results_dir_ui(self):
        try:
            results_dir = default_work_dir() / "results"
            results_dir.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(results_dir))
            else:
                subprocess.Popen(["xdg-open", str(results_dir)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.slicer_output.setPlainText(json.dumps({"results_dir": str(results_dir)}, ensure_ascii=False, indent=2))
            self.log_ui("Slicer results folder opened")
        except Exception as exc:
            self.slicer_output.setPlainText("Open Slicer results folder error: " + str(exc)); self.log_ui("Open Slicer results folder error: " + str(exc))

    def vmtk_status_ui(self):
        try:
            slicer_res = find_slicer()
            payload = {
                "VMTK embedded in DicomView": False,
                "VMTK via Python environment": vmtk_available_in_python(),
                "3D Slicer found": slicer_res.ok,
                "Slicer path": slicer_res.path,
                "Integration mode": "external 3D Slicer + SlicerVMTK extension",
                "Note": "VMTK не вшивається в DicomView PRO. Безпечна інтеграція йде через 3D Slicer Bridge PRO: встановіть розширення SlicerVMTK у 3D Slicer і запускайте його з цієї вкладки.",
            }
            res = create_vmtk_slicer_script()
            payload["helper_script"] = res.to_dict()
            self.slicer_output.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            self.log_ui("VMTK Bridge status checked")
        except Exception as exc:
            self.slicer_output.setPlainText("VMTK status error: " + str(exc)); self.log_ui("VMTK status error: " + str(exc))

    def vmtk_launch_ui(self):
        try:
            exe = self._slicer_exe_text()
            res = run_vmtk_bridge_in_slicer(exe)
            self.slicer_output.setPlainText(json.dumps(res.to_dict(), ensure_ascii=False, indent=2))
            self.log_ui("VMTK Bridge: " + res.message)
        except Exception as exc:
            self.slicer_output.setPlainText("VMTK launch error: " + str(exc)); self.log_ui("VMTK launch error: " + str(exc))

    def export_current_png(self):
        if self.volume is None:
            QMessageBox.warning(self, "PNG", "Немає відкритого зображення."); return
        path, _ = QFileDialog.getSaveFileName(self, "Зберегти PNG", "dicomview_frame.png", "PNG image (*.png)")
        if not path:
            return
        try:
            # Export visible 2D axial slice with current window/level.
            arr = self.render_slice_u8(np.asarray(self.volume[self.cross_z]))
            arr = np.ascontiguousarray(arr)
            h, w = arr.shape[:2]
            bytes_per_line = int(arr.strides[0])
            img = QImage(arr.data, w, h, bytes_per_line, QImage.Format_Grayscale8).copy()
            if not img.save(path, "PNG"):
                raise RuntimeError("QImage.save() повернув False")
            self.log_ui("PNG exported: " + path)
        except Exception as exc:
            self.log_ui("PNG export error: " + str(exc))
            QMessageBox.critical(self, "PNG", str(exc))

    def export_mask_stl(self):
        self.export_mask_model("stl")

    def export_mask_model(self, fmt: str = "auto"):
        if self.current_mask is None:
            QMessageBox.warning(self, "Export", "Спочатку створіть маску сегментації."); return
        if fmt == "stl":
            filters = "STL model (*.stl)"; default = "dicomview_segmentation.stl"
        else:
            filters = "3D models (*.stl *.obj *.ply *.glb);;STL (*.stl);;OBJ (*.obj);;PLY (*.ply);;GLB (*.glb)"; default = "dicomview_segmentation.obj"
        path, _ = QFileDialog.getSaveFileName(self, "Експорт 3D моделі", default, filters)
        if not path:
            return
        try:
            spacing = tuple(float(v) for v in self.metadata.get("spacing", [1,1,1]))
            stats = export_mask(np.asarray(self.current_mask, dtype=bool), path, spacing)
            self.log_ui(f"3D model exported: {stats.path}; vertices={stats.vertices}; faces={stats.faces}")
            QMessageBox.information(self, "Export", f"Модель збережено.\nВершин: {stats.vertices}\nГраней: {stats.faces}")
        except Exception as exc:
            self.log_ui("3D export error: " + str(exc))
            QMessageBox.critical(self, "Export", str(exc))

    def _current_series_files(self) -> list[str]:
        uid = self.metadata.get("series_uid", "")
        for s in self.metadata.get("available_series", []) or []:
            if s.get("uid") == uid:
                return [str(x) for x in s.get("files", [])]
        return []

    def _study_export_label(self) -> str:
        patient = str(self.metadata.get("patient_name") or self.metadata.get("patient") or self.metadata.get("PatientName") or "Patient")
        study = str(self.metadata.get("study_date") or self.metadata.get("StudyDate") or "Study")
        series = str(self.metadata.get("series_description") or self.metadata.get("SeriesDescription") or "Series")
        return f"DicomView_{patient}_{study}_{series}"

    def export_current_series_to_usb(self):
        files = self._current_series_files()
        if not files:
            QMessageBox.warning(self, "USB export", "Немає відкритої серії або список DICOM-файлів недоступний.")
            return
        drives = list_windows_drives()
        start_dir = drives[-1] if drives else str(Path.home())
        target = QFileDialog.getExistingDirectory(self, "Виберіть USB флешку або папку призначення", start_dir)
        if not target:
            return
        try:
            res = export_series_to_usb(files, target, study_label=self._study_export_label())
            self.log_ui(f"USB export: {res.files_written} files -> {res.target}")
            QMessageBox.information(self, "USB export", f"Серію збережено на носій.\nФайлів: {res.files_written}\nПапка: {res.target}\nManifest: {res.manifest_path}")
        except Exception as exc:
            self.log_ui("USB export error: " + str(exc))
            QMessageBox.critical(self, "USB export", str(exc))

    def export_current_series_for_cd_dvd(self):
        files = self._current_series_files()
        if not files:
            QMessageBox.warning(self, "CD/DVD export", "Немає відкритої серії або список DICOM-файлів недоступний.")
            return
        target = QFileDialog.getExistingDirectory(self, "Виберіть папку, де створити CD/DVD-ready експорт", str(Path.home()))
        if not target:
            return
        try:
            res = create_cd_dvd_ready_folder(files, target, study_label=self._study_export_label())
            self.log_ui(f"CD/DVD ready export: {res.files_written} files -> {res.target}")
            msg = f"Папку для запису CD/DVD створено.\nФайлів: {res.files_written}\nПапка: {res.target}\nManifest: {res.manifest_path}"
            if res.zip_path:
                msg += f"\nZIP-копія: {res.zip_path}"
            QMessageBox.information(self, "CD/DVD export", msg)
        except Exception as exc:
            self.log_ui("CD/DVD export error: " + str(exc))
            QMessageBox.critical(self, "CD/DVD export", str(exc))

    def export_current_series_dicomdir_ready(self):
        files = self._current_series_files()
        if not files:
            QMessageBox.warning(self, "DICOMDIR export", "Немає відкритої серії або список DICOM-файлів недоступний.")
            return
        target = QFileDialog.getExistingDirectory(self, "Виберіть папку для DICOMDIR / USB / CD-DVD носія", str(Path.home()))
        if not target:
            return
        try:
            res = create_dicomdir_ready_folder(files, target, study_label=self._study_export_label(), include_viewer_launcher=True, make_zip=True)
            self.log_ui(f"DICOMDIR-ready export: {res.files_written} files -> {res.target}; {res.message}")
            msg = (
                f"DICOMDIR-ready носій підготовлено.\n"
                f"Файлів: {res.files_written}\n"
                f"Папка: {res.target}\n"
                f"Manifest: {res.manifest_path}\n"
                f"Стан: {res.message}"
            )
            if res.zip_path:
                msg += f"\nZIP-копія: {res.zip_path}"
            QMessageBox.information(self, "DICOMDIR export", msg)
        except Exception as exc:
            self.log_ui("DICOMDIR export error: " + str(exc))
            QMessageBox.critical(self, "DICOMDIR export", str(exc))

    def _run_background(self, title: str, func, on_success, *args, **kwargs):
        self.update_system_status(f"{title}: виконується…")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        task = BackgroundTask(func, *args, parent=self, **kwargs)
        self._background_tasks.append(task)

        def done(result):
            QApplication.restoreOverrideCursor()
            self.update_system_status(f"{title}: готово")
            try:
                on_success(result)
            finally:
                self._background_tasks.remove(task) if task in self._background_tasks else None

        def fail(message: str):
            QApplication.restoreOverrideCursor()
            self.update_system_status(f"{title}: помилка")
            self.log_ui(f"{title} error: {message}")
            QMessageBox.critical(self, title, message)
            self._background_tasks.remove(task) if task in self._background_tasks else None

        task.finished_ok.connect(done)
        task.failed.connect(fail)
        task.start()

    def weasis_inspect_current_folder(self):
        base = self.current_path or QFileDialog.getExistingDirectory(self, "Виберіть DICOM-папку для аналізу SR/SEG/RT/ECG", str(Path.home()))
        if not base:
            return

        def on_success(infos):
            counts = {}
            for i in infos:
                counts[i.kind] = counts.get(i.kind, 0) + 1
            lines = ["Weasis-style compatibility scan:", f"Об'єктів: {len(infos)}"]
            for k, v in sorted(counts.items()):
                lines.append(f"{k}: {v}")
            special = [i for i in infos if i.kind != "Image/Other"][:30]
            if special:
                lines.append("\nСпеціальні DICOM-об'єкти:")
                for i in special:
                    lines.append(f"- {i.kind}: {Path(i.path).name} — {i.summary}")
            self.log_ui("\n".join(lines))
            QMessageBox.information(self, "Weasis compatibility", "\n".join(lines[:45]))

        self._run_background("Weasis compatibility scan", inspect_folder, on_success, base)

    def _dicomweb_config_dialog(self) -> DicomWebConfig | None:
        url, ok = QInputDialog.getText(self, "DICOMweb", "Base URL QIDO/WADO/STOW:", text="http://localhost:8042/dicom-web")
        if not ok or not url:
            return None
        return DicomWebConfig(base_url=url.strip())

    def dicomweb_qido_demo(self):
        cfg = self._dicomweb_config_dialog()
        if cfg is None:
            return
        patient, ok = QInputDialog.getText(self, "QIDO-RS", "ПІБ/ID пацієнта (можна порожньо):", text="")
        if not ok:
            return

        def on_success(res):
            self.log_ui(f"DICOMweb QIDO: {res.message}; count={res.count}")
            QMessageBox.information(self, "DICOMweb QIDO-RS", f"{res.message}\nЗнайдено: {res.count}")

        self._run_background("DICOMweb QIDO-RS", qido_studies, on_success, cfg, patient, "", 25)

    def dicomweb_stow_current_series(self):
        files = self._current_series_files()
        if not files:
            QMessageBox.warning(self, "STOW-RS", "Немає поточної серії для upload.")
            return
        cfg = self._dicomweb_config_dialog()
        if cfg is None:
            return

        def on_success(res):
            self.log_ui(f"DICOMweb STOW: {res.message}; files={res.count}")
            QMessageBox.information(self, "DICOMweb STOW-RS", f"{res.message}\nФайлів: {res.count}")

        self._run_background("DICOMweb STOW-RS", stow_instances, on_success, cfg, files[:200])


    def dicomweb_wado_series_raw_dialog(self):
        cfg = self._dicomweb_config_dialog()
        if cfg is None:
            return
        study_uid, ok = QInputDialog.getText(self, "WADO-RS", "StudyInstanceUID:", text=str(self.metadata.get("study_uid") or ""))
        if not ok or not study_uid.strip():
            return
        series_uid, ok = QInputDialog.getText(self, "WADO-RS", "SeriesInstanceUID:", text=str(self.metadata.get("series_uid") or ""))
        if not ok or not series_uid.strip():
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Папка для raw WADO-RS multipart", str(Path.home()))
        if not out_dir:
            return
        out_path = str(Path(out_dir) / "wado_series_raw.multipart")

        def on_success(res):
            self.log_ui(f"DICOMweb WADO-RS: {res.message}")
            QMessageBox.information(self, "DICOMweb WADO-RS", res.message)

        self._run_background("DICOMweb WADO-RS", wado_retrieve_series_raw, on_success, cfg, study_uid.strip(), series_uid.strip(), out_path)

    def sr_viewer_dialog(self):
        path, _ = QFileDialog.getOpenFileName(self, "Відкрити DICOM SR", "", "DICOM (*.dcm *.dicom);;All files (*.*)")
        if not path:
            return

        def on_success(text):
            dlg = QMessageBox(self)
            dlg.setWindowTitle("DICOM SR Viewer")
            dlg.setText("DICOM Structured Report")
            dlg.setDetailedText(text)
            dlg.setIcon(QMessageBox.Information)
            dlg.exec()
            self.log_ui("DICOM SR Viewer:\n" + text[:4000])

        self._run_background("DICOM SR Viewer", sr_plain_text, on_success, path)

    def seg_rt_summary_dialog(self):
        path, _ = QFileDialog.getOpenFileName(self, "Відкрити DICOM SEG / RT", "", "DICOM (*.dcm *.dicom);;All files (*.*)")
        if not path:
            return

        def summarize(p):
            try:
                rows = seg_summary_table(p)
                if rows:
                    return "DICOM SEG\n" + "\n".join(f"#{r.get('number')} {r.get('label')} {r.get('description')} {r.get('algorithm')}" for r in rows)
            except Exception:
                pass
            rows = rt_summary_table(p)
            if rows:
                return "DICOM RT\n" + "\n".join(f"#{r.get('number')} {r.get('name')} {r.get('description')}" for r in rows)
            return "SEG/RT summary: об'єкт не містить SegmentSequence/RT Structure/DoseGrid."

        def on_success(text):
            self.log_ui(text)
            QMessageBox.information(self, "SEG/RT summary", text[:3500])

        self._run_background("SEG/RT summary", summarize, on_success, path)

    def dicomizer_import_dialog(self):
        in_path, _ = QFileDialog.getOpenFileName(self, "Dicomizer import", "", "Supported (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.pdf *.stl);;All files (*.*)")
        if not in_path:
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Папка для створеного DICOM", str(Path.home()))
        if not out_dir:
            return
        patient = str(self.metadata.get("patient_name") or self.metadata.get("patient") or "Anonymous")
        try:
            res = dicomize_file(in_path, out_dir, patient_name=patient, patient_id=str(self.metadata.get("patient_id") or "DICOMIZER"))
            self.log_ui(f"Dicomizer: {res.message}; {res.output_path}")
            if res.ok:
                QMessageBox.information(self, "Dicomizer", f"Створено DICOM:\n{res.output_path}")
            else:
                QMessageBox.warning(self, "Dicomizer", res.message)
        except Exception as exc:
            QMessageBox.critical(self, "Dicomizer", str(exc))

    def frame_sync_report_dialog(self):
        try:
            available = self.metadata.get("available_series", []) or []
            report = sync_report(self.metadata, available)
            lines = ["FrameOfReferenceUID sync", f"Поточний UID: {report['current'].get('frame_of_reference_uid') or '—'}", f"Сумісних серій: {report['count']}"]
            for m in report["matches"][:20]:
                lines.append(f"- {m.get('modality')} | {m.get('description')} | {m.get('series_uid')}")
            self.log_ui("\n".join(lines))
            QMessageBox.information(self, "FrameOfReference sync", "\n".join(lines))
        except Exception as exc:
            QMessageBox.critical(self, "FrameOfReference sync", str(exc))


    def anonymize_current_series(self):
        files = self._current_series_files()
        if not files:
            QMessageBox.warning(self, "Анонімізація", "Немає відкритої серії або список файлів недоступний."); return
        path, _ = QFileDialog.getSaveFileName(self, "Створити анонімний ZIP", "dicomview_anonymized.zip", "ZIP archive (*.zip)")
        if not path:
            return
        try:
            summary = anonymize_to_zip(files, path)
            self.log_ui(f"Anonymized ZIP created: {summary.zip_path}; files={summary.files_written}")
            QMessageBox.information(self, "Анонімізація", f"Анонімний архів створено.\nФайлів: {summary.files_written}")
        except Exception as exc:
            self.log_ui("Anonymization error: " + str(exc))
            QMessageBox.critical(self, "Анонімізація", str(exc))

    def about(self):
        QMessageBox.information(
            self,
            "DicomView PRO",
            "DicomView PRO\n"
            "Автор: Іван Кіранчук\n"
            "Компанія: KirivSoft\n\n"
            "Робочий прототип DICOM viewer. Не є сертифікованим медичним виробом."
        )

    def toggle_fullscreen(self):
        """F11: fullscreen workspace mode; Esc/F11: restore full interface.

        In fullscreen the patient/model work area occupies the screen: menu,
        header, mode buttons and side panels are hidden.  The current tab stays
        active, so 2D/MPR/3D work without changing the loaded series.
        """
        if self.isFullScreen():
            self.exit_workspace_fullscreen()
        else:
            self.enter_workspace_fullscreen()

    def enter_workspace_fullscreen(self):
        self._pre_fullscreen_state = {
            "left": bool(getattr(self.left_panel, "isVisible", lambda: True)()),
            "right": bool(getattr(self.right_panel, "isVisible", lambda: True)()),
            "tabbar": bool(self.tabs.tabBar().isVisible()) if hasattr(self, "tabs") else True,
        }
        try: self.menuBar().hide()
        except Exception: pass
        for w in (getattr(self, "topbar", None), getattr(self, "mode_bar", None), getattr(self, "left_panel", None), getattr(self, "right_panel", None)):
            try:
                if w is not None: w.hide()
            except Exception:
                pass
        try: self.tabs.tabBar().hide()
        except Exception: pass
        self.showFullScreen()
        self.update_system_status("Повноекранний робочий режим: F11 або Esc — вихід")

    def exit_workspace_fullscreen(self):
        self.showNormal()
        try: self.menuBar().show()
        except Exception: pass
        for w in (getattr(self, "topbar", None), getattr(self, "mode_bar", None)):
            try:
                if w is not None: w.show()
            except Exception:
                pass
        st = getattr(self, "_pre_fullscreen_state", {}) or {}
        for name, default in (("left_panel", True), ("right_panel", True)):
            try:
                w = getattr(self, name, None)
                if w is not None:
                    w.setVisible(bool(st.get("left" if name == "left_panel" else "right", default)))
            except Exception:
                pass
        try:
            self.tabs.tabBar().setVisible(bool(st.get("tabbar", True)))
        except Exception:
            pass
        self.update_system_status("Вийшли з повноекранного робочого режиму")

    def open_log(self):
        p = log_path()
        if not p.exists():
            p.write_text("", encoding="utf-8")
        os.startfile(str(p)) if sys.platform.startswith("win") else subprocess.Popen(["xdg-open", str(p)])


    def open_logs_dir(self):
        try:
            p = log_path().parent
            p.mkdir(parents=True, exist_ok=True)
            if sys.platform.startswith("win"):
                os.startfile(str(p))
            else:
                subprocess.Popen(["xdg-open", str(p)])
            self.log_ui(f"Папку логів відкрито: {p}")
        except Exception as exc:
            QMessageBox.critical(self, "DicomView PRO", f"Не вдалося відкрити папку логів:\n{exc}")

    def _safe_widget_text(self, widget_name: str) -> str:
        try:
            w = getattr(self, widget_name, None)
            if w is None:
                return "<missing>"
            if hasattr(w, "currentText"):
                return str(w.currentText())
            if hasattr(w, "isChecked"):
                return str(bool(w.isChecked()))
            if hasattr(w, "value"):
                return str(w.value())
            return repr(w)
        except Exception as exc:
            return f"<error: {exc}>"

    def _collect_diagnostic_snapshot(self) -> str:
        """Collect a human-readable diagnostic snapshot for support.

        This does not contain DICOM pixel data or patient images. It records the
        app state, selected 3D controls, runtime paths and the last lines of the
        normal application log so the user can send one compact file for debug.
        """
        lines: list[str] = []
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines.append("DicomView PRO — TEST DIAGNOSTIC LOG")
        lines.append(f"Created: {now}")
        lines.append(f"Author/brand: Іван Кіранчук / KirivSoft")
        lines.append("")
        lines.append("[Runtime]")
        lines.append(f"Python: {sys.version.replace(chr(10), ' ')}")
        lines.append(f"Platform: {platform.platform()}")
        lines.append(f"Executable: {sys.executable}")
        lines.append(f"Working directory: {os.getcwd()}")
        lines.append(f"Log file: {log_path()}")
        try:
            lines.append(f"Data directory: {data_dir()}")
        except Exception as exc:
            lines.append(f"Data directory: <error: {exc}>")
        lines.append("")
        lines.append("[Study state]")
        lines.append(f"Current path: {getattr(self, 'current_path', '')}")
        vol = getattr(self, "volume", None)
        if vol is None:
            lines.append("Volume: <not loaded>")
        else:
            try:
                lines.append(f"Volume shape: {getattr(vol, 'shape', None)}")
                lines.append(f"Volume dtype: {getattr(vol, 'dtype', None)}")
                lines.append(f"Volume HU min/max: {float(np.nanmin(vol)):.1f} / {float(np.nanmax(vol)):.1f}")
            except Exception as exc:
                lines.append(f"Volume details: <error: {exc}>")
        lines.append(f"Metadata keys: {sorted(list(getattr(self, 'metadata', {}).keys()))[:80]}")
        lines.append(f"Window/level: center={getattr(self, 'center', None)}, width={getattr(self, 'width', None)}")
        lines.append(f"Current slice index Z/Y/X: {getattr(self, 'cross_z', None)} / {getattr(self, 'cross_y', None)} / {getattr(self, 'cross_x', None)}")
        lines.append("")
        lines.append("[3D controls]")
        for name in (
            "vtk_mode", "vtk_preset", "vtk_threshold", "vtk_mip_btn", "vtk_sub_btn",
            "vtk_clip_check", "vtk_clip_nav_check", "vtk_clip_depth", "vtk_ruler_check",
            "vtk_slab_mode", "vtk_slab_thick",
        ):
            lines.append(f"{name}: {self._safe_widget_text(name)}")
        for viewer_name in ("vtk_viewer", "legacy_vtk_viewer"):
            viewer = getattr(self, viewer_name, None)
            lines.append(f"{viewer_name}: {type(viewer).__name__ if viewer is not None else '<missing>'}")
            if viewer is not None:
                if hasattr(viewer, "describe_3d_state"):
                    try:
                        lines.append("  [describe_3d_state]")
                        lines.extend("  " + ln for ln in viewer.describe_3d_state().splitlines())
                    except Exception as exc:
                        lines.append(f"  describe_3d_state: <error: {exc}>")
                for attr in ("last_mode", "last_preset", "mapper_name", "engine_name", "_last_build_mode", "_last_preset"):
                    if hasattr(viewer, attr):
                        try:
                            lines.append(f"  {attr}: {getattr(viewer, attr)}")
                        except Exception as exc:
                            lines.append(f"  {attr}: <error: {exc}>")
        lines.append("")
        lines.append("[Recent UI log panel]")
        try:
            lines.append(self.logs.toPlainText()[-8000:] if hasattr(self, "logs") else "<no log tab>")
        except Exception as exc:
            lines.append(f"<error reading UI log: {exc}>")
        lines.append("")
        lines.append("[Tail of application log]")
        try:
            p = log_path()
            if p.exists():
                text = p.read_text(encoding="utf-8", errors="replace")
                lines.append(text[-12000:])
            else:
                lines.append("<application log file does not exist yet>")
        except Exception as exc:
            lines.append(f"<error reading application log: {exc}>")
        return "\n".join(lines) + "\n"

    def create_test_diagnostic_log(self):
        try:
            out_dir = log_path().parent
            out_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            out = out_dir / f"dicomview_pro_diagnostic_{stamp}.txt"
            snapshot = self._collect_diagnostic_snapshot()
            out.write_text(snapshot, encoding="utf-8")
            log.info("Diagnostic test log generated: %s", out)
            self.log_ui(f"Діагностичний лог створено: {out}")
            QMessageBox.information(self, "DicomView PRO", f"Діагностичний лог створено:\n{out}\n\nНадішліть мені саме цей файл.")
        except Exception as exc:
            log.exception("Failed to create diagnostic log")
            QMessageBox.critical(self, "DicomView PRO", f"Не вдалося створити діагностичний лог:\n{exc}")

    def save_log_as(self):
        try:
            src = log_path()
            if not src.exists():
                src.write_text("", encoding="utf-8")
            default_name = f"dicomview_pro_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
            target, _ = QFileDialog.getSaveFileName(self, "Зберегти лог як", str(Path.home() / "Desktop" / default_name), "Log files (*.log *.txt);;All files (*)")
            if not target:
                return
            shutil.copy2(src, target)
            self.log_ui(f"Лог збережено як: {target}")
            QMessageBox.information(self, "DicomView PRO", f"Лог збережено:\n{target}")
        except Exception as exc:
            log.exception("Failed to save log as")
            QMessageBox.critical(self, "DicomView PRO", f"Не вдалося зберегти лог:\n{exc}")

    def eventFilter(self, obj, ev):
        # Global fullscreen hotkeys: child widgets often consume Escape/F11,
        # so QMainWindow.keyPressEvent alone is not enough.
        if ev.type() == QEvent.KeyPress:
            if ev.key() == Qt.Key_Escape and self.isFullScreen():
                self.showNormal()
                ev.accept()
                return True
            if ev.key() == Qt.Key_F11:
                self.toggle_fullscreen()
                ev.accept()
                return True
        return super().eventFilter(obj, ev)

    def keyPressEvent(self, ev):
        if ev.key() == Qt.Key_Escape and self.isFullScreen():
            self.showNormal()
            ev.accept()
            return
        if ev.key() == Qt.Key_F11:
            self.toggle_fullscreen()
            ev.accept()
            return
        if ev.key() in (Qt.Key_PageDown, Qt.Key_Down):
            self.step_slice(1)
            ev.accept()
            return
        if ev.key() in (Qt.Key_PageUp, Qt.Key_Up):
            self.step_slice(-1)
            ev.accept()
            return
        super().keyPressEvent(ev)

    def closeEvent(self, ev):
        try:
            self.cine_timer.stop()
        except Exception:
            pass
        for th in (self.scan_thread, self.load_thread):
            try:
                if th is not None and th.isRunning():
                    th.requestInterruption()
                    th.quit()
                    th.wait(1500)
            except Exception:
                pass
        try:
            for th in list(getattr(self, "_background_tasks", [])):
                if th is not None and th.isRunning():
                    th.requestInterruption()
                    th.quit()
                    th.wait(1500)
        except Exception:
            pass
        try:
            self.controller.cleanup_all()
        except Exception:
            pass
        super().closeEvent(ev)
