from __future__ import annotations
import math
import logging
import numpy as np
from dicomview_pro.core.image_ops import diagnostic_content_bbox
try:
    from PIL import Image as PILImage
except Exception:  # optional; Qt Smooth fallback remains available
    PILImage = None
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QImage, QPixmap, QPainter, QPen, QColor, QBrush
from PySide6.QtWidgets import QLabel

class ImageLabel(QLabel):
    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(520, 380)
        self._arr: np.ndarray | None = None
        self._pix: QPixmap | None = None
        self.interpolation_mode = "lanczos"  # lanczos | cubic | linear | nearest
        self.fit_mode = "fit_window"  # fit_window | one_to_one | fit_content
        self.auto_crop = False
        self._crop_bbox: tuple[int, int, int, int] | None = None
        self._locked_crop_bbox: tuple[int, int, int, int] | None = None
        self._display_arr: np.ndarray | None = None
        self._mask_overlay: np.ndarray | None = None
        self._mask_overlay_color: tuple[int, int, int] = (255, 0, 0)
        self._mask_overlay_alpha: int = 120
        self.points: list[tuple[int, int]] = []
        self.pixel_spacing = (1.0, 1.0)  # row, col mm
        self.measure_mode = "distance"  # distance | angle | roi | rect_roi | circle_roi | polygon_roi | hu | none
        self.plane = "axial"
        self.on_distance = None
        self.on_angle = None
        self.on_roi = None
        self.on_hu = None
        self.on_point = None
        self.on_slice_step = None
        self.on_view_double_click = None
        self.source_slice: np.ndarray | None = None
        self.crosshair: tuple[int, int] | None = None
        self.show_crosshair = True
        self.zoom_factor = 1.0
        self.pan_x = 0
        self.pan_y = 0
        self._drag_start: QPoint | None = None
        self._pan_start = (0, 0)
        self._last_scaled_size: tuple[int, int] = (0, 0)
        self._last_scaled_origin: tuple[int, int] = (0, 0)
        self._last_scale_valid = False
        self._pillow_lanczos_available = PILImage is not None

    def clear_overlays(self):
        self.points.clear()
        self.crosshair = None
        self._update_pixmap()

    def clear_mask_overlay(self) -> None:
        """Remove diagnostic colored mask overlay from this 2D/MPR view."""
        self._mask_overlay = None
        self._update_pixmap()

    def set_mask_overlay(self, mask: np.ndarray | None, *, color=(255, 0, 0), alpha: int = 120) -> None:
        """Set a display-only colored mask overlay for pathology protocols.

        The overlay is rendered over the 8-bit diagnostic image only. It never
        changes the original HU data, measurements, or exported DICOM pixels.
        ``mask`` must be in the same pixel space as the displayed source slice
        before optional display crop.
        """
        if mask is None:
            self._mask_overlay = None
        else:
            self._mask_overlay = np.asarray(mask).astype(bool)
        try:
            r, g, b = [int(max(0, min(255, v))) for v in color]
            self._mask_overlay_color = (r, g, b)
        except Exception:
            self._mask_overlay_color = (255, 0, 0)
        self._mask_overlay_alpha = int(max(0, min(255, alpha)))
        self._update_pixmap()

    def reset_view(self):
        self.zoom_factor = 1.0
        self.pan_x = 0
        self.pan_y = 0
        self._update_pixmap()

    def set_locked_crop_bbox(self, bbox: tuple[int, int, int, int] | None) -> None:
        """Lock display crop for a whole series to prevent zoom/viewport jumps.

        SmoothStack/Cine mode computes the anatomical bbox once after loading
        the series. Every subsequent slice uses the same crop, so scrolling and
        Cine playback do not resize the anatomy frame-by-frame. Measurements are
        still mapped back to the original full-resolution slice coordinates.
        """
        if self._locked_crop_bbox == bbox:
            return
        self._locked_crop_bbox = bbox
        self._last_scale_valid = False
        self._update_pixmap()

    def clear_series_state(self) -> None:
        """Drop all per-series display state before another DICOM package loads."""
        self._arr = None
        self._pix = None
        self._crop_bbox = None
        self._locked_crop_bbox = None
        self._display_arr = None
        self._mask_overlay = None
        self.source_slice = None
        self.points.clear()
        self.crosshair = None
        self.show_crosshair = True
        self.zoom_factor = 1.0
        self.pan_x = 0
        self.pan_y = 0
        self._drag_start = None
        self._last_scaled_size = (0, 0)
        self._last_scaled_origin = (0, 0)
        self._last_scale_valid = False
        self.clear()

    def set_image(self, arr: np.ndarray, source_slice: np.ndarray | None = None):
        full = np.ascontiguousarray(arr)
        self.source_slice = None if source_slice is None else np.asarray(source_slice)
        self._crop_bbox = None
        # Diagnostic default: crop empty scanner canvas for display only.
        # Coordinates and measurements remain mapped back to the original slice.
        # If SmoothStack locked a crop bbox for this series, use it for every
        # frame to avoid zoom jumps while scrolling or playing Cine.
        if self._locked_crop_bbox is not None and (self.fit_mode == "fit_content" or (self.auto_crop and self.fit_mode == "fit_window")):
            try:
                x0, y0, x1, y1 = self._locked_crop_bbox
                x0 = max(0, min(full.shape[1]-1, int(x0))); x1 = max(x0+1, min(full.shape[1], int(x1)))
                y0 = max(0, min(full.shape[0]-1, int(y0))); y1 = max(y0+1, min(full.shape[0], int(y1)))
                self._crop_bbox = (x0, y0, x1, y1)
                disp = np.ascontiguousarray(full[y0:y1, x0:x1])
            except Exception:
                disp = full
        elif self.fit_mode == "fit_content" or (self.auto_crop and self.fit_mode == "fit_window"):
            try:
                bbox = diagnostic_content_bbox(full)
                if bbox is not None:
                    x0, y0, x1, y1 = bbox
                    # keep crop if it really improves viewport use
                    if (x1 - x0) * (y1 - y0) < full.shape[1] * full.shape[0] * 0.92:
                        self._crop_bbox = bbox
                        disp = np.ascontiguousarray(full[y0:y1, x0:x1])
                    else:
                        disp = full
                else:
                    disp = full
            except Exception:
                disp = full
        else:
            disp = full
        self._arr = np.ascontiguousarray(disp)
        self._display_arr = self._arr
        h, w = self._arr.shape[:2]
        bytes_per_line = int(self._arr.strides[0])
        q = QImage(self._arr.data, w, h, bytes_per_line, QImage.Format_Grayscale8).copy()
        self._pix = QPixmap.fromImage(q)
        self._last_scale_valid = False
        self._update_pixmap()

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._update_pixmap()

    def set_interpolation(self, mode: str):
        self.interpolation_mode = (mode or "lanczos").lower()
        self._last_scale_valid = False
        self._update_pixmap()

    def set_fit_mode(self, mode: str):
        self.fit_mode = (mode or "fit_window").lower()
        # Default diagnostic behavior: Fit-to-window shows the full slice.
        # Anatomical auto-crop is manual only; otherwise CT Brain noise can
        # change the crop/zoom and create grain amplification or Cine jumps.
        if self.fit_mode == "no_crop":
            self.auto_crop = False
            self.fit_mode = "fit_window"
        elif self.fit_mode == "fit_content":
            self.auto_crop = True
        else:
            self.auto_crop = False
        if self.fit_mode == "one_to_one":
            self.zoom_factor = 1.0
        self._last_scale_valid = False
        self._update_pixmap()

    def _target_size(self):
        if not self._pix:
            return (1, 1)
        if self.fit_mode == "one_to_one":
            base_w, base_h = self._pix.width(), self._pix.height()
        else:
            pw, ph = max(1, self._pix.width()), max(1, self._pix.height())
            ww, wh = max(1, self.width()), max(1, self.height())
            # Medical aspect ratio: MPR coronal/sagittal slices must be drawn
            # in patient millimetres, not raw array pixels.  Otherwise Z-spacing
            # is compressed and the two reconstructed planes look small/grainy.
            try:
                row_mm = max(1e-6, float(self.pixel_spacing[0]))
                col_mm = max(1e-6, float(self.pixel_spacing[1]))
            except Exception:
                row_mm, col_mm = 1.0, 1.0
            phys_w = pw * col_mm
            phys_h = ph * row_mm
            if phys_w > 0 and phys_h > 0 and abs(row_mm - col_mm) > 1e-6:
                scale = min(ww / phys_w, wh / phys_h)
                base_w, base_h = int(phys_w * scale), int(phys_h * scale)
            else:
                scale = min(ww / pw, wh / ph)
                base_w, base_h = int(pw * scale), int(ph * scale)
        return (max(1, int(base_w * self.zoom_factor)), max(1, int(base_h * self.zoom_factor)))

    def _scale_pixmap_quality(self, w: int, h: int) -> QPixmap:
        if not self._pix:
            return QPixmap()
        mode = (self.interpolation_mode or "cubic").lower()
        if mode == "nearest":
            return self._pix.scaled(w, h, Qt.KeepAspectRatio, Qt.FastTransformation)
        # Use Pillow for deterministic diagnostic interpolation modes.  For soft
        # tissue CT/MR, cubic/linear are intentionally softer than Lanczos and
        # avoid amplifying quantum noise in narrow brain windows.
        if self._arr is not None and PILImage is not None:
            try:
                src = np.ascontiguousarray(self._arr)
                img = PILImage.fromarray(src, mode="L")
                if mode == "lanczos":
                    resample = PILImage.Resampling.LANCZOS
                elif mode == "linear":
                    resample = PILImage.Resampling.BILINEAR
                else:
                    resample = PILImage.Resampling.BICUBIC
                img = img.resize((w, h), resample=resample)
                out = np.ascontiguousarray(np.asarray(img, dtype=np.uint8))
                bytes_per_line = int(out.strides[0])
                q = QImage(out.data, out.shape[1], out.shape[0], bytes_per_line, QImage.Format_Grayscale8).copy()
                return QPixmap.fromImage(q)
            except Exception as exc:
                logging.getLogger(__name__).warning(
                    "Pillow %s resize failed (%s); using Qt SmoothTransformation fallback", mode, exc
                )
        elif mode == "lanczos":
            logging.getLogger(__name__).warning(
                "Pillow/PIL is unavailable: true Lanczos is disabled; using Qt SmoothTransformation fallback"
            )
        return self._pix.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)

    def _update_pixmap(self):
        if not self._pix:
            return
        sw, sh = self._target_size()
        scaled = self._scale_pixmap_quality(sw, sh)
        canvas = QPixmap(self.size())
        canvas.fill(Qt.transparent)
        p = QPainter(canvas)
        x = (self.width() - scaled.width()) // 2 + int(self.pan_x)
        y = (self.height() - scaled.height()) // 2 + int(self.pan_y)
        self._last_scaled_size = (scaled.width(), scaled.height())
        self._last_scaled_origin = (x, y)
        self._last_scale_valid = True
        p.drawPixmap(x, y, scaled)
        if self._mask_overlay is not None and self._mask_overlay_alpha > 0:
            try:
                mask = np.asarray(self._mask_overlay).astype(np.uint8)
                if self._crop_bbox is not None:
                    x0, y0, x1, y1 = self._crop_bbox
                    mask = mask[y0:y1, x0:x1]
                if mask.shape[:2] == self._arr.shape[:2]:
                    rgba = np.zeros((mask.shape[0], mask.shape[1], 4), dtype=np.uint8)
                    rgba[..., 0] = self._mask_overlay_color[0]
                    rgba[..., 1] = self._mask_overlay_color[1]
                    rgba[..., 2] = self._mask_overlay_color[2]
                    rgba[..., 3] = mask * int(self._mask_overlay_alpha)
                    qmask = QImage(rgba.data, rgba.shape[1], rgba.shape[0], int(rgba.strides[0]), QImage.Format_RGBA8888).copy()
                    mpix = QPixmap.fromImage(qmask).scaled(scaled.width(), scaled.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    p.drawPixmap(x, y, mpix)
            except Exception:
                pass
        pen = QPen(QColor(0, 220, 255), 2)
        p.setPen(pen)
        pts = [self._image_to_widget(pt, scaled, x, y) for pt in self.points]
        for pt in pts:
            p.setBrush(QBrush(QColor(0, 220, 255)))
            p.drawEllipse(pt, 4, 4)
        if len(pts) >= 2:
            if self.measure_mode in ("roi", "rect_roi"):
                p.setBrush(Qt.NoBrush)
                p.drawRect(min(pts[0].x(), pts[1].x()), min(pts[0].y(), pts[1].y()), abs(pts[1].x()-pts[0].x()), abs(pts[1].y()-pts[0].y()))
            elif self.measure_mode == "circle_roi":
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(pts[0], abs(pts[1].x()-pts[0].x()), abs(pts[1].y()-pts[0].y()))
            elif self.measure_mode == "polygon_roi" and len(pts) >= 3:
                p.setBrush(Qt.NoBrush)
                poly = pts + [pts[0]]
                for i in range(len(poly)-1):
                    p.drawLine(poly[i], poly[i+1])
            else:
                for i in range(len(pts)-1):
                    p.drawLine(pts[i], pts[i+1])
        if self.show_crosshair and self.crosshair is not None:
            cp = self._image_to_widget(self.crosshair, scaled, x, y)
            p.setPen(QPen(QColor(255, 210, 60), 1))
            p.drawLine(cp.x(), y, cp.x(), y + scaled.height())
            p.drawLine(x, cp.y(), x + scaled.width(), cp.y())
        p.end()
        self.setPixmap(canvas)

    def _widget_to_image(self, pos: QPoint):
        if self._arr is None or self._pix is None:
            return None
        if not self._last_scale_valid:
            self._update_pixmap()
        scaled_w, scaled_h = self._last_scaled_size
        ox, oy = self._last_scaled_origin
        if pos.x() < ox or pos.y() < oy or pos.x() > ox + scaled_w or pos.y() > oy + scaled_h:
            return None
        h, w = self._arr.shape[:2]
        ix = int((pos.x() - ox) * w / max(scaled_w, 1))
        iy = int((pos.y() - oy) * h / max(scaled_h, 1))
        ix = max(0, min(w - 1, ix)); iy = max(0, min(h - 1, iy))
        if self._crop_bbox is not None:
            x0, y0, _, _ = self._crop_bbox
            return (ix + x0, iy + y0)
        return (ix, iy)

    def _image_to_widget(self, pt, scaled, ox, oy):
        if self._arr is None:
            return QPoint(0, 0)
        h, w = self._arr.shape[:2]
        px, py = int(pt[0]), int(pt[1])
        if self._crop_bbox is not None:
            x0, y0, x1, y1 = self._crop_bbox
            px -= x0; py -= y0
            # do not draw off-crop overlay wildly outside the viewer
            px = max(0, min(x1 - x0 - 1, px)); py = max(0, min(y1 - y0 - 1, py))
        return QPoint(ox + int(px * scaled.width() / max(w, 1)), oy + int(py * scaled.height() / max(h, 1)))

    def _finish_measure_if_ready(self):
        if self.source_slice is None:
            source = None
        else:
            source = self.source_slice
        mode = self.measure_mode
        if mode in ("distance", "ruler") and len(self.points) == 2:
            (x1, y1), (x2, y2) = self.points
            row, col = self.pixel_spacing
            dist = math.sqrt(((y2 - y1) * row) ** 2 + ((x2 - x1) * col) ** 2)
            if self.on_distance:
                self.on_distance(dist)
        elif mode == "angle" and len(self.points) == 3:
            p1, v, p3 = self.points
            ax, ay = p1[0] - v[0], p1[1] - v[1]
            bx, by = p3[0] - v[0], p3[1] - v[1]
            den = math.hypot(ax, ay) * math.hypot(bx, by)
            deg = 0.0 if den <= 0 else math.degrees(math.acos(max(-1.0, min(1.0, (ax * bx + ay * by) / den))))
            if self.on_angle:
                self.on_angle(deg)
        elif mode in ("roi", "rect_roi") and len(self.points) == 2 and source is not None:
            if self.on_roi:
                self.on_roi(list(self.points), "rect_roi", self.plane)
        elif mode == "circle_roi" and len(self.points) == 2 and source is not None:
            if self.on_roi:
                self.on_roi(list(self.points), "circle_roi", self.plane)
        elif mode == "polygon_roi" and len(self.points) >= 3 and source is not None:
            if self.on_roi:
                self.on_roi(list(self.points), "polygon_roi", self.plane)
        elif mode == "hu" and len(self.points) == 1 and source is not None:
            x, y = self.points[0]
            try:
                value = float(source[y, x])
            except Exception:
                value = 0.0
            if self.on_hu:
                self.on_hu(value, self.points[0])

    def mousePressEvent(self, ev):
        if ev.button() in (Qt.RightButton, Qt.MiddleButton):
            self._drag_start = ev.position().toPoint()
            self._pan_start = (self.pan_x, self.pan_y)
            ev.accept()
            return
        pt = self._widget_to_image(ev.position().toPoint())
        if pt and self.measure_mode != "none":
            needed = {"distance": 2, "ruler": 2, "angle": 3, "roi": 2, "rect_roi": 2, "circle_roi": 2, "polygon_roi": 4, "hu": 1, "sam_click": 1}.get(self.measure_mode, 2)
            if len(self.points) >= needed:
                self.points.clear()
            self.points.append(pt)
            self.crosshair = pt
            if self.on_point:
                self.on_point(pt, self.plane)
            self._finish_measure_if_ready()
            self._update_pixmap()
            return
        super().mousePressEvent(ev)

    def wheelEvent(self, ev):
        if self._pix is None:
            super().wheelEvent(ev)
            return
        delta = ev.angleDelta().y()
        if delta == 0:
            return
        # DicomView PRO Stability rule:
        #   Wheel = zoom in/out in the current 2D/MPR view.
        #   Shift+Wheel = scroll slices.
        # This prevents the previous bug where an attempt to zoom in coronal/
        # sagittal unexpectedly scrolled slices instead of changing scale.
        if self.on_slice_step and (ev.modifiers() & Qt.ShiftModifier):
            self.on_slice_step(-1 if delta > 0 else 1)
            ev.accept()
            return
        factor = 1.15 if delta > 0 else 1 / 1.15
        old = self.zoom_factor
        self.zoom_factor = max(0.2, min(12.0, self.zoom_factor * factor))
        if abs(self.zoom_factor - old) > 1e-6:
            self._update_pixmap()
        ev.accept()

    def mouseMoveEvent(self, ev):
        if self._drag_start is not None:
            d = ev.position().toPoint() - self._drag_start
            self.pan_x = self._pan_start[0] + d.x()
            self.pan_y = self._pan_start[1] + d.y()
            self._update_pixmap()
            ev.accept()
            return
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._drag_start is not None:
            self._drag_start = None
            ev.accept()
            return
        super().mouseReleaseEvent(ev)

    def mouseDoubleClickEvent(self, ev):
        if self.on_view_double_click:
            try:
                self.on_view_double_click(self.plane)
                ev.accept()
                return
            except Exception:
                pass
        self.reset_view()
        ev.accept()
