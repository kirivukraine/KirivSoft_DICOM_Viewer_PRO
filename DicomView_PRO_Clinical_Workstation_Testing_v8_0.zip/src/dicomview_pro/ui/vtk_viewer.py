from __future__ import annotations
import logging
import time
from typing import Any
import numpy as np
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QApplication
from dicomview_pro.core.volume_inspect_controller import VolumeInspectController
from dicomview_pro.rendering.cinematic_fidelity import build_cinematic_property, apply_cinematic_mapper_quality, is_cinematic_preset
from dicomview_pro.rendering.integration_bridge import attach_deep3d_controllers

log = logging.getLogger(__name__)


def _window_to_uint8(a: np.ndarray) -> np.ndarray:
    arr = np.asarray(a, dtype=np.float32)
    lo, hi = np.percentile(arr, [1, 99]) if arr.size else (0, 1)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = float(np.nanmin(arr)), float(np.nanmax(arr) if np.nanmax(arr) > np.nanmin(arr) else np.nanmin(arr) + 1)
    out = (np.clip(arr, lo, hi) - lo) * 255.0 / max(hi - lo, 1e-6)
    return np.ascontiguousarray(out.astype(np.uint8))


class VtkVolumeViewer(QWidget):
    """3D/preview widget with a safe mode for old hospital computers.

    Full VTK volume rendering is the Enterprise default.  Older/weak PCs can
    still switch back to VTK Surface Safe or CPU MIP Preview from the 3D mode
    selector if their OpenGL driver is unstable.
    """
    def __init__(self):
        super().__init__()
        self._layout = QVBoxLayout(self)
        self._status = QLabel("3D Viewer готовий. Для старих ПК використовуйте Auto Safe / MIP Preview.")
        self._status.setWordWrap(True)
        self._preview = QLabel()
        self._preview.setAlignment(Qt.AlignCenter)
        self._preview.setMinimumSize(900, 620)
        self._preview.setStyleSheet("background:#020812; border:1px solid #17466d; border-radius:12px;")
        self._layout.addWidget(self._status)
        self._layout.addWidget(self._preview, 1)
        self._vtk_ready = False
        self._vtk_failed = False
        self._distance_widget = None
        self._distance_enabled = False
        self._ruler_points = []
        self._ruler_actors = []
        self._ruler_observer = None
        self._clip_nav_enabled = False
        self._clip_nav_observers = []
        self._clip_nav_old_style = None
        self._last_left_press = (0.0, -9999, -9999)
        self._render_widget: Any | None = None
        self._renderer: Any | None = None
        self._volume_mapper: Any | None = None
        self._volume_property: Any | None = None
        self._volume_actor: Any | None = None
        self._volume_importer: Any | None = None
        self._clip_box_widget: Any | None = None
        self._clip_box_enabled = False
        self._inspect_controller = None
        self._last_render_fps = 0.0
        self._deep3d_controllers = None
        self._deep_wheel_observers = []
        self._organ_mesh_actors: dict[str, object] = {}
        self._source_volume_hu: np.ndarray | None = None
        self._source_spacing_zyx: tuple[float, float, float] | None = None
        self._source_preset: str = "Bone"
        self._artifact_clean_active = False
        self._artifact_clean_mask: np.ndarray | None = None
        self._ctrl_freeze_observers = []
        self._ctrl_freeze_style = None
        self._ctrl_saved_style = None
        self._ctrl_lock_active = False
        self._render_quality_observers = []
        self._debug_event_counter = 0
        self._last_debug_event_ts = 0.0
        self._measurement_overlay = QLabel("3D Measurement: —")
        self._measurement_overlay.setVisible(False)
        self._measurement_overlay.setWordWrap(True)
        self._measurement_overlay.setStyleSheet("background:rgba(0,0,0,190); color:#fff36a; border:1px solid #58ff68; border-radius:8px; padding:6px; font-weight:700;")
        self._layout.addWidget(self._measurement_overlay)
        self._status.setText("3D Enterprise default: VTK Volume Rendering. Safe Surface/MIP режими залишені для слабких ПК.")


    def _log_3d_event(self, event: str, **payload) -> None:
        """Write compact 3D interaction diagnostics to the application log.

        This is intentionally lightweight. It helps verify whether Ctrl/Alt,
        VTK observers and Qt event filters are really firing on the user's PC.
        """
        try:
            self._debug_event_counter += 1
            data = ", ".join(f"{k}={v}" for k, v in payload.items())
            log.info("3D_EVENT #%s %s%s%s", self._debug_event_counter, event, ": " if data else "", data)
        except Exception:
            pass

    def describe_3d_state(self) -> str:
        """Return a text snapshot of the active VTK 3D viewer state."""
        lines = []
        try:
            lines.append(f"vtk_ready={self._vtk_ready}, vtk_failed={self._vtk_failed}")
            lines.append(f"distance_enabled={self._distance_enabled}, ctrl_lock_active={self._ctrl_lock_active}")
            lines.append(f"clip_box_enabled={self._clip_box_enabled}, clip_nav_enabled={self._clip_nav_enabled}")
            lines.append(f"artifact_clean_active={self._artifact_clean_active}")
            for name in ("_volume_mapper", "_volume_property", "_volume_actor", "_volume_importer", "_inspect_controller"):
                obj = getattr(self, name, None)
                lines.append(f"{name}={type(obj).__name__ if obj is not None else '<none>'}")
            if self._source_volume_hu is not None:
                v = self._source_volume_hu
                lines.append(f"source_volume_shape={getattr(v, 'shape', None)}, dtype={getattr(v, 'dtype', None)}")
                try:
                    lines.append(f"source_volume_minmax={float(np.nanmin(v)):.1f}/{float(np.nanmax(v)):.1f}")
                except Exception as exc:
                    lines.append(f"source_volume_minmax=<error {exc}>")
            lines.append(f"source_spacing_zyx={self._source_spacing_zyx}, source_preset={self._source_preset}")
            if self._render_widget is not None:
                iren = self._render_widget.GetRenderWindow().GetInteractor()
                style = iren.GetInteractorStyle() if iren is not None else None
                lines.append(f"interactor={type(iren).__name__ if iren is not None else '<none>'}")
                lines.append(f"interactor_style={type(style).__name__ if style is not None else '<none>'}")
                try:
                    lines.append(f"vtk_keys ctrl={bool(iren.GetControlKey())}, alt={bool(iren.GetAltKey())}, shift={bool(iren.GetShiftKey())}")
                except Exception as exc:
                    lines.append(f"vtk_keys=<error {exc}>")
            if self._renderer is not None:
                cam = self._renderer.GetActiveCamera()
                lines.append(f"camera_pos={cam.GetPosition()}")
                lines.append(f"camera_fp={cam.GetFocalPoint()}")
                lines.append(f"camera_parallel={cam.GetParallelProjection()}, scale={cam.GetParallelScale():.4g}")
        except Exception as exc:
            lines.append(f"<describe_3d_state error: {exc}>")
        return "\n".join(lines)

    def _ensure_vtk(self) -> bool:
        if self._vtk_ready:
            return True
        if self._vtk_failed:
            return False
        try:
            from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
            import vtkmodules.vtkRenderingOpenGL2  # noqa: F401  # noqa: F401
            import vtkmodules.vtkInteractionStyle  # noqa: F401
            import vtkmodules.vtkRenderingVolumeOpenGL2  # noqa: F401  # noqa: F401
            from vtkmodules.vtkRenderingCore import vtkRenderer
            self._render_widget = QVTKRenderWindowInteractor(self)
            try:
                self._render_widget.setFocusPolicy(Qt.StrongFocus)
                self._render_widget.setMouseTracking(True)
            except Exception:
                pass
            self._renderer = vtkRenderer()
            self._render_widget.GetRenderWindow().AddRenderer(self._renderer)
            self._layout.addWidget(self._render_widget, 1)
            self._render_widget.hide()
            self._vtk_ready = True
            self._status.setText("VTK доступний. Якщо 3D працює повільно або падає — використовуйте Auto Safe / MIP Preview.")
            return True
        except Exception as exc:
            self._vtk_ready = False
            self._vtk_failed = True
            self._status.setText("VTK недоступний або несумісний з цим ПК. Використовується безпечний MIP Preview.\n" + str(exc))
            log.warning("VTK init failed: %s", exc)
            return False

    def _show_preview(self):
        self._preview.show()
        if self._render_widget is not None:
            self._render_widget.hide()

    def _show_vtk(self):
        self._preview.hide()
        if self._render_widget is not None:
            self._render_widget.show()


    def _clear_3d_ruler(self) -> None:
        try:
            if self._distance_widget is not None:
                self._distance_widget.Off()
        except Exception:
            pass
        try:
            if self._ruler_observer is not None and self._render_widget is not None:
                iren = self._render_widget.GetRenderWindow().GetInteractor()
                iren.RemoveObserver(self._ruler_observer)
        except Exception:
            pass
        self._ruler_observer = None
        self._distance_widget = None
        self._ruler_points = []
        try:
            if hasattr(self, "_measurement_overlay"):
                self._measurement_overlay.setVisible(False)
                self._measurement_overlay.setText("3D Measurement: —")
        except Exception:
            pass
        try:
            if self._renderer is not None:
                for a in list(self._ruler_actors):
                    try:
                        self._renderer.RemoveActor(a)
                    except Exception:
                        try:
                            self._renderer.RemoveViewProp(a)
                        except Exception:
                            pass
        except Exception:
            pass
        self._ruler_actors = []
        self._remove_ctrl_freeze_for_ruler()
        try:
            if self._render_widget is not None:
                self._render_widget.GetRenderWindow().Render()
        except Exception:
            pass

    def _is_ctrl_down(self, iren_obj: Any) -> bool:
        """Return camera-lock modifier state for 3D ruler.

        RC5 restores the older working behavior: Ctrl+Alt freezes the VTK
        camera completely.  Plain Ctrl is also accepted as a fallback for users
        who already learned the RC4 shortcut.
        """
        vtk_ctrl = False; vtk_alt = False
        try:
            g = getattr(iren_obj, "GetControlKey", None); vtk_ctrl = bool(g()) if g is not None else False
            a = getattr(iren_obj, "GetAltKey", None); vtk_alt = bool(a()) if a is not None else False
        except Exception:
            pass
        if vtk_ctrl and vtk_alt:
            return True
        try:
            mods = QApplication.keyboardModifiers()
            if (mods & Qt.ControlModifier) and (mods & Qt.AltModifier):
                return True
            # fallback: keep plain Ctrl usable if Alt is swallowed by Windows/driver
            if mods & Qt.ControlModifier:
                return True
        except Exception:
            pass
        return bool(vtk_ctrl)

    def _set_camera_frozen(self, frozen: bool) -> None:
        """Hard VTK camera lock for 3D ruler mode.

        Qt key events alone do not stop vtkInteractorStyleTrackballCamera.  When
        Ctrl is held and the 3D ruler is active, replace the interactor style
        with vtkInteractorStyleUser so rotate/pan/zoom cannot consume the mouse.
        Releasing Ctrl restores the exact previous style.
        """
        if self._render_widget is None:
            return
        try:
            import vtkmodules.all as vtk
            iren = self._render_widget.GetRenderWindow().GetInteractor()
            if frozen:
                if self._ctrl_saved_style is None:
                    self._ctrl_saved_style = iren.GetInteractorStyle()
                if self._ctrl_freeze_style is None:
                    self._ctrl_freeze_style = vtk.vtkInteractorStyleUser()
                if iren.GetInteractorStyle() is not self._ctrl_freeze_style:
                    iren.SetInteractorStyle(self._ctrl_freeze_style)
                if not self._ctrl_lock_active:
                    self._log_3d_event("CTRL_ALT_LOCK_ON", style=type(self._ctrl_freeze_style).__name__)
                self._ctrl_lock_active = True
                self._status.setText("3D лінійка: Ctrl+Alt LOCK — камера/zoom/pan зупинені. Клік по моделі ставить P1/P2.")
            else:
                if self._ctrl_saved_style is not None:
                    iren.SetInteractorStyle(self._ctrl_saved_style)
                if self._ctrl_lock_active:
                    self._log_3d_event("CTRL_ALT_LOCK_OFF")
                self._ctrl_lock_active = False
                self._ctrl_saved_style = None
        except Exception:
            pass

    def _install_ctrl_freeze_for_ruler(self) -> None:
        if self._render_widget is None or getattr(self, "_ctrl_freeze_observers", None):
            return
        try:
            iren = self._render_widget.GetRenderWindow().GetInteractor()
            def _key_press(obj, ev):
                if self._distance_enabled and self._is_ctrl_down(obj):
                    self._set_camera_frozen(True)
                    self._log_3d_event("VTK_ABORT", vtk_event=ev)
                    try: obj.AbortFlagOn()
                    except Exception: pass
            def _key_release(obj, ev):
                if self._distance_enabled and not self._is_ctrl_down(obj):
                    self._set_camera_frozen(False)
            def _abort_if_ctrl(obj, ev):
                if self._distance_enabled and self._is_ctrl_down(obj):
                    self._set_camera_frozen(True)
                    self._log_3d_event("VTK_ABORT", vtk_event=ev)
                    try: obj.AbortFlagOn()
                    except Exception: pass
            for ev in ("KeyPressEvent", "KeyReleaseEvent"):
                cb = _key_press if ev == "KeyPressEvent" else _key_release
                self._ctrl_freeze_observers.append(iren.AddObserver(ev, cb, 999.0))
            for ev in ("MouseMoveEvent", "MouseWheelForwardEvent", "MouseWheelBackwardEvent", "RightButtonPressEvent", "MiddleButtonPressEvent"):
                self._ctrl_freeze_observers.append(iren.AddObserver(ev, _abort_if_ctrl, 999.0))
            # Also watch Qt events from the QVTK widget.  This catches Left Ctrl
            # even when VTK itself does not emit/remember the control state.
            try:
                self._render_widget.installEventFilter(self)
                app = QApplication.instance()
                if app is not None:
                    app.installEventFilter(self)
            except Exception:
                pass
        except Exception:
            pass

    def _remove_ctrl_freeze_for_ruler(self) -> None:
        self._set_camera_frozen(False)
        try:
            if self._render_widget is not None:
                iren = self._render_widget.GetRenderWindow().GetInteractor()
                for oid in list(getattr(self, "_ctrl_freeze_observers", [])):
                    try: iren.RemoveObserver(oid)
                    except Exception: pass
        except Exception:
            pass
        self._ctrl_freeze_observers = []
        try:
            if self._render_widget is not None:
                self._render_widget.removeEventFilter(self)
                app = QApplication.instance()
                if app is not None:
                    app.removeEventFilter(self)
        except Exception:
            pass

    def eventFilter(self, obj, ev):
        """Qt-level Ctrl freeze for the VTK 3D ruler.

        RC4: the lock is global while the 3D ruler is enabled, because on
        Windows QVTK sometimes sends Ctrl/key events to the QApplication or to
        a child native window rather than to QVTKRenderWindowInteractor itself.
        While Ctrl is held, rotate/zoom/pan/wheel events are swallowed and the
        current camera style is replaced by vtkInteractorStyleUser.
        """
        try:
            if self._distance_enabled:
                et = ev.type()
                watch = (ev.Type.KeyPress, ev.Type.KeyRelease, ev.Type.MouseMove, ev.Type.Wheel,
                         ev.Type.MouseButtonPress, ev.Type.MouseButtonRelease)
                if et in watch:
                    frozen = bool(QApplication.keyboardModifiers() & Qt.ControlModifier)
                    self._set_camera_frozen(frozen)
                    if frozen and et in (ev.Type.MouseMove, ev.Type.Wheel, ev.Type.MouseButtonPress):
                        # Left button must still reach VTK picker through the high priority
                        # VTK observer.  Block only non-left mouse events at Qt level.
                        try:
                            btn = ev.button() if hasattr(ev, 'button') else None
                            if et == ev.Type.MouseButtonPress and btn == Qt.LeftButton:
                                return False
                        except Exception:
                            pass
                        self._log_3d_event("QT_EVENT_SWALLOWED", event_type=int(et))
                        ev.accept()
                        return True
        except Exception:
            pass
        return super().eventFilter(obj, ev)


    def _camera_snapshot(self):
        try:
            if self._renderer is None:
                return None
            cam = self._renderer.GetActiveCamera()
            return {
                "pos": cam.GetPosition(),
                "fp": cam.GetFocalPoint(),
                "vu": cam.GetViewUp(),
                "va": cam.GetViewAngle(),
                "ps": cam.GetParallelScale(),
                "parallel": cam.GetParallelProjection(),
            }
        except Exception:
            return None

    def _restore_camera_snapshot(self, snap) -> None:
        try:
            if not snap or self._renderer is None:
                return
            cam = self._renderer.GetActiveCamera()
            cam.SetPosition(*snap["pos"]); cam.SetFocalPoint(*snap["fp"]); cam.SetViewUp(*snap["vu"])
            cam.SetViewAngle(float(snap["va"])); cam.SetParallelScale(float(snap["ps"]))
            cam.SetParallelProjection(int(snap["parallel"]))
            self._renderer.ResetCameraClippingRange()
        except Exception:
            pass

    def apply_post_artifact_cleaner(self, *, strength_percent: int = 50, threshold_hu: float = 180.0, min_component_voxels: int = 1500) -> bool:
        if self._source_volume_hu is None or self._source_spacing_zyx is None:
            self._status.setText("Спочатку побудуйте 3D. Очищення артефактів працює після побудови оригіналу.")
            return False
        try:
            from dicomview_pro.core.volume_cleaner import post_render_artifact_mask_clean_volume
            res = post_render_artifact_mask_clean_volume(
                self._source_volume_hu,
                threshold_hu=float(threshold_hu),
                min_component_voxels=int(min_component_voxels),
                strength_percent=int(strength_percent),
            )
            if not res.ok:
                self._status.setText(res.message + " — оригінальна 3D модель не змінена.")
                return False
            preset = self._source_preset
            cam_snap = self._camera_snapshot()
            self.set_volume(res.display_volume, self._source_spacing_zyx, preset, preserve_source=True)
            self._restore_camera_snapshot(cam_snap)
            try:
                self._render_widget.GetRenderWindow().Render()
            except Exception:
                pass
            self._artifact_clean_active = True
            self._artifact_clean_mask = res.artifact_mask
            self._status.setText(res.message + " | Відновити оригінал поверне попередній стан.")
            return True
        except Exception as exc:
            self._status.setText("Artifact Cleaner error: " + str(exc))
            return False

    def restore_original_3d_volume(self) -> bool:
        if self._source_volume_hu is None or self._source_spacing_zyx is None:
            self._status.setText("Оригінальний 3D стан ще не збережено. Побудуйте 3D заново.")
            return False
        try:
            preset = self._source_preset
            cam_snap = self._camera_snapshot()
            self.set_volume(self._source_volume_hu, self._source_spacing_zyx, preset, preserve_source=True)
            self._restore_camera_snapshot(cam_snap)
            try:
                self._render_widget.GetRenderWindow().Render()
            except Exception:
                pass
            self._artifact_clean_active = False
            self._artifact_clean_mask = None
            self._status.setText("3D Clean OFF: відновлено оригінальний Volume Rendering без зміни preset/transfer function.")
            return True
        except Exception as exc:
            self._status.setText("Restore original 3D error: " + str(exc))
            return False

    def enable_distance_measurement(self, enabled: bool = True) -> bool:
        """Surface-snap 3D ruler: two left double-clicks create one locked measurement.

        Re-enabling always clears the previous line/points.  The points are picked
        on the visible VTK prop surface with vtkCellPicker, so they do not float
        in empty 3D space while the camera is rotated or zoomed.
        """
        self._distance_enabled = bool(enabled)
        self._clear_3d_ruler()
        if not enabled:
            self._log_3d_event("RULER_OFF")
            self._status.setText("3D лінійка вимкнена і очищена.")
            return True
        if not self._ensure_vtk() or self._render_widget is None or self._renderer is None:
            self._status.setText("3D лінійка доступна тільки у VTK-режимі.")
            return False
        try:
            import vtkmodules.all as vtk
            iren = self._render_widget.GetRenderWindow().GetInteractor()
            try:
                iren.Initialize()
            except Exception:
                pass

            picker = vtk.vtkCellPicker(); picker.SetTolerance(0.005)
            self._ruler_picker = picker
            try:
                self._measurement_overlay.setVisible(True)
                self._measurement_overlay.setText("3D Measurement: P1/P2 — утримуйте Ctrl+Alt і клацніть по моделі")
            except Exception:
                pass

            def _place_point_from_event(obj):
                x, y = obj.GetEventPosition()
                ok = picker.Pick(float(x), float(y), 0, self._renderer)
                if not ok:
                    self._status.setText("3D лінійка: клік не потрапив у поверхню моделі.")
                    return
                pt = tuple(float(v) for v in picker.GetPickPosition())
                if len(self._ruler_points) >= 2:
                    # Start a clean new measurement automatically.
                    keep_enabled = self._distance_enabled
                    self._clear_3d_ruler()
                    self._distance_enabled = keep_enabled
                self._ruler_points.append(pt)
                self._add_ruler_marker(pt)
                if len(self._ruler_points) == 2:
                    self._draw_ruler_line()
                else:
                    self._status.setText("3D лінійка: перша точка поставлена. Подвійний ЛКМ для другої точки.")

            def _on_left_press(obj, event):
                if not self._distance_enabled:
                    return
                try:
                    if not self._is_ctrl_down(obj):
                        return
                    x, y = obj.GetEventPosition()
                    now = time.monotonic()
                    last_t, last_x, last_y = self._last_left_press
                    self._last_left_press = (now, int(x), int(y))
                    # In locked ruler mode use Ctrl+LeftClick as the primary
                    # point action.  Double-click still works naturally because
                    # it produces two left-presses, but single-click is much
                    # easier when the model is frozen.
                    _place_point_from_event(obj)
                    try: obj.AbortFlagOn()
                    except Exception: pass
                except Exception as exc:
                    self._status.setText("3D лінійка: помилка вибору точки: " + str(exc))

            self._ruler_observer = iren.AddObserver("LeftButtonPressEvent", _on_left_press, 999.0)
            self._install_ctrl_freeze_for_ruler()
            self._log_3d_event("RULER_ON", observer=self._ruler_observer, ctrl_observers=len(self._ctrl_freeze_observers))
            self._status.setText("3D лінійка ON: утримуйте Ctrl+Alt — камера заморожена; Ctrl+Alt+ЛКМ ставить P1/P2.")
            return True
        except Exception as exc:
            self._status.setText("Не вдалося увімкнути 3D лінійку: " + str(exc))
            return False

    def _add_ruler_marker(self, pt) -> None:
        try:
            import vtkmodules.all as vtk
            src = vtk.vtkSphereSource(); src.SetCenter(*pt); src.SetRadius(2.0); src.SetThetaResolution(16); src.SetPhiResolution(16)
            mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(src.GetOutputPort())
            actor = vtk.vtkActor(); actor.SetMapper(mapper); actor.GetProperty().SetColor(0.0, 1.0, 0.15)
            self._renderer.AddActor(actor); self._ruler_actors.append(actor)
            self._render_widget.GetRenderWindow().Render()
        except Exception:
            pass

    def _draw_ruler_line(self) -> None:
        try:
            import math
            import vtkmodules.all as vtk
            p1, p2 = self._ruler_points[:2]
            line = vtk.vtkLineSource(); line.SetPoint1(*p1); line.SetPoint2(*p2)
            mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(line.GetOutputPort())
            actor = vtk.vtkActor(); actor.SetMapper(mapper); actor.GetProperty().SetColor(0.0, 1.0, 0.15); actor.GetProperty().SetLineWidth(3)
            self._renderer.AddActor(actor); self._ruler_actors.append(actor)
            dist = math.sqrt(sum((p2[i]-p1[i])**2 for i in range(3)))
            mid = tuple((p1[i]+p2[i])*0.5 for i in range(3))
            # 2D overlay text: always visible on top of the 3D viewport, never hidden behind skull/bone.
            text2d = vtk.vtkTextActor(); text2d.SetInput(f"{dist:.1f} mm")
            try:
                coord = vtk.vtkCoordinate(); coord.SetCoordinateSystemToWorld(); coord.SetValue(*mid)
                xy = coord.GetComputedDisplayValue(self._renderer)
                text2d.SetDisplayPosition(int(xy[0]), int(xy[1]))
            except Exception:
                text2d.SetDisplayPosition(24, 60)
            try:
                text2d.GetTextProperty().SetColor(1, 0.95, 0.25); text2d.GetTextProperty().SetFontSize(28); text2d.GetTextProperty().BoldOn()
                text2d.GetTextProperty().SetBackgroundColor(0, 0, 0); text2d.GetTextProperty().SetBackgroundOpacity(0.55)
            except Exception:
                pass
            self._renderer.AddActor2D(text2d); self._ruler_actors.append(text2d)
            try:
                self._measurement_overlay.setVisible(True)
                self._measurement_overlay.setText(
                    f"3D Measurement\nP1: {p1[0]:.1f}, {p1[1]:.1f}, {p1[2]:.1f} mm\n"
                    f"P2: {p2[0]:.1f}, {p2[1]:.1f}, {p2[2]:.1f} mm\n"
                    f"Distance: {dist:.1f} mm"
                )
            except Exception:
                pass
            self._render_widget.GetRenderWindow().Render()
            self._status.setText(f"3D відстань: {dist:.1f} mm. Результат винесено в overlay-панель і поверх 3D сцени.")
        except Exception as exc:
            self._status.setText("3D лінійка: не вдалося намалювати лінію: " + str(exc))


    def apply_transfer_preset(self, preset: str) -> bool:
        """Apply 3D Enterprise Foundation HU transfer preset live."""
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(
                self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor()
            )
        if self._inspect_controller is None:
            self._status.setText("3D preset доступний після побудови VTK Volume Rendering.")
            return False
        ok = self._inspect_controller.apply_preset(preset)
        if ok:
            self._status.setText(f"3D Transfer Function preset застосовано: {preset}")
        else:
            self._status.setText("Не вдалося застосувати 3D Transfer Function preset.")
        return ok

    def update_opacity_threshold(self, threshold_hu: float) -> bool:
        """Dynamically move scalar-opacity threshold for the active volume."""
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(
                self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor()
            )
        if self._inspect_controller is None:
            self._status.setText("Density Threshold доступний після побудови VTK Volume Rendering.")
            return False
        threshold = float(threshold_hu)
        ok = self._inspect_controller.set_depth_threshold(threshold)
        if ok:
            self._status.setText(f"3D Density Threshold: {threshold:g} HU — нижчі тканини прозорі.")
        else:
            self._status.setText("Не вдалося оновити 3D прозорість.")
        return ok


    def set_mip_blend(self, enabled: bool = True) -> bool:
        """Switch active volume mapper between Composite and Maximum Intensity Projection."""
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(
                self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor()
            )
        if self._inspect_controller is None:
            self._status.setText("MIP blend доступний після побудови VTK Volume Rendering.")
            return False
        ok = self._inspect_controller.set_mip(bool(enabled))
        if enabled and ok:
            self._status.setText("3D MIP blend увімкнено: судини/кальцинати світяться крізь об’єм.")
        elif ok:
            self._status.setText("3D Composite blend відновлено.")
        else:
            self._status.setText("Не вдалося перемкнути 3D MIP.")
        return ok


    def enable_clip_box(self, enabled: bool = True) -> bool:
        """Enable/disable interactive VTK clipping box for the active volume."""
        self._clip_box_enabled = bool(enabled)
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(
                self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor()
            )
        if self._inspect_controller is None:
            self._status.setText("Clip Box доступний після побудови VTK Volume Rendering.")
            return False
        ok = self._inspect_controller.set_clipping_box_visible(bool(enabled))
        if ok and enabled:
            self._status.setText("3D Clip Box увімкнено: рухайте грані куба для відсікання анатомії.")
        elif ok:
            self._status.setText("3D Clip Box вимкнено.")
        else:
            self._status.setText("Не вдалося перемкнути Clip Box.")
        return ok

    def enable_clip_navigate(self, enabled: bool = True, axis: str = "Y") -> bool:
        """Enable single-plane clip navigation.

        In this mode the VTK camera interaction style is temporarily replaced
        by vtkInteractorStyleUser, so mouse wheel cannot zoom the scene.  Wheel
        and the depth slider move the clipping plane smoothly into the volume.
        Disabling restores normal TrackballCamera rotation/zoom.
        """
        self._clip_nav_enabled = bool(enabled)
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor())
        if self._inspect_controller is None or self._render_widget is None:
            self._status.setText("Clip Navigate доступний після побудови VTK Volume Rendering.")
            return False
        ok = self._inspect_controller.enable_clip_plane_navigate(bool(enabled), axis=axis, renderer=self._renderer)
        if not ok:
            self._status.setText("Не вдалося увімкнути Clip Navigate.")
            return False
        try:
            import vtkmodules.all as vtk
            iren = self._render_widget.GetRenderWindow().GetInteractor()
            if enabled:
                # Keep TrackballCamera active: only wheel events are intercepted.
                # This preserves rotation and zoom state after clipping mode.
                if not self._clip_nav_observers:
                    def _wheel_forward(obj, ev):
                        if self._clip_nav_enabled and self._inspect_controller is not None:
                            self._inspect_controller.move_clip_plane_step(3.0)
                            try:
                                obj.AbortFlagOn()
                            except Exception:
                                pass
                            self._status.setText("Clip Navigate: площина рухається всередину. Reset Clip = повернути камеру/ніж.")
                    def _wheel_backward(obj, ev):
                        if self._clip_nav_enabled and self._inspect_controller is not None:
                            self._inspect_controller.move_clip_plane_step(-3.0)
                            try:
                                obj.AbortFlagOn()
                            except Exception:
                                pass
                            self._status.setText("Clip Navigate: площина рухається назовні.")
                    self._clip_nav_observers.append(iren.AddObserver("MouseWheelForwardEvent", _wheel_forward, 100.0))
                    self._clip_nav_observers.append(iren.AddObserver("MouseWheelBackwardEvent", _wheel_backward, 100.0))
            else:
                # No style restoration needed because we no longer replace it.
                pass
        except Exception:
            pass
        if enabled:
            self._status.setText("Clip Navigate ON: колесо миші рухає площину відсікання; ротація/панорамування моделі залишаються доступними.")
        else:
            self._status.setText("Clip Navigate OFF: нормальна ротація і масштабування 3D відновлені.")
        return True

    def set_clip_depth_percent(self, value: float) -> bool:
        if self._inspect_controller is None and self._volume_actor is not None and self._volume_mapper is not None and self._render_widget is not None:
            self._inspect_controller = VolumeInspectController(self._volume_actor, self._volume_mapper, self._render_widget.GetRenderWindow().GetInteractor())
        if self._inspect_controller is None:
            return False
        if not self._clip_nav_enabled:
            self.enable_clip_navigate(True)
        ok = self._inspect_controller.set_clip_plane_percent(float(value))
        if ok:
            self._inspect_controller._clip_percent = float(value)
            self._status.setText(f"Clip depth: {float(value):.0f}%")
        return ok



    def _attach_deep3d_runtime(self, volume_hu: np.ndarray | None = None, spacing_zyx: tuple[float, float, float] = (1.0,1.0,1.0)) -> None:
        """Attach modular Deep3D controllers and wheel shortcuts without breaking legacy VTK UI."""
        try:
            self._deep3d_controllers = attach_deep3d_controllers(self, volume_hu, spacing_zyx)
            self._bind_deep3d_wheel_shortcuts()
        except Exception:
            self._deep3d_controllers = None

    def _bind_deep3d_wheel_shortcuts(self) -> None:
        """High-priority wheel mapping:
        - normal wheel remains VTK zoom;
        - Shift+wheel moves camera forward/backward into the volume;
        - Ctrl+wheel changes slab thickness controller;
        - Alt+wheel or active Clip Navigate moves the clipping plane.
        Rotation/pan are not disabled anymore, so the 3D knife no longer traps the camera.
        """
        if self._render_widget is None:
            return
        try:
            iren = self._render_widget.GetRenderWindow().GetInteractor()
            if getattr(self, "_deep_wheel_observers", None):
                return
            def _wheel(sign: int):
                def _cb(obj, ev):
                    try:
                        def _key(name: str) -> bool:
                            getter = getattr(obj, name, None)
                            try:
                                return bool(getter()) if getter is not None else False
                            except Exception:
                                return False
                        shift = _key("GetShiftKey")
                        ctrl = _key("GetControlKey")
                        alt = _key("GetAltKey")
                        if ctrl and self._distance_enabled:
                            try: obj.AbortFlagOn()
                            except Exception: pass
                            self._status.setText("3D лінійка: Ctrl+Alt блокує wheel zoom/slab під час постановки точок.")
                            return
                        ctrls = getattr(self, "_deep3d_controllers", None)
                        deep = getattr(ctrls, "deep_camera", None) if ctrls is not None else None
                        slab = getattr(ctrls, "slab", None) if ctrls is not None else None
                        clip = getattr(ctrls, "clip", None) if ctrls is not None else None
                        handled = False
                        if self._clip_nav_enabled or alt:
                            if self._inspect_controller is not None:
                                self._inspect_controller.move_clip_plane_step(3.0 * sign)
                                handled = True
                                self._status.setText("Clip Navigate: площина відсікання рухається вглиб/назовні; ротація моделі лишається доступною.")
                            elif clip is not None:
                                clip.enable(True)
                                clip.move_mm(3.0 * sign)
                                handled = True
                                self._status.setText("ClipPlaneController: площина рухається вглиб/назовні; ротація моделі лишається доступною.")
                        elif shift and deep is not None:
                            deep.move_forward_mm(2.5 * sign)
                            handled = True
                            self._status.setText("Deep camera: Shift+Wheel рухає камеру всередину/назовні без зміни масштабу.")
                        elif ctrl and slab is not None:
                            slab.increase_thickness(1.0 * sign)
                            handled = True
                            self._status.setText(f"Slab thickness: {slab.thickness_mm:.1f} mm")
                        if handled:
                            try: obj.AbortFlagOn()
                            except Exception: pass
                    except Exception as exc:
                        self._status.setText("Deep3D wheel handler error: " + str(exc))
                return _cb
            self._deep_wheel_observers.append(iren.AddObserver("MouseWheelForwardEvent", _wheel(+1), 100.0))
            self._deep_wheel_observers.append(iren.AddObserver("MouseWheelBackwardEvent", _wheel(-1), 100.0))
        except Exception:
            pass

    def set_mip_preview(self, volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], preset: str = "MIP Preview") -> None:
        self._volume_mapper = None; self._volume_property = None; self._volume_actor = None; self._volume_importer = None
        volume = np.asarray(volume_hu)
        if volume.ndim != 3:
            self._status.setText("MIP Preview: volume must be 3D")
            return
        # CPU-only pseudo-3D: combine three projections into a color preview.
        mip_ax = np.max(volume, axis=0)
        mip_cor = np.max(volume, axis=1)
        mip_sag = np.max(volume, axis=2)
        # Resize by simple nearest padding/cropping into one canvas; no OpenGL needed.
        imgs = [_window_to_uint8(mip_ax), _window_to_uint8(mip_cor), _window_to_uint8(mip_sag)]
        h = max(i.shape[0] for i in imgs)
        w = sum(i.shape[1] for i in imgs) + 20
        canvas = np.zeros((h, w), dtype=np.uint8)
        x = 0
        for im in imgs:
            canvas[:im.shape[0], x:x+im.shape[1]] = im
            x += im.shape[1] + 10
        q = QImage(canvas.data, canvas.shape[1], canvas.shape[0], canvas.shape[1], QImage.Format_Grayscale8).copy()
        self._preview.setPixmap(QPixmap.fromImage(q).scaled(self._preview.size(), Qt.KeepAspectRatio, Qt.FastTransformation))
        self._show_preview()
        self._status.setText(
            f"3D Safe MIP Preview: {preset} | CPU-only | shape={volume.shape} | spacing z/y/x=({spacing_zyx[0]:.3g}, {spacing_zyx[1]:.3g}, {spacing_zyx[2]:.3g})"
        )

    def set_surface(self, volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], threshold: float = 300.0) -> None:
        self._volume_mapper = None; self._volume_property = None; self._volume_actor = None; self._volume_importer = None
        if not self._ensure_vtk() or self._renderer is None or self._render_widget is None:
            self.set_mip_preview(volume_hu, spacing_zyx, "Surface fallback")
            return
        try:
            import vtkmodules.all as vtk
            volume = np.asarray(volume_hu, dtype=np.float32)
            z, y, x = volume.shape
            data = np.ascontiguousarray(volume.ravel(order="C"))
            importer = vtk.vtkImageImport()
            importer.CopyImportVoidPointer(data.tobytes(), data.nbytes)
            importer.SetDataScalarTypeToFloat(); importer.SetNumberOfScalarComponents(1)
            importer.SetDataExtent(0, x - 1, 0, y - 1, 0, z - 1); importer.SetWholeExtent(0, x - 1, 0, y - 1, 0, z - 1)
            sz, sy, sx = spacing_zyx; importer.SetDataSpacing(float(sx), float(sy), float(sz)); importer.Update()
            contour = vtk.vtkFlyingEdges3D(); contour.SetInputConnection(importer.GetOutputPort()); contour.SetValue(0, float(threshold)); contour.Update()
            mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(contour.GetOutputPort()); mapper.ScalarVisibilityOff()
            actor = vtk.vtkActor(); actor.SetMapper(mapper); actor.GetProperty().SetColor(0.95, 0.82, 0.62)
            self._renderer.RemoveAllViewProps(); self._renderer.AddActor(actor); self._renderer.SetBackground(0.02,0.06,0.11); self._renderer.ResetCamera()
            self._show_vtk(); self._render_widget.GetRenderWindow().Render(); self._render_widget.Initialize()
            self._attach_deep3d_runtime(volume, spacing_zyx)
            try:
                self._inspect_controller = VolumeInspectController(actor, mapper, self._render_widget.GetRenderWindow().GetInteractor())
            except Exception:
                self._inspect_controller = None
            if self._distance_enabled:
                self.enable_distance_measurement(True)
            self._status.setText(f"3D Surface Safe: threshold={threshold:g} HU | shape={volume.shape} | spacing z/y/x=({sz:.3g}, {sy:.3g}, {sx:.3g})")
        except Exception as exc:
            log.exception("3D surface failed")
            self.set_mip_preview(volume_hu, spacing_zyx, "Surface failed → MIP")
            self._status.setText("3D Surface не вдався, увімкнено MIP Preview: " + str(exc))

    def _clear_render_quality_observers(self) -> None:
        """Remove temporary VTK interaction observers used by adaptive sampling.

        set_volume() can be called many times when changing presets or opening new
        series.  Without explicit cleanup, VTK observers accumulate and each camera
        interaction fires old callbacks attached to previous mappers.
        """
        if not self._render_quality_observers:
            return
        try:
            iren = self._render_widget.GetRenderWindow().GetInteractor() if self._render_widget is not None else None
            if iren is not None:
                for oid in list(self._render_quality_observers):
                    try:
                        iren.RemoveObserver(oid)
                    except Exception:
                        pass
        except Exception:
            pass
        self._render_quality_observers = []

    def _attach_adaptive_render_quality(self, mapper, spacing_zyx: tuple[float, float, float], preset: str) -> None:
        """Use coarse sampling while interacting and finer sampling after release.

        This is deliberately attached to the real visible VTK path in vtk_viewer.py.
        It does not rely on the unused experimental render engines.  Unsupported
        mapper methods are ignored so the code remains safe on older VTK builds.
        """
        self._clear_render_quality_observers()
        try:
            iren = self._render_widget.GetRenderWindow().GetInteractor() if self._render_widget is not None else None
        except Exception:
            iren = None
        if iren is None:
            return
        try:
            sz, sy, sx = (float(spacing_zyx[0]), float(spacing_zyx[1]), float(spacing_zyx[2]))
            min_spacing = max(1e-3, min(sx, sy, sz))
        except Exception:
            min_spacing = 1.0
        p = str(preset or "").lower()
        still_factor = 0.50 if ("bone" in p or "trauma" in p or "hemorrhage" in p or "classic" in p) else 0.65
        moving_factor = 1.35 if ("bone" in p or "trauma" in p) else 1.60
        still_distance = max(0.28, min_spacing * still_factor)
        moving_distance = max(still_distance, min_spacing * moving_factor)

        def _set_quality(sample_distance: float, image_sample_distance: float, label: str) -> None:
            try:
                if hasattr(mapper, "SetAutoAdjustSampleDistances"):
                    mapper.SetAutoAdjustSampleDistances(False)
            except Exception:
                pass
            try:
                mapper.SetSampleDistance(float(sample_distance))
            except Exception:
                pass
            try:
                mapper.SetImageSampleDistance(float(image_sample_distance))
            except Exception:
                pass
            try:
                if hasattr(mapper, "SetUseJittering"):
                    mapper.SetUseJittering(True)
            except Exception:
                pass
            self._log_3d_event("RENDER_QUALITY", preset=preset, mode=label, sample_distance=round(float(sample_distance), 4))

        # Start in high-quality still mode; switch to faster sampling only while the
        # user rotates/pans/zooms the volume.
        _set_quality(still_distance, 1.0, "still")

        def _start(_obj=None, _evt=None):
            _set_quality(moving_distance, 1.35, "interaction")

        def _end(_obj=None, _evt=None):
            _set_quality(still_distance, 1.0, "still")
            try:
                if self._render_widget is not None:
                    self._render_widget.GetRenderWindow().Render()
            except Exception:
                pass

        for event_name, callback in (("StartInteractionEvent", _start), ("EndInteractionEvent", _end)):
            try:
                self._render_quality_observers.append(iren.AddObserver(event_name, callback, 20.0))
            except Exception:
                pass

    def set_volume(self, volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], preset: str = "Bone", *, preserve_source: bool = False) -> None:
        if not self._ensure_vtk() or self._renderer is None or self._render_widget is None:
            self.set_mip_preview(volume_hu, spacing_zyx, "VTK unavailable")
            return
        try:
            import vtkmodules.all as vtk
            volume = np.asarray(volume_hu, dtype=np.float32)
            if not preserve_source:
                self._source_volume_hu = np.ascontiguousarray(volume.copy())
                self._source_spacing_zyx = tuple(float(v) for v in spacing_zyx)
                self._source_preset = str(preset)
                self._artifact_clean_active = False
                self._artifact_clean_mask = None
            if volume.ndim != 3:
                raise ValueError("Volume must be 3D")
            # Downsample huge data for weak GPUs; full-resolution remains visible in 2D/MPR.
            max_voxels = 140_000_000
            if volume.size > max_voxels:
                step = int(np.ceil((volume.size / max_voxels) ** (1/3)))
                volume = volume[::step, ::step, ::step]
                spacing_zyx = tuple(float(v) * step for v in spacing_zyx)
            z, y, x = volume.shape
            data = np.ascontiguousarray(volume.ravel(order="C"))
            importer = vtk.vtkImageImport()
            importer.CopyImportVoidPointer(data.tobytes(), data.nbytes)
            importer.SetDataScalarTypeToFloat()
            importer.SetNumberOfScalarComponents(1)
            importer.SetDataExtent(0, x - 1, 0, y - 1, 0, z - 1)
            importer.SetWholeExtent(0, x - 1, 0, y - 1, 0, z - 1)
            sz, sy, sx = spacing_zyx
            importer.SetDataSpacing(float(sx), float(sy), float(sz))
            importer.Update()

            mapper = vtk.vtkSmartVolumeMapper()
            mapper.SetInputConnection(importer.GetOutputPort())
            mapper.SetBlendModeToComposite()
            try:
                mapper.SetRequestedRenderModeToGPU()
            except Exception:
                pass
            # v7.8 Rendering Refactor: quality changes are applied to the real
            # visible vtk_viewer.py path.  Experimental render engines remain
            # documented but are not relied on for the on-screen pipeline.
            try:
                if is_cinematic_preset(preset):
                    apply_cinematic_mapper_quality(mapper, preset, spacing_zyx)
            except Exception:
                pass
            self._attach_adaptive_render_quality(mapper, spacing_zyx, preset)

            color = vtk.vtkColorTransferFunction(); opacity = vtk.vtkPiecewiseFunction()
            p = preset.lower()
            if "classic" in p or "head/face" in p:
                # RC4 Classic 3D: old-style head/face transfer function.
                # Very low filtering, smooth soft-tissue ramp, keeps face/ears/skin
                # contours visible and does not auto-hide low HU soft tissues.
                color.AddRGBPoint(-1000, 0.01, 0.02, 0.05); color.AddRGBPoint(-760, 0.06, 0.16, 0.42); color.AddRGBPoint(-350, 0.34, 0.48, 0.70)
                color.AddRGBPoint(-120, 0.64, 0.42, 0.34); color.AddRGBPoint(40, 0.84, 0.52, 0.42); color.AddRGBPoint(180, 0.95, 0.68, 0.50); color.AddRGBPoint(550, 1.00, 0.82, 0.58); color.AddRGBPoint(1200, 1.0, 0.96, 0.82)
                opacity.AddPoint(-1000, 0.0); opacity.AddPoint(-760, 0.018); opacity.AddPoint(-350, 0.045); opacity.AddPoint(-120, 0.075); opacity.AddPoint(35, 0.105); opacity.AddPoint(120, 0.165); opacity.AddPoint(300, 0.24); opacity.AddPoint(600, 0.43); opacity.AddPoint(1200, 0.72)
            elif "hemorrhage" in p or "blood" in p:
                # Non-AI native CT brain hemorrhage visual aid.
                # Blood is highlighted in red/magenta at ~45..110 HU; bone remains
                # bright but semi-transparent. Not a diagnostic segmentation.
                color.AddRGBPoint(-1000, 0.0, 0.0, 0.0); color.AddRGBPoint(20, 0.22, 0.22, 0.24); color.AddRGBPoint(40, 0.55, 0.05, 0.05)
                color.AddRGBPoint(65, 1.0, 0.0, 0.0); color.AddRGBPoint(100, 1.0, 0.12, 0.32); color.AddRGBPoint(160, 1.0, 0.50, 0.25); color.AddRGBPoint(300, 0.95, 0.84, 0.66); color.AddRGBPoint(1200, 1.0, 0.96, 0.85)
                opacity.AddPoint(-1000, 0.0); opacity.AddPoint(20, 0.0); opacity.AddPoint(38, 0.02); opacity.AddPoint(48, 0.30); opacity.AddPoint(75, 0.88); opacity.AddPoint(110, 0.70); opacity.AddPoint(160, 0.08); opacity.AddPoint(240, 0.10); opacity.AddPoint(600, 0.35); opacity.AddPoint(1200, 0.55)
            elif "air" in p:
                color.AddRGBPoint(-1000, 0.02, 0.06, 0.20); color.AddRGBPoint(-850, 0.05, 0.22, 0.85); color.AddRGBPoint(-700, 0.30, 0.75, 1.0); color.AddRGBPoint(-300, 0.80, 0.90, 1.0); color.AddRGBPoint(100, 0.75, 0.55, 0.45)
                opacity.AddPoint(-1000, 0.0); opacity.AddPoint(-900, 0.04); opacity.AddPoint(-760, 0.15); opacity.AddPoint(-520, 0.08); opacity.AddPoint(-150, 0.02); opacity.AddPoint(50, 0.0)
            elif "color anatomy" in p:
                color.AddRGBPoint(-1000, 0.04, 0.08, 0.25); color.AddRGBPoint(-760, 0.10, 0.28, 0.72); color.AddRGBPoint(-520, 0.18, 0.55, 0.95)
                color.AddRGBPoint(-120, 0.72, 0.45, 0.36); color.AddRGBPoint(80, 0.88, 0.54, 0.42); color.AddRGBPoint(320, 0.95, 0.72, 0.55); color.AddRGBPoint(1200, 1.00, 0.98, 0.90)
                opacity.AddPoint(-1000, 0.00); opacity.AddPoint(-900, 0.015); opacity.AddPoint(-720, 0.075); opacity.AddPoint(-520, 0.11); opacity.AddPoint(-180, 0.04); opacity.AddPoint(50, 0.07); opacity.AddPoint(250, 0.16); opacity.AddPoint(600, 0.48); opacity.AddPoint(1200, 0.86)
            elif "angio" in p or "vessel" in p:
                color.AddRGBPoint(-200, 0, 0, 0); color.AddRGBPoint(120, 0.35, 0.0, 0.02); color.AddRGBPoint(260, 1.0, 0.05, 0.02); color.AddRGBPoint(520, 1, 0.55, 0.10); color.AddRGBPoint(1100, 1, 0.92, 0.62)
                opacity.AddPoint(-200, 0); opacity.AddPoint(120, 0.0); opacity.AddPoint(220, 0.18); opacity.AddPoint(420, 0.55); opacity.AddPoint(850, 0.95)
            elif "lung" in p:
                color.AddRGBPoint(-1000, 0.01, 0.03, 0.08); color.AddRGBPoint(-950, 0.05, 0.12, 0.35); color.AddRGBPoint(-850, 0.20, 0.42, 0.95); color.AddRGBPoint(-700, 0.58, 0.82, 1.0); color.AddRGBPoint(-350, 0.78, 0.90, 1.0); color.AddRGBPoint(250, 1.0, 0.72, 0.55)
                opacity.AddPoint(-1000, 0.00); opacity.AddPoint(-950, 0.025); opacity.AddPoint(-850, 0.08); opacity.AddPoint(-700, 0.16); opacity.AddPoint(-350, 0.11); opacity.AddPoint(50, 0.025); opacity.AddPoint(250, 0.12)
            elif "soft" in p or "skin_muscle" in p or "skin" in p:
                color.AddRGBPoint(-220, 0.32, 0.15, 0.10); color.AddRGBPoint(-100, 0.72, 0.43, 0.34); color.AddRGBPoint(40, 0.90, 0.50, 0.38); color.AddRGBPoint(180, 0.96, 0.74, 0.58); color.AddRGBPoint(360, 1.0, 0.86, 0.68)
                opacity.AddPoint(-250, 0.00); opacity.AddPoint(-180, 0.035); opacity.AddPoint(-80, 0.10); opacity.AddPoint(40, 0.22); opacity.AddPoint(180, 0.42); opacity.AddPoint(350, 0.70)
            elif "bone ultra" in p or "fracture ultra" in p:
                # Enterprise high-fidelity skull/bone preset: crisper cortical bone, sutures and fracture lines.
                color.AddRGBPoint(-700, 0.0, 0.0, 0.0); color.AddRGBPoint(120, 0.18, 0.12, 0.08); color.AddRGBPoint(260, 0.62, 0.42, 0.22)
                color.AddRGBPoint(420, 0.92, 0.78, 0.50); color.AddRGBPoint(760, 1.0, 0.92, 0.72); color.AddRGBPoint(1400, 1.0, 0.99, 0.88)
                opacity.AddPoint(-700, 0.0); opacity.AddPoint(160, 0.0); opacity.AddPoint(260, 0.035); opacity.AddPoint(360, 0.22); opacity.AddPoint(520, 0.58); opacity.AddPoint(900, 0.92); opacity.AddPoint(1400, 1.0)
            elif "brain transparent" in p:
                color.AddRGBPoint(-1000, 0.0, 0.0, 0.0); color.AddRGBPoint(-30, 0.35, 0.20, 0.18); color.AddRGBPoint(35, 0.86, 0.56, 0.50)
                color.AddRGBPoint(80, 1.0, 0.10, 0.08); color.AddRGBPoint(180, 0.96, 0.76, 0.62); color.AddRGBPoint(600, 0.92, 0.86, 0.72); color.AddRGBPoint(1200, 1.0, 0.96, 0.84)
                opacity.AddPoint(-1000, 0.0); opacity.AddPoint(-30, 0.0); opacity.AddPoint(25, 0.035); opacity.AddPoint(45, 0.12); opacity.AddPoint(75, 0.26); opacity.AddPoint(120, 0.08); opacity.AddPoint(420, 0.18); opacity.AddPoint(900, 0.32)
            elif "vessel ultra" in p:
                color.AddRGBPoint(-200, 0, 0, 0); color.AddRGBPoint(140, 0.22, 0.0, 0.02); color.AddRGBPoint(240, 0.95, 0.0, 0.02); color.AddRGBPoint(500, 1.0, 0.45, 0.08); color.AddRGBPoint(1200, 1.0, 0.92, 0.58)
                opacity.AddPoint(-200, 0.0); opacity.AddPoint(160, 0.0); opacity.AddPoint(230, 0.12); opacity.AddPoint(360, 0.48); opacity.AddPoint(700, 0.90); opacity.AddPoint(1200, 1.0)
            elif "tumor ultra" in p:
                color.AddRGBPoint(-1000, 0, 0, 0); color.AddRGBPoint(20, 0.40, 0.22, 0.42); color.AddRGBPoint(60, 0.72, 0.18, 1.0); color.AddRGBPoint(110, 1.0, 0.25, 0.86); color.AddRGBPoint(350, 0.95, 0.80, 0.62); color.AddRGBPoint(1200, 1.0, 0.96, 0.84)
                opacity.AddPoint(-1000, 0.0); opacity.AddPoint(10, 0.0); opacity.AddPoint(45, 0.10); opacity.AddPoint(80, 0.36); opacity.AddPoint(140, 0.16); opacity.AddPoint(500, 0.20); opacity.AddPoint(1200, 0.46)
            elif "bone color" in p:
                color.AddRGBPoint(-500, 0, 0, 0); color.AddRGBPoint(180, 0.40, 0.18, 0.08); color.AddRGBPoint(380, 0.95, 0.65, 0.35); color.AddRGBPoint(1200, 1.0, 0.98, 0.88)
                opacity.AddPoint(-500, 0); opacity.AddPoint(220, 0.015); opacity.AddPoint(420, 0.30); opacity.AddPoint(1200, 0.90)
            else:
                color.AddRGBPoint(-500, 0, 0, 0); color.AddRGBPoint(250, 0.75, 0.55, 0.40); color.AddRGBPoint(1200, 1.0, 0.98, 0.90)
                opacity.AddPoint(-500, 0); opacity.AddPoint(250, 0.02); opacity.AddPoint(450, 0.25); opacity.AddPoint(1200, 0.85)

            # v7.4 Cinematic/Fidelity 3D: use dedicated clinical cinematic
            # presets when available, otherwise keep the previous stable fallback.
            try:
                prop = build_cinematic_property(preset) if is_cinematic_preset(preset) else None
            except Exception:
                prop = None
            if prop is None:
                prop = vtk.vtkVolumeProperty(); prop.SetColor(color); prop.SetScalarOpacity(opacity); prop.ShadeOn(); prop.SetInterpolationTypeToLinear()
                try:
                    # Softer gradient-opacity ramp for non-cinematic fallback presets.
                    # This reduces wax/plastic shine while keeping bone and vessel edges crisp.
                    grad = vtk.vtkPiecewiseFunction(); grad.AddPoint(0, 0.0); grad.AddPoint(25, 0.025); grad.AddPoint(75, 0.12); grad.AddPoint(180, 0.46); grad.AddPoint(420, 0.78)
                    prop.SetGradientOpacity(grad)
                    prop.SetAmbient(0.18); prop.SetDiffuse(0.88); prop.SetSpecular(0.16); prop.SetSpecularPower(18.0)
                    if hasattr(prop, "SetUseGradientOpacity"):
                        prop.SetUseGradientOpacity(True)
                    try:
                        prop.SetScalarOpacityUnitDistance(0.55)
                    except Exception:
                        pass
                except Exception:
                    pass
            actor = vtk.vtkVolume(); actor.SetMapper(mapper); actor.SetProperty(prop)
            self._volume_mapper = mapper
            self._volume_property = prop
            self._volume_actor = actor
            self._volume_importer = importer
            self._inspect_controller = None
            self._renderer.RemoveAllViewProps(); self._renderer.AddVolume(actor); self._renderer.SetBackground(0.02, 0.06, 0.11); self._renderer.ResetCamera()
            self._show_vtk(); self._render_widget.GetRenderWindow().Render(); self._render_widget.Initialize()
            self._attach_deep3d_runtime(volume, spacing_zyx)
            try:
                self._inspect_controller = VolumeInspectController(actor, mapper, self._render_widget.GetRenderWindow().GetInteractor())
            except Exception:
                self._inspect_controller = None
            if self._distance_enabled:
                self.enable_distance_measurement(True)
            if self._clip_box_enabled:
                self.enable_clip_box(True)
            self._log_3d_event("SET_VOLUME", preset=preset, mapper=type(mapper).__name__, shape=volume.shape, spacing=spacing_zyx)
            self._status.setText(f"3D Volume Rendering: {preset} | shape={volume.shape} | spacing z/y/x=({sz:.3g}, {sy:.3g}, {sx:.3g})")
        except Exception as exc:
            log.exception("3D render failed")
            self.set_mip_preview(volume_hu, spacing_zyx, "Volume failed → MIP")
            self._status.setText("Помилка 3D Volume, увімкнено безпечний MIP Preview: " + str(exc))


    def set_legacy_headface_volume(self, volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float]) -> None:
        """RC5 true Legacy 3D tab: old-style head/face visualization.

        This path intentionally avoids modern clipping/mask/ruler logic and uses a
        softer, less aggressive transfer function to preserve face, ears, nose and
        skull contours similarly to the older successful builds.
        """
        if not self._ensure_vtk() or self._renderer is None or self._render_widget is None:
            self.set_mip_preview(volume_hu, spacing_zyx, "Legacy 3D fallback")
            return
        try:
            import vtkmodules.all as vtk
            volume = np.asarray(volume_hu, dtype=np.float32)
            if volume.ndim != 3:
                raise ValueError("Volume must be 3D")
            z, y, x = volume.shape
            data = np.ascontiguousarray(volume.ravel(order="C"))
            importer = vtk.vtkImageImport(); importer.CopyImportVoidPointer(data.tobytes(), data.nbytes)
            importer.SetDataScalarTypeToFloat(); importer.SetNumberOfScalarComponents(1)
            importer.SetDataExtent(0, x-1, 0, y-1, 0, z-1); importer.SetWholeExtent(0, x-1, 0, y-1, 0, z-1)
            sz, sy, sx = spacing_zyx; importer.SetDataSpacing(float(sx), float(sy), float(sz)); importer.Update()
            # Legacy Fidelity mode: reproduce the older successful "Lung/Face" look.
            # Prefer the deterministic CPU fixed-point mapper because the old build used
            # softer volume accumulation than the newer aggressive SmartVolume/GPU path.
            try:
                mapper = vtk.vtkFixedPointVolumeRayCastMapper()
                mapper.SetInputConnection(importer.GetOutputPort())
                try:
                    mapper.SetSampleDistance(max(0.35, min(float(sx), float(sy), float(sz)) * 0.60))
                    mapper.SetImageSampleDistance(1.0)
                except Exception:
                    pass
                mapper_name = "vtkFixedPointVolumeRayCastMapper"
            except Exception:
                mapper = vtk.vtkSmartVolumeMapper(); mapper.SetInputConnection(importer.GetOutputPort()); mapper.SetBlendModeToComposite()
                try:
                    mapper.SetRequestedRenderModeToDefault(); mapper.SetSampleDistance(max(0.40, min(float(sx), float(sy), float(sz)) * 0.65))
                except Exception:
                    pass
                mapper_name = type(mapper).__name__
            color = vtk.vtkColorTransferFunction(); op = vtk.vtkPiecewiseFunction(); grad = vtk.vtkPiecewiseFunction()
            # Old Lung/Face Fidelity: low HU starts the translucent skin/soft-tissue
            # envelope; bone stays warm and dense. This preserves ears, nose and face
            # contours instead of making a skull-only or red-tinted model.
            for hu, r, g, b in [
                (-1000, 0.00, 0.00, 0.00),
                (-720,  0.08, 0.13, 0.20),
                (-520,  0.20, 0.30, 0.42),
                (-320,  0.42, 0.34, 0.30),
                (-160,  0.62, 0.42, 0.34),
                (-60,   0.78, 0.52, 0.42),
                (35,    0.88, 0.58, 0.47),
                (95,    0.94, 0.64, 0.50),
                (220,   0.98, 0.72, 0.54),
                (520,   1.00, 0.84, 0.62),
                (900,   1.00, 0.92, 0.72),
                (1350,  1.00, 0.98, 0.86),
            ]:
                color.AddRGBPoint(float(hu), float(r), float(g), float(b))
            for hu, a in [
                (-1000, 0.000),
                (-760,  0.000),
                (-620,  0.010),
                (-500,  0.030),
                (-340,  0.055),
                (-180,  0.082),
                (-70,   0.108),
                (20,    0.132),
                (90,    0.155),
                (180,   0.205),
                (320,   0.285),
                (620,   0.520),
                (1100,  0.780),
                (1600,  0.920),
            ]:
                op.AddPoint(float(hu), float(a))
            for g, a in [(0,0.0),(18,0.02),(45,0.10),(90,0.24),(180,0.48),(420,0.72)]:
                grad.AddPoint(float(g), float(a))
            prop = vtk.vtkVolumeProperty(); prop.SetColor(color); prop.SetScalarOpacity(op); prop.SetGradientOpacity(grad)
            prop.SetInterpolationTypeToLinear(); prop.ShadeOn(); prop.SetAmbient(0.34); prop.SetDiffuse(0.74); prop.SetSpecular(0.18); prop.SetSpecularPower(22)
            try:
                prop.SetScalarOpacityUnitDistance(0.62)
            except Exception:
                pass
            try:
                if hasattr(prop, "SetUseGradientOpacity"):
                    prop.SetUseGradientOpacity(True)
            except Exception:
                pass
            actor = vtk.vtkVolume(); actor.SetMapper(mapper); actor.SetProperty(prop)
            self._renderer.RemoveAllViewProps(); self._renderer.AddVolume(actor); self._renderer.SetBackground(0.015, 0.045, 0.085); self._renderer.ResetCamera()
            self._volume_mapper = mapper; self._volume_property = prop; self._volume_actor = actor; self._volume_importer = importer; self._inspect_controller = None
            self._show_vtk(); self._render_widget.GetRenderWindow().Render(); self._render_widget.Initialize()
            self._log_3d_event("SET_LEGACY_VOLUME", mapper=mapper_name if "mapper_name" in locals() else type(mapper).__name__, shape=volume.shape, spacing=spacing_zyx)
            self._status.setText(f"Legacy 3D Fidelity old Lung/Face | mapper={mapper_name if 'mapper_name' in locals() else type(mapper).__name__} | shape={volume.shape} | spacing z/y/x=({sz:.3g}, {sy:.3g}, {sx:.3g})")
        except Exception as exc:
            log.exception("Legacy 3D render failed")
            self.set_mip_preview(volume_hu, spacing_zyx, "Legacy failed → MIP")
            self._status.setText("Legacy 3D error: " + str(exc))


    def set_hemorrhage_focus_volume(self, volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], mask: np.ndarray, metrics: dict | None = None) -> bool:
        """Dedicated hemorrhage visualization: transparent head/skull + solid red hematoma mesh.

        This avoids the old mistake where the whole soft-tissue volume was tinted red.
        The hemorrhage mask is rendered as a separate 3D object with an outline and
        an always-visible measurement label.
        """
        if not self._ensure_vtk() or self._renderer is None or self._render_widget is None:
            self.set_mip_preview(volume_hu, spacing_zyx, "Hemorrhage focus fallback")
            return False
        try:
            import vtkmodules.all as vtk
            volume = np.asarray(volume_hu, dtype=np.float32)
            hem_mask = np.asarray(mask).astype(np.uint8)
            if volume.ndim != 3 or hem_mask.shape != volume.shape:
                raise ValueError(f"Volume/mask mismatch: volume={volume.shape}, mask={hem_mask.shape}")
            z, y, x = volume.shape
            sz, sy, sx = tuple(float(v) for v in spacing_zyx)

            self._renderer.RemoveAllViewProps()

            # Base CT volume: low opacity brain/skin + translucent skull so the red mask is visible inside.
            data = np.ascontiguousarray(volume.ravel(order="C"))
            importer = vtk.vtkImageImport(); importer.CopyImportVoidPointer(data.tobytes(), data.nbytes)
            importer.SetDataScalarTypeToFloat(); importer.SetNumberOfScalarComponents(1)
            importer.SetDataExtent(0, x - 1, 0, y - 1, 0, z - 1); importer.SetWholeExtent(0, x - 1, 0, y - 1, 0, z - 1)
            importer.SetDataSpacing(sx, sy, sz); importer.Update()
            mapper = vtk.vtkSmartVolumeMapper(); mapper.SetInputConnection(importer.GetOutputPort()); mapper.SetBlendModeToComposite()
            try:
                mapper.SetRequestedRenderModeToGPU(); mapper.SetSampleDistance(max(0.55, min(sx, sy, sz) * 0.9))
            except Exception:
                pass
            color = vtk.vtkColorTransferFunction(); opacity = vtk.vtkPiecewiseFunction(); grad = vtk.vtkPiecewiseFunction()
            for hu, r, g, b in [(-1000,0,0,0),(0,0.25,0.22,0.20),(35,0.86,0.62,0.55),(90,0.96,0.72,0.62),(180,0.85,0.78,0.66),(450,0.96,0.88,0.68),(1200,1.0,0.98,0.88)]:
                color.AddRGBPoint(float(hu), float(r), float(g), float(b))
            for hu, a in [(-1000,0.0),(-100,0.0),(0,0.012),(35,0.028),(90,0.035),(180,0.018),(420,0.055),(900,0.13),(1400,0.22)]:
                opacity.AddPoint(float(hu), float(a))
            for g, a in [(0,0.0),(50,0.05),(120,0.18),(350,0.45)]:
                grad.AddPoint(float(g), float(a))
            prop = vtk.vtkVolumeProperty(); prop.SetColor(color); prop.SetScalarOpacity(opacity); prop.SetGradientOpacity(grad)
            prop.ShadeOn(); prop.SetInterpolationTypeToLinear(); prop.SetAmbient(0.36); prop.SetDiffuse(0.72); prop.SetSpecular(0.12); prop.SetSpecularPower(16)
            actor = vtk.vtkVolume(); actor.SetMapper(mapper); actor.SetProperty(prop)
            self._renderer.AddVolume(actor)
            self._volume_mapper = mapper; self._volume_property = prop; self._volume_actor = actor; self._volume_importer = importer

            # Hemorrhage mesh from binary mask, independent of CT transfer function.
            mdata = np.ascontiguousarray(hem_mask.ravel(order="C"))
            mimport = vtk.vtkImageImport(); mimport.CopyImportVoidPointer(mdata.tobytes(), mdata.nbytes)
            mimport.SetDataScalarTypeToUnsignedChar(); mimport.SetNumberOfScalarComponents(1)
            mimport.SetDataExtent(0, x - 1, 0, y - 1, 0, z - 1); mimport.SetWholeExtent(0, x - 1, 0, y - 1, 0, z - 1)
            mimport.SetDataSpacing(sx, sy, sz); mimport.Update()
            try:
                contour = vtk.vtkDiscreteFlyingEdges3D()
            except Exception:
                contour = vtk.vtkDiscreteMarchingCubes()
            contour.SetInputConnection(mimport.GetOutputPort()); contour.SetValue(0, 1); contour.Update()
            smooth = vtk.vtkWindowedSincPolyDataFilter(); smooth.SetInputConnection(contour.GetOutputPort())
            smooth.SetNumberOfIterations(18); smooth.BoundarySmoothingOff(); smooth.FeatureEdgeSmoothingOff(); smooth.SetPassBand(0.12); smooth.NonManifoldSmoothingOn(); smooth.NormalizeCoordinatesOn(); smooth.Update()
            normals = vtk.vtkPolyDataNormals(); normals.SetInputConnection(smooth.GetOutputPort()); normals.ConsistencyOn(); normals.AutoOrientNormalsOn(); normals.Update()
            hmapper = vtk.vtkPolyDataMapper(); hmapper.SetInputConnection(normals.GetOutputPort()); hmapper.ScalarVisibilityOff()
            hactor = vtk.vtkActor(); hactor.SetMapper(hmapper)
            hactor.GetProperty().SetColor(1.0, 0.02, 0.0); hactor.GetProperty().SetOpacity(1.0)
            hactor.GetProperty().SetAmbient(0.30); hactor.GetProperty().SetDiffuse(0.72); hactor.GetProperty().SetSpecular(0.55); hactor.GetProperty().SetSpecularPower(36)
            self._renderer.AddActor(hactor)
            self._organ_mesh_actors["__classic_hemorrhage_focus__"] = hactor

            outline = vtk.vtkOutlineFilter(); outline.SetInputConnection(mimport.GetOutputPort())
            omapper = vtk.vtkPolyDataMapper(); omapper.SetInputConnection(outline.GetOutputPort())
            oactor = vtk.vtkActor(); oactor.SetMapper(omapper); oactor.GetProperty().SetColor(1.0, 0.92, 0.05); oactor.GetProperty().SetLineWidth(3.0)
            self._renderer.AddActor(oactor)

            txt = vtk.vtkTextActor()
            if metrics:
                vol = metrics.get("volume_ml", 0)
                dims = metrics.get("diameters_mm_zyx") or metrics.get("bbox_mm") or [0,0,0]
                maxd = metrics.get("max_dimension_mm", max(dims) if dims else 0)
                comps = metrics.get("component_count", 0)
                txt.SetInput(f"Hemorrhage: {float(vol):.2f} ml\nSize Z/Y/X: {float(dims[0]):.1f} × {float(dims[1]):.1f} × {float(dims[2]):.1f} mm\nMax: {float(maxd):.1f} mm | components: {int(comps)}")
            else:
                txt.SetInput("Hemorrhage focus")
            txt.SetDisplayPosition(22, 72)
            tp = txt.GetTextProperty(); tp.SetColor(1.0, 0.95, 0.25); tp.SetFontSize(24); tp.BoldOn(); tp.SetBackgroundColor(0, 0, 0); tp.SetBackgroundOpacity(0.55)
            self._renderer.AddActor2D(txt)

            self._renderer.SetBackground(0.015, 0.045, 0.085)
            self._renderer.ResetCamera(); self._renderer.ResetCameraClippingRange()
            self._show_vtk(); self._render_widget.GetRenderWindow().Render(); self._render_widget.Initialize()
            self._status.setText("Hemorrhage Focus 3D: червона маска окремим об'єктом, жовтий bbox, прозорий skull/brain, розміри на екрані.")
            self._log_3d_event("SET_HEMORRHAGE_FOCUS", voxels=int(np.count_nonzero(hem_mask)), metrics=metrics or {})
            return True
        except Exception as exc:
            log.exception("Hemorrhage focus render failed")
            self._status.setText("Hemorrhage Focus 3D error: " + str(exc))
            return False

    def add_organ_mesh(self, mesh_path: str, name: str | None = None, color=(0.75, 0.75, 0.75), opacity: float = 0.82) -> bool:
        """Load STL/PLY/OBJ organ mesh into the current VTK scene.

        This is intentionally VTK-native, not PyVista-dependent, so the EXE can
        run on hospital PCs where optional PyVista is not installed.
        """
        if not self._ensure_vtk() or self._renderer is None or self._render_widget is None:
            self._status.setText("Organ mesh viewer requires VTK; залишено safe fallback без 3D-моделі.")
            return False
        try:
            from pathlib import Path
            import vtkmodules.all as vtk
            path = Path(mesh_path)
            ext = path.suffix.lower()
            if ext == ".stl":
                reader = vtk.vtkSTLReader()
            elif ext == ".ply":
                reader = vtk.vtkPLYReader()
            elif ext == ".obj":
                reader = vtk.vtkOBJReader()
            else:
                self._status.setText("Непідтриманий формат органної моделі: " + ext)
                return False
            reader.SetFileName(str(path)); reader.Update()
            mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(reader.GetOutputPort()); mapper.ScalarVisibilityOff()
            actor = vtk.vtkActor(); actor.SetMapper(mapper)
            try:
                actor.GetProperty().SetColor(float(color[0]), float(color[1]), float(color[2]))
                actor.GetProperty().SetOpacity(float(opacity))
            except Exception:
                pass
            # Replace same file actor without clearing volume rendering.
            old = self._organ_mesh_actors.get(str(path))
            if old is not None:
                try: self._renderer.RemoveActor(old)
                except Exception: pass
            self._renderer.AddActor(actor)
            self._organ_mesh_actors[str(path)] = actor
            self._show_vtk()
            try:
                self._renderer.ResetCameraClippingRange()
                self._render_widget.GetRenderWindow().Render()
                self._render_widget.Initialize()
            except Exception:
                pass
            organ_name = name or path.stem
            self._status.setText(f"Organ 3D loaded: {organ_name} ({path.suffix.upper().lstrip('.')})")
            return True
        except Exception as exc:
            log.exception("Organ mesh load failed")
            self._status.setText("Не вдалося завантажити 3D-модель органа: " + str(exc))
            return False

    def set_organ_mesh_visible(self, mesh_path: str, visible: bool) -> bool:
        actor = self._organ_mesh_actors.get(str(mesh_path))
        if actor is None:
            return False
        try:
            actor.SetVisibility(bool(visible))
            if self._render_widget is not None:
                self._render_widget.GetRenderWindow().Render()
            return True
        except Exception:
            return False

    def clear_organ_meshes(self) -> None:
        if self._renderer is not None:
            for actor in list(self._organ_mesh_actors.values()):
                try: self._renderer.RemoveActor(actor)
                except Exception: pass
        self._organ_mesh_actors.clear()
        try:
            if self._render_widget is not None:
                self._render_widget.GetRenderWindow().Render()
        except Exception:
            pass
