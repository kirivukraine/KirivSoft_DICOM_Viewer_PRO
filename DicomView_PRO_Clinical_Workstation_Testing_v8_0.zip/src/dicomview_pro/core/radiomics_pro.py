from __future__ import annotations

"""Small safe radiomics facade used by Lite/PRO tests and reports.

This is intentionally not pyradiomics.  It returns deterministic numpy-only
statistics so the desktop viewer can generate basic measurement reports without
heavy dependencies.
"""

from dataclasses import dataclass
from typing import Any
import numpy as np


@dataclass(frozen=True)
class RadiomicsPROResult:
    ok: bool
    features: dict[str, Any]
    engine: str = "numpy_safe"
    message: str = "Basic deterministic radiomics only"


def _entropy(vals: np.ndarray, bins: int = 32) -> float:
    if vals.size == 0:
        return 0.0
    hist, _ = np.histogram(vals.astype(np.float32), bins=bins)
    total = float(hist.sum())
    if total <= 0:
        return 0.0
    p = hist.astype(np.float64) / total
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def analyze_roi_or_mask(volume_hu, mask, spacing=(1.0, 1.0, 1.0)) -> RadiomicsPROResult:
    vol = np.asarray(volume_hu, dtype=np.float32)
    m = np.asarray(mask).astype(bool)
    vals = vol[m] if vol.shape == m.shape else np.asarray([], dtype=np.float32)
    sp = tuple(float(v) for v in (spacing or (1.0, 1.0, 1.0)))
    if len(sp) < 3:
        sp = (1.0, 1.0, 1.0)
    voxel_mm3 = abs(float(sp[0]) * float(sp[1]) * float(sp[2]))
    count = int(vals.size)
    features: dict[str, Any] = {
        "count": count,
        "voxel_volume_mm3": voxel_mm3,
        "volume_mm3": float(count * voxel_mm3),
        "volume_ml": float(count * voxel_mm3 / 1000.0),
        "histogram_entropy": _entropy(vals),
    }
    if count:
        features.update({
            "mean_hu": float(np.mean(vals)),
            "median_hu": float(np.median(vals)),
            "min_hu": float(np.min(vals)),
            "max_hu": float(np.max(vals)),
            "std_hu": float(np.std(vals)),
            "p10_hu": float(np.percentile(vals, 10)),
            "p90_hu": float(np.percentile(vals, 90)),
        })
    else:
        features.update({"mean_hu": 0.0, "median_hu": 0.0, "min_hu": 0.0, "max_hu": 0.0, "std_hu": 0.0, "p10_hu": 0.0, "p90_hu": 0.0})
    return RadiomicsPROResult(True, features)
