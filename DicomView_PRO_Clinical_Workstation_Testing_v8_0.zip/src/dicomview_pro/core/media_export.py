from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable


@dataclass
class MediaExportResult:
    ok: bool
    target: str
    files_written: int
    bytes_written: int
    manifest_path: str
    zip_path: str = ""
    message: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_name(text: str, default: str = "DicomView_Export") -> str:
    text = (text or default).strip()
    cleaned = "".join(c if c.isalnum() or c in " ._-" else "_" for c in text).strip(" ._")
    return cleaned or default


def build_export_manifest(files: Iterable[str], *, label: str = "DicomView PRO export") -> dict:
    items = []
    total = 0
    for raw in files:
        p = Path(raw)
        if not p.exists() or not p.is_file():
            continue
        size = p.stat().st_size
        total += size
        items.append({
            "name": p.name,
            "source": str(p),
            "size_bytes": size,
            "sha256": _sha256(p),
        })
    return {
        "product": "DicomView PRO",
        "author": "Іван Кіранчук",
        "company": "KirivSoft",
        "label": label,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "file_count": len(items),
        "total_bytes": total,
        "files": items,
    }


def export_series_to_folder(files: Iterable[str], target_dir: str | Path, *, label: str = "DicomView PRO export", make_zip: bool = False) -> MediaExportResult:
    target = Path(target_dir)
    target.mkdir(parents=True, exist_ok=True)
    dicom_dir = target / "DICOM"
    dicom_dir.mkdir(parents=True, exist_ok=True)

    manifest = build_export_manifest(files, label=label)
    written = 0
    bytes_written = 0
    for item in manifest["files"]:
        src = Path(item["source"])
        dst = dicom_dir / item["name"]
        # Avoid accidental overwrite when duplicate filenames exist.
        if dst.exists():
            stem, suffix = dst.stem, dst.suffix
            idx = 1
            while dst.exists():
                dst = dicom_dir / f"{stem}_{idx:03d}{suffix}"
                idx += 1
        shutil.copy2(src, dst)
        item["exported_name"] = str(dst.relative_to(target))
        written += 1
        bytes_written += dst.stat().st_size

    manifest_path = target / "KIRIVSOFT_DICOM_EXPORT_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    readme = target / "README_КИРИВСОФТ_DICOM_EXPORT.txt"
    readme.write_text(
        "DicomView PRO — експорт DICOM-дослідження\n"
        "Автор: Іван Кіранчук, компанія KirivSoft\n\n"
        "Папка DICOM містить копії файлів серії.\n"
        "KIRIVSOFT_DICOM_EXPORT_MANIFEST.json містить SHA-256 контрольні суми.\n"
        "Цю папку можна скопіювати на USB або записати на CD/DVD як data-disc.\n",
        encoding="utf-8",
    )

    zip_path = ""
    if make_zip:
        zp = target.with_suffix(".zip")
        with zipfile.ZipFile(zp, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for p in target.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(target))
        zip_path = str(zp)

    return MediaExportResult(True, str(target), written, bytes_written, str(manifest_path), zip_path, "Експорт завершено")


def export_series_to_usb(files: Iterable[str], usb_root: str | Path, *, study_label: str = "DicomView_Study") -> MediaExportResult:
    root = Path(usb_root)
    if not root.exists():
        raise FileNotFoundError(f"Носій не знайдено: {root}")
    folder = root / _safe_name(study_label)
    if folder.exists():
        suffix = datetime.now().strftime("_%Y%m%d_%H%M%S")
        folder = root / (_safe_name(study_label) + suffix)
    return export_series_to_folder(files, folder, label="USB export", make_zip=False)


def create_cd_dvd_ready_folder(files: Iterable[str], target_dir: str | Path, *, study_label: str = "DicomView_CD_DVD") -> MediaExportResult:
    target = Path(target_dir) / _safe_name(study_label)
    if target.exists():
        target = Path(str(target) + datetime.now().strftime("_%Y%m%d_%H%M%S"))
    return export_series_to_folder(files, target, label="CD/DVD ready export", make_zip=True)


def _write_dicomdir_with_pydicom(files: list[str], target: Path) -> tuple[bool, str]:
    """Best-effort DICOMDIR creation using pydicom FileSet when available.

    This is intentionally optional: if pydicom/fileset cannot create the
    directory for a vendor-specific dataset, the export still remains usable
    through KIRIVSOFT_DICOM_INDEX.json and the copied DICOM files.
    """
    try:
        try:
            from pydicom.fileset import FileSet  # type: ignore
        except ImportError:
            version = getattr(__import__("pydicom"), "__version__", "unknown")
            return False, f"DICOMDIR fallback: pydicom.fileset недоступний у pydicom {version}. Потрібен pydicom >= 2.3"
        fs = FileSet()
        for raw in files:
            try:
                fs.add(str(raw))
            except Exception:
                continue
        if len(fs) == 0:
            return False, "FileSet порожній: pydicom не зміг додати файли"
        fs.write(str(target))
        return (target / "DICOMDIR").exists(), "DICOMDIR створено через pydicom.fileset"
    except Exception as exc:
        return False, f"DICOMDIR fallback: {exc}"


def create_dicomdir_ready_folder(files: Iterable[str], target_dir: str | Path, *, study_label: str = "DicomView_DICOMDIR", include_viewer_launcher: bool = True, make_zip: bool = True) -> MediaExportResult:
    """Create a CD/DVD/USB-ready folder with DICOM files, manifest and best-effort DICOMDIR.

    The exported folder is safe even when formal DICOMDIR generation fails: it
    still contains a JSON index, checksums and all copied files in DICOM/.
    """
    target = Path(target_dir) / _safe_name(study_label)
    if target.exists():
        target = Path(str(target) + datetime.now().strftime("_%Y%m%d_%H%M%S"))

    res = export_series_to_folder(files, target, label="DICOMDIR / CD-DVD-USB ready export", make_zip=False)

    copied = sorted(str(p) for p in (target / "DICOM").glob("*"))
    dicomdir_ok, dicomdir_message = _write_dicomdir_with_pydicom(copied, target)

    index = {
        "product": "DicomView PRO",
        "author": "Іван Кіранчук",
        "company": "KirivSoft",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "dicomdir_created": dicomdir_ok,
        "dicomdir_message": dicomdir_message,
        "file_count": len(copied),
        "files": [str(Path(p).relative_to(target)) for p in copied],
        "usage": "Запишіть усю цю папку на CD/DVD або скопіюйте на USB. Якщо DICOMDIR не створено, відкривайте папку DICOM у DicomView PRO.",
    }
    (target / "KIRIVSOFT_DICOM_INDEX.json").write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")

    if include_viewer_launcher:
        (target / "START_DicomView_PRO.bat").write_text(
            "@echo off\r\n"
            "echo DicomView PRO portable media launcher\r\n"
            "echo.\r\n"
            "if exist DicomView_PRO_Portable\\DicomView_PRO.exe (\r\n"
            "  start "" DicomView_PRO_Portable\\DicomView_PRO.exe DICOM\r\n"
            ") else (\r\n"
            "  echo Portable viewer folder not found. Open the DICOM folder manually in DicomView PRO.\r\n"
            "  pause\r\n"
            ")\r\n",
            encoding="utf-8",
        )
        (target / "autorun.inf").write_text(
            "[AutoRun]\r\n"
            "open=START_DicomView_PRO.bat\r\n"
            "label=DicomView PRO DICOM Media\r\n"
            "icon=DicomView_PRO_Portable\\DicomView_PRO.exe\r\n",
            encoding="ascii",
        )
        (target / "DicomView_PRO_Portable_README.txt").write_text(
            "За бажанням скопіюйте сюди папку портативної збірки та перейменуйте її у DicomView_PRO_Portable.\n"
            "Тоді START_DicomView_PRO.bat відкриватиме дослідження прямо з носія.\n"
            "Windows може ігнорувати autorun.inf з міркувань безпеки — запускайте START_DicomView_PRO.bat вручну.\n",
            encoding="utf-8",
        )

    zip_path = ""
    if make_zip:
        zp = target.with_suffix(".zip")
        with zipfile.ZipFile(zp, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for p in target.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(target))
        zip_path = str(zp)

    # Refresh result fields
    res.zip_path = zip_path
    res.message = "DICOMDIR-ready export created" if dicomdir_ok else "DICOMDIR fallback export created"
    return res


def list_windows_drives() -> list[str]:
    """Return existing drive roots on Windows. Kept simple to avoid extra dependencies."""
    if os.name != "nt":
        return []
    drives = []
    for code in range(ord("A"), ord("Z") + 1):
        root = f"{chr(code)}:/"
        if Path(root).exists():
            drives.append(root)
    return drives
