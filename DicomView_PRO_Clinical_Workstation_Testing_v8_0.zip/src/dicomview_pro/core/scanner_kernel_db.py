from __future__ import annotations

"""Vendor/kernel knowledge base for deterministic CT visualization tuning.

This module contains no AI.  It classifies scanner reconstruction kernels using
DICOM metadata (Manufacturer + ConvolutionKernel) and returns conservative,
display-only recommendations for denoising/sharpening, WL/WW and 3D presets.
The raw HU volume used for measurements is never modified by this module.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Mapping
import json
import re


@dataclass(frozen=True)
class KernelProfile:
    vendor: str = "UNKNOWN"
    kernel: str = ""
    matched_key: str = ""
    category: str = "unknown"  # soft / medium / sharp / ultra_sharp / unknown
    sharpness: int = 5          # 1..10 display sharpness estimate
    noise: int = 5              # 1..10 display noise estimate
    denoise_strength: float = 0.5
    default_sharpen: str = "brain_fidelity_pro"
    window_center: float | None = None
    window_width: float | None = None
    recommended_3d_preset: str | None = None
    note_ua: str = "Невідомий kernel; використано безпечний середній профіль."

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# Practical seed database.  It is intentionally conservative and can be extended
# from real hospital DICOMs without changing code via load_external_json().
KERNEL_DB: dict[str, dict[str, dict[str, Any]]] = {
    "SIEMENS": {
        "B20": {"category":"soft", "sharpness":2, "noise":2, "denoise_strength":0.20, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Soft Tissue", "note_ua":"дуже м'яке тіло/живіт"},
        "B30": {"category":"soft", "sharpness":3, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"м'яке стандартне"},
        "B31": {"category":"soft", "sharpness":3, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"м'яке стандартне"},
        "B40": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"універсальне середнє"},
        "B50": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Bone", "note_ua":"гостре"},
        "B60": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":500, "window_width":2000, "recommended_3d_preset":"Classic Bone", "note_ua":"дуже гостре/кістка"},
        "B70": {"category":"ultra_sharp", "sharpness":9, "noise":9, "denoise_strength":0.90, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"ультра-гостре кісткове"},
        "H30": {"category":"soft", "sharpness":3, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_bilateral_pro", "window_center":35, "window_width":100, "recommended_3d_preset":"Classic Hospital", "note_ua":"мозок, м'яке"},
        "H40": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":35, "window_width":90, "recommended_3d_preset":"Classic Hospital", "note_ua":"мозок, стандарт"},
        "H60": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":35, "window_width":90, "recommended_3d_preset":"Classic Bone", "note_ua":"голова/кістка, гостре"},
        "HR64": {"category":"ultra_sharp", "sharpness":10, "noise":10, "denoise_strength":0.95, "default_sharpen":"itk_anisotropic_strong", "window_center":35, "window_width":100, "recommended_3d_preset":"Classic Hospital", "note_ua":"високороздільний мозок"},
        "I30": {"category":"soft", "sharpness":3, "noise":2, "denoise_strength":0.20, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"ітеративне м'яке"},
        "I40": {"category":"medium", "sharpness":5, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"ітеративне стандартне"},
        "BR40": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":500, "window_width":2000, "recommended_3d_preset":"Classic Bone", "note_ua":"кісткове стандартне Force"},
        "UR77": {"category":"ultra_sharp", "sharpness":9, "noise":8, "denoise_strength":0.85, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"ультра-висока роздільність"},
    },
    "GE": {
        "STANDARD": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"стандартне"},
        "SOFT": {"category":"soft", "sharpness":3, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Soft Tissue", "note_ua":"м'яке"},
        "DETAIL": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Hospital", "note_ua":"детальне"},
        "BONE PLUS": {"category":"ultra_sharp", "sharpness":9, "noise":9, "denoise_strength":0.90, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"дуже гостре кісткове"},
        "BONE": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":500, "window_width":2000, "recommended_3d_preset":"Classic Bone", "note_ua":"кісткове"},
        "LUNG": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":-600, "window_width":1500, "recommended_3d_preset":"Classic Lung Fidelity", "note_ua":"легеневе"},
        "EDGE": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Bone", "note_ua":"гостре/edge"},
        "BRAIN": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":35, "window_width":90, "recommended_3d_preset":"Classic Hospital", "note_ua":"голова/мозок"},
    },
    "PHILIPS": {
        "A": {"category":"soft", "sharpness":2, "noise":2, "denoise_strength":0.20, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Soft Tissue", "note_ua":"дуже м'яке"},
        "B": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"стандартне"},
        "C": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Bone", "note_ua":"гостре"},
        "D": {"category":"ultra_sharp", "sharpness":9, "noise":9, "denoise_strength":0.90, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"кісткове/дуже гостре"},
        "L": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":-600, "window_width":1500, "recommended_3d_preset":"Classic Lung Fidelity", "note_ua":"легеневе"},
    },
    "CANON": {
        "FC05": {"category":"soft", "sharpness":2, "noise":2, "denoise_strength":0.20, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Soft Tissue", "note_ua":"дуже м'яке"},
        "FC08": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"стандартне"},
        "FC13": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Bone", "note_ua":"гостре"},
        "FC30": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":500, "window_width":2000, "recommended_3d_preset":"Classic Bone", "note_ua":"кісткове"},
        "FC50": {"category":"ultra_sharp", "sharpness":9, "noise":9, "denoise_strength":0.90, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"кісткове високої роздільності"},
        "FC64": {"category":"ultra_sharp", "sharpness":10, "noise":10, "denoise_strength":1.00, "default_sharpen":"itk_anisotropic_strong", "window_center":500, "window_width":2000, "recommended_3d_preset":"Trauma Cinematic", "note_ua":"надвисока роздільність"},
    },
    "TOSHIBA": {},
    "HITACHI": {
        "SOFT": {"category":"soft", "sharpness":3, "noise":3, "denoise_strength":0.30, "default_sharpen":"brain_bilateral_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Soft Tissue", "note_ua":"м'яке"},
        "STANDARD": {"category":"medium", "sharpness":5, "noise":5, "denoise_strength":0.50, "default_sharpen":"brain_fidelity_pro", "window_center":40, "window_width":400, "recommended_3d_preset":"Classic Hospital", "note_ua":"стандартне"},
        "SHARP": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":50, "window_width":350, "recommended_3d_preset":"Classic Bone", "note_ua":"гостре"},
        "BONE": {"category":"sharp", "sharpness":8, "noise":8, "denoise_strength":0.80, "default_sharpen":"brain_fidelity_ultra", "window_center":500, "window_width":2000, "recommended_3d_preset":"Classic Bone", "note_ua":"кісткове"},
        "LUNG": {"category":"sharp", "sharpness":7, "noise":7, "denoise_strength":0.70, "default_sharpen":"brain_fidelity_ultra", "window_center":-600, "window_width":1500, "recommended_3d_preset":"Classic Lung Fidelity", "note_ua":"легеневе"},
    },
}
KERNEL_DB["TOSHIBA"] = KERNEL_DB["CANON"]


def normalize_text(value: Any) -> str:
    text = str(value or "").strip().upper()
    text = text.replace("TOSHIBA", "CANON") if "CANON" not in text else text
    return re.sub(r"[^A-Z0-9]+", "", text)


def detect_vendor(manufacturer: str, model: str = "") -> str:
    text = f"{manufacturer} {model}".upper()
    if "SIEMENS" in text: return "SIEMENS"
    if "GE" in text or "GENERAL ELECTRIC" in text: return "GE"
    if "PHILIPS" in text: return "PHILIPS"
    if "CANON" in text or "TOSHIBA" in text: return "CANON"
    if "HITACHI" in text or "FUJIFILM" in text or "FUJI" in text: return "HITACHI" if "HITACHI" in text else "FUJI"
    return "UNKNOWN"


def _profile_from_dict(vendor: str, kernel: str, matched_key: str, data: Mapping[str, Any]) -> KernelProfile:
    return KernelProfile(
        vendor=vendor,
        kernel=str(kernel or ""),
        matched_key=matched_key,
        category=str(data.get("category", "unknown")),
        sharpness=int(data.get("sharpness", 5) or 5),
        noise=int(data.get("noise", 5) or 5),
        denoise_strength=float(data.get("denoise_strength", 0.5) or 0.5),
        default_sharpen=str(data.get("default_sharpen", "brain_fidelity_pro")),
        window_center=None if data.get("window_center") is None else float(data.get("window_center")),
        window_width=None if data.get("window_width") is None else float(data.get("window_width")),
        recommended_3d_preset=None if data.get("recommended_3d_preset") is None else str(data.get("recommended_3d_preset")),
        note_ua=str(data.get("note_ua", "")),
    )


class ScannerKernelDB:
    def __init__(self, db: Mapping[str, Mapping[str, Mapping[str, Any]]] | None = None) -> None:
        self.db: dict[str, dict[str, dict[str, Any]]] = {
            str(v).upper(): {str(k).upper(): dict(val) for k, val in kernels.items()}
            for v, kernels in (db or KERNEL_DB).items()
        }

    def get_kernel_profile(self, manufacturer: str, kernel: str, model: str = "") -> KernelProfile:
        vendor = detect_vendor(manufacturer, model)
        vendor_db = self.db.get(vendor, {})
        clean = normalize_text(kernel)
        if not vendor_db:
            return KernelProfile(vendor=vendor, kernel=str(kernel or ""))
        # longest keys first, so BONEPLUS beats BONE and FC05 beats F.
        for key, data in sorted(vendor_db.items(), key=lambda kv: len(normalize_text(kv[0])), reverse=True):
            nk = normalize_text(key)
            if clean == nk or clean.startswith(nk) or nk in clean:
                return _profile_from_dict(vendor, str(kernel or ""), key, data)
        return KernelProfile(vendor=vendor, kernel=str(kernel or ""), category="medium", note_ua="Kernel не знайдено в базі; використано середній безпечний профіль.")

    def merge_external_json(self, path: str | Path) -> None:
        p = Path(path)
        data = json.loads(p.read_text(encoding="utf-8"))
        for vendor, kernels in data.items():
            vd = self.db.setdefault(str(vendor).upper(), {})
            for key, profile in kernels.items():
                vd[str(key).upper()] = dict(profile)

    def save_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.db, ensure_ascii=False, indent=2), encoding="utf-8")


DEFAULT_KERNEL_DB = ScannerKernelDB()


def get_kernel_profile(manufacturer: str, kernel: str, model: str = "") -> KernelProfile:
    return DEFAULT_KERNEL_DB.get_kernel_profile(manufacturer, kernel, model)
