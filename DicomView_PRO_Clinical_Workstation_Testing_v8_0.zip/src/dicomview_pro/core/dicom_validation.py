from __future__ import annotations

"""Lightweight DICOM validation helpers.

The goal is not to reject every imperfect hospital disc.  The validator records
warnings and catches missing critical fields early, so the UI/log can explain
why a series may fail or have limited MPR/3D quality.
"""

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class DicomValidationResult:
    ok: bool
    errors: list[str]
    warnings: list[str]
    transfer_syntax: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_dataset(ds: Any, require_pixels: bool = True) -> DicomValidationResult:
    errors: list[str] = []
    warnings: list[str] = []
    ts = ""
    try:
        ts = str(getattr(getattr(ds, "file_meta", None), "TransferSyntaxUID", "") or "")
    except Exception:
        ts = ""
    if require_pixels and not hasattr(ds, "PixelData"):
        errors.append("Missing PixelData")
    for attr in ("Rows", "Columns"):
        try:
            if int(getattr(ds, attr, 0) or 0) <= 0:
                errors.append(f"Invalid {attr}")
        except Exception:
            errors.append(f"Invalid {attr}")
    if not getattr(ds, "PixelSpacing", None):
        warnings.append("Missing PixelSpacing; fallback spacing will be used")
    if not getattr(ds, "ImageOrientationPatient", None):
        warnings.append("Missing ImageOrientationPatient; non-axial MPR may be less accurate")
    if not getattr(ds, "ImagePositionPatient", None):
        warnings.append("Missing ImagePositionPatient; slice sorting may use InstanceNumber fallback")
    if ts and any(x in ts for x in ("1.2.840.10008.1.2.4.90", "1.2.840.10008.1.2.4.91", "1.2.840.10008.1.2.4.80", "1.2.840.10008.1.2.4.81")):
        warnings.append("Compressed JPEG2000/JPEG-LS TransferSyntax detected; decoder plugins may be required")
    return DicomValidationResult(ok=not errors, errors=errors, warnings=warnings, transfer_syntax=ts)
