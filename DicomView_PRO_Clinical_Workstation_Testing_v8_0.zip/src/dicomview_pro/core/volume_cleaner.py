from __future__ import annotations

from dataclasses import dataclass
from typing import Literal
from collections import deque
import os
import numpy as np

CleanMode = Literal["bone_largest", "body_table", "largest_component"]


@dataclass(frozen=True)
class CleanVolumeResult:
    ok: bool
    message: str
    cleaned_volume: np.ndarray
    mask: np.ndarray
    threshold_hu: float
    kept_components: int
    removed_components: int
    kept_voxels: int
    removed_voxels: int


def _label_components_numpy(mask: np.ndarray) -> tuple[np.ndarray, int]:
    """Small dependency-free 3D connected components fallback.

    This keeps AutoClean 3D clinically useful even in a portable/source
    environment where scipy is missing. It uses 26-neighbour connectivity to
    match the scipy path. It is slower than scipy, but it removes isolated
    table/plate/noise components instead of silently degrading to threshold-only
    cleanup.
    """
    m = np.asarray(mask, dtype=bool)
    labels = np.zeros(m.shape, dtype=np.int32)
    if not bool(m.any()):
        return labels, 0

    neighbours = [
        (dz, dy, dx)
        for dz in (-1, 0, 1)
        for dy in (-1, 0, 1)
        for dx in (-1, 0, 1)
        if not (dz == 0 and dy == 0 and dx == 0)
    ]
    zmax, ymax, xmax = m.shape
    label = 0

    # Iterate only over foreground candidates. Each candidate is either already
    # labelled or starts a new flood fill.
    for z, y, x in np.argwhere(m):
        z = int(z); y = int(y); x = int(x)
        if labels[z, y, x] != 0:
            continue
        label += 1
        labels[z, y, x] = label
        q: deque[tuple[int, int, int]] = deque([(z, y, x)])
        while q:
            cz, cy, cx = q.popleft()
            for dz, dy, dx in neighbours:
                nz, ny, nx = cz + dz, cy + dy, cx + dx
                if (
                    0 <= nz < zmax
                    and 0 <= ny < ymax
                    and 0 <= nx < xmax
                    and m[nz, ny, nx]
                    and labels[nz, ny, nx] == 0
                ):
                    labels[nz, ny, nx] = label
                    q.append((nz, ny, nx))
    return labels, int(label)


def _label_components(mask: np.ndarray):
    """Return (labels, count, used_scipy).

    Prefer scipy.ndimage.label for speed. If scipy is unavailable, fall back to
    a pure NumPy/Python 26-connected component labeller so AutoClean 3D still
    removes floating objects. Set DICOMVIEW_VOLUME_CLEANER_NO_SCIPY=1 to test
    the fallback path explicitly.
    """
    if os.environ.get("DICOMVIEW_VOLUME_CLEANER_NO_SCIPY") != "1":
        try:
            from scipy import ndimage as ndi  # type: ignore
            structure = np.ones((3, 3, 3), dtype=np.uint8)
            labels, count = ndi.label(mask.astype(bool), structure=structure)
            return labels.astype(np.int32, copy=False), int(count), True
        except Exception:
            pass
    labels, count = _label_components_numpy(mask)
    return labels, count, False


def auto_clean_volume_for_3d(
    volume_hu: np.ndarray,
    *,
    mode: CleanMode = "bone_largest",
    threshold_hu: float = 200.0,
    min_component_voxels: int = 2500,
    background_hu: float = -1000.0,
) -> CleanVolumeResult:
    """Remove CT table/plates/floating objects before 3D rendering.

    The original DICOM volume is never modified.  The function creates a runtime
    copy for VTK only: voxels outside the clean mask are set to air
    (``background_hu``).  This makes foreign objects disappear in Volume
    Rendering and Surface/Marching-Cubes while measurements and source slices
    remain unchanged.

    Modes:
    - ``bone_largest``: threshold by HU and keep the largest connected object.
      Best for skull/bone reconstruction with table/side plate removal.
    - ``body_table``: threshold by HU, remove tiny floating objects, keep all
      sufficiently large connected anatomy. Useful for body scans where several
      bones are not physically connected in the ROI.
    - ``largest_component``: generic keep-largest-component filter.
    """
    vol = np.asarray(volume_hu)
    if vol.ndim != 3 or vol.size == 0:
        raise ValueError("auto_clean_volume_for_3d expects a non-empty 3D volume")

    source = np.asarray(vol, dtype=np.float32)
    threshold_mask = np.isfinite(source) & (source >= float(threshold_hu))
    if not bool(threshold_mask.any()):
        return CleanVolumeResult(
            False,
            f"Auto Clean 3D: no voxels above {threshold_hu:g} HU; original volume used.",
            np.ascontiguousarray(source),
            np.zeros(source.shape, dtype=np.uint8),
            float(threshold_hu),
            0,
            0,
            0,
            0,
        )

    labels, count, has_scipy = _label_components(threshold_mask)
    if count <= 0:
        return CleanVolumeResult(
            False,
            "Auto Clean 3D: no connected components found; original volume used.",
            np.ascontiguousarray(source),
            np.zeros(source.shape, dtype=np.uint8),
            float(threshold_hu),
            0,
            0,
            0,
            0,
        )

    counts = np.bincount(labels.ravel())
    counts[0] = 0
    nonzero_labels = np.flatnonzero(counts > 0)
    engine = "scipy" if has_scipy else "numpy fallback"
    if nonzero_labels.size == 0:
        clean_mask = np.zeros_like(threshold_mask, dtype=bool)
        kept_components = 0
        removed_components = int(count)
        msg_extra = f"empty labels ({engine})"
    elif mode in ("bone_largest", "largest_component"):
        largest = int(nonzero_labels[np.argmax(counts[nonzero_labels])])
        clean_mask = labels == largest
        kept_components = 1
        removed_components = int(max(0, count - 1))
        msg_extra = f"kept largest component label={largest} ({engine})"
    else:  # body_table
        min_vox = max(1, int(min_component_voxels))
        keep_labels = nonzero_labels[counts[nonzero_labels] >= min_vox]
        if keep_labels.size == 0:
            largest = int(nonzero_labels[np.argmax(counts[nonzero_labels])])
            keep_labels = np.array([largest], dtype=nonzero_labels.dtype)
        clean_mask = np.isin(labels, keep_labels)
        kept_components = int(keep_labels.size)
        removed_components = int(max(0, count - kept_components))
        msg_extra = f"kept components >= {min_vox} voxels ({engine})"

    cleaned = np.where(clean_mask, source, float(background_hu)).astype(np.float32, copy=False)
    kept_voxels = int(np.count_nonzero(clean_mask))
    removed_voxels = int(np.count_nonzero(threshold_mask & ~clean_mask))
    mode_label = {
        "bone_largest": "Bone/Skull largest component",
        "body_table": "Body/table removal",
        "largest_component": "Largest component",
    }.get(mode, str(mode))
    return CleanVolumeResult(
        True,
        f"Auto Clean 3D: {mode_label}; {msg_extra}; kept={kept_voxels:,} voxels; removed={removed_voxels:,} voxels.",
        np.ascontiguousarray(cleaned),
        np.ascontiguousarray(clean_mask.astype(np.uint8)),
        float(threshold_hu),
        int(kept_components),
        int(removed_components),
        kept_voxels,
        removed_voxels,
    )


@dataclass(frozen=True)
class ArtifactMaskResult:
    ok: bool
    message: str
    display_volume: np.ndarray
    artifact_mask: np.ndarray
    threshold_hu: float
    removed_voxels: int
    strength_percent: int


def _component_slices(labels: np.ndarray, count: int):
    try:
        from scipy import ndimage as ndi  # type: ignore
        return ndi.find_objects(labels, max_label=int(count))
    except Exception:
        out = []
        for lab in range(1, int(count) + 1):
            pts = np.argwhere(labels == lab)
            if pts.size == 0:
                out.append(None); continue
            lo = pts.min(axis=0); hi = pts.max(axis=0) + 1
            out.append(tuple(slice(int(lo[i]), int(hi[i])) for i in range(3)))
        return out


def post_render_artifact_mask_clean_volume(
    volume_hu: np.ndarray,
    *,
    threshold_hu: float = 180.0,
    min_component_voxels: int = 1500,
    strength_percent: int = 50,
    background_hu: float = -1000.0,
) -> ArtifactMaskResult:
    """Non-destructive post-3D artifact cleaner.

    This function is intentionally different from the old keep-largest cleaner.
    It never computes a *patient keep mask* and never overwrites the original
    data.  It detects external high-density components near scan borders
    (table, head holder, side plates) and creates an artifact mask only.  The
    returned display volume is ``OriginalVolume - ArtifactMask``; turning the
    cleaner off simply displays the stored original volume again.

    The rule is conservative by design: preserve central anatomy/components and
    remove only components that are border/edge biased.  This protects face,
    ears, mandible and cervical bones better than Largest Component filtering.
    """
    vol = np.asarray(volume_hu, dtype=np.float32)
    if vol.ndim != 3 or vol.size == 0:
        raise ValueError("post_render_artifact_mask_clean_volume expects a non-empty 3D volume")
    source = np.ascontiguousarray(vol)
    mask = np.isfinite(source) & (source >= float(threshold_hu))
    if not bool(mask.any()):
        return ArtifactMaskResult(False, f"Artifact Clean: no voxels above {threshold_hu:g} HU", source.copy(), np.zeros(source.shape, np.uint8), float(threshold_hu), 0, int(strength_percent))

    labels, count, has_scipy = _label_components(mask)
    counts = np.bincount(labels.ravel()) if count > 0 else np.zeros(1, dtype=np.int64)
    if counts.size:
        counts[0] = 0
    if count <= 0 or counts.max(initial=0) <= 0:
        return ArtifactMaskResult(False, "Artifact Clean: no components found", source.copy(), np.zeros(source.shape, np.uint8), float(threshold_hu), 0, int(strength_percent))

    zmax, ymax, xmax = source.shape
    cz0, cy0, cx0 = (zmax - 1) / 2.0, (ymax - 1) / 2.0, (xmax - 1) / 2.0
    slices = _component_slices(labels, count)
    min_vox = max(1, int(min_component_voxels))
    border_margin_z = max(1, int(round(zmax * 0.035)))
    border_margin_y = max(1, int(round(ymax * 0.045)))
    border_margin_x = max(1, int(round(xmax * 0.045)))
    outer_x0, outer_x1 = xmax * 0.18, xmax * 0.82
    outer_y0, outer_y1 = ymax * 0.12, ymax * 0.88

    # Pick the strongest central anatomical component to protect.  For head CT
    # this is typically the skull/mandible complex; for body scans it protects
    # central bone/contrast structures.
    best_keep = None
    best_score = -1.0
    props = {}
    for lab in range(1, count + 1):
        c = int(counts[lab]) if lab < len(counts) else 0
        if c <= 0:
            continue
        sl = slices[lab - 1] if lab - 1 < len(slices) else None
        if sl is None:
            continue
        zsl, ysl, xsl = sl
        zc = (zsl.start + zsl.stop - 1) / 2.0
        yc = (ysl.start + ysl.stop - 1) / 2.0
        xc = (xsl.start + xsl.stop - 1) / 2.0
        dz = abs(zc - cz0) / max(zmax, 1)
        dy = abs(yc - cy0) / max(ymax, 1)
        dx = abs(xc - cx0) / max(xmax, 1)
        centrality = max(0.05, 1.0 - 2.4 * (dx + dy + 0.35 * dz))
        score = float(c) * centrality
        props[lab] = (c, zsl, ysl, xsl, zc, yc, xc)
        if c >= min_vox and score > best_score:
            best_score = score; best_keep = lab
    if best_keep is None:
        best_keep = int(np.argmax(counts))

    artifact_labels = []
    protected = {int(best_keep)}
    # Conservative geometry-only rules: never remove a component merely because
    # it is not the largest.  Head/face soft tissues, mandible, teeth and ears
    # are often separate or weakly connected in volume rendering.  Remove only
    # high-density islands that are clearly outside the central patient zone and
    # touch the acquisition borders, such as CT table, side plates and holders.
    central_x0, central_x1 = xmax * 0.10, xmax * 0.90
    central_y0, central_y1 = ymax * 0.08, ymax * 0.92
    central_z0, central_z1 = zmax * 0.03, zmax * 0.97
    for lab, (c, zsl, ysl, xsl, zc, yc, xc) in props.items():
        if lab in protected:
            continue
        touches_border = (
            xsl.start <= border_margin_x or xsl.stop >= xmax - border_margin_x or
            ysl.start <= border_margin_y or ysl.stop >= ymax - border_margin_y or
            zsl.start <= border_margin_z or zsl.stop >= zmax - border_margin_z
        )
        overlaps_patient_core = not (
            xsl.stop < central_x0 or xsl.start > central_x1 or
            ysl.stop < central_y0 or ysl.start > central_y1 or
            zsl.stop < central_z0 or zsl.start > central_z1
        )
        edge_centroid = (xc < outer_x0 or xc > outer_x1 or yc < outer_y0 or yc > outer_y1)
        sx = max(1, xsl.stop - xsl.start); sy = max(1, ysl.stop - ysl.start); sz = max(1, zsl.stop - zsl.start)
        aspect = max(sx, sy, sz) / max(1, min(sx, sy, sz))
        flat_plate_like = (aspect >= 8.0 and c >= min_vox)
        tiny_border_speck = c < min_vox and touches_border and edge_centroid and not overlaps_patient_core
        external_plate_or_table = touches_border and edge_centroid and flat_plate_like and not overlaps_patient_core
        if tiny_border_speck or external_plate_or_table:
            artifact_labels.append(lab)

    if not artifact_labels:
        return ArtifactMaskResult(False, f"Artifact Clean: no external components detected; protected label={best_keep}", source.copy(), np.zeros(source.shape, np.uint8), float(threshold_hu), 0, int(strength_percent))

    artifact = np.isin(labels, np.asarray(artifact_labels, dtype=labels.dtype))
    # Aggressiveness expands only the artifact mask, not the patient keep mask.
    strength = int(max(0, min(100, strength_percent)))
    iterations = 0 if strength < 60 else int(round((strength - 50) / 30.0))
    if iterations > 0:
        try:
            from scipy import ndimage as ndi  # type: ignore
            artifact = ndi.binary_dilation(artifact, iterations=iterations)
            # Never allow dilation to eat the protected central component.
            artifact &= labels != int(best_keep)
        except Exception:
            pass
    display = source.copy()
    display[artifact] = float(background_hu)
    removed = int(np.count_nonzero(artifact))
    engine = "scipy" if has_scipy else "numpy fallback"
    return ArtifactMaskResult(True, f"Artifact Clean mask-only: removed={removed:,} voxels; labels={artifact_labels[:12]}; protected={best_keep}; engine={engine}", np.ascontiguousarray(display), np.ascontiguousarray(artifact.astype(np.uint8)), float(threshold_hu), removed, strength)
