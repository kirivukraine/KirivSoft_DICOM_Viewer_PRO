from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
try:
    import pydicom
except Exception:  # optional in lightweight test/build environments
    pydicom = None

SR_SOP = {
    "1.2.840.10008.5.1.4.1.1.88.11", "1.2.840.10008.5.1.4.1.1.88.22",
    "1.2.840.10008.5.1.4.1.1.88.33", "1.2.840.10008.5.1.4.1.1.88.34",
    "1.2.840.10008.5.1.4.1.1.88.40", "1.2.840.10008.5.1.4.1.1.88.59",
    "1.2.840.10008.5.1.4.1.1.88.65", "1.2.840.10008.5.1.4.1.1.88.67",
}
SEG_SOP = {"1.2.840.10008.5.1.4.1.1.66.4"}
RT_SOP_PREFIX = "1.2.840.10008.5.1.4.1.1.481."
ECG_SOP = {
    "1.2.840.10008.5.1.4.1.1.9.1.1", "1.2.840.10008.5.1.4.1.1.9.1.2",
    "1.2.840.10008.5.1.4.1.1.9.1.3",
}
PDF_SOP = {"1.2.840.10008.5.1.4.1.1.104.1"}

@dataclass
class SpecialObjectInfo:
    path: str
    sop_class_uid: str
    modality: str
    kind: str
    patient: str = ""
    study_uid: str = ""
    series_uid: str = ""
    summary: str = ""


def classify_dataset(ds: Any, path: str = "") -> SpecialObjectInfo:
    sop = str(getattr(ds, "SOPClassUID", ""))
    mod = str(getattr(ds, "Modality", ""))
    if sop in SR_SOP or mod == "SR":
        kind = "DICOM SR"
        summary = _sr_summary(ds)
    elif sop in SEG_SOP or mod == "SEG":
        kind = "DICOM SEG"
        summary = _seg_summary(ds)
    elif sop.startswith(RT_SOP_PREFIX) or mod.startswith("RT"):
        kind = "DICOM RT"
        summary = _rt_summary(ds)
    elif sop in ECG_SOP or mod in {"ECG", "HD", "WAVEFORM"}:
        kind = "DICOM ECG/Waveform"
        summary = _waveform_summary(ds)
    elif sop in PDF_SOP:
        kind = "Encapsulated PDF"
        summary = "DICOM PDF document"
    else:
        kind = "Image/Other"
        summary = f"{mod or 'Unknown'} image/object"
    return SpecialObjectInfo(
        path=path,
        sop_class_uid=sop,
        modality=mod,
        kind=kind,
        patient=str(getattr(ds, "PatientName", "")),
        study_uid=str(getattr(ds, "StudyInstanceUID", "")),
        series_uid=str(getattr(ds, "SeriesInstanceUID", "")),
        summary=summary,
    )


def inspect_file(path: str | Path) -> SpecialObjectInfo:
    if pydicom is None:
        raise RuntimeError("pydicom is required to inspect DICOM files")
    ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    return classify_dataset(ds, str(path))


def inspect_folder(path: str | Path, limit: int = 1000) -> list[SpecialObjectInfo]:
    base = Path(path)
    files = [base] if base.is_file() else [p for p in base.rglob("*") if p.is_file() and p.name.upper() != "DICOMDIR"]
    out: list[SpecialObjectInfo] = []
    for f in files[:limit]:
        try:
            out.append(inspect_file(f))
        except Exception:
            continue
    return out


def _sr_summary(ds: Any) -> str:
    seq = getattr(ds, "ContentSequence", []) or []
    return f"Structured Report; content items: {len(seq)}"


def _seg_summary(ds: Any) -> str:
    segs = getattr(ds, "SegmentSequence", []) or []
    nf = getattr(ds, "NumberOfFrames", "")
    return f"Segmentation; segments: {len(segs)}; frames: {nf}"


def _rt_summary(ds: Any) -> str:
    if hasattr(ds, "StructureSetROISequence"):
        return f"RT Structure Set; ROIs: {len(ds.StructureSetROISequence)}"
    if hasattr(ds, "DoseGridScaling"):
        return "RT Dose object"
    return "RT object"


def _waveform_summary(ds: Any) -> str:
    seq = getattr(ds, "WaveformSequence", []) or []
    return f"Waveform/ECG; channels blocks: {len(seq)}"


def infos_to_dict(infos: list[SpecialObjectInfo]) -> list[dict[str, Any]]:
    return [asdict(x) for x in infos]


def sr_plain_text(path: str | Path, max_items: int = 300) -> str:
    """Return a compact text rendering of a DICOM SR ContentSequence.

    This is intentionally conservative: it never evaluates codes and is safe for
    development/non-certified viewing. It is useful for quick inspection and reports.
    """
    if pydicom is None:
        raise RuntimeError("pydicom is required to read DICOM SR")
    ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    lines: list[str] = []
    title = getattr(ds, "ConceptNameCodeSequence", None)
    lines.append(f"DICOM SR: {Path(path).name}")
    lines.append(f"Patient: {getattr(ds, 'PatientName', '')}  Study: {getattr(ds, 'StudyDate', '')}")

    def code_label(code_seq: Any) -> str:
        try:
            c = code_seq[0]
            return str(getattr(c, "CodeMeaning", "") or getattr(c, "CodeValue", ""))
        except Exception:
            return ""

    def walk(seq: Any, depth: int = 0):
        nonlocal lines
        if len(lines) >= max_items:
            return
        for item in seq or []:
            if len(lines) >= max_items:
                break
            name = code_label(getattr(item, "ConceptNameCodeSequence", []))
            vtype = str(getattr(item, "ValueType", ""))
            value = ""
            for attr in ("TextValue", "DateTime", "Date", "Time", "PersonName"):
                if hasattr(item, attr):
                    value = str(getattr(item, attr)); break
            if hasattr(item, "MeasuredValueSequence"):
                try:
                    mv = item.MeasuredValueSequence[0]
                    unit = code_label(getattr(mv, "MeasurementUnitsCodeSequence", []))
                    value = f"{getattr(mv, 'NumericValue', '')} {unit}".strip()
                except Exception:
                    pass
            line = "  " * depth + f"- {name or vtype}: {value}".rstrip()
            lines.append(line)
            walk(getattr(item, "ContentSequence", []), depth + 1)
    walk(getattr(ds, "ContentSequence", []))
    return "\n".join(lines)


def seg_summary_table(path: str | Path) -> list[dict[str, str]]:
    if pydicom is None:
        raise RuntimeError("pydicom is required to read DICOM SEG")
    ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    out: list[dict[str, str]] = []
    for i, seg in enumerate(getattr(ds, "SegmentSequence", []) or [], start=1):
        out.append({
            "number": str(getattr(seg, "SegmentNumber", i)),
            "label": str(getattr(seg, "SegmentLabel", "")),
            "description": str(getattr(seg, "SegmentDescription", "")),
            "algorithm": str(getattr(seg, "SegmentAlgorithmType", "")),
        })
    return out


def rt_summary_table(path: str | Path) -> list[dict[str, str]]:
    if pydicom is None:
        raise RuntimeError("pydicom is required to read RT objects")
    ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    out: list[dict[str, str]] = []
    for roi in getattr(ds, "StructureSetROISequence", []) or []:
        out.append({
            "number": str(getattr(roi, "ROINumber", "")),
            "name": str(getattr(roi, "ROIName", "")),
            "description": str(getattr(roi, "ROIDescription", "")),
        })
    if hasattr(ds, "DoseGridScaling"):
        out.append({"number": "RTDOSE", "name": "DoseGridScaling", "description": str(getattr(ds, "DoseGridScaling", ""))})
    return out
