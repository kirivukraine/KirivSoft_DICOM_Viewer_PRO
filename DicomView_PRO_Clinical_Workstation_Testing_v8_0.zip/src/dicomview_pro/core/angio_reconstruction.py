from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class AngioReconStatus:
    possible: bool
    mode: str
    message: str
    details: dict


def inspect_angio_metadata(metadata: dict) -> AngioReconStatus:
    modality = str(metadata.get('modality') or metadata.get('tags', {}).get('Modality','')).upper()
    tags = metadata.get('tags', {}) or {}
    frames = int(metadata.get('cine_frames') or metadata.get('frames') or 0) if str(metadata.get('cine_frames') or metadata.get('frames') or '0').isdigit() else 0
    has_angles = any(k in tags for k in ('PositionerPrimaryAngle','PositionerSecondaryAngle','XRayImageReceptorAngle','ImagePositionPatient'))
    if modality in ('XA','XRF') and has_angles:
        return AngioReconStatus(True, 'rotational-angio-candidate', 'Є ознаки ангіографічної серії з геометрією. Можливий preview-реконструкційний workflow.', {'modality':modality,'frames':frames,'has_geometry':has_angles})
    if modality in ('XA','XRF'):
        return AngioReconStatus(False, 'cine-2d', 'Це схоже на 2D cine-ангіографію. Для справжньої 3D-реконструкції потрібна ротаційна геометрія C-arm.', {'modality':modality,'frames':frames,'has_geometry':has_angles})
    return AngioReconStatus(False, 'not-angio', 'Поточна серія не схожа на XA/XRF ангіографію.', {'modality':modality,'frames':frames,'has_geometry':has_angles})


def dsa_subtraction(volume: np.ndarray, mask_frame: int = 0) -> np.ndarray:
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3:
        raise ValueError('DSA subtraction потребує multi-frame/3D масив z,y,x')
    mask_frame = int(np.clip(mask_frame, 0, vol.shape[0]-1))
    base = vol[mask_frame]
    out = vol - base[None, :, :]
    return out


def temporal_max_projection(volume: np.ndarray) -> np.ndarray:
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError('Temporal projection потребує 3D/multi-frame обсяг')
    return np.max(vol, axis=0)


def pseudo_3d_angio_preview(volume: np.ndarray, min_value: float | None = None) -> np.ndarray:
    """Returns a safe pseudo-3D vessel mask from cine/CTA volume for preview.

    It is intentionally not labelled as diagnostic 3D reconstruction.
    """
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError('Потрібен обсяг кадрів/зрізів')
    if min_value is None:
        min_value = float(np.percentile(vol, 92))
    return vol >= min_value
