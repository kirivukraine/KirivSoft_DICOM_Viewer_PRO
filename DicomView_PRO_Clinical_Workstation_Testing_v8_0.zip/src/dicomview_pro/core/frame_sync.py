from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class FrameSyncInfo:
    frame_of_reference_uid: str
    study_uid: str
    series_uid: str
    modality: str
    description: str


def series_frame_info(metadata: dict[str, Any]) -> FrameSyncInfo:
    tags = metadata.get("tags", {}) if isinstance(metadata, dict) else {}
    return FrameSyncInfo(
        frame_of_reference_uid=str(tags.get("FrameOfReferenceUID") or metadata.get("FrameOfReferenceUID") or ""),
        study_uid=str(metadata.get("study_uid") or metadata.get("StudyInstanceUID") or tags.get("StudyInstanceUID") or ""),
        series_uid=str(metadata.get("series_uid") or tags.get("SeriesInstanceUID") or ""),
        modality=str(metadata.get("modality") or tags.get("Modality") or ""),
        description=str(metadata.get("series_description") or tags.get("SeriesDescription") or ""),
    )


def can_sync(a: dict[str, Any], b: dict[str, Any]) -> bool:
    ia, ib = series_frame_info(a), series_frame_info(b)
    return bool(ia.frame_of_reference_uid and ia.frame_of_reference_uid == ib.frame_of_reference_uid)


def sync_report(current: dict[str, Any], available_series: list[dict[str, Any]]) -> dict[str, Any]:
    cur = series_frame_info(current)
    matches = []
    for s in available_series:
        info = series_frame_info(s)
        if cur.frame_of_reference_uid and info.frame_of_reference_uid == cur.frame_of_reference_uid:
            matches.append(info.__dict__)
    return {"current": cur.__dict__, "matches": matches, "count": len(matches)}
