
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import logging
import numpy as np

from .image_ops import window_to_uint8

log = logging.getLogger(__name__)

@dataclass
class CineExportResult:
    path: str
    frames: int
    fps: float
    format: str


def _frames_uint8(volume_hu: np.ndarray, center: float, width: float, max_frames: int | None = None) -> list[np.ndarray]:
    vol = np.asarray(volume_hu)
    if vol.ndim != 3 or vol.shape[0] == 0:
        raise ValueError("Cine export потребує 3D обсяг / multi-frame DICOM")
    count = vol.shape[0] if max_frames is None else min(int(max_frames), vol.shape[0])
    return [np.ascontiguousarray(window_to_uint8(vol[i], center, width)) for i in range(count)]


def export_cine_gif(volume_hu: np.ndarray, path: str | Path, center: float, width: float, fps: float = 12.0, max_frames: int | None = None) -> CineExportResult:
    """Export cine loop as GIF. Uses Pillow, graceful error if unavailable."""
    try:
        from PIL import Image
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Для GIF експорту потрібен пакет Pillow") from exc
    frames = _frames_uint8(volume_hu, center, width, max_frames)
    if not frames:
        raise RuntimeError("Немає кадрів для GIF")
    pil = [Image.fromarray(f) for f in frames]
    duration_ms = int(1000 / max(1.0, float(fps)))
    out = Path(path)
    if out.suffix.lower() != '.gif':
        out = out.with_suffix('.gif')
    pil[0].save(out, save_all=True, append_images=pil[1:], duration=duration_ms, loop=0)
    return CineExportResult(str(out), len(frames), float(fps), 'GIF')


def export_cine_mp4(volume_hu: np.ndarray, path: str | Path, center: float, width: float, fps: float = 12.0, max_frames: int | None = None) -> CineExportResult:
    """Export cine loop as MP4. Uses imageio-ffmpeg when installed."""
    try:
        import imageio.v2 as imageio
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Для MP4 експорту потрібні пакети imageio та imageio-ffmpeg") from exc
    frames = _frames_uint8(volume_hu, center, width, max_frames)
    if not frames:
        raise RuntimeError("Немає кадрів для MP4")
    out = Path(path)
    if out.suffix.lower() != '.mp4':
        out = out.with_suffix('.mp4')
    # imageio expects RGB for broadly compatible mp4
    rgb = [np.repeat(f[:, :, None], 3, axis=2) for f in frames]
    imageio.mimsave(str(out), rgb, fps=float(fps), quality=8)
    return CineExportResult(str(out), len(frames), float(fps), 'MP4')
