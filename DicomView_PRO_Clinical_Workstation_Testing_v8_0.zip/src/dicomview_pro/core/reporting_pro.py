from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json
from .reporting import create_pdf_report, create_docx_report, ReportResult


@dataclass(frozen=True)
class ReportBundleResult:
    ok: bool
    message: str
    files: list[str]


def create_report_bundle(out_dir: str | Path, metadata: dict[str, Any], measurements: list[str] | None = None,
                         screenshots: list[str] | None = None, include_docx: bool = True) -> ReportBundleResult:
    """Create PDF/DOCX/JSON report bundle with graceful fallbacks."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    files: list[str] = []
    messages: list[str] = []
    pdf: ReportResult = create_pdf_report(out / "DicomView_PRO_Report.pdf", metadata, measurements, screenshots)
    files.append(pdf.path); messages.append(pdf.message)
    if include_docx:
        docx: ReportResult = create_docx_report(out / "DicomView_PRO_Report.docx", metadata, measurements)
        files.append(docx.path); messages.append(docx.message)
    manifest = {
        "metadata": metadata,
        "measurements": measurements or [],
        "screenshots": screenshots or [],
        "files": files,
        "note": "DicomView PRO report bundle. Not a certified medical device."
    }
    manifest_path = out / "DicomView_PRO_Report_Manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    files.append(str(manifest_path))
    return ReportBundleResult(True, "; ".join(messages), files)
