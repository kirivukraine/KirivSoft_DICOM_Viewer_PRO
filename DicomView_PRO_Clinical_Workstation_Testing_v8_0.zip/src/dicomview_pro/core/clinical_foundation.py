from __future__ import annotations
from dataclasses import dataclass, asdict
import importlib.util
from typing import Any

@dataclass(frozen=True)
class ModuleFoundationStatus:
    module: str
    ready: bool
    mode: str
    fallback: str
    required_for_core: bool = False
    notes: str = ""


def _has(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def clinical_foundation_status(hardware_note: str = "") -> list[ModuleFoundationStatus]:
    """Return safe capability map for advanced clinical modules.

    This function is deliberately dependency-light. It never imports heavy engines
    such as VTK, MONAI, Torch or PyRadiomics, so it is safe on old hospital PCs.
    """
    vtk_ok = _has('vtkmodules')
    pynet_ok = _has('pynetdicom')
    orthanc_ok = True  # REST client uses stdlib urllib; Orthanc server is optional runtime dependency.
    report_pdf = _has('reportlab')
    report_docx = _has('docx')
    pyrad_ok = _has('radiomics') or _has('pyradiomics')
    imageio_ok = _has('imageio')
    monai_ok = _has('monai') and _has('torch')
    return [
        ModuleFoundationStatus('Orthanc Explorer PRO', orthanc_ok, 'REST stdlib client', 'offline/manual DICOM import', False, 'Works when Orthanc server is available.'),
        ModuleFoundationStatus('PACS PRO', pynet_ok, 'pynetdicom C-ECHO/C-FIND/C-STORE' if pynet_ok else 'disabled', 'Orthanc REST/manual import fallback', False, 'PACS is optional and must not block local viewing.'),
        ModuleFoundationStatus('Reporting PRO', report_pdf or report_docx, 'PDF/DOCX if packages exist', 'TXT report fallback', False, 'Never blocks DICOM viewing.'),
        ModuleFoundationStatus('Radiomics PRO', True, 'NumPy base metrics' + (' + PyRadiomics' if pyrad_ok else ''), 'NumPy histogram/shape fallback', False, 'Advanced PyRadiomics remains optional.'),
        ModuleFoundationStatus('Cine PRO', True, 'in-app cine playback' + (' + GIF/MP4 export' if imageio_ok else ''), 'frame slider + PNG frame export', False, 'XA/XRF multi-frame support depends on DICOM decoder.'),
        ModuleFoundationStatus('Vessel Analysis', True, 'threshold/MIP vessel preview', '2D MIP preview', False, 'Not diagnostic stenosis grading yet.'),
        ModuleFoundationStatus('3D Angio Reconstruction', vtk_ok, 'VTK preview if GPU/OpenGL available', 'CPU pseudo-3D mask + MIP preview', False, hardware_note or 'Safe mode is default on weak PCs.'),
        ModuleFoundationStatus('4D Cardiac Viewer v1', True, 'cine/timeline foundation', '2D frame-by-frame viewer', False, 'True 4D volume requires t,z,y,x data.'),
        ModuleFoundationStatus('AI / MONAI', monai_ok, 'MONAI/Torch optional', 'threshold fallback masks', False, 'AI is disabled gracefully when dependencies are absent.'),
        ModuleFoundationStatus('Core DICOM Viewer', True, '2D/MPR/Series Selector', 'No fallback required', True, 'Core must remain usable even if every advanced module is unavailable.'),
    ]


def clinical_foundation_report(hardware_note: str = "") -> str:
    rows = clinical_foundation_status(hardware_note)
    lines = [
        'DicomView PRO — Clinical Foundation статус',
        'Принцип: базовий перегляд DICOM не повинен падати навіть якщо Orthanc/VTK/MONAI/PyRadiomics недоступні.',
        '',
    ]
    for r in rows:
        mark = '✅' if r.ready else '⚠️'
        lines.append(f'{mark} {r.module}')
        lines.append(f'   Режим: {r.mode}')
        lines.append(f'   Fallback: {r.fallback}')
        if r.notes:
            lines.append(f'   Примітка: {r.notes}')
    return '\n'.join(lines)


def clinical_foundation_json(hardware_note: str = "") -> dict[str, Any]:
    return {'modules': [asdict(x) for x in clinical_foundation_status(hardware_note)]}
