from __future__ import annotations

import logging
from typing import Any

from dicomview_pro.rendering.cinematic_fidelity import build_cinematic_property, is_cinematic_preset

log = logging.getLogger("DicomViewPRO.VolumeInspect")


class VolumeInspectController:
    """Enterprise 3D controller for HU transfer functions and clipping.

    This class intentionally contains only VTK state manipulation.  It does not
    own PySide widgets, so it can be reused from the main 3D viewer, diagnostics
    panel, or a future separate surgical planning window.
    """

    def __init__(self, volume_actor: Any, volume_mapper: Any, interactor: Any):
        self.volume_actor = volume_actor
        self.volume_mapper = volume_mapper
        self.interactor = interactor
        self.volume_property = volume_actor.GetProperty() if volume_actor is not None else None
        self.box_widget: Any | None = None

    def apply_preset(self, preset_name: str) -> bool:
        """Apply clinical HU color/opacity preset without rebuilding volume data."""
        if self.volume_property is None or self.volume_mapper is None:
            return False
        try:
            import vtkmodules.all as vtk

            # v7.4 Cinematic/Fidelity 3D: for supported presets replace the
            # whole vtkVolumeProperty, not only color/opacity. This preserves
            # gradient opacity, scalar opacity unit distance and lighting.
            if is_cinematic_preset(preset_name) and self.volume_actor is not None:
                prop = build_cinematic_property(preset_name)
                self.volume_actor.SetProperty(prop)
                self.volume_property = prop
                try:
                    self.volume_mapper.SetBlendModeToComposite()
                except Exception:
                    pass
                self._render()
                return True

            name = (preset_name or "").strip().lower().replace(" ", "_").replace("&", "_")
            color = vtk.vtkColorTransferFunction()
            opacity = vtk.vtkPiecewiseFunction()

            if name in {"skin_muscle", "skin", "soft_tissue", "soft"}:
                self.volume_mapper.SetBlendModeToComposite()
                opacity.AddPoint(-250, 0.0)
                opacity.AddPoint(-120, 0.08)
                opacity.AddPoint(0, 0.30)
                opacity.AddPoint(150, 0.65)
                opacity.AddPoint(350, 0.95)
                color.AddRGBPoint(-250, 0.02, 0.02, 0.02)
                color.AddRGBPoint(-100, 0.78, 0.45, 0.34)
                color.AddRGBPoint(80, 0.90, 0.38, 0.28)
                color.AddRGBPoint(300, 1.00, 0.80, 0.62)

            elif name in {"bone", "bone_color", "skeleton"}:
                self.volume_mapper.SetBlendModeToComposite()
                opacity.AddPoint(120, 0.0)
                opacity.AddPoint(220, 0.12)
                opacity.AddPoint(420, 0.65)
                opacity.AddPoint(1000, 1.0)
                color.AddRGBPoint(120, 0.0, 0.0, 0.0)
                color.AddRGBPoint(300, 0.85, 0.73, 0.58)
                color.AddRGBPoint(900, 1.0, 0.98, 0.88)
                color.AddRGBPoint(1800, 1.0, 1.0, 0.96)

            elif name in {"angio_mip", "angio", "mip", "vessel"}:
                self.volume_mapper.SetBlendModeToMaximumIntensity()
                opacity.AddPoint(180, 0.0)
                opacity.AddPoint(280, 0.20)
                opacity.AddPoint(450, 0.85)
                opacity.AddPoint(1200, 1.0)
                color.AddRGBPoint(180, 0.0, 0.0, 0.0)
                color.AddRGBPoint(350, 1.0, 0.05, 0.04)
                color.AddRGBPoint(750, 1.0, 0.75, 0.20)
                color.AddRGBPoint(1300, 1.0, 0.95, 0.75)

            elif name in {"lung", "thorax_lung"}:
                self.volume_mapper.SetBlendModeToComposite()
                opacity.AddPoint(-1000, 0.0)
                opacity.AddPoint(-760, 0.11)
                opacity.AddPoint(-520, 0.20)
                opacity.AddPoint(-200, 0.05)
                opacity.AddPoint(250, 0.18)
                color.AddRGBPoint(-1000, 0.02, 0.05, 0.10)
                color.AddRGBPoint(-700, 0.50, 0.80, 1.0)
                color.AddRGBPoint(-250, 0.72, 0.86, 1.0)
                color.AddRGBPoint(250, 1.0, 0.75, 0.58)

            else:  # Color anatomy default
                self.volume_mapper.SetBlendModeToComposite()
                opacity.AddPoint(-1000, 0.0)
                opacity.AddPoint(-700, 0.06)
                opacity.AddPoint(-350, 0.12)
                opacity.AddPoint(60, 0.08)
                opacity.AddPoint(250, 0.15)
                opacity.AddPoint(600, 0.45)
                opacity.AddPoint(1200, 0.85)
                color.AddRGBPoint(-1000, 0.05, 0.12, 0.30)
                color.AddRGBPoint(-600, 0.16, 0.58, 0.92)
                color.AddRGBPoint(60, 0.95, 0.45, 0.30)
                color.AddRGBPoint(500, 0.95, 0.70, 0.45)
                color.AddRGBPoint(1200, 1.0, 0.98, 0.88)

            self.volume_property.SetColor(color)
            self.volume_property.SetScalarOpacity(opacity)
            try:
                grad = vtk.vtkPiecewiseFunction(); grad.AddPoint(0, 0.0); grad.AddPoint(60, 0.18); grad.AddPoint(180, 0.55); grad.AddPoint(500, 0.90)
                self.volume_property.SetGradientOpacity(grad)
                self.volume_property.SetAmbient(0.22); self.volume_property.SetDiffuse(0.72); self.volume_property.SetSpecular(0.18); self.volume_property.SetSpecularPower(18.0)
            except Exception:
                pass
            self._render()
            return True
        except Exception as exc:
            log.exception("apply_preset failed: %s", exc)
            return False

    def set_depth_threshold(self, threshold_hu: float) -> bool:
        """Move HU opacity threshold dynamically: lower densities become transparent."""
        if self.volume_property is None:
            return False
        try:
            import vtkmodules.all as vtk

            t = float(threshold_hu)
            opacity = vtk.vtkPiecewiseFunction()
            opacity.AddPoint(t - 50.0, 0.0)
            opacity.AddPoint(t, 0.20)
            opacity.AddPoint(t + 200.0, 1.0)
            self.volume_property.SetScalarOpacity(opacity)
            self._render()
            return True
        except Exception as exc:
            log.exception("set_depth_threshold failed: %s", exc)
            return False

    def set_mip(self, enabled: bool = True) -> bool:
        if self.volume_mapper is None:
            return False
        try:
            if enabled:
                self.volume_mapper.SetBlendModeToMaximumIntensity()
            else:
                self.volume_mapper.SetBlendModeToComposite()
            self._render()
            return True
        except Exception as exc:
            log.exception("set_mip failed: %s", exc)
            return False

    def set_clipping_box_visible(self, visible: bool) -> bool:
        """Toggle VTK interactive clip box; clipping is done in the volume mapper."""
        if self.volume_mapper is None or self.interactor is None:
            return False
        try:
            import vtkmodules.all as vtk

            if not visible:
                if self.box_widget is not None:
                    self.box_widget.Off()
                try:
                    self.volume_mapper.RemoveAllClippingPlanes()
                except Exception:
                    pass
                self._render()
                return True

            if self.box_widget is None:
                rep = vtk.vtkBoxRepresentation()
                rep.SetPlaceFactor(1.0)
                try:
                    bounds = self.volume_mapper.GetInput().GetBounds()
                except Exception:
                    bounds = (0, 1, 0, 1, 0, 1)
                rep.PlaceWidget(bounds)
                widget = vtk.vtkBoxWidget2()
                widget.SetInteractor(self.interactor)
                widget.SetRepresentation(rep)

                def _on_interact(w, _event):
                    planes = vtk.vtkPlanes()
                    w.GetRepresentation().GetPlanes(planes)
                    self.volume_mapper.SetClippingPlanes(planes)
                    self._render()

                widget.AddObserver("InteractionEvent", _on_interact)
                self.box_widget = widget

            self.box_widget.On()
            self._render()
            return True
        except Exception as exc:
            log.exception("set_clipping_box_visible failed: %s", exc)
            return False

    def enable_clip_plane_navigate(self, enabled: bool = True, axis: str = "Y", renderer: Any | None = None) -> bool:
        """Enable a single interactive clipping plane controlled by sliders/wheel.

        This avoids the VTK camera/box-widget mouse conflict: the user can
        smoothly enter the skull/chest by moving one plane through the volume.
        """
        if self.volume_mapper is None:
            return False
        try:
            import vtkmodules.all as vtk
            if not enabled:
                try:
                    self.volume_mapper.RemoveAllClippingPlanes()
                except Exception:
                    pass
                self._clip_plane = None
                self._clip_planes = None
                self._render()
                return True
            try:
                bounds = self.volume_mapper.GetInput().GetBounds()
            except Exception:
                bounds = (0, 1, 0, 1, 0, 1)
            axis = (axis or "Y").upper()
            center = ((bounds[0]+bounds[1])*0.5, (bounds[2]+bounds[3])*0.5, (bounds[4]+bounds[5])*0.5)
            if axis in {"CAMERA", "VIEW"} and renderer is not None:
                try:
                    cam = renderer.GetActiveCamera()
                    normal = tuple(float(v) for v in cam.GetDirectionOfProjection())
                    import math
                    nlen = math.sqrt(sum(v*v for v in normal)) or 1.0
                    normal = tuple(v/nlen for v in normal)
                    corners = [(x,y,z) for x in (bounds[0],bounds[1]) for y in (bounds[2],bounds[3]) for z in (bounds[4],bounds[5])]
                    dots = [sum(c[i]*normal[i] for i in range(3)) for c in corners]
                    rng = (min(dots), max(dots))
                    origin = center
                except Exception:
                    normal = (0.0, 1.0, 0.0); rng = (bounds[2], bounds[3]); origin = center
                    axis = "Y"
            elif axis == "X":
                normal = (1.0, 0.0, 0.0); rng = (bounds[0], bounds[1]); origin = center
            elif axis == "Z":
                normal = (0.0, 0.0, 1.0); rng = (bounds[4], bounds[5]); origin = center
            else:
                normal = (0.0, 1.0, 0.0); rng = (bounds[2], bounds[3]); origin = center
            plane = vtk.vtkPlane(); plane.SetNormal(*normal); plane.SetOrigin(*origin)
            planes = vtk.vtkPlaneCollection(); planes.AddItem(plane)
            self.volume_mapper.SetClippingPlanes(planes)
            self._clip_plane = plane
            self._clip_planes = planes
            self._clip_axis = axis
            self._clip_bounds = bounds
            self._clip_range = rng
            self._render()
            return True
        except Exception as exc:
            log.exception("enable_clip_plane_navigate failed: %s", exc)
            return False

    def set_clip_plane_percent(self, percent: float) -> bool:
        """Move active single clipping plane by 0..100 percent through the volume."""
        try:
            if getattr(self, "_clip_plane", None) is None:
                if not self.enable_clip_plane_navigate(True):
                    return False
            p = max(0.0, min(100.0, float(percent))) / 100.0
            lo, hi = getattr(self, "_clip_range", (0.0, 1.0))
            v = float(lo) + (float(hi) - float(lo)) * p
            b = getattr(self, "_clip_bounds", (0,1,0,1,0,1))
            axis = getattr(self, "_clip_axis", "Y")
            if axis == "X":
                origin = (v, (b[2]+b[3])*0.5, (b[4]+b[5])*0.5)
            elif axis == "Z":
                origin = ((b[0]+b[1])*0.5, (b[2]+b[3])*0.5, v)
            elif axis in {"CAMERA", "VIEW"}:
                n = self._clip_plane.GetNormal()
                center = ((b[0]+b[1])*0.5, (b[2]+b[3])*0.5, (b[4]+b[5])*0.5)
                c_dot = sum(center[i]*n[i] for i in range(3))
                delta = v - c_dot
                origin = (center[0] + n[0]*delta, center[1] + n[1]*delta, center[2] + n[2]*delta)
            else:
                origin = ((b[0]+b[1])*0.5, v, (b[4]+b[5])*0.5)
            self._clip_plane.SetOrigin(*origin)
            self._render()
            return True
        except Exception as exc:
            log.exception("set_clip_plane_percent failed: %s", exc)
            return False

    def move_clip_plane_step(self, step_percent: float) -> bool:
        cur = float(getattr(self, "_clip_percent", 50.0)) + float(step_percent)
        self._clip_percent = max(0.0, min(100.0, cur))
        return self.set_clip_plane_percent(self._clip_percent)

    def _render(self) -> None:
        try:
            if self.interactor is not None and self.interactor.GetRenderWindow() is not None:
                self.interactor.GetRenderWindow().Render()
        except Exception:
            pass
