from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np

@dataclass
class RadiomicsResult:
    available: bool
    features: dict[str, Any]
    message: str = "Lite basic radiomics only"

def pyradiomics_available() -> bool:
    return False

def basic_radiomics(volume_hu, mask, spacing=(1.0, 1.0, 1.0)) -> RadiomicsResult:
    """Small dependency-free Lite fallback used by reports and tests.

    This is not pyradiomics.  It only returns simple voxel statistics so Lite
    can generate basic PDF/DOCX reports without bundling heavy Enterprise AI
    modules.
    """
    vol = np.asarray(volume_hu, dtype=np.float32)
    m = np.asarray(mask).astype(bool)
    vals = vol[m] if vol.shape == m.shape else np.asarray([], dtype=np.float32)
    count = int(vals.size)
    sp = tuple(float(v) for v in (spacing or (1, 1, 1)))
    voxel_mm3 = float(abs(sp[0] * sp[1] * sp[2])) if len(sp) >= 3 else 1.0
    feats = {
        "count": count,
        "voxel_volume_mm3": voxel_mm3,
        "volume_mm3": float(count * voxel_mm3),
        "volume_ml": float(count * voxel_mm3 / 1000.0),
    }
    if count:
        feats.update({
            "mean_hu": float(np.mean(vals)),
            "median_hu": float(np.median(vals)),
            "min_hu": float(np.min(vals)),
            "max_hu": float(np.max(vals)),
            "std_hu": float(np.std(vals)),
        })
    else:
        feats.update({"mean_hu": 0.0, "median_hu": 0.0, "min_hu": 0.0, "max_hu": 0.0, "std_hu": 0.0})
    return RadiomicsResult(True, feats)
