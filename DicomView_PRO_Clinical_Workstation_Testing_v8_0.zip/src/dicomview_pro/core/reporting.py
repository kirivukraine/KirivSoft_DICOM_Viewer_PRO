from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import datetime, json

@dataclass(frozen=True)
class ReportResult:
    ok: bool
    path: str
    message: str


def _meta_lines(metadata: dict[str, Any]) -> list[str]:
    keys = [
        ('patient_name','Пацієнт'),('patient_id','ID'),('modality','Модальність'),
        ('series_description','Серія'),('series_uid','Series UID'),('shape','Розмір'),('spacing','Spacing')
    ]
    lines=[]
    for k, label in keys:
        v = metadata.get(k)
        if v not in (None, '', []):
            lines.append(f"{label}: {v}")
    return lines


def create_pdf_report(out_path: str | Path, metadata: dict[str, Any], measurements: list[str] | None = None, screenshots: list[str] | None = None) -> ReportResult:
    out = Path(out_path)
    try:
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.lib.units import cm
        try:
            pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
            font='DejaVuSans'
        except Exception:
            font='Helvetica'
        styles=getSampleStyleSheet()
        for s in styles.byName.values():
            s.fontName=font
        story=[Paragraph('DicomView PRO — звіт дослідження', styles['Title']), Spacer(1, 12)]
        story.append(Paragraph('Автор: Іван Кіранчук · KirivSoft', styles['Heading2']))
        story.append(Paragraph('Дата звіту: '+datetime.datetime.now().strftime('%Y-%m-%d %H:%M'), styles['BodyText']))
        story.append(Spacer(1, 10)); story.append(Paragraph('DICOM інформація', styles['Heading1']))
        for line in _meta_lines(metadata):
            story.append(Paragraph(line, styles['BodyText']))
        if measurements:
            story.append(Spacer(1, 10)); story.append(Paragraph('Вимірювання / ROI / HU', styles['Heading1']))
            for m in measurements[-20:]: story.append(Paragraph(str(m), styles['BodyText']))
        for img in screenshots or []:
            p=Path(img)
            if p.exists():
                story.append(Spacer(1, 10)); story.append(Image(str(p), width=15*cm, height=9*cm))
        story.append(Spacer(1, 12)); story.append(Paragraph('Примітка: програма не є сертифікованим медичним виробом.', styles['Italic']))
        SimpleDocTemplate(str(out)).build(story)
        return ReportResult(True, str(out), 'PDF звіт створено')
    except Exception as exc:
        # Fallback readable text if reportlab is not installed or font path is unavailable.
        txt = out.with_suffix('.txt')
        txt.write_text('\n'.join(['DicomView PRO — звіт', *(_meta_lines(metadata)), '', 'Measurements:', *(measurements or []), '', json.dumps(metadata, ensure_ascii=False, indent=2)]), encoding='utf-8')
        return ReportResult(False, str(txt), f'PDF недоступний, створено TXT fallback: {exc}')


def create_docx_report(out_path: str | Path, metadata: dict[str, Any], measurements: list[str] | None = None) -> ReportResult:
    out=Path(out_path)
    try:
        from docx import Document
        doc=Document(); doc.add_heading('DicomView PRO — звіт дослідження', 0)
        doc.add_paragraph('Автор: Іван Кіранчук · KirivSoft')
        doc.add_heading('DICOM інформація', level=1)
        for line in _meta_lines(metadata): doc.add_paragraph(line)
        if measurements:
            doc.add_heading('Вимірювання / ROI / HU', level=1)
            for m in measurements[-20:]: doc.add_paragraph(str(m))
        doc.add_paragraph('Примітка: програма не є сертифікованим медичним виробом.')
        doc.save(str(out))
        return ReportResult(True, str(out), 'DOCX звіт створено')
    except Exception as exc:
        txt=out.with_suffix('.txt')
        txt.write_text('\n'.join(['DicomView PRO — звіт', *(_meta_lines(metadata)), *(measurements or [])]), encoding='utf-8')
        return ReportResult(False, str(txt), f'DOCX недоступний, створено TXT fallback: {exc}')
