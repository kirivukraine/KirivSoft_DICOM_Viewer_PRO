"""DicomView PRO v8.0 Clinical Workstation readiness helpers.

This module intentionally contains no AI logic. It is a small integration
manifest used by tests, diagnostic logs and the About/Report panels to show
which deterministic clinical subsystems are present in the testing build.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List


VERSION = "8.0"
EDITION = "Clinical Workstation Testing Edition"


@dataclass(frozen=True)
class WorkstationSubsystem:
    """A deterministic subsystem included in the v8.0 testing build."""

    key: str
    title: str
    status: str
    purpose: str


SUBSYSTEMS: List[WorkstationSubsystem] = [
    WorkstationSubsystem(
        "viewer_fidelity",
        "Viewer Fidelity",
        "included",
        "High-quality 2D/MPR display pipeline, SmoothStack and fidelity controls.",
    ),
    WorkstationSubsystem(
        "scanner_intelligence",
        "Scanner Intelligence",
        "included",
        "DICOM metadata based profile selection for anatomy, series quality and visualization settings.",
    ),
    WorkstationSubsystem(
        "scanner_kernel_db",
        "Scanner Kernel DB",
        "included",
        "Vendor/kernel based deterministic tuning for WL/WW, denoise/sharpen and 3D presets.",
    ),
    WorkstationSubsystem(
        "cinematic_3d",
        "Cinematic/Fidelity 3D",
        "included",
        "VTK volume rendering presets, adaptive sampling and gradient opacity refinement.",
    ),
    WorkstationSubsystem(
        "hemorrhage_protocol",
        "Hemorrhage Protocol",
        "included",
        "Classic HU/morphology hemorrhage mask, volume, dimensions and report output.",
    ),
    WorkstationSubsystem(
        "trauma_protocol",
        "Trauma Protocol",
        "included",
        "Classic trauma focus for bone/air/dense fragments/hematoma candidates and report output.",
    ),
    WorkstationSubsystem(
        "comparative_viewer",
        "Comparative Viewer",
        "included",
        "Study A vs Study B delta reporting and safe overlay generation when shapes match.",
    ),
    WorkstationSubsystem(
        "dicom_validation",
        "DICOM Validation",
        "included",
        "Pre-load checks for essential DICOM tags and transfer syntax limitations.",
    ),
]


def clinical_workstation_manifest() -> Dict[str, Any]:
    """Return a JSON-serializable v8.0 readiness manifest."""

    return {
        "product": "DicomView PRO",
        "version": VERSION,
        "edition": EDITION,
        "clinical_use_note": "Research/testing build. Not a certified medical device.",
        "ai_policy": "No AI model is required for the core v8.0 testing workflow.",
        "subsystems": [asdict(item) for item in SUBSYSTEMS],
    }


def clinical_workstation_text() -> str:
    """Return a concise human-readable readiness summary."""

    manifest = clinical_workstation_manifest()
    lines = [
        f"{manifest['product']} v{manifest['version']} — {manifest['edition']}",
        manifest["clinical_use_note"],
        "",
        "Included deterministic subsystems:",
    ]
    for item in SUBSYSTEMS:
        lines.append(f"- {item.title}: {item.status} — {item.purpose}")
    return "\n".join(lines)
