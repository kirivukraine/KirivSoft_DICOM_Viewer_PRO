from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class SegmentationResult:
    mode: str
    mask: np.ndarray
    voxel_count: int
    volume_ml: float
    threshold: str


def _volume_ml(mask: np.ndarray, spacing_zyx: tuple[float, float, float]) -> float:
    z, y, x = [float(v) for v in spacing_zyx]
    return float(np.count_nonzero(mask) * z * y * x / 1000.0)


def segment_bones(volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], min_hu: float = 300.0) -> SegmentationResult:
    mask = np.asarray(volume_hu) >= float(min_hu)
    return SegmentationResult("bones", np.ascontiguousarray(mask), int(np.count_nonzero(mask)), _volume_ml(mask, spacing_zyx), f"HU >= {min_hu:g}")


def segment_lungs(volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], min_hu: float = -1000.0, max_hu: float = -350.0) -> SegmentationResult:
    v = np.asarray(volume_hu)
    mask = (v >= float(min_hu)) & (v <= float(max_hu))
    return SegmentationResult("lungs", np.ascontiguousarray(mask), int(np.count_nonzero(mask)), _volume_ml(mask, spacing_zyx), f"{min_hu:g} <= HU <= {max_hu:g}")


def segment_vessels(volume_hu: np.ndarray, spacing_zyx: tuple[float, float, float], min_hu: float = 180.0) -> SegmentationResult:
    mask = np.asarray(volume_hu) >= float(min_hu)
    return SegmentationResult("vessels_contrast", np.ascontiguousarray(mask), int(np.count_nonzero(mask)), _volume_ml(mask, spacing_zyx), f"HU >= {min_hu:g}")


def mask_projection(mask: np.ndarray) -> np.ndarray:
    a = np.asarray(mask, dtype=bool)
    if a.ndim != 3:
        raise ValueError("Mask must be 3D")
    return np.ascontiguousarray((np.max(a, axis=0).astype(np.uint8)) * 255)
