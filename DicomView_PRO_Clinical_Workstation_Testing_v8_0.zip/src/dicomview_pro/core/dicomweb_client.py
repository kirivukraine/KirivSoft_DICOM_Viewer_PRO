from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json
import urllib.parse
import urllib.request
import urllib.error

@dataclass
class DicomWebConfig:
    base_url: str = "http://localhost:8042/dicom-web"
    username: str = ""
    password: str = ""
    timeout: float = 60.0

@dataclass
class DicomWebResult:
    ok: bool
    message: str
    count: int = 0
    payload: Any | None = None


def _auth_header(cfg: DicomWebConfig) -> dict[str, str]:
    if not cfg.username:
        return {}
    import base64
    token = base64.b64encode(f"{cfg.username}:{cfg.password}".encode("utf-8")).decode("ascii")
    return {"Authorization": f"Basic {token}"}


def _request_json(cfg: DicomWebConfig, path: str, query: dict[str, str] | None = None) -> Any:
    base = cfg.base_url.rstrip("/")
    url = base + "/" + path.lstrip("/")
    if query:
        url += "?" + urllib.parse.urlencode({k: v for k, v in query.items() if v})
    headers = {"Accept": "application/dicom+json, application/json"}
    headers.update(_auth_header(cfg))
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=cfg.timeout) as resp:
        data = resp.read()
    if not data:
        return []
    return json.loads(data.decode("utf-8", errors="replace"))


def qido_studies(cfg: DicomWebConfig, patient: str = "", study_date: str = "", limit: int = 50) -> DicomWebResult:
    query: dict[str, str] = {"limit": str(limit)}
    if patient:
        # QIDO accepts DICOM keywords in many implementations, including Orthanc DICOMweb.
        query["PatientName"] = patient
    if study_date:
        query["StudyDate"] = study_date
    try:
        payload = _request_json(cfg, "studies", query)
        return DicomWebResult(True, "QIDO-RS studies OK", len(payload) if isinstance(payload, list) else 1, payload)
    except Exception as exc:
        return DicomWebResult(False, f"QIDO-RS error: {exc}")


def qido_series(cfg: DicomWebConfig, study_uid: str, limit: int = 100) -> DicomWebResult:
    try:
        payload = _request_json(cfg, f"studies/{study_uid}/series", {"limit": str(limit)})
        return DicomWebResult(True, "QIDO-RS series OK", len(payload) if isinstance(payload, list) else 1, payload)
    except Exception as exc:
        return DicomWebResult(False, f"QIDO-RS series error: {exc}")


def wado_metadata(cfg: DicomWebConfig, study_uid: str, series_uid: str | None = None) -> DicomWebResult:
    path = f"studies/{study_uid}"
    if series_uid:
        path += f"/series/{series_uid}"
    path += "/metadata"
    try:
        payload = _request_json(cfg, path)
        return DicomWebResult(True, "WADO-RS metadata OK", len(payload) if isinstance(payload, list) else 1, payload)
    except Exception as exc:
        return DicomWebResult(False, f"WADO-RS metadata error: {exc}")


def stow_instances(cfg: DicomWebConfig, dicom_files: list[str | Path]) -> DicomWebResult:
    """Minimal STOW-RS multipart uploader.

    This keeps dependencies small and works with Orthanc DICOMweb. It is a foundation,
    not a replacement for a certified DICOMweb stack.
    """
    files = [Path(p) for p in dicom_files if Path(p).is_file()]
    if not files:
        return DicomWebResult(False, "No DICOM files for STOW-RS")
    boundary = "----KirivSoftDicomViewBoundary"
    body = bytearray()
    for f in files:
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(b"Content-Type: application/dicom\r\n")
        body.extend(f"Content-Location: {f.name}\r\n\r\n".encode())
        body.extend(f.read_bytes())
        body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())
    url = cfg.base_url.rstrip("/") + "/studies"
    headers = {"Content-Type": f"multipart/related; type=application/dicom; boundary={boundary}", "Accept": "application/dicom+json, application/json"}
    headers.update(_auth_header(cfg))
    try:
        req = urllib.request.Request(url, data=bytes(body), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=cfg.timeout) as resp:
            payload = resp.read().decode("utf-8", errors="replace")
        return DicomWebResult(True, "STOW-RS upload OK", len(files), payload)
    except Exception as exc:
        return DicomWebResult(False, f"STOW-RS error: {exc}", len(files))


def config_to_json(cfg: DicomWebConfig) -> dict[str, Any]:
    d = asdict(cfg)
    if d.get("password"):
        d["password"] = "***"
    return d


def wado_retrieve_series_raw(cfg: DicomWebConfig, study_uid: str, series_uid: str, output_path: str | Path) -> DicomWebResult:
    """Retrieve a DICOMweb WADO-RS series response as raw multipart bytes.

    This foundation avoids a fragile multipart parser inside the GUI. The raw file can
    be archived, inspected, or parsed by a future decoder module. Orthanc/dcm4chee
    compatible servers return multipart/related application/dicom here.
    """
    if not study_uid or not series_uid:
        return DicomWebResult(False, "StudyInstanceUID and SeriesInstanceUID are required")
    url = cfg.base_url.rstrip('/') + f"/studies/{urllib.parse.quote(study_uid)}/series/{urllib.parse.quote(series_uid)}"
    headers = {"Accept": "multipart/related; type=application/dicom"}
    headers.update(_auth_header(cfg))
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=cfg.timeout) as resp:
            data = resp.read()
        out.write_bytes(data)
        return DicomWebResult(True, f"WADO-RS series raw download OK: {out}", 1, str(out))
    except Exception as exc:
        return DicomWebResult(False, f"WADO-RS series download error: {exc}")
