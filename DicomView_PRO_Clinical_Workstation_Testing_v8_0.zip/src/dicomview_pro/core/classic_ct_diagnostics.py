from __future__ import annotations

"""CPU-only deterministic CT brain diagnostics helpers.

This module intentionally does not use AI frameworks. It is designed for
DicomView PRO Lite/Clinical builds where we need transparent, fast, reproducible
HU-based tools that run on an ordinary CPU.

It is NOT a diagnostic medical device. Results are visualization aids and must
be reviewed by a clinician on the original DICOM images.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
import json
import math

import numpy as np


@dataclass(frozen=True)
class DicomSliceInfo:
    path: str
    instance_number: int
    z_position: float
    slope: float
    intercept: float
    rows: int
    cols: int


@dataclass(frozen=True)
class ClassicHemorrhageConfig:
    min_hu: float = 50.0
    max_hu: float = 95.0
    brain_hu_min: float = -5.0
    brain_hu_max: float = 120.0
    bone_hu_min: float = 180.0
    min_component_ml: float = 0.20
    max_component_ml: float = 150.0
    morphology_iterations: int = 1
    keep_components: int = 12
    use_intracranial_mask: bool = True
    remove_midline_small_calcifications: bool = True
    midline_band_mm: float = 3.0


@dataclass
class ClassicHemorrhageResult:
    mask: np.ndarray
    brain_mask: np.ndarray
    bone_mask: np.ndarray
    volume_ml: float
    voxel_count: int
    component_count: int
    components: list[dict[str, Any]]
    spacing_zyx_mm: tuple[float, float, float]
    bbox_voxels: tuple[int, int, int, int, int, int] | None
    bbox_mm: tuple[float, float, float] | None
    center_of_mass_voxels: tuple[float, float, float] | None
    confidence: float
    notes: list[str]
    debug: dict[str, Any]

    def to_json_dict(self) -> dict[str, Any]:
        max_dim = max(self.bbox_mm) if self.bbox_mm else 0.0
        return {
            "volume_ml": round(float(self.volume_ml), 4),
            "voxel_count": int(self.voxel_count),
            "component_count": int(self.component_count),
            "components": self.components,
            "spacing_zyx_mm": [float(x) for x in self.spacing_zyx_mm],
            "bbox_voxels": list(self.bbox_voxels) if self.bbox_voxels else None,
            "bbox_mm": [float(x) for x in self.bbox_mm] if self.bbox_mm else None,
            "max_dimension_mm": round(float(max_dim), 3),
            "diameters_mm_zyx": [round(float(x), 3) for x in self.bbox_mm] if self.bbox_mm else None,
            "center_of_mass_voxels": [float(x) for x in self.center_of_mass_voxels] if self.center_of_mass_voxels else None,
            "confidence": round(float(self.confidence), 4),
            "notes": list(self.notes),
            "debug": self.debug,
            "warning": "Classic CPU HU/morphology visualization aid, not an automatic diagnosis.",
        }


class DicomSeriesLoaderClassic:
    """Load a DICOM series into an HU volume sorted by physical slice position."""

    def load_dicom_series(self, folder_or_files: str | Path | Iterable[str | Path]) -> tuple[np.ndarray, tuple[float, float, float], dict[str, Any]]:
        try:
            import pydicom  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("pydicom is required: pip install pydicom") from exc

        files = self._collect_files(folder_or_files)
        slices: list[tuple[float, int, np.ndarray, Any, DicomSliceInfo]] = []
        skipped = 0
        for fp in files:
            try:
                ds = pydicom.dcmread(str(fp), stop_before_pixels=False, force=True)
                if not hasattr(ds, "PixelData"):
                    skipped += 1
                    continue
                arr = ds.pixel_array.astype(np.float32)
                slope = float(getattr(ds, "RescaleSlope", 1.0))
                intercept = float(getattr(ds, "RescaleIntercept", 0.0))
                hu = arr * slope + intercept
                inst = int(getattr(ds, "InstanceNumber", len(slices)))
                ipp = getattr(ds, "ImagePositionPatient", None)
                zpos = float(ipp[2]) if ipp is not None and len(ipp) >= 3 else float(inst)
                info = DicomSliceInfo(str(fp), inst, zpos, slope, intercept, int(hu.shape[0]), int(hu.shape[1]))
                slices.append((zpos, inst, hu, ds, info))
            except Exception:
                skipped += 1

        if not slices:
            raise RuntimeError("No readable DICOM slices with PixelData found")
        slices.sort(key=lambda item: (item[0], item[1]))

        shapes = {s[2].shape for s in slices}
        if len(shapes) != 1:
            raise RuntimeError(f"DICOM series has mixed matrix sizes: {sorted(shapes)}")

        volume = np.stack([s[2] for s in slices], axis=0).astype(np.float32)
        ds0 = slices[0][3]
        px = getattr(ds0, "PixelSpacing", [1.0, 1.0])
        sy, sx = float(px[0]), float(px[1])
        z_positions = np.array([s[0] for s in slices], dtype=float)
        dz = np.diff(z_positions)
        dz_nonzero = np.abs(dz[np.abs(dz) > 1e-5])
        if dz_nonzero.size:
            sz = float(np.median(dz_nonzero))
            z_source = "ImagePositionPatient median delta"
        else:
            sz = float(getattr(ds0, "SpacingBetweenSlices", getattr(ds0, "SliceThickness", 1.0)))
            z_source = "SpacingBetweenSlices/SliceThickness fallback"

        metadata = {
            "loader": "DicomSeriesLoaderClassic",
            "files_total": len(files),
            "slices_loaded": len(slices),
            "slices_skipped": skipped,
            "spacing_source_z": z_source,
            "slice_order_first": asdict(slices[0][4]),
            "slice_order_last": asdict(slices[-1][4]),
            "modality": str(getattr(ds0, "Modality", "")),
            "series_description": str(getattr(ds0, "SeriesDescription", "")),
            "rows": int(volume.shape[1]),
            "cols": int(volume.shape[2]),
        }
        return volume, (sz, sy, sx), metadata

    @staticmethod
    def _collect_files(folder_or_files: str | Path | Iterable[str | Path]) -> list[Path]:
        if isinstance(folder_or_files, (str, Path)):
            p = Path(folder_or_files)
            if p.is_dir():
                return sorted([x for x in p.rglob("*") if x.is_file()])
            return [p]
        return [Path(x) for x in folder_or_files]


class Hemorrhage3DClassicAnalyzer:
    def __init__(self, config: ClassicHemorrhageConfig | None = None):
        self.config = config or ClassicHemorrhageConfig()

    def detect_volume(self, volume_hu: np.ndarray, spacing_zyx_mm: tuple[float, float, float]) -> ClassicHemorrhageResult:
        if volume_hu is None or np.asarray(volume_hu).ndim != 3:
            raise ValueError("volume_hu must be a 3D array shaped (z, y, x)")
        v = np.asarray(volume_hu, dtype=np.float32)
        spacing = tuple(float(x) for x in spacing_zyx_mm)
        cfg = self.config
        notes: list[str] = []

        finite = np.isfinite(v)
        brain_soft = finite & (v >= cfg.brain_hu_min) & (v <= cfg.brain_hu_max)
        bone_mask = finite & (v >= cfg.bone_hu_min)
        raw_blood = finite & (v >= cfg.min_hu) & (v <= cfg.max_hu)

        intracranial = brain_soft
        if cfg.use_intracranial_mask:
            intracranial = self._largest_intracranial_region(brain_soft)
            if np.count_nonzero(intracranial) < max(500, int(0.005 * brain_soft.size)):
                notes.append("Intracranial mask was weak; falling back to full soft-tissue HU mask.")
                intracranial = brain_soft
            raw_blood = raw_blood & intracranial

        cleaned = self._clean_3d(raw_blood, cfg.morphology_iterations)
        filtered, components = self._filter_components(cleaned, spacing)

        if cfg.remove_midline_small_calcifications and np.any(filtered):
            filtered, removed = self._remove_tiny_midline_components(filtered, spacing, cfg.midline_band_mm)
            if removed:
                notes.append(f"Removed {removed} tiny midline HU components likely calcification/noise.")
            filtered, components = self._filter_components(filtered, spacing)

        voxel_count = int(np.count_nonzero(filtered))
        vol_ml = voxel_count * self._voxel_volume_ml(spacing)
        bbox_vox = self._bbox_voxels(filtered)
        bbox_mm = self._bbox_size_mm(bbox_vox, spacing) if bbox_vox else None
        com = self._center_of_mass(filtered)
        confidence = self._confidence(v, filtered, vol_ml, components)
        debug = {
            "hu_range": [cfg.min_hu, cfg.max_hu],
            "raw_candidate_voxels": int(np.count_nonzero(raw_blood)),
            "cleaned_voxels": int(np.count_nonzero(cleaned)),
            "final_voxels": voxel_count,
            "intracranial_voxels": int(np.count_nonzero(intracranial)),
            "bone_voxels": int(np.count_nonzero(bone_mask)),
            "voxel_volume_ml": self._voxel_volume_ml(spacing),
        }
        return ClassicHemorrhageResult(
            mask=filtered.astype(bool),
            brain_mask=intracranial.astype(bool),
            bone_mask=bone_mask.astype(bool),
            volume_ml=float(vol_ml),
            voxel_count=voxel_count,
            component_count=len(components),
            components=components,
            spacing_zyx_mm=spacing,
            bbox_voxels=bbox_vox,
            bbox_mm=bbox_mm,
            center_of_mass_voxels=com,
            confidence=confidence,
            notes=notes,
            debug=debug,
        )

    def detect_dicom_series(self, folder_or_files: str | Path | Iterable[str | Path]) -> tuple[ClassicHemorrhageResult, np.ndarray, dict[str, Any]]:
        volume, spacing, metadata = DicomSeriesLoaderClassic().load_dicom_series(folder_or_files)
        result = self.detect_volume(volume, spacing)
        return result, volume, metadata

    @staticmethod
    def _voxel_volume_ml(spacing: tuple[float, float, float]) -> float:
        return float(spacing[0] * spacing[1] * spacing[2]) / 1000.0

    @staticmethod
    def _largest_intracranial_region(mask: np.ndarray) -> np.ndarray:
        try:
            from scipy import ndimage as ndi  # type: ignore
            filled = ndi.binary_fill_holes(mask)
            st = ndi.generate_binary_structure(3, 1)
            filled = ndi.binary_opening(filled, structure=st, iterations=1)
            labels, n = ndi.label(filled, structure=st)
            if n <= 0:
                return mask
            counts = np.bincount(labels.ravel())
            counts[0] = 0
            main = labels == int(np.argmax(counts))
            main = ndi.binary_erosion(main, structure=st, iterations=1)
            return main.astype(bool)
        except Exception:
            return mask.astype(bool)

    @staticmethod
    def _clean_3d(mask: np.ndarray, iterations: int) -> np.ndarray:
        try:
            from scipy import ndimage as ndi  # type: ignore
            st = ndi.generate_binary_structure(3, 1)
            out = mask.astype(bool)
            if iterations > 0:
                out = ndi.binary_opening(out, structure=st, iterations=iterations)
                out = ndi.binary_closing(out, structure=st, iterations=iterations)
            out = ndi.binary_fill_holes(out)
            return out.astype(bool)
        except Exception:
            return mask.astype(bool)

    def _filter_components(self, mask: np.ndarray, spacing: tuple[float, float, float]) -> tuple[np.ndarray, list[dict[str, Any]]]:
        try:
            from scipy import ndimage as ndi  # type: ignore
            st = ndi.generate_binary_structure(3, 1)
            labels, n = ndi.label(mask.astype(bool), structure=st)
            if n <= 0:
                return mask & False, []
            voxel_ml = self._voxel_volume_ml(spacing)
            sizes_vox = np.bincount(labels.ravel())
            candidates: list[tuple[int, int, float]] = []
            for label_id in range(1, n + 1):
                vox = int(sizes_vox[label_id])
                ml = float(vox * voxel_ml)
                if self.config.min_component_ml <= ml <= self.config.max_component_ml:
                    candidates.append((label_id, vox, ml))
            candidates.sort(key=lambda item: item[2], reverse=True)
            candidates = candidates[: max(1, int(self.config.keep_components))]
            out = np.isin(labels, [c[0] for c in candidates]) if candidates else (mask & False)
            components = []
            for idx, (label_id, vox, ml) in enumerate(candidates, start=1):
                cm = labels == label_id
                bbox = self._bbox_voxels(cm)
                components.append({
                    "id": idx,
                    "label": int(label_id),
                    "voxels": int(vox),
                    "volume_ml": round(float(ml), 4),
                    "bbox_voxels": list(bbox) if bbox else None,
                    "bbox_mm": [round(float(x), 3) for x in self._bbox_size_mm(bbox, spacing)] if bbox else None,
                    "center_of_mass_voxels": [round(float(x), 3) for x in self._center_of_mass(cm)] if np.any(cm) else None,
                    "max_dimension_mm": round(float(max(self._bbox_size_mm(bbox, spacing) or (0.0, 0.0, 0.0))), 3) if bbox else 0.0,
                    "diameters_mm_zyx": [round(float(x), 3) for x in (self._bbox_size_mm(bbox, spacing) or (0.0, 0.0, 0.0))],
                    "axial_max_diameter_mm": round(float(self._max_axial_diameter_mm(cm, spacing)), 3),
                    "largest_slice_z": int(self._largest_slice_index(cm)),
                })
            return out.astype(bool), components
        except Exception:
            vox = int(np.count_nonzero(mask))
            ml = float(vox * self._voxel_volume_ml(spacing))
            keep = self.config.min_component_ml <= ml <= self.config.max_component_ml
            return (mask.astype(bool) if keep else (mask & False)), []

    def _remove_tiny_midline_components(self, mask: np.ndarray, spacing: tuple[float, float, float], band_mm: float) -> tuple[np.ndarray, int]:
        try:
            from scipy import ndimage as ndi  # type: ignore
            labels, n = ndi.label(mask)
            if n <= 0:
                return mask, 0
            cx = (mask.shape[2] - 1) / 2.0
            half_vox = max(1.0, float(band_mm) / max(spacing[2], 1e-6))
            out = mask.copy()
            removed = 0
            voxel_ml = self._voxel_volume_ml(spacing)
            for label_id in range(1, n + 1):
                comp = labels == label_id
                vox = int(np.count_nonzero(comp))
                if vox == 0:
                    continue
                zz, yy, xx = np.where(comp)
                near_midline = abs(float(np.mean(xx)) - cx) <= half_vox
                very_small = (vox * voxel_ml) < max(0.05, self.config.min_component_ml * 0.5)
                if near_midline and very_small:
                    out[comp] = False
                    removed += 1
            return out.astype(bool), removed
        except Exception:
            return mask, 0

    @staticmethod
    def _bbox_voxels(mask: np.ndarray) -> tuple[int, int, int, int, int, int] | None:
        if not np.any(mask):
            return None
        z, y, x = np.where(mask)
        return int(z.min()), int(z.max()), int(y.min()), int(y.max()), int(x.min()), int(x.max())

    @staticmethod
    def _bbox_size_mm(bbox: tuple[int, int, int, int, int, int] | None, spacing: tuple[float, float, float]) -> tuple[float, float, float] | None:
        if not bbox:
            return None
        z0, z1, y0, y1, x0, x1 = bbox
        return ((z1 - z0 + 1) * spacing[0], (y1 - y0 + 1) * spacing[1], (x1 - x0 + 1) * spacing[2])

    @staticmethod
    def _center_of_mass(mask: np.ndarray) -> tuple[float, float, float] | None:
        if not np.any(mask):
            return None
        coords = np.argwhere(mask)
        mean = coords.mean(axis=0)
        return float(mean[0]), float(mean[1]), float(mean[2])

    @staticmethod
    def _largest_slice_index(mask: np.ndarray) -> int:
        if not np.any(mask):
            return -1
        per_z = np.count_nonzero(mask, axis=(1, 2))
        return int(np.argmax(per_z))

    @staticmethod
    def _max_axial_diameter_mm(mask: np.ndarray, spacing: tuple[float, float, float]) -> float:
        """Approximate maximum in-plane diameter on the largest axial slice.

        Uses the component bounding rectangle on the slice with most voxels. It is
        deterministic and fast; exact caliper distance can be added later.
        """
        if not np.any(mask):
            return 0.0
        z = Hemorrhage3DClassicAnalyzer._largest_slice_index(mask)
        sl = mask[z]
        yy, xx = np.where(sl)
        if yy.size == 0:
            return 0.0
        dy = (float(yy.max() - yy.min() + 1) * float(spacing[1]))
        dx = (float(xx.max() - xx.min() + 1) * float(spacing[2]))
        return float(math.hypot(dx, dy))

    @staticmethod
    def measurement_summary(result: ClassicHemorrhageResult) -> str:
        dims = result.bbox_mm or (0.0, 0.0, 0.0)
        main = result.components[0] if result.components else {}
        axial = float(main.get("axial_max_diameter_mm", 0.0) or 0.0)
        return (
            f"Крововилив: {result.volume_ml:.2f} мл | "
            f"розміри Z/Y/X: {dims[0]:.1f} × {dims[1]:.1f} × {dims[2]:.1f} мм | "
            f"max: {max(dims):.1f} мм | axial: {axial:.1f} мм | "
            f"компоненти: {result.component_count}"
        )

    @staticmethod
    def _confidence(volume_hu: np.ndarray, mask: np.ndarray, volume_ml: float, components: list[dict[str, Any]]) -> float:
        if not np.any(mask) or volume_ml <= 0:
            return 0.0
        vals = volume_hu[mask]
        if vals.size == 0:
            return 0.0
        mean = float(np.mean(vals))
        center_score = max(0.0, 1.0 - abs(mean - 70.0) / 45.0)
        volume_score = min(1.0, volume_ml / 5.0) if volume_ml < 5 else 1.0
        component_penalty = max(0.35, 1.0 - 0.04 * max(0, len(components) - 1))
        return float(np.clip(0.15 + 0.55 * center_score + 0.25 * volume_score, 0.0, 1.0) * component_penalty)


class DicomViewDiagnosticsClassic:
    @staticmethod
    def apply_window(hu_image: np.ndarray, window_center: float, window_width: float) -> np.ndarray:
        arr = np.asarray(hu_image, dtype=np.float32)
        ww = max(float(window_width), 1.0)
        wc = float(window_center)
        lo = wc - ww / 2.0
        hi = wc + ww / 2.0
        out = np.clip(arr, lo, hi)
        out = (out - lo) / (hi - lo) * 255.0
        return np.clip(out, 0, 255).astype(np.uint8)

    @staticmethod
    def analyze_brain_asymmetry_slice(hu_image: np.ndarray, threshold: int = 35) -> np.ndarray:
        brain = DicomViewDiagnosticsClassic.apply_window(hu_image, 40, 80)
        h, w = brain.shape
        # Estimate head center from non-air pixels instead of blindly using image center.
        tissue = np.asarray(hu_image) > -50
        if np.count_nonzero(tissue) > 50:
            _, xs = np.where(tissue)
            mid_x = int(round((float(xs.min()) + float(xs.max())) / 2.0))
        else:
            mid_x = w // 2
        half = min(mid_x, w - mid_x)
        if half <= 2:
            return np.zeros_like(brain, dtype=np.uint8)
        left = brain[:, mid_x - half:mid_x]
        right = brain[:, mid_x:mid_x + half]
        diff = np.abs(left.astype(np.int16) - np.fliplr(right).astype(np.int16))
        diff[diff < int(threshold)] = 0
        full = np.zeros_like(brain, dtype=np.uint8)
        full[:, mid_x - half:mid_x] = np.clip(diff, 0, 255).astype(np.uint8)
        full[:, mid_x:mid_x + half] = np.fliplr(np.clip(diff, 0, 255).astype(np.uint8))
        return full

    @staticmethod
    def analyze_brain_asymmetry_volume(volume_hu: np.ndarray, threshold: int = 35) -> np.ndarray:
        v = np.asarray(volume_hu)
        if v.ndim != 3:
            raise ValueError("volume_hu must be 3D")
        return np.stack([DicomViewDiagnosticsClassic.analyze_brain_asymmetry_slice(v[z], threshold) for z in range(v.shape[0])], axis=0)

    @staticmethod
    def max_projection_uint8(mask_or_map: np.ndarray) -> np.ndarray:
        arr = np.asarray(mask_or_map)
        if arr.ndim == 3:
            proj = arr.max(axis=0)
        else:
            proj = arr
        if proj.dtype == bool:
            return (proj.astype(np.uint8) * 255)
        return np.clip(proj, 0, 255).astype(np.uint8)


def save_classic_result_json(result: ClassicHemorrhageResult, out_path: str | Path) -> Path:
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result.to_json_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return path
