from __future__ import annotations

"""Scanner/series-aware visualization profile engine for DicomView PRO.

The goal is deliberately conservative: read DICOM metadata, estimate how good
2D/MPR/3D can be for the current series, and recommend display-only viewer
settings.  It never changes HU values used for measurements or reports.
"""

from dataclasses import dataclass, asdict
from typing import Any, Mapping
try:
    from .scanner_kernel_db import get_kernel_profile, KernelProfile
except Exception:  # pragma: no cover
    get_kernel_profile = None
    KernelProfile = None


@dataclass(frozen=True)
class ScannerProfile:
    manufacturer: str
    model: str
    kernel: str
    modality: str
    body_part: str
    series_description: str
    slice_thickness_mm: float
    spacing_z_mm: float
    spacing_y_mm: float
    spacing_x_mm: float
    anisotropy_ratio: float
    quality_label: str
    quality_score: int
    quality_reason_ua: str
    anatomy_profile: str
    recommended_window_center: float
    recommended_window_width: float
    recommended_mpr_quality: str
    recommended_slab_slices: int
    recommended_3d_preset: str
    vendor_kernel_category: str = "unknown"
    vendor_kernel_sharpness: int = 5
    vendor_kernel_noise: int = 5
    vendor_suggested_sharpen: str = "brain_fidelity_pro"
    vendor_denoise_strength: float = 0.5
    vendor_kernel_note_ua: str = ""
    warning_ua: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def short_text_ua(self) -> str:
        maker = self.manufacturer or "невідомий апарат"
        model = f" {self.model}" if self.model else ""
        return (
            f"{self.quality_label} · {self.quality_score}% · "
            f"{self.anatomy_profile} · {maker}{model} · "
            f"spacing Z/Y/X {self.spacing_z_mm:.3g}/{self.spacing_y_mm:.3g}/{self.spacing_x_mm:.3g} мм"
        )

    def detail_text_ua(self) -> str:
        lines = [
            f"Якість серії: {self.quality_label} ({self.quality_score}%)",
            f"Причина: {self.quality_reason_ua}",
            f"Апарат: {self.manufacturer or '—'} {self.model or ''}".strip(),
            f"Kernel/реконструкція: {self.kernel or '—'}",
            f"Профіль kernel: {self.vendor_kernel_category} · sharp {self.vendor_kernel_sharpness}/10 · noise {self.vendor_kernel_noise}/10",
            f"Профіль: {self.anatomy_profile}",
            f"Рекомендоване 2D: WL {self.recommended_window_center:.0f} / WW {self.recommended_window_width:.0f}",
            f"MPR: {self.recommended_mpr_quality}, slab {self.recommended_slab_slices}",
            f"3D: {self.recommended_3d_preset}",
        ]
        if self.warning_ua:
            lines.append(f"Увага: {self.warning_ua}")
        return "\n".join(lines)


def _first(metadata: Mapping[str, Any], *keys: str, default: str = "") -> str:
    tags = metadata.get("tags", {}) if isinstance(metadata, Mapping) else {}
    for key in keys:
        val = metadata.get(key) if isinstance(metadata, Mapping) else None
        if val not in (None, ""):
            return str(val)
        if isinstance(tags, Mapping):
            val = tags.get(key)
            if val not in (None, ""):
                return str(val)
    return default


def _float(value: Any, default: float = 0.0) -> float:
    try:
        if isinstance(value, (list, tuple)):
            value = value[0]
        return float(value)
    except Exception:
        return float(default)


def _spacing(metadata: Mapping[str, Any]) -> tuple[float, float, float]:
    sp = metadata.get("spacing") if isinstance(metadata, Mapping) else None
    if isinstance(sp, (list, tuple)) and len(sp) >= 3:
        return max(_float(sp[0], 1.0), 1e-6), max(_float(sp[1], 1.0), 1e-6), max(_float(sp[2], 1.0), 1e-6)
    pix = metadata.get("pixel_spacing") if isinstance(metadata, Mapping) else None
    sy = sx = 1.0
    if isinstance(pix, (list, tuple)) and len(pix) >= 2:
        sy, sx = _float(pix[0], 1.0), _float(pix[1], 1.0)
    z = _float(metadata.get("slice_spacing") or metadata.get("SliceThickness") or metadata.get("slice_thickness"), 1.0)
    return max(z, 1e-6), max(sy, 1e-6), max(sx, 1e-6)


def _detect_anatomy(metadata: Mapping[str, Any]) -> str:
    text = " ".join(
        _first(metadata, k) for k in (
            "series_description", "SeriesDescription", "protocol_name", "ProtocolName",
            "body_part", "BodyPartExamined", "convolution_kernel", "ConvolutionKernel"
        )
    ).lower()
    if any(w in text for w in ("lung", "chest", "thorax", "hrct", "леген", "груд")):
        return "Lung/Thorax"
    if any(w in text for w in ("bone", "spine", "skull", "trauma", "b70", "br64", "кіст", "травм")):
        return "Trauma/Bone"
    if any(w in text for w in ("angio", "cta", "contrast", "arter", "ven", "суд", "ангі")):
        return "CTA/Angio"
    if any(w in text for w in ("brain", "head", "head brain", "cerebr", "b30", "b31", "моз", "голов")):
        return "Brain CT"
    if any(w in text for w in ("abd", "liver", "kidney", "pelvis", "черев", "живіт", "печін")):
        return "Abdomen"
    return "General CT"


def _recommend_window(anatomy: str) -> tuple[float, float]:
    if anatomy == "Brain CT":
        return 35.0, 100.0
    if anatomy == "Lung/Thorax":
        return -600.0, 1500.0
    if anatomy == "Trauma/Bone":
        return 500.0, 2000.0
    if anatomy == "CTA/Angio":
        return 250.0, 700.0
    if anatomy == "Abdomen":
        return 50.0, 400.0
    return 40.0, 400.0


def _recommend_3d(anatomy: str) -> str:
    return {
        "Brain CT": "Classic Hospital / Soft Tissue",
        "Lung/Thorax": "Classic Lung",
        "Trauma/Bone": "Classic Bone",
        "CTA/Angio": "Angio MIP",
        "Abdomen": "Classic Soft Tissue",
    }.get(anatomy, "Classic Hospital")


def _quality(spacing_z: float, spacing_y: float, spacing_x: float, shape: tuple[int, ...] | None) -> tuple[str, int, str, str, int]:
    inplane = max(min(spacing_y, spacing_x), 1e-6)
    ratio = spacing_z / inplane
    slices = int(shape[0]) if shape and len(shape) >= 3 else 0
    reasons: list[str] = []
    warning = ""
    if spacing_z <= 0.8 and ratio <= 1.6 and slices >= 150:
        return "Excellent", 92, "тонкі майже ізотропні зрізи, придатні для якісного MPR/3D", warning, 3
    if spacing_z <= 1.5 and ratio <= 2.5 and slices >= 80:
        return "Good", 80, "достатньо тонкі зрізи; рекомендовано Fidelity MPR", warning, 3
    if spacing_z <= 3.0:
        warning = "помірна неізотропність; для 3D можливі сходинки, потрібне згладжування"
        return "Limited", 62, "товщина зрізу обмежує coronal/sagittal та 3D", warning, 5
    warning = "товсті зрізи; дрібні деталі в 3D/MPR можуть бути недостовірними"
    return "Poor", 42, "дуже товсті або неізотропні зрізи; потрібне обережне трактування", warning, 7


def analyze_scanner_profile(metadata: Mapping[str, Any] | None, volume_shape: tuple[int, ...] | None = None) -> ScannerProfile:
    md: Mapping[str, Any] = metadata or {}
    zsp, ysp, xsp = _spacing(md)
    anatomy = _detect_anatomy(md)
    quality_label, quality_score, reason, warning, slab = _quality(zsp, ysp, xsp, volume_shape)
    wc, ww = _recommend_window(anatomy)
    manufacturer = _first(md, "manufacturer", "Manufacturer")
    model = _first(md, "model_name", "ManufacturerModelName", "model")
    kernel = _first(md, "convolution_kernel", "ConvolutionKernel", "kernel")
    kp = get_kernel_profile(manufacturer, kernel, model) if get_kernel_profile is not None else None
    if kp is not None:
        if kp.window_center is not None and kp.window_width is not None:
            # Use vendor/kernel WL only when anatomy detection does not strongly override it.
            if anatomy in ("General CT", "Trauma/Bone", "Lung/Thorax"):
                wc, ww = float(kp.window_center), float(kp.window_width)
        recommended_3d = kp.recommended_3d_preset or _recommend_3d(anatomy)
        vendor_category = kp.category
        vendor_sharpness = kp.sharpness
        vendor_noise = kp.noise
        vendor_sharpen = kp.default_sharpen
        vendor_denoise = kp.denoise_strength
        vendor_note = kp.note_ua
    else:
        recommended_3d = _recommend_3d(anatomy)
        vendor_category = "unknown"; vendor_sharpness = 5; vendor_noise = 5
        vendor_sharpen = "brain_fidelity_pro"; vendor_denoise = 0.5; vendor_note = ""
    inplane = max(min(ysp, xsp), 1e-6)
    ratio = zsp / inplane
    return ScannerProfile(
        manufacturer=manufacturer,
        model=model,
        kernel=kernel,
        vendor_kernel_category=vendor_category,
        vendor_kernel_sharpness=int(vendor_sharpness),
        vendor_kernel_noise=int(vendor_noise),
        vendor_suggested_sharpen=str(vendor_sharpen),
        vendor_denoise_strength=float(vendor_denoise),
        vendor_kernel_note_ua=vendor_note,
        modality=_first(md, "modality", "Modality"),
        body_part=_first(md, "body_part", "BodyPartExamined"),
        series_description=_first(md, "series_description", "SeriesDescription"),
        slice_thickness_mm=_float(md.get("slice_thickness") or md.get("SliceThickness") or zsp, zsp),
        spacing_z_mm=float(zsp), spacing_y_mm=float(ysp), spacing_x_mm=float(xsp),
        anisotropy_ratio=float(ratio),
        quality_label=quality_label, quality_score=int(quality_score), quality_reason_ua=reason,
        anatomy_profile=anatomy,
        recommended_window_center=wc, recommended_window_width=ww,
        recommended_mpr_quality="Fidelity Max" if quality_score >= 60 else "Adaptive Smooth",
        recommended_slab_slices=int(slab),
        recommended_3d_preset=recommended_3d,
        warning_ua=warning,
    )
