from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json, logging, math, os, time
import numpy as np
import pydicom
try:
    from dicomview_pro.runtime.memory_budget import dicom_cache_budget_bytes, human_bytes
except Exception:
    dicom_cache_budget_bytes = None
    human_bytes = None
try:
    from pydicom.pixel_data_handlers.util import apply_modality_lut
except Exception:
    apply_modality_lut = None

log = logging.getLogger(__name__)
try:
    from .dicom_validation import validate_dataset
except Exception:
    validate_dataset = None

@dataclass
class SeriesInfo:
    uid: str
    description: str
    modality: str
    patient: str
    count: int
    files: list[str]
    is_cine: bool = False
    frames: int = 0
    fps: float = 0.0

@dataclass
class LoadedVolume:
    volume_path: str
    metadata_path: str
    shape: tuple[int, int, int]
    spacing: tuple[float, float, float]
    series_uid: str
    series_description: str
    modality: str
    patient: str
    tags: dict[str, str]


def _dicomdir_referenced_files(dicomdir: Path) -> list[Path]:
    """Return file paths referenced by a DICOMDIR file.

    DICOMDIR stores paths as components in ReferencedFileID.  This helper keeps
    the reader compatible with hospital CDs where images may not use .dcm
    extensions and may live in nested folders.
    """
    files: list[Path] = []
    try:
        ds = pydicom.dcmread(str(dicomdir), force=True)
        base = dicomdir.parent
        for rec in getattr(ds, "DirectoryRecordSequence", []) or []:
            ref = getattr(rec, "ReferencedFileID", None)
            if not ref:
                continue
            if isinstance(ref, (list, tuple)):
                parts = [str(x) for x in ref]
            else:
                parts = str(ref).replace("\\", os.sep).replace("/", os.sep).split(os.sep)
            candidate = base.joinpath(*[p for p in parts if p])
            if candidate.exists() and candidate.is_file():
                files.append(candidate)
    except Exception as exc:
        log.warning("DICOMDIR parse failed %s: %s", dicomdir, exc)
    # Deduplicate preserving order
    seen: set[str] = set()
    out: list[Path] = []
    for f in files:
        key = str(f.resolve()).lower()
        if key not in seen:
            seen.add(key); out.append(f)
    return out

def _is_dicom_candidate(p: Path) -> bool:
    if not p.is_file() or p.name.upper() == "DICOMDIR":
        return False
    if p.suffix.lower() in {".dcm", ".dicom", ".ima"}:
        return True
    if p.suffix == "":
        try:
            with p.open("rb") as f:
                head = f.read(132)
            return len(head) >= 132 and head[128:132] == b"DICM"
        except Exception:
            return False
    return False

def scan_files(path: str | Path) -> list[Path]:
    p = Path(path)
    if p.is_file():
        if p.name.upper() == "DICOMDIR":
            return _dicomdir_referenced_files(p)
        return [p] if _is_dicom_candidate(p) else []
    files: list[Path] = []
    dicomdir = p / "DICOMDIR"
    if dicomdir.exists():
        # Hospital media often reference extensionless files from DICOMDIR.
        # Trust DICOMDIR and do not rglob the whole disc again: this avoids
        # duplicate reads and accidental inclusion of non-DICOM files.
        files.extend(_dicomdir_referenced_files(dicomdir))
    else:
        files.extend([x for x in p.rglob("*") if _is_dicom_candidate(x)])
    seen: set[str] = set()
    out: list[Path] = []
    for f in files:
        key = str(f.resolve()).lower()
        if key not in seen:
            seen.add(key); out.append(f)
    return out

def _safe_str(v: Any, limit: int = 180) -> str:
    try:
        s = str(v)
    except Exception:
        s = ""
    return s[:limit]

def scan_series(path: str | Path) -> list[SeriesInfo]:
    t0 = time.perf_counter()
    groups: dict[str, list[Path]] = {}
    preview: dict[str, dict[str, str]] = {}
    cine_frames: dict[str, int] = {}
    cine_fps: dict[str, float] = {}
    for f in scan_files(path):
        try:
            ds = pydicom.dcmread(str(f), stop_before_pixels=True, force=True)
            uid = _safe_str(getattr(ds, "SeriesInstanceUID", "NO_SERIES_UID")) or "NO_SERIES_UID"
            groups.setdefault(uid, []).append(f)
            preview.setdefault(uid, {
                "description": _safe_str(getattr(ds, "SeriesDescription", "")),
                "modality": _safe_str(getattr(ds, "Modality", "")),
                "patient": _safe_str(getattr(ds, "PatientName", "")),
            })
            try:
                nf = int(getattr(ds, "NumberOfFrames", 0) or 0)
            except Exception:
                nf = 0
            cine_frames[uid] = cine_frames.get(uid, 0) + max(nf, 0)
            try:
                fps = float(getattr(ds, "CineRate", 0) or getattr(ds, "RecommendedDisplayFrameRate", 0) or 0)
                if fps <= 0:
                    ft = float(getattr(ds, "FrameTime", 0) or 0)
                    fps = 1000.0 / ft if ft > 0 else 0.0
            except Exception:
                fps = 0.0
            if fps > 0:
                cine_fps[uid] = fps
        except Exception as exc:
            log.warning("Skip non-readable DICOM %s: %s", f, exc)
    result = []
    for uid, files in groups.items():
        meta = preview.get(uid, {})
        modality = meta.get("modality", "")
        frames = cine_frames.get(uid, 0)
        is_cine = modality.upper() in {"XA", "XRF", "RF"} or frames > len(files)
        result.append(SeriesInfo(uid, meta.get("description", ""), modality, meta.get("patient", ""), len(files), [str(x) for x in files], is_cine, frames, cine_fps.get(uid, 0.0)))
    result.sort(key=lambda s: s.count, reverse=True)
    try:
        log.info("Fast DICOM scan completed: %d series from %s in %.2fs; PixelData not decoded", len(result), path, time.perf_counter() - t0)
    except Exception:
        pass
    return result

def _slice_position(ds: Any, fallback: int, frame_index: int = 0) -> float:
    """Return physical slice position along the acquisition normal.

    Older builds used only ImagePositionPatient[2]. That works for axial CT,
    but breaks coronal/sagittal reformats because Z may barely change while
    the real slice step is along X or Y.  Using ImageOrientationPatient gives
    the patient-space normal and keeps 3D proportions correct for axial,
    coronal and sagittal series.
    """
    eps = frame_index * 1e-7
    try:
        ipp = getattr(ds, "ImagePositionPatient", None)
        iop = getattr(ds, "ImageOrientationPatient", None)
        if ipp and len(ipp) >= 3 and iop and len(iop) >= 6:
            row = np.array([float(iop[0]), float(iop[1]), float(iop[2])], dtype=float)
            col = np.array([float(iop[3]), float(iop[4]), float(iop[5])], dtype=float)
            normal = np.cross(row, col)
            n = np.linalg.norm(normal)
            if n > 0:
                normal = normal / n
                pos = np.array([float(ipp[0]), float(ipp[1]), float(ipp[2])], dtype=float)
                return float(np.dot(pos, normal)) + eps
        if ipp and len(ipp) >= 3:
            return float(ipp[2]) + eps
    except Exception:
        pass
    try:
        return float(getattr(ds, "SliceLocation")) + eps
    except Exception:
        pass
    try:
        return float(getattr(ds, "InstanceNumber")) + eps
    except Exception:
        return float(fallback) + eps

def _spacing(ds_list: list[Any], positions: list[float]) -> tuple[float, float, float]:
    first = ds_list[0]
    try:
        row, col = [float(x) for x in getattr(first, "PixelSpacing", [1.0, 1.0])[:2]]
    except Exception:
        row, col = 1.0, 1.0
    z = 0.0
    # Use sorted unique physical positions and only positive gaps.  This keeps
    # accidental non-monotonic DICOM ordering from underestimating slice spacing.
    unique = sorted(set(round(float(x), 6) for x in positions if math.isfinite(float(x))))
    if len(unique) >= 2:
        diffs = np.diff(np.asarray(unique, dtype=float))
        positive = [float(d) for d in diffs if math.isfinite(float(d)) and float(d) > 1e-6]
        if positive:
            z = float(np.median(positive))
    if not math.isfinite(z) or z <= 0:
        for key in ("SpacingBetweenSlices", "SliceThickness"):
            try:
                candidate = abs(float(getattr(first, key)))
                if math.isfinite(candidate) and candidate > 0:
                    z = candidate
                    break
            except Exception:
                pass
    if not math.isfinite(z) or z <= 0:
        z = 1.0
    return (z, row, col)

def load_series_to_runtime(path: str | Path, out_dir: str | Path, series_uid: str | None = None) -> LoadedVolume:
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    all_series = scan_series(path)
    if not all_series:
        raise RuntimeError("DICOM файли не знайдено або не читаються")
    selected = next((s for s in all_series if s.uid == series_uid), all_series[0])
    try:
        log.info("Loading selected DICOM series only: uid=%s files=%d", selected.uid, len(selected.files))
    except Exception:
        pass
    frames: list[tuple[float, np.ndarray, Any]] = []
    ds_for_spacing: list[Any] = []
    errors: list[str] = []
    for idx, file_name in enumerate(selected.files):
        try:
            ds = pydicom.dcmread(file_name, force=True)
            if validate_dataset is not None:
                vr = validate_dataset(ds, require_pixels=True)
                for w in vr.warnings:
                    errors.append(f"{file_name}: WARNING: {w}")
                    log.warning("DICOM validation warning %s: %s", file_name, w)
                if not vr.ok:
                    raise RuntimeError("; ".join(vr.errors))
            arr = ds.pixel_array
            # DICOM medical rendering pipeline starts with Modality LUT.
            # For CT this converts stored pixels to HU.  Fallback keeps the
            # explicit RescaleSlope/Intercept path when LUT support is absent.
            try:
                if apply_modality_lut is not None:
                    arr = apply_modality_lut(arr, ds)
                else:
                    slope = float(getattr(ds, "RescaleSlope", 1.0) or 1.0)
                    intercept = float(getattr(ds, "RescaleIntercept", 0.0) or 0.0)
                    arr = arr.astype(np.float32) * slope + intercept
            except Exception:
                slope = float(getattr(ds, "RescaleSlope", 1.0) or 1.0)
                intercept = float(getattr(ds, "RescaleIntercept", 0.0) or 0.0)
                arr = arr.astype(np.float32) * slope + intercept
            if arr.ndim == 2:
                img = arr.astype(np.float32)
                frames.append((_slice_position(ds, idx), img, ds))
                ds_for_spacing.append(ds)
            elif arr.ndim == 3:
                # Multi-frame XA/RF/cine files are one DICOM object with time frames,
                # not separate spatial slices.  Do not feed micro-offset frame
                # positions into z-spacing estimation.
                for fi in range(arr.shape[0]):
                    img = arr[fi].astype(np.float32)
                    frames.append((_slice_position(ds, idx, fi), img, ds))
                if not str(getattr(ds, "Modality", "")).upper() in {"XA", "XRF", "RF"}:
                    ds_for_spacing.append(ds)
        except Exception as exc:
            errors.append(f"{file_name}: {exc}")
    if not frames:
        detail = "\n".join(errors[:5])
        raise RuntimeError("Не вдалося декодувати PixelData. Можливо, потрібен JPEG/JPEG2000 decoder.\n" + detail)
    frames.sort(key=lambda x: x[0])
    shapes = [f[1].shape for f in frames]
    common_shape = max(set(shapes), key=shapes.count)
    dropped_shape_count = sum(1 for f in frames if f[1].shape != common_shape)
    if dropped_shape_count:
        msg = f"Відкинуто {dropped_shape_count} DICOM-кадрів з нестандартним розміром; використано common_shape={common_shape}"
        errors.append(msg)
        log.warning(msg)
    frames = [f for f in frames if f[1].shape == common_shape]
    volume = np.stack([f[1] for f in frames]).astype(np.float32)
    positions = [f[0] for f in frames]
    spacing = _spacing(ds_for_spacing or [frames[0][2]], positions)
    ds0 = frames[0][2]
    def _float_values_tag(name: str) -> list[float]:
        try:
            v = getattr(ds0, name, None)
            if v is None:
                return []
            if isinstance(v, (str, bytes)):
                vals = [v]
            else:
                try:
                    vals = list(v)
                except TypeError:
                    vals = [v]
            out_vals: list[float] = []
            for item in vals:
                try:
                    f = float(item)
                    if math.isfinite(f):
                        out_vals.append(f)
                except Exception:
                    continue
            return out_vals
        except Exception:
            return []
    dicom_window_center_values = _float_values_tag("WindowCenter")
    dicom_window_width_values = _float_values_tag("WindowWidth")
    dicom_window_center = dicom_window_center_values[0] if dicom_window_center_values else None
    dicom_window_width = dicom_window_width_values[0] if dicom_window_width_values else None
    if len(dicom_window_center_values) > 1 or len(dicom_window_width_values) > 1:
        log.warning("DICOM contains multiple window presets: centers=%s widths=%s; defaulting to first preset", dicom_window_center_values, dicom_window_width_values)
    photometric = _safe_str(getattr(ds0, "PhotometricInterpretation", ""))
    presentation_lut = _safe_str(getattr(ds0, "PresentationLUTShape", ""))
    invert_display = photometric.upper() == "MONOCHROME1" or presentation_lut.upper() == "INVERSE"
    patient_name = _safe_str(getattr(ds0, "PatientName", selected.patient)) or selected.patient
    patient_id = _safe_str(getattr(ds0, "PatientID", ""))
    patient_birth_date = _safe_str(getattr(ds0, "PatientBirthDate", ""))
    patient_sex = _safe_str(getattr(ds0, "PatientSex", ""))
    patient_age = _safe_str(getattr(ds0, "PatientAge", ""))
    study_date = _safe_str(getattr(ds0, "StudyDate", ""))
    study_time = _safe_str(getattr(ds0, "StudyTime", ""))
    study_description = _safe_str(getattr(ds0, "StudyDescription", ""))
    accession_number = _safe_str(getattr(ds0, "AccessionNumber", ""))
    tags = {}
    for elem in ds0:
        if elem.VR == "SQ":
            continue
        tags[f"{elem.tag} {elem.keyword or elem.name}"] = _safe_str(elem.value, 300)
    try:
        _cache_budget = dicom_cache_budget_bytes(volume.nbytes) if dicom_cache_budget_bytes else int(volume.nbytes)
        _cache_budget_text = human_bytes(_cache_budget) if human_bytes else str(_cache_budget)
    except Exception:
        _cache_budget = int(volume.nbytes)
        _cache_budget_text = str(_cache_budget)
    metadata = {
        "shape": list(volume.shape),
        "volume_bytes": int(volume.nbytes),
        "cache_budget_bytes": int(_cache_budget),
        "cache_budget_text": _cache_budget_text,
        "cache_policy": "Lite adaptive RAM cache: 10/20/30/40% of available RAM by study size",
        "spacing": list(spacing),
        "series_uid": selected.uid,
        "series_description": selected.description,
        "modality": selected.modality,
        "patient": patient_name,
        "patient_name": patient_name,
        "patient_id": patient_id,
        "patient_birth_date": patient_birth_date,
        "patient_sex": patient_sex,
        "patient_age": patient_age,
        "study_date": study_date,
        "study_time": study_time,
        "study_description": study_description,
        "accession_number": accession_number,
        "tags": tags,
        "available_series": [asdict(s) for s in all_series],
        "decode_errors": errors[:50],
        "is_cine": selected.is_cine,
        "cine_frames": selected.frames or int(volume.shape[0]),
        "cine_fps": selected.fps,
        "dicom_window_center": dicom_window_center,
        "dicom_window_width": dicom_window_width,
        "dicom_window_center_values": dicom_window_center_values,
        "dicom_window_width_values": dicom_window_width_values,
        "photometric_interpretation": photometric,
        "presentation_lut_shape": presentation_lut,
        "invert_display": invert_display,
    }
    volume_path = out / "active_volume.npy"
    metadata_path = out / "active_metadata.json"
    np.save(volume_path, np.ascontiguousarray(volume))
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return LoadedVolume(str(volume_path), str(metadata_path), tuple(volume.shape), spacing, selected.uid, selected.description, selected.modality, selected.patient, tags)
