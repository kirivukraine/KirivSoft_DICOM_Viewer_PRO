from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json, urllib.parse, urllib.request, urllib.error

@dataclass(frozen=True)
class OrthancConfig:
    url: str = "http://127.0.0.1:8042"
    username: str = ""
    password: str = ""
    timeout: float = 10.0

@dataclass(frozen=True)
class OrthancResult:
    ok: bool
    message: str
    data: Any = None

class OrthancClient:
    """Small REST client for local Orthanc integration.

    The client intentionally uses Python stdlib only so the desktop viewer can
    keep working even when the optional `requests` package is not installed.
    """
    def __init__(self, cfg: OrthancConfig):
        self.cfg = cfg
        self.base = cfg.url.rstrip('/')

    def _request(self, method: str, path: str, body: bytes | None = None, headers: dict[str, str] | None = None) -> Any:
        url = self.base + path
        req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
        if self.cfg.username:
            import base64
            token = base64.b64encode(f"{self.cfg.username}:{self.cfg.password}".encode()).decode()
            req.add_header("Authorization", "Basic " + token)
        try:
            with urllib.request.urlopen(req, timeout=self.cfg.timeout) as r:
                raw = r.read()
                if not raw:
                    return None
                ctype = r.headers.get('Content-Type','')
                if 'json' in ctype or raw[:1] in (b'{', b'['):
                    return json.loads(raw.decode('utf-8', errors='replace'))
                return raw
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Orthanc недоступний: {exc}") from exc

    def system(self) -> OrthancResult:
        try:
            return OrthancResult(True, "Orthanc відповідає", self._request('GET', '/system'))
        except Exception as exc:
            return OrthancResult(False, str(exc))

    def patients(self) -> OrthancResult:
        try:
            ids = self._request('GET', '/patients') or []
            return OrthancResult(True, f"Знайдено пацієнтів: {len(ids)}", ids)
        except Exception as exc:
            return OrthancResult(False, str(exc), [])

    def studies(self) -> OrthancResult:
        try:
            ids = self._request('GET', '/studies') or []
            data = []
            for sid in ids[:200]:
                try:
                    data.append(self._request('GET', '/studies/' + urllib.parse.quote(str(sid))))
                except Exception:
                    data.append({'ID': sid})
            return OrthancResult(True, f"Знайдено досліджень: {len(ids)}", data)
        except Exception as exc:
            return OrthancResult(False, str(exc), [])


    def patient_details(self, patient_id: str) -> OrthancResult:
        try:
            data = self._request('GET', '/patients/' + urllib.parse.quote(str(patient_id)))
            return OrthancResult(True, 'Пацієнта отримано', data)
        except Exception as exc:
            return OrthancResult(False, str(exc))

    def study_details(self, study_id: str) -> OrthancResult:
        try:
            data = self._request('GET', '/studies/' + urllib.parse.quote(str(study_id)))
            return OrthancResult(True, 'Дослідження отримано', data)
        except Exception as exc:
            return OrthancResult(False, str(exc))

    def series_details(self, series_id: str) -> OrthancResult:
        try:
            data = self._request('GET', '/series/' + urllib.parse.quote(str(series_id)))
            return OrthancResult(True, 'Серію отримано', data)
        except Exception as exc:
            return OrthancResult(False, str(exc))

    def search_studies_by_patient_name(self, name: str) -> OrthancResult:
        try:
            query = {'Level': 'Study', 'Query': {'PatientName': name or '*'}}
            body = json.dumps(query).encode('utf-8')
            ids = self._request('POST', '/tools/find', body, {'Content-Type': 'application/json'}) or []
            data = []
            for sid in ids[:200]:
                try:
                    data.append(self._request('GET', '/studies/' + urllib.parse.quote(str(sid))))
                except Exception:
                    data.append({'ID': sid})
            return OrthancResult(True, f'Знайдено досліджень: {len(ids)}', data)
        except Exception as exc:
            return OrthancResult(False, str(exc), [])

    def upload_file(self, file_path: str | Path) -> OrthancResult:
        p = Path(file_path)
        try:
            raw = p.read_bytes()
            data = self._request('POST', '/instances', raw, {'Content-Type': 'application/dicom'})
            return OrthancResult(True, f"Файл відправлено в Orthanc: {p.name}", data)
        except Exception as exc:
            return OrthancResult(False, str(exc))

    def download_series_zip(self, series_id: str, out_zip: str | Path) -> OrthancResult:
        try:
            raw = self._request('GET', '/series/' + urllib.parse.quote(series_id) + '/archive')
            Path(out_zip).write_bytes(raw if isinstance(raw, (bytes, bytearray)) else bytes(raw or b''))
            return OrthancResult(True, f"Серію збережено: {out_zip}", str(out_zip))
        except Exception as exc:
            return OrthancResult(False, str(exc))
