from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np

@dataclass(frozen=True)
class MeshStats:
    vertices: int
    faces: int
    path: str


def _mesh_from_mask(mask: np.ndarray, spacing_zyx=(1.0,1.0,1.0)):
    """Extract surface mesh from a 3D boolean mask.

    Uses VTK when available. Coordinates are exported in millimeters as x,y,z.
    """
    try:
        import vtkmodules.all as vtk
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Для експорту 3D моделі потрібен VTK") from exc
    m = np.asarray(mask, dtype=np.uint8)
    if m.ndim != 3 or int(np.count_nonzero(m)) == 0:
        raise RuntimeError("Маска порожня або не є 3D")
    z, y, x = m.shape
    data = np.ascontiguousarray(m.ravel(order="C"))
    importer = vtk.vtkImageImport()
    importer.CopyImportVoidPointer(data.tobytes(), data.nbytes)
    importer.SetDataScalarTypeToUnsignedChar()
    importer.SetNumberOfScalarComponents(1)
    importer.SetDataExtent(0, x-1, 0, y-1, 0, z-1)
    importer.SetWholeExtent(0, x-1, 0, y-1, 0, z-1)
    sz, sy, sx = [float(v) for v in spacing_zyx]
    importer.SetDataSpacing(sx, sy, sz)
    importer.Update()
    contour = vtk.vtkFlyingEdges3D()
    contour.SetInputConnection(importer.GetOutputPort())
    contour.SetValue(0, 0.5)
    contour.Update()
    poly = contour.GetOutput()
    if poly.GetNumberOfPoints() <= 0 or poly.GetNumberOfCells() <= 0:
        raise RuntimeError("VTK не створив поверхню: маска занадто мала або порожня")
    cleaner = vtk.vtkCleanPolyData()
    cleaner.SetInputData(poly)
    cleaner.Update()
    return cleaner.GetOutput()


def export_mask(mask: np.ndarray, path: str | Path, spacing_zyx=(1.0,1.0,1.0)) -> MeshStats:
    path = Path(path)
    suffix = path.suffix.lower()
    poly = _mesh_from_mask(mask, spacing_zyx)
    import vtkmodules.all as vtk
    if suffix == ".stl":
        writer = vtk.vtkSTLWriter()
    elif suffix == ".obj":
        writer = vtk.vtkOBJWriter()
    elif suffix == ".ply":
        writer = vtk.vtkPLYWriter()
    elif suffix == ".glb":
        # Prefer trimesh for GLB if installed; fallback to OBJ-like note.
        try:
            import trimesh
            pts = np.array([poly.GetPoint(i) for i in range(poly.GetNumberOfPoints())], dtype=float)
            faces = []
            for i in range(poly.GetNumberOfCells()):
                cell = poly.GetCell(i)
                if cell.GetNumberOfPoints() == 3:
                    faces.append([cell.GetPointId(0), cell.GetPointId(1), cell.GetPointId(2)])
            mesh = trimesh.Trimesh(vertices=pts, faces=np.asarray(faces, dtype=np.int64), process=False)
            mesh.export(str(path))
            return MeshStats(len(pts), len(faces), str(path))
        except Exception as exc:
            raise RuntimeError("GLB експорт потребує пакета trimesh. Встановіть: pip install trimesh") from exc
    else:
        raise RuntimeError("Підтримуються STL, OBJ, PLY, GLB")
    writer.SetFileName(str(path))
    writer.SetInputData(poly)
    ok = writer.Write()
    if not ok:
        raise RuntimeError(f"Не вдалося записати модель: {path}")
    return MeshStats(int(poly.GetNumberOfPoints()), int(poly.GetNumberOfCells()), str(path))
