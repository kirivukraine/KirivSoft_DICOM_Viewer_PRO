from __future__ import annotations
from dataclasses import dataclass, asdict
from .hardware_profile import detect_hardware_profile

@dataclass
class AdaptiveDecision:
    tier: str
    viewer_3d_mode: str
    enable_vtk_volume: bool
    enable_vtk_surface: bool
    enable_ai: bool
    enable_4d: bool
    reason: str


def decide_adaptive_mode() -> AdaptiveDecision:
    """Choose safe capabilities for the current workstation.

    The rule is conservative by design: on old medical PCs the program must
    keep working in 2D/MPR/MIP even if VTK/OpenGL or AI libraries are missing.
    """
    p = detect_hardware_profile()
    cpu = p.cpu.lower()
    ram = p.ram_gb
    weak_cpu = any(w in cpu for w in ("celeron", "atom", "pentium", "core(tm)2", "n3050", "n3060"))
    if p.safe_mode or weak_cpu or (0 < ram < 6) or p.cores <= 2:
        return AdaptiveDecision(
            "safe", "Auto Safe / MIP Preview", False, False, False, False,
            "Старий або слабкий ПК: 3D/AI/4D запускаються лише у безпечних fallback-режимах.",
        )
    if 0 < ram < 12 or p.cores <= 4:
        return AdaptiveDecision(
            "balanced", "VTK Surface Safe", False, True, False, True,
            "Середній ПК: доступні MPR/Cine/Surface 3D; важкий Volume/AI вимкнено за замовчуванням.",
        )
    return AdaptiveDecision(
        "full", "VTK Volume Rendering", True, True, True, True,
        "Потужніша станція: доступні повні режими, але з crash guard/fallback.",
    )


def adaptive_dict() -> dict:
    return asdict(decide_adaptive_mode())
