from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import math
import numpy as np

from .image_ops import window_to_uint8


@dataclass
class AngioCineProfile:
    modality: str
    is_xa_xrf: bool
    is_multiframe: bool
    frames: int
    fps: float
    cine_rate_source: str
    recommended_window_center: float
    recommended_window_width: float
    suggested_mode: str
    warnings: list[str]


def _as_float(v, default: float = 0.0) -> float:
    try:
        if isinstance(v, (list, tuple)):
            v = v[0]
        return float(v)
    except Exception:
        return default


def detect_angio_cine_profile(metadata: dict, volume_shape: tuple[int, ...] | None = None) -> AngioCineProfile:
    """Classify current series for XA/XRF/coronary cine use.

    The function intentionally uses only metadata that is already available in
    DicomView PRO, so it remains safe in portable builds and on old PCs.
    """
    tags = metadata.get("tags", {}) or {}
    modality = str(metadata.get("modality") or "").upper()
    frames = int(metadata.get("cine_frames") or 0)
    if not frames and volume_shape and len(volume_shape) >= 1:
        frames = int(volume_shape[0])
    fps = _as_float(metadata.get("cine_fps"), 0.0)
    rate_source = "metadata:cine_fps" if fps > 0 else "default"
    if fps <= 0:
        # DICOM tag keys in our metadata contain tag+keyword, so scan names.
        for k, v in tags.items():
            lk = str(k).lower()
            if "cinerate" in lk or "recommendeddisplayframerate" in lk:
                fps = _as_float(v, 0.0)
                if fps > 0:
                    rate_source = str(k)
                    break
            if "frametime" in lk:
                ft = _as_float(v, 0.0)
                if ft > 0:
                    fps = 1000.0 / ft
                    rate_source = str(k)
                    break
    if fps <= 0:
        fps = 15.0
    is_xa = modality in {"XA", "XRF", "RF"}
    is_multiframe = bool(metadata.get("is_cine")) or frames > 1
    # Angio/coronary defaults: preserve vessel contrast but avoid overblown whites.
    wc = _as_float(metadata.get("dicom_window_center"), 250.0 if is_xa else 40.0)
    ww = _as_float(metadata.get("dicom_window_width"), 700.0 if is_xa else 400.0)
    if not math.isfinite(ww) or ww <= 1:
        ww = 700.0 if is_xa else 400.0
    if not math.isfinite(wc):
        wc = 250.0 if is_xa else 40.0
    warnings: list[str] = []
    if is_xa and not is_multiframe:
        warnings.append("XA/XRF визначено, але NumberOfFrames не знайдено — можливо це окремі кадри, а не cine loop.")
    if not is_xa and is_multiframe:
        warnings.append("Multi-frame серія не XA/XRF; Cine режим доступний, але ангіо-пресети можуть не підходити.")
    if is_xa:
        mode = "XA/XRF coronary cine"
    elif is_multiframe:
        mode = "generic multi-frame cine"
    else:
        mode = "static series / CT-MR stack"
    return AngioCineProfile(
        modality=modality or "UNKNOWN",
        is_xa_xrf=is_xa,
        is_multiframe=is_multiframe,
        frames=int(frames),
        fps=float(fps),
        cine_rate_source=rate_source,
        recommended_window_center=float(wc),
        recommended_window_width=float(ww),
        suggested_mode=mode,
        warnings=warnings,
    )


def dsa_subtract(volume: np.ndarray, mask_frame: int = 0, invert: bool = False) -> np.ndarray:
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3 or vol.shape[0] < 2:
        raise ValueError("DSA потребує multi-frame/серію мінімум з 2 кадрами")
    idx = int(np.clip(mask_frame, 0, vol.shape[0] - 1))
    out = vol - vol[idx][None, :, :]
    if invert:
        out = -out
    return out


def dsa_frame(volume: np.ndarray, frame: int, mask_frame: int = 0, invert: bool = False) -> np.ndarray:
    dsa = dsa_subtract(volume, mask_frame=mask_frame, invert=invert)
    idx = int(np.clip(frame, 0, dsa.shape[0] - 1))
    return np.asarray(dsa[idx], dtype=np.float32)


def contrast_enhance_frame(frame: np.ndarray, low: float = 1.0, high: float = 99.5) -> np.ndarray:
    arr = np.asarray(frame, dtype=np.float32)
    if arr.size == 0:
        return arr
    lo, hi = np.percentile(arr, [low, high])
    if not math.isfinite(float(hi - lo)) or hi <= lo:
        return arr
    return np.clip((arr - lo) * (255.0 / (hi - lo)), 0, 255).astype(np.float32)


def temporal_projection(volume: np.ndarray, mode: str = "max") -> np.ndarray:
    vol = np.asarray(volume, dtype=np.float32)
    if vol.ndim != 3:
        raise ValueError("Temporal projection потребує 3D/multi-frame масив")
    mode = (mode or "max").lower()
    if mode == "min":
        return np.min(vol, axis=0)
    if mode == "avg" or mode == "mean":
        return np.mean(vol, axis=0)
    return np.max(vol, axis=0)


def export_png_sequence(volume: np.ndarray, output_dir: str | Path, center: float, width: float, fps: float = 15.0, max_frames: int | None = None, prefix: str = "cine_frame") -> dict:
    try:
        from PIL import Image
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Для PNG sequence експорту потрібен Pillow") from exc
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError("PNG sequence потребує 3D/multi-frame масив")
    count = vol.shape[0] if max_frames is None else min(int(max_frames), vol.shape[0])
    files: list[str] = []
    for i in range(count):
        img = window_to_uint8(vol[i], center, width)
        path = out / f"{prefix}_{i+1:04d}.png"
        Image.fromarray(np.ascontiguousarray(img)).save(path)
        files.append(str(path))
    manifest = {
        "format": "PNG_SEQUENCE",
        "frames": count,
        "fps": float(fps),
        "prefix": prefix,
        "files": files,
    }
    (out / "cine_png_sequence_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def profile_to_text(profile: AngioCineProfile) -> str:
    d = asdict(profile)
    warnings = "\n".join(f"- {w}" for w in profile.warnings) if profile.warnings else "немає"
    return (
        f"Mode: {profile.suggested_mode}\n"
        f"Modality: {profile.modality}\n"
        f"Frames: {profile.frames}\n"
        f"FPS: {profile.fps:.2f} ({profile.cine_rate_source})\n"
        f"Recommended W/L: W={profile.recommended_window_width:.0f}, C={profile.recommended_window_center:.0f}\n"
        f"Warnings:\n{warnings}\n\n"
        f"Raw:\n{json.dumps(d, ensure_ascii=False, indent=2)}"
    )
