from __future__ import annotations

"""Deterministic follow-up comparison engine for DicomView PRO.

The module compares two already-loaded studies or two protocol results.  It is
CPU-only and deliberately conservative: if volume shapes/spacings are not
compatible, it still reports numeric deltas but disables voxel-by-voxel overlays
and records a warning instead of pretending that the studies are registered.

Volume layout convention: (z, y, x).  Spacing convention: (z, y, x) in mm.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import datetime as _dt
import json
import math

import numpy as np

try:  # imported only for typing/runtime duck-typing; no hard UI dependency
    from .clinical_protocol_engine import ClinicalProtocolResult
except Exception:  # pragma: no cover - keeps standalone import safe
    ClinicalProtocolResult = Any  # type: ignore


@dataclass(frozen=True)
class StudyMetrics:
    """Small numeric summary of a mask/lesion/attention region."""

    label: str
    protocol_key: str
    volume_ml: float
    voxel_count: int
    component_count: int
    spacing_zyx_mm: tuple[float, float, float]
    shape_zyx: tuple[int, int, int] | None
    bbox_mm: tuple[float, float, float] | None
    max_dimension_mm: float
    center_of_mass_voxels: tuple[float, float, float] | None
    hu_min: float | None = None
    hu_max: float | None = None
    hu_mean: float | None = None

    def to_json_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["spacing_zyx_mm"] = [float(x) for x in self.spacing_zyx_mm]
        data["shape_zyx"] = list(self.shape_zyx) if self.shape_zyx else None
        data["bbox_mm"] = [round(float(x), 3) for x in self.bbox_mm] if self.bbox_mm else None
        data["center_of_mass_voxels"] = [round(float(x), 3) for x in self.center_of_mass_voxels] if self.center_of_mass_voxels else None
        for key in ("volume_ml", "max_dimension_mm", "hu_min", "hu_max", "hu_mean"):
            if data.get(key) is not None:
                data[key] = round(float(data[key]), 4)
        return data


@dataclass(frozen=True)
class DifferenceOverlay:
    """Voxel-wise comparison masks for already aligned studies."""

    growth_mask: np.ndarray
    shrink_mask: np.ndarray
    stable_mask: np.ndarray
    growth_volume_ml: float
    shrink_volume_ml: float
    stable_volume_ml: float

    def to_summary_dict(self) -> dict[str, Any]:
        return {
            "growth_volume_ml": round(float(self.growth_volume_ml), 4),
            "shrink_volume_ml": round(float(self.shrink_volume_ml), 4),
            "stable_volume_ml": round(float(self.stable_volume_ml), 4),
            "growth_voxels": int(np.count_nonzero(self.growth_mask)),
            "shrink_voxels": int(np.count_nonzero(self.shrink_mask)),
            "stable_voxels": int(np.count_nonzero(self.stable_mask)),
        }


@dataclass(frozen=True)
class ComparisonResult:
    """Complete follow-up comparison result."""

    baseline: StudyMetrics
    followup: StudyMetrics
    delta_volume_ml: float
    delta_volume_percent: float | None
    delta_max_dimension_mm: float
    delta_hu_mean: float | None
    direction: str
    overlay: DifferenceOverlay | None
    warnings: list[str]
    notes: list[str]
    created_at: str

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "created_at": self.created_at,
            "baseline": self.baseline.to_json_dict(),
            "followup": self.followup.to_json_dict(),
            "delta_volume_ml": round(float(self.delta_volume_ml), 4),
            "delta_volume_percent": round(float(self.delta_volume_percent), 4) if self.delta_volume_percent is not None else None,
            "delta_max_dimension_mm": round(float(self.delta_max_dimension_mm), 4),
            "delta_hu_mean": round(float(self.delta_hu_mean), 4) if self.delta_hu_mean is not None else None,
            "direction": self.direction,
            "overlay": self.overlay.to_summary_dict() if self.overlay else None,
            "warnings": list(self.warnings),
            "notes": list(self.notes),
            "disclaimer": "Порівняння є вимірювальною підказкою. Для точного follow-up потрібна клінічна верифікація та коректна реєстрація досліджень.",
        }

    def pretty_text_ua(self) -> str:
        data = self.to_json_dict()
        lines = [
            "Порівняння досліджень / Follow-up",
            "",
            f"Базове дослідження: {self.baseline.label}",
            f"Повторне дослідження: {self.followup.label}",
            "",
            "Основні зміни:",
            f"  Об'єм: {self.baseline.volume_ml:.2f} → {self.followup.volume_ml:.2f} мл",
            f"  Δ об'єму: {self.delta_volume_ml:+.2f} мл",
            f"  Δ об'єму %: {self.delta_volume_percent:+.2f}%" if self.delta_volume_percent is not None else "  Δ об'єму %: недоступно",
            f"  Макс. розмір: {self.baseline.max_dimension_mm:.1f} → {self.followup.max_dimension_mm:.1f} мм",
            f"  Напрямок: {self.direction}",
        ]
        if self.delta_hu_mean is not None:
            lines.append(f"  Δ HU mean: {self.delta_hu_mean:+.2f}")
        if self.overlay:
            o = self.overlay.to_summary_dict()
            lines += [
                "",
                "Voxel-wise overlay:",
                f"  Збільшення: {o['growth_volume_ml']} мл",
                f"  Зменшення: {o['shrink_volume_ml']} мл",
                f"  Без змін: {o['stable_volume_ml']} мл",
            ]
        if self.warnings:
            lines += ["", "Попередження:"] + [f"  - {w}" for w in self.warnings]
        if self.notes:
            lines += ["", "Примітки:"] + [f"  - {n}" for n in self.notes]
        lines += ["", "JSON:", json.dumps(data, ensure_ascii=False, indent=2)]
        return "\n".join(lines)


class ComparativeViewerEngine:
    """Create numeric and mask-based follow-up comparisons.

    The class is intentionally independent from Qt/VTK.  UI code can use the
    returned overlay masks as red/blue/gray 2D or 3D overlays.
    """

    def metrics_from_protocol_result(self, result: ClinicalProtocolResult, label: str = "Study") -> StudyMetrics:
        data = result.to_json_dict()
        hu_stats = self._hu_stats_from_components(data.get("components") or [])
        return StudyMetrics(
            label=label,
            protocol_key=str(data.get("protocol_key") or data.get("protocol") or "unknown"),
            volume_ml=float(data.get("volume_ml") or 0.0),
            voxel_count=int(data.get("voxel_count") or 0),
            component_count=int(data.get("component_count") or 0),
            spacing_zyx_mm=tuple(float(x) for x in (data.get("spacing_zyx_mm") or (1.0, 1.0, 1.0))),
            shape_zyx=tuple(int(x) for x in result.mask.shape) if getattr(result, "mask", None) is not None else None,
            bbox_mm=tuple(float(x) for x in data["bbox_mm"]) if data.get("bbox_mm") else None,
            max_dimension_mm=float(data.get("max_dimension_mm") or 0.0),
            center_of_mass_voxels=tuple(float(x) for x in data["center_of_mass_voxels"]) if data.get("center_of_mass_voxels") else None,
            hu_min=hu_stats.get("hu_min"),
            hu_max=hu_stats.get("hu_max"),
            hu_mean=hu_stats.get("hu_mean"),
        )

    def metrics_from_mask(
        self,
        mask: np.ndarray,
        spacing_zyx_mm: tuple[float, float, float],
        label: str,
        protocol_key: str = "mask",
        volume_hu: np.ndarray | None = None,
    ) -> StudyMetrics:
        m = np.asarray(mask, dtype=bool)
        spacing = tuple(float(x) for x in spacing_zyx_mm)
        voxel_count = int(np.count_nonzero(m))
        volume_ml = voxel_count * self._voxel_ml(spacing)
        bbox = self._bbox(m)
        bbox_mm = self._bbox_mm(bbox, spacing) if bbox else None
        center = self._center(m)
        hu_min = hu_max = hu_mean = None
        if volume_hu is not None and np.any(m):
            vals = np.asarray(volume_hu, dtype=np.float32)[m]
            if vals.size:
                hu_min, hu_max, hu_mean = float(np.nanmin(vals)), float(np.nanmax(vals)), float(np.nanmean(vals))
        return StudyMetrics(
            label=label,
            protocol_key=protocol_key,
            volume_ml=float(volume_ml),
            voxel_count=voxel_count,
            component_count=self._component_count(m),
            spacing_zyx_mm=spacing,
            shape_zyx=tuple(int(x) for x in m.shape),
            bbox_mm=bbox_mm,
            max_dimension_mm=float(max(bbox_mm) if bbox_mm else 0.0),
            center_of_mass_voxels=center,
            hu_min=hu_min,
            hu_max=hu_max,
            hu_mean=hu_mean,
        )

    def compare_protocol_results(
        self,
        baseline: ClinicalProtocolResult,
        followup: ClinicalProtocolResult,
        baseline_label: str = "Study A",
        followup_label: str = "Study B",
    ) -> ComparisonResult:
        base_metrics = self.metrics_from_protocol_result(baseline, baseline_label)
        foll_metrics = self.metrics_from_protocol_result(followup, followup_label)
        overlay, warnings = self._overlay_if_compatible(
            np.asarray(baseline.mask, dtype=bool),
            np.asarray(followup.mask, dtype=bool),
            base_metrics.spacing_zyx_mm,
            foll_metrics.spacing_zyx_mm,
        )
        return self._build_result(base_metrics, foll_metrics, overlay, warnings)

    def compare_masks(
        self,
        baseline_mask: np.ndarray,
        followup_mask: np.ndarray,
        spacing_zyx_mm: tuple[float, float, float],
        baseline_label: str = "Study A",
        followup_label: str = "Study B",
        protocol_key: str = "mask",
        baseline_hu: np.ndarray | None = None,
        followup_hu: np.ndarray | None = None,
    ) -> ComparisonResult:
        base = self.metrics_from_mask(baseline_mask, spacing_zyx_mm, baseline_label, protocol_key, baseline_hu)
        foll = self.metrics_from_mask(followup_mask, spacing_zyx_mm, followup_label, protocol_key, followup_hu)
        overlay, warnings = self._overlay_if_compatible(np.asarray(baseline_mask, dtype=bool), np.asarray(followup_mask, dtype=bool), base.spacing_zyx_mm, foll.spacing_zyx_mm)
        return self._build_result(base, foll, overlay, warnings)

    def save_json(self, result: ComparisonResult, out_path: str | Path) -> Path:
        path = Path(out_path)
        path.write_text(json.dumps(result.to_json_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def save_txt(self, result: ComparisonResult, out_path: str | Path) -> Path:
        path = Path(out_path)
        path.write_text(result.pretty_text_ua(), encoding="utf-8")
        return path

    def _build_result(self, base: StudyMetrics, follow: StudyMetrics, overlay: DifferenceOverlay | None, warnings: list[str]) -> ComparisonResult:
        delta_ml = float(follow.volume_ml - base.volume_ml)
        delta_pct = None if base.volume_ml <= 1e-9 else float(delta_ml / base.volume_ml * 100.0)
        delta_dim = float(follow.max_dimension_mm - base.max_dimension_mm)
        delta_hu = None
        if base.hu_mean is not None and follow.hu_mean is not None:
            delta_hu = float(follow.hu_mean - base.hu_mean)
        direction = self._direction(delta_ml, delta_pct)
        notes = [
            "Red overlay = збільшення / нова зона; blue overlay = зменшення; gray = стабільна частина.",
            "Якщо дослідження не зареєстровані просторово, voxel-wise overlay вимикається або є орієнтовним.",
        ]
        return ComparisonResult(
            baseline=base,
            followup=follow,
            delta_volume_ml=delta_ml,
            delta_volume_percent=delta_pct,
            delta_max_dimension_mm=delta_dim,
            delta_hu_mean=delta_hu,
            direction=direction,
            overlay=overlay,
            warnings=warnings,
            notes=notes,
            created_at=_dt.datetime.now().isoformat(timespec="seconds"),
        )

    def _overlay_if_compatible(
        self,
        baseline_mask: np.ndarray,
        followup_mask: np.ndarray,
        baseline_spacing: tuple[float, float, float],
        followup_spacing: tuple[float, float, float],
    ) -> tuple[DifferenceOverlay | None, list[str]]:
        warnings: list[str] = []
        if baseline_mask.shape != followup_mask.shape:
            warnings.append(f"Voxel-wise overlay вимкнено: різні shape {baseline_mask.shape} vs {followup_mask.shape}.")
            return None, warnings
        if not self._spacing_close(baseline_spacing, followup_spacing):
            warnings.append(f"Voxel-wise overlay вимкнено: різний spacing {baseline_spacing} vs {followup_spacing}.")
            return None, warnings
        b = np.asarray(baseline_mask, dtype=bool)
        f = np.asarray(followup_mask, dtype=bool)
        growth = f & ~b
        shrink = b & ~f
        stable = b & f
        spacing = tuple(float(x) for x in baseline_spacing)
        voxel_ml = self._voxel_ml(spacing)
        return DifferenceOverlay(
            growth_mask=growth,
            shrink_mask=shrink,
            stable_mask=stable,
            growth_volume_ml=float(np.count_nonzero(growth) * voxel_ml),
            shrink_volume_ml=float(np.count_nonzero(shrink) * voxel_ml),
            stable_volume_ml=float(np.count_nonzero(stable) * voxel_ml),
        ), warnings

    @staticmethod
    def _direction(delta_ml: float, delta_pct: float | None) -> str:
        threshold_ml = 0.005
        threshold_pct = 5.0
        if abs(delta_ml) < threshold_ml or (delta_pct is not None and abs(delta_pct) < threshold_pct):
            return "стабільно / мінімальна зміна"
        return "збільшення" if delta_ml > 0 else "зменшення"

    @staticmethod
    def _spacing_close(a: tuple[float, float, float], b: tuple[float, float, float], rel_tol: float = 0.03) -> bool:
        return all(math.isclose(float(x), float(y), rel_tol=rel_tol, abs_tol=0.05) for x, y in zip(a, b))

    @staticmethod
    def _voxel_ml(spacing: tuple[float, float, float]) -> float:
        return float(spacing[0] * spacing[1] * spacing[2]) / 1000.0

    @staticmethod
    def _bbox(mask: np.ndarray) -> tuple[int, int, int, int, int, int] | None:
        if not np.any(mask):
            return None
        z, y, x = np.where(mask)
        return int(z.min()), int(z.max()), int(y.min()), int(y.max()), int(x.min()), int(x.max())

    @staticmethod
    def _bbox_mm(bbox: tuple[int, int, int, int, int, int] | None, spacing: tuple[float, float, float]) -> tuple[float, float, float] | None:
        if bbox is None:
            return None
        z0, z1, y0, y1, x0, x1 = bbox
        return ((z1 - z0 + 1) * spacing[0], (y1 - y0 + 1) * spacing[1], (x1 - x0 + 1) * spacing[2])

    @staticmethod
    def _center(mask: np.ndarray) -> tuple[float, float, float] | None:
        if not np.any(mask):
            return None
        c = np.argwhere(mask).mean(axis=0)
        return float(c[0]), float(c[1]), float(c[2])

    @staticmethod
    def _component_count(mask: np.ndarray) -> int:
        if not np.any(mask):
            return 0
        try:
            from scipy import ndimage as ndi  # type: ignore
            _, n = ndi.label(np.asarray(mask, dtype=bool))
            return int(n)
        except Exception:
            return 1

    @staticmethod
    def _hu_stats_from_components(components: list[dict[str, Any]]) -> dict[str, float | None]:
        if not components:
            return {"hu_min": None, "hu_max": None, "hu_mean": None}
        mins = [float(c["hu_min"]) for c in components if c.get("hu_min") is not None]
        maxs = [float(c["hu_max"]) for c in components if c.get("hu_max") is not None]
        weighted_sum = 0.0
        weighted_n = 0
        for c in components:
            if c.get("hu_mean") is not None:
                n = int(c.get("voxels") or 1)
                weighted_sum += float(c["hu_mean"]) * n
                weighted_n += n
        return {
            "hu_min": min(mins) if mins else None,
            "hu_max": max(maxs) if maxs else None,
            "hu_mean": (weighted_sum / weighted_n) if weighted_n else None,
        }


def comparison_pretty_text(result: ComparisonResult) -> str:
    return result.pretty_text_ua()
