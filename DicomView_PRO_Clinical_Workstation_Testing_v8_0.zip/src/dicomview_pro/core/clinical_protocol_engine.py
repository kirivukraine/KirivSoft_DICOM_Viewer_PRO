from __future__ import annotations

"""Deterministic clinical protocol engine for DicomView PRO.

The engine is deliberately CPU-only and transparent.  It creates visualization
masks and measurement hints for a clinician; it does not make a diagnosis.
Volume layout is expected to be ``(z, y, x)`` and spacing ``(z, y, x)`` in mm.
"""

from dataclasses import dataclass, asdict
from typing import Any
import math
import numpy as np

from .classic_ct_diagnostics import (
    ClassicHemorrhageConfig,
    Hemorrhage3DClassicAnalyzer,
    DicomViewDiagnosticsClassic,
)
from .trauma_protocol import TraumaProtocolAnalyzer


@dataclass(frozen=True)
class ProtocolDefinition:
    key: str
    title_ua: str
    window_center: float
    window_width: float
    color_rgb: tuple[float, float, float]
    target_note: str
    warning: str = "Це вимірювальна/візуальна підказка для лікаря, не автоматичний діагноз."


@dataclass
class ClinicalProtocolResult:
    protocol: ProtocolDefinition
    mask: np.ndarray
    auxiliary_mask: np.ndarray | None
    volume_ml: float
    voxel_count: int
    component_count: int
    components: list[dict[str, Any]]
    spacing_zyx_mm: tuple[float, float, float]
    bbox_voxels: tuple[int, int, int, int, int, int] | None
    bbox_mm: tuple[float, float, float] | None
    max_dimension_mm: float
    center_of_mass_voxels: tuple[float, float, float] | None
    confidence: float
    notes: list[str]
    debug: dict[str, Any]

    def summary_ua(self) -> str:
        dims = self.bbox_mm or (0.0, 0.0, 0.0)
        return (
            f"{self.protocol.title_ua}: {self.volume_ml:.2f} мл | "
            f"розміри Z/Y/X: {dims[0]:.1f} × {dims[1]:.1f} × {dims[2]:.1f} мм | "
            f"max: {self.max_dimension_mm:.1f} мм | компоненти: {self.component_count}"
        )

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "protocol": self.protocol.title_ua,
            "protocol_key": self.protocol.key,
            "window_center": self.protocol.window_center,
            "window_width": self.protocol.window_width,
            "target_note": self.protocol.target_note,
            "volume_ml": round(float(self.volume_ml), 4),
            "voxel_count": int(self.voxel_count),
            "component_count": int(self.component_count),
            "components": self.components,
            "spacing_zyx_mm": [float(x) for x in self.spacing_zyx_mm],
            "bbox_voxels": list(self.bbox_voxels) if self.bbox_voxels else None,
            "bbox_mm": [round(float(x), 3) for x in self.bbox_mm] if self.bbox_mm else None,
            "diameters_mm_zyx": [round(float(x), 3) for x in self.bbox_mm] if self.bbox_mm else None,
            "max_dimension_mm": round(float(self.max_dimension_mm), 3),
            "center_of_mass_voxels": [round(float(x), 3) for x in self.center_of_mass_voxels] if self.center_of_mass_voxels else None,
            "confidence": round(float(self.confidence), 4),
            "notes": list(self.notes),
            "debug": self.debug,
            "warning": self.protocol.warning,
        }


class ClinicalProtocolEngine:
    """Run deterministic HU/morphology protocols for clinical visualization."""

    DEFINITIONS: dict[str, ProtocolDefinition] = {
        "hemorrhage": ProtocolDefinition(
            "hemorrhage", "Гемораж", 40.0, 80.0, (1.0, 0.02, 0.02),
            "Свіжа кров/гематома/крововилив: HU-поріг + 3D морфологія + компоненти.",
        ),
        "trauma": ProtocolDefinition(
            "trauma", "Травма", 500.0, 2500.0, (1.0, 0.85, 0.05),
            "Кістка, підозрілі фрагменти, щільні гематоми, вільне повітря — як підказка для огляду.",
        ),
        "ischemia": ProtocolDefinition(
            "ischemia", "Ішемія", 40.0, 80.0, (0.05, 0.35, 1.0),
            "Гіподенсність/асиметрія мозку. Рання ішемія на КТ може бути майже непомітною.",
        ),
        "onco": ProtocolDefinition(
            "onco", "Онко", 50.0, 350.0, (0.75, 0.15, 1.0),
            "Атипова щільність/асиметрія/мас-ефект. Без AI і фаз контрасту це лише орієнтир.",
        ),
        "inflammation": ProtocolDefinition(
            "inflammation", "Запалення", 40.0, 400.0, (1.0, 0.45, 0.05),
            "Рідина, інфільтрація, газ у нетипових місцях, абсцес-подібні зони — орієнтовна підсвітка.",
        ),
    }

    def __init__(self) -> None:
        self.hemo = Hemorrhage3DClassicAnalyzer(ClassicHemorrhageConfig())
        self.trauma = TraumaProtocolAnalyzer()

    def run(self, key: str, volume_hu: np.ndarray, spacing_zyx_mm: tuple[float, float, float]) -> ClinicalProtocolResult:
        key = (key or "hemorrhage").lower()
        if key == "hemorrhage":
            return self._run_hemorrhage(volume_hu, spacing_zyx_mm)
        if key == "trauma":
            return self._run_trauma(volume_hu, spacing_zyx_mm)
        if key == "ischemia":
            return self._run_ischemia(volume_hu, spacing_zyx_mm)
        if key == "onco":
            return self._run_onco(volume_hu, spacing_zyx_mm)
        if key == "inflammation":
            return self._run_inflammation(volume_hu, spacing_zyx_mm)
        raise ValueError(f"Unknown clinical protocol: {key}")

    def _run_hemorrhage(self, volume_hu: np.ndarray, spacing: tuple[float, float, float]) -> ClinicalProtocolResult:
        res = self.hemo.detect_volume(volume_hu, spacing)
        proto = self.DEFINITIONS["hemorrhage"]
        return ClinicalProtocolResult(
            proto, res.mask, res.brain_mask, res.volume_ml, res.voxel_count,
            res.component_count, res.components, res.spacing_zyx_mm, res.bbox_voxels,
            res.bbox_mm, max(res.bbox_mm) if res.bbox_mm else 0.0,
            res.center_of_mass_voxels, res.confidence, res.notes,
            {**res.debug, "algorithm": "ClassicHemorrhageConfig HU 50-95 + 3D morphology"},
        )

    def _run_trauma(self, volume_hu: np.ndarray, spacing: tuple[float, float, float]) -> ClinicalProtocolResult:
        """Run the dedicated classic trauma workflow.

        This is not an automatic fracture detector.  It generates a trauma attention
        mask with bone, dense fragment candidates, air candidates and HU-compatible
        hematoma candidates, then returns the same report structure as other
        clinical protocols.
        """
        tr = self.trauma.analyze(volume_hu, spacing)
        proto = self.DEFINITIONS["trauma"]
        debug = dict(tr.debug)
        debug["class_metrics"] = tr.class_metrics
        return ClinicalProtocolResult(
            protocol=proto,
            mask=tr.mask,
            auxiliary_mask=(tr.air_mask | tr.hematoma_candidate_mask).astype(bool),
            volume_ml=tr.volume_ml,
            voxel_count=tr.voxel_count,
            component_count=tr.component_count,
            components=tr.components,
            spacing_zyx_mm=spacing,
            bbox_voxels=tr.bbox_voxels,
            bbox_mm=tr.bbox_mm,
            max_dimension_mm=max(tr.bbox_mm) if tr.bbox_mm else 0.0,
            center_of_mass_voxels=tr.center_of_mass_voxels,
            confidence=tr.confidence,
            notes=tr.notes,
            debug=debug,
        )

    def _run_ischemia(self, volume_hu: np.ndarray, spacing: tuple[float, float, float]) -> ClinicalProtocolResult:
        v = np.asarray(volume_hu, dtype=np.float32)
        soft_brain = np.isfinite(v) & (v > -5.0) & (v < 85.0)
        # Very broad hypodensity candidate; refine by asymmetry projection.
        hypo = np.isfinite(v) & (v >= 10.0) & (v <= 32.0) & soft_brain
        try:
            asym = DicomViewDiagnosticsClassic.analyze_brain_asymmetry_volume(v, threshold=28) > 0
            hypo = hypo & asym
        except Exception:
            asym = None
        mask = self._clean_and_keep(hypo, spacing, min_ml=0.25, max_ml=250.0, keep=16)
        notes = ["Ішемічний протокол є низькоспецифічним без перфузії/AI; перевіряти на Brain Window і клініці."]
        return self._generic_result("ischemia", mask, spacing, notes, {"hypodense_voxels_raw": int(np.count_nonzero(hypo)), "asymmetry_used": asym is not None})

    def _run_onco(self, volume_hu: np.ndarray, spacing: tuple[float, float, float]) -> ClinicalProtocolResult:
        v = np.asarray(volume_hu, dtype=np.float32)
        # General atypical soft-tissue focus: mid/high soft tissue densities
        # combined with side asymmetry.  Useful as visual attention map only.
        candidate = np.isfinite(v) & (v >= 35.0) & (v <= 95.0)
        try:
            asym = DicomViewDiagnosticsClassic.analyze_brain_asymmetry_volume(v, threshold=32) > 0
            candidate = candidate & asym
        except Exception:
            asym = None
        mask = self._clean_and_keep(candidate, spacing, min_ml=0.30, max_ml=350.0, keep=16)
        notes = ["Онко-протокол без навченої моделі та фаз контрасту є лише картою уваги, не детектором пухлин."]
        return self._generic_result("onco", mask, spacing, notes, {"candidate_voxels_raw": int(np.count_nonzero(candidate)), "asymmetry_used": asym is not None})

    def _run_inflammation(self, volume_hu: np.ndarray, spacing: tuple[float, float, float]) -> ClinicalProtocolResult:
        v = np.asarray(volume_hu, dtype=np.float32)
        # Fluid/pus-like soft tissue and consolidation-like lung opacities are
        # very modality/anatomy dependent.  Highlight broad candidates only.
        fluid_soft = np.isfinite(v) & (v >= 10.0) & (v <= 45.0)
        dense_infiltrate = np.isfinite(v) & (v >= -250.0) & (v <= 80.0)
        candidate = fluid_soft | dense_infiltrate
        mask = self._clean_and_keep(candidate, spacing, min_ml=0.50, max_ml=1000.0, keep=24)
        notes = ["Запальний протокол підсвічує рідину/інфільтрацію за HU; анатомічну інтерпретацію виконує лікар."]
        return self._generic_result("inflammation", mask, spacing, notes, {"fluid_voxels_raw": int(np.count_nonzero(fluid_soft)), "infiltrate_voxels_raw": int(np.count_nonzero(dense_infiltrate))})

    def _generic_result(self, key: str, mask: np.ndarray, spacing: tuple[float, float, float], notes: list[str], debug: dict[str, Any]) -> ClinicalProtocolResult:
        proto = self.DEFINITIONS[key]
        comps = self._components(mask, spacing)
        vox = int(np.count_nonzero(mask))
        volume_ml = vox * self._voxel_ml(spacing)
        bbox = self._bbox(mask)
        bbox_mm = self._bbox_mm(bbox, spacing) if bbox else None
        com = self._center(mask)
        return ClinicalProtocolResult(
            protocol=proto,
            mask=mask.astype(bool),
            auxiliary_mask=None,
            volume_ml=float(volume_ml),
            voxel_count=vox,
            component_count=len(comps),
            components=comps,
            spacing_zyx_mm=tuple(float(x) for x in spacing),
            bbox_voxels=bbox,
            bbox_mm=bbox_mm,
            max_dimension_mm=float(max(bbox_mm) if bbox_mm else 0.0),
            center_of_mass_voxels=com,
            confidence=self._simple_confidence(volume_ml, len(comps)),
            notes=notes,
            debug={**debug, "algorithm": "Deterministic HU/asymmetry/morphology protocol"},
        )

    def _clean_and_keep(self, mask: np.ndarray, spacing: tuple[float, float, float], *, min_ml: float, max_ml: float, keep: int) -> np.ndarray:
        try:
            from scipy import ndimage as ndi  # type: ignore
            st = ndi.generate_binary_structure(3, 1)
            out = ndi.binary_opening(mask.astype(bool), structure=st, iterations=1)
            out = ndi.binary_closing(out, structure=st, iterations=1)
            labels, n = ndi.label(out, structure=st)
            if n <= 0:
                return out & False
            sizes = np.bincount(labels.ravel())
            voxel_ml = self._voxel_ml(spacing)
            candidates = []
            for lid in range(1, n + 1):
                ml = float(sizes[lid] * voxel_ml)
                if min_ml <= ml <= max_ml:
                    candidates.append((lid, ml))
            candidates.sort(key=lambda x: x[1], reverse=True)
            keep_ids = [x[0] for x in candidates[: max(1, int(keep))]]
            return np.isin(labels, keep_ids).astype(bool) if keep_ids else (out & False)
        except Exception:
            return mask.astype(bool)

    def _components(self, mask: np.ndarray, spacing: tuple[float, float, float]) -> list[dict[str, Any]]:
        try:
            from scipy import ndimage as ndi  # type: ignore
            labels, n = ndi.label(mask.astype(bool))
            out = []
            voxel_ml = self._voxel_ml(spacing)
            for lid in range(1, n + 1):
                cm = labels == lid
                vox = int(np.count_nonzero(cm))
                if vox == 0:
                    continue
                bbox = self._bbox(cm)
                dims = self._bbox_mm(bbox, spacing) if bbox else (0.0, 0.0, 0.0)
                out.append({
                    "label": int(lid),
                    "voxels": vox,
                    "volume_ml": round(float(vox * voxel_ml), 4),
                    "bbox_voxels": list(bbox) if bbox else None,
                    "bbox_mm": [round(float(x), 3) for x in dims],
                    "max_dimension_mm": round(float(max(dims)), 3),
                    "center_of_mass_voxels": [round(float(x), 3) for x in (self._center(cm) or (0.0, 0.0, 0.0))],
                })
            out.sort(key=lambda x: x["volume_ml"], reverse=True)
            return out
        except Exception:
            return []

    @staticmethod
    def _voxel_ml(spacing: tuple[float, float, float]) -> float:
        return float(spacing[0] * spacing[1] * spacing[2]) / 1000.0

    @staticmethod
    def _bbox(mask: np.ndarray) -> tuple[int, int, int, int, int, int] | None:
        if not np.any(mask):
            return None
        z, y, x = np.where(mask)
        return int(z.min()), int(z.max()), int(y.min()), int(y.max()), int(x.min()), int(x.max())

    @staticmethod
    def _bbox_mm(bbox: tuple[int, int, int, int, int, int] | None, spacing: tuple[float, float, float]) -> tuple[float, float, float] | None:
        if not bbox:
            return None
        z0, z1, y0, y1, x0, x1 = bbox
        return ((z1 - z0 + 1) * spacing[0], (y1 - y0 + 1) * spacing[1], (x1 - x0 + 1) * spacing[2])

    @staticmethod
    def _center(mask: np.ndarray) -> tuple[float, float, float] | None:
        if not np.any(mask):
            return None
        c = np.argwhere(mask).mean(axis=0)
        return float(c[0]), float(c[1]), float(c[2])

    @staticmethod
    def _simple_confidence(volume_ml: float, component_count: int) -> float:
        if volume_ml <= 0:
            return 0.0
        return float(np.clip(0.25 + min(0.55, volume_ml / 50.0) - max(0, component_count - 1) * 0.02, 0.0, 0.8))


def protocol_pretty_text(result: ClinicalProtocolResult) -> str:
    data = result.to_json_dict()
    dims = data.get("bbox_mm") or [0.0, 0.0, 0.0]
    lines = [
        f"Протокол: {data['protocol']}",
        "",
        "Основні вимірювання:",
        f"  Об'єм: {data['volume_ml']} мл",
        f"  Розміри Z/Y/X: {dims[0]} × {dims[1]} × {dims[2]} мм",
        f"  Максимальний розмір: {data['max_dimension_mm']} мм",
        f"  Компоненти: {data['component_count']}",
        f"  Впевненість алгоритму: {data['confidence']}",
        "",
        "Пояснення:",
        f"  {data['target_note']}",
        "",
        "Примітки:",
    ]
    for note in data.get("notes") or [data.get("warning")]:
        lines.append(f"  - {note}")
    lines += ["", "JSON:", json_dumps(data)]
    return "\n".join(lines)


def json_dumps(data: dict[str, Any]) -> str:
    import json
    return json.dumps(data, ensure_ascii=False, indent=2)
