from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json
import urllib.parse

from .orthanc_client import OrthancClient, OrthancConfig, OrthancResult


@dataclass(frozen=True)
class OrthancNode:
    level: str
    orthanc_id: str
    label: str
    raw: dict[str, Any]


class OrthancExplorerPRO:
    """Safe Orthanc explorer wrapper.

    It never raises into the UI. Every operation returns OrthancResult so the
    viewer can show a message and keep running when Orthanc is not installed,
    offline, password-protected, or misconfigured.
    """

    def __init__(self, cfg: OrthancConfig | None = None):
        self.cfg = cfg or OrthancConfig()
        self.client = OrthancClient(self.cfg)

    def ping(self) -> OrthancResult:
        return self.client.system()

    def find_studies(self, patient_name: str = "*", patient_id: str = "", modality: str = "") -> OrthancResult:
        try:
            query: dict[str, Any] = {"Level": "Study", "Query": {}}
            query["Query"]["PatientName"] = patient_name or "*"
            if patient_id:
                query["Query"]["PatientID"] = patient_id
            if modality:
                query["Query"]["ModalitiesInStudy"] = modality
            body = json.dumps(query).encode("utf-8")
            ids = self.client._request("POST", "/tools/find", body, {"Content-Type": "application/json"}) or []
            rows: list[dict[str, Any]] = []
            for sid in ids[:300]:
                try:
                    rows.append(self.client._request("GET", "/studies/" + urllib.parse.quote(str(sid))))
                except Exception:
                    rows.append({"ID": sid})
            return OrthancResult(True, f"Знайдено досліджень: {len(ids)}", rows)
        except Exception as exc:
            return OrthancResult(False, f"Orthanc пошук недоступний: {exc}", [])

    def build_patient_study_series_tree(self) -> OrthancResult:
        try:
            studies = self.client.studies()
            if not studies.ok:
                return studies
            nodes: list[OrthancNode] = []
            for st in studies.data or []:
                main = st.get("MainDicomTags", {}) if isinstance(st, dict) else {}
                patient = st.get("PatientMainDicomTags", {}) if isinstance(st, dict) else {}
                sid = str(st.get("ID", "")) if isinstance(st, dict) else ""
                label = f"{patient.get('PatientName','Unknown')} | {main.get('StudyDescription','Study')} | {main.get('StudyDate','')}"
                nodes.append(OrthancNode("Study", sid, label, st if isinstance(st, dict) else {"ID": sid}))
            return OrthancResult(True, f"Дерево Orthanc: {len(nodes)} досліджень", nodes)
        except Exception as exc:
            return OrthancResult(False, str(exc), [])

    def download_series_zip_safe(self, series_id: str, out_dir: str | Path) -> OrthancResult:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        target = out / f"orthanc_series_{series_id}.zip"
        return self.client.download_series_zip(series_id, target)
