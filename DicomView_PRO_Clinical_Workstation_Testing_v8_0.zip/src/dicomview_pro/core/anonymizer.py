from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, zipfile, hashlib, datetime
import pydicom

SENSITIVE_TAGS = [
    "PatientName", "PatientID", "PatientBirthDate", "PatientSex", "PatientAddress",
    "PatientTelephoneNumbers", "OtherPatientIDs", "OtherPatientNames", "IssuerOfPatientID",
    "InstitutionName", "InstitutionAddress", "ReferringPhysicianName", "PerformingPhysicianName",
    "OperatorsName", "PhysiciansOfRecord", "RequestingPhysician", "AccessionNumber",
]

@dataclass(frozen=True)
class AnonymizeSummary:
    files_written: int
    zip_path: str
    manifest_path: str


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def anonymize_to_zip(files: list[str], out_zip: str | Path, patient_label: str = "ANONYMIZED") -> AnonymizeSummary:
    out_zip = Path(out_zip)
    work = out_zip.with_suffix("")
    work.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    manifest = {
        "created_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "software": "DicomView PRO KirivSoft",
        "patient_label": patient_label,
        "files": [],
    }
    for idx, file_name in enumerate(files):
        src = Path(file_name)
        try:
            ds = pydicom.dcmread(str(src), force=True)
            for tag in SENSITIVE_TAGS:
                if hasattr(ds, tag):
                    try:
                        setattr(ds, tag, patient_label if tag in ("PatientName", "PatientID") else "")
                    except Exception:
                        pass
            ds.remove_private_tags()
            dst = work / f"IMG_{idx:05d}.dcm"
            ds.save_as(str(dst), write_like_original=False)
            written.append(dst)
            manifest["files"].append({"source": src.name, "output": dst.name, "sha256": _sha256(dst)})
        except Exception as exc:
            manifest["files"].append({"source": src.name, "error": str(exc)})
    manifest_path = work / "KIRIVSOFT_ANONYMIZATION_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for f in written:
            z.write(f, arcname=f.name)
        z.write(manifest_path, arcname=manifest_path.name)
    return AnonymizeSummary(len(written), str(out_zip), str(manifest_path))
