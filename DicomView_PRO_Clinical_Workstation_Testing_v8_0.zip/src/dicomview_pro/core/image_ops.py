from __future__ import annotations
import numpy as np


def auto_window(volume: np.ndarray, low_pct: float = 1.0, high_pct: float = 99.0) -> tuple[float, float]:
    finite = volume[np.isfinite(volume)]
    if finite.size == 0:
        return 40.0, 400.0
    lo, hi = np.percentile(finite, [float(low_pct), float(high_pct)])
    width = max(float(hi - lo), 1.0)
    center = float((hi + lo) / 2.0)
    return center, width


def _box_blur3(img: np.ndarray) -> np.ndarray:
    pad = np.pad(img.astype(np.float32), 1, mode="edge")
    return (
        pad[:-2, :-2] + 2 * pad[:-2, 1:-1] + pad[:-2, 2:] +
        2 * pad[1:-1, :-2] + 4 * pad[1:-1, 1:-1] + 2 * pad[1:-1, 2:] +
        pad[2:, :-2] + 2 * pad[2:, 1:-1] + pad[2:, 2:]
    ) / 16.0


def _median3(img: np.ndarray) -> np.ndarray:
    """Small dependency-free 3x3 median for display-only denoise."""
    try:
        pad = np.pad(img.astype(np.float32), 1, mode="edge")
        stack = np.stack([
            pad[:-2, :-2], pad[:-2, 1:-1], pad[:-2, 2:],
            pad[1:-1, :-2], pad[1:-1, 1:-1], pad[1:-1, 2:],
            pad[2:, :-2], pad[2:, 1:-1], pad[2:, 2:],
        ], axis=0)
        return np.median(stack, axis=0).astype(np.float32)
    except Exception:
        return img.astype(np.float32)


def _tissue_gate(img: np.ndarray) -> np.ndarray:
    """Display-space soft-tissue gate: preserve black background and bright bone."""
    img = img.astype(np.float32)
    # Brain soft-tissue after W/L usually lives in midtones. Keep very dark
    # background and saturated bone mostly untouched to avoid plastic edges.
    return (img > 8.0) & (img < 248.0)


def _noise_safe_smooth(img: np.ndarray, strength: str) -> np.ndarray:
    """Display-only denoise profiles for noisy CT brain/high-resolution kernels.

    This does not touch HU data, ROI statistics or measurements. It operates only
    on the final 8-bit image shown to the user.
    """
    base = img.astype(np.float32)
    gate = _tissue_gate(base)
    if not np.any(gate):
        return base
    if strength == "brain_smooth":
        med = _median3(base)
        blur = _box_blur3(med)
        mixed = 0.70 * med + 0.30 * blur
    elif strength == "ct_brain_strong":
        med = _median3(base)
        blur = _box_blur3(_box_blur3(med))
        mixed = 0.55 * med + 0.45 * blur
    elif strength == "syngo_soft_max":
        med = _median3(_median3(base))
        blur = _box_blur3(_box_blur3(med))
        mixed = 0.35 * med + 0.65 * blur
    else:
        return base
    out = base.copy()
    out[gate] = mixed[gate]
    return np.clip(out, 0, 255)


def _noise_safe_unsharp(img: np.ndarray, amount: float) -> np.ndarray:
    """Unsharp with pre-smoothing to avoid salt/pepper amplification."""
    smoothed = _box_blur3(_median3(img))
    blur = _box_blur3(smoothed)
    return np.clip(smoothed + amount * (smoothed - blur), 0, 255)


def _gradient_mag3(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float32)
    gx = np.zeros_like(a, dtype=np.float32)
    gy = np.zeros_like(a, dtype=np.float32)
    gx[:, 1:-1] = (a[:, 2:] - a[:, :-2]) * 0.5
    gy[1:-1, :] = (a[2:, :] - a[:-2, :]) * 0.5
    return np.sqrt(gx * gx + gy * gy)


def _edge_preserving_hu_fallback(a: np.ndarray, strength: str = "brain") -> np.ndarray:
    """Dependency-free HU-space denoise used when SimpleITK/OpenCV is absent.

    It smooths only low-gradient soft-tissue pixels and preserves air/bone/high
    gradients. This is intentionally conservative and display-only: measurements
    still use the original HU slice passed as source_slice.
    """
    src = np.asarray(a, dtype=np.float32)
    if src.ndim != 2 or src.size == 0:
        return src
    grad = _gradient_mag3(src)
    # Brain soft tissue range is broad enough for plain CT HU and scanner LUTs.
    tissue = (src > -20.0) & (src < 120.0) & (grad < (10.0 if strength == "strong" else 14.0))
    if not np.any(tissue):
        return src
    sm = _box_blur3(_median3(src))
    if strength == "strong":
        sm = _box_blur3(sm)
    out = src.copy()
    alpha = 0.72 if strength == "strong" else 0.55
    out[tissue] = (1.0 - alpha) * src[tissue] + alpha * sm[tissue]
    return out.astype(np.float32)


def _itk_anisotropic_hu(a: np.ndarray, strength: str = "brain") -> np.ndarray:
    """Apply SimpleITK edge-preserving diffusion in HU space before windowing.

    Uses ITK if available; otherwise falls back to a safe NumPy implementation.
    This function never mutates the original slice.
    """
    src = np.asarray(a, dtype=np.float32)
    if src.ndim != 2 or src.size == 0:
        return src
    try:
        import SimpleITK as sitk  # type: ignore
        img = sitk.GetImageFromArray(src.astype(np.float32))
        # Conservative parameters for CT brain. Keep boundaries and avoid plastic look.
        iterations = 4 if strength != "strong" else 6
        conductance = 2.0 if strength != "strong" else 2.8
        filt = sitk.CurvatureAnisotropicDiffusionImageFilter()
        filt.SetTimeStep(0.0625)
        filt.SetNumberOfIterations(int(iterations))
        filt.SetConductanceParameter(float(conductance))
        out = sitk.GetArrayFromImage(filt.Execute(img)).astype(np.float32)
        if out.shape == src.shape:
            return out
    except Exception:
        pass
    return _edge_preserving_hu_fallback(src, "strong" if strength == "strong" else "brain")



def _bilateral_hu_fallback(a: np.ndarray, strength: str = "pro") -> np.ndarray:
    """Small edge-preserving HU-domain bilateral-like fallback.

    It is deliberately conservative: smooths only brain soft-tissue values and
    avoids air, bone and steep HU gradients. This is display-only when called by
    window_to_uint8(); measurement/ROI still use original HU arrays.
    """
    src = np.asarray(a, dtype=np.float32)
    if src.ndim != 2 or src.size == 0:
        return src
    grad = _gradient_mag3(src)
    tissue = (src > -15.0) & (src < 115.0) & (grad < (18.0 if strength != "ultra" else 12.0))
    if not np.any(tissue):
        return src
    # 3x3 spatial kernel, range weight based on HU difference.
    sigma_color = 22.0 if strength == "pro" else 16.0
    sigma_space = 1.25
    pad = np.pad(src, 1, mode="edge")
    acc = np.zeros_like(src, dtype=np.float32)
    wsum = np.zeros_like(src, dtype=np.float32)
    center = src
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            nei = pad[1+dy:1+dy+src.shape[0], 1+dx:1+dx+src.shape[1]]
            spatial = np.exp(-float(dx*dx + dy*dy) / (2.0 * sigma_space * sigma_space))
            range_w = np.exp(-((nei - center) ** 2) / (2.0 * sigma_color * sigma_color))
            w = spatial * range_w
            acc += nei * w
            wsum += w
    sm = acc / np.maximum(wsum, 1e-6)
    out = src.copy()
    alpha = 0.78 if strength == "ultra" else 0.62
    out[tissue] = (1.0 - alpha) * src[tissue] + alpha * sm[tissue]
    return out.astype(np.float32)


def _brain_bilateral_hu(a: np.ndarray, strength: str = "pro") -> np.ndarray:
    """Edge-preserving bilateral denoise in HU space for CT Brain.

    Prefer OpenCV when present; fall back to a deterministic NumPy filter.  It is
    intentionally applied before VOI windowing so narrow brain windows do not
    amplify quantum noise before denoise.
    """
    src = np.asarray(a, dtype=np.float32)
    if src.ndim != 2 or src.size == 0:
        return src
    try:
        import cv2  # type: ignore
        # Work only on broad brain soft tissue, keep air and high-density bone.
        tissue = (src > -15.0) & (src < 115.0)
        if not np.any(tissue):
            return src
        sigma_color = 24.0 if strength == "pro" else 18.0
        sigma_space = 2.0 if strength == "pro" else 2.8
        filtered = cv2.bilateralFilter(src.astype(np.float32), d=5 if strength == "pro" else 7,
                                       sigmaColor=float(sigma_color), sigmaSpace=float(sigma_space))
        out = src.copy()
        alpha = 0.70 if strength == "ultra" else 0.55
        out[tissue] = (1.0 - alpha) * src[tissue] + alpha * filtered[tissue]
        return out.astype(np.float32)
    except Exception:
        return _bilateral_hu_fallback(src, strength)


def _brain_fidelity_pro_hu(a: np.ndarray, mode: str = "pro") -> np.ndarray:
    """CT Brain Fidelity PRO pipeline in HU before window/level.

    PRO: bilateral + light ITK diffusion.
    ULTRA: stronger bilateral + stronger ITK diffusion for very sharp Hr/H kernels.
    """
    strength = "ultra" if mode == "ultra" else "pro"
    out = _brain_bilateral_hu(a, strength)
    out = _itk_anisotropic_hu(out, "strong" if strength == "ultra" else "brain")
    return out.astype(np.float32)

def _clahe_u8(img: np.ndarray, mode: str = "low") -> np.ndarray:
    """Contrast-limited adaptive histogram equalization for XA/XRF/CR/DX display."""
    src = np.ascontiguousarray(np.asarray(img, dtype=np.uint8))
    try:
        import cv2  # type: ignore
        if mode == "angio":
            clip, grid = 2.2, (8, 8)
        elif mode == "medium":
            clip, grid = 1.8, (8, 8)
        else:
            clip, grid = 1.2, (8, 8)
        clahe = cv2.createCLAHE(clipLimit=float(clip), tileGridSize=grid)
        return np.ascontiguousarray(clahe.apply(src))
    except Exception:
        # Lightweight fallback: local-ish contrast through global percentile stretch.
        lo, hi = np.percentile(src, [1.0, 99.0])
        if hi <= lo:
            return src
        return np.ascontiguousarray(np.clip((src.astype(np.float32) - lo) * 255.0 / (hi - lo), 0, 255).astype(np.uint8))


def window_to_uint8(a: np.ndarray, center: float, width: float, invert: bool = False, sharpen: str = "off") -> np.ndarray:
    """Convert HU / modality pixels to display-ready uint8.

    Correct order for fidelity modes:
    modality pixels / HU -> optional HU-space edge-preserving denoise -> DICOM
    VOI window -> optional presentation inversion -> optional display-only
    enhancement -> uint8.

    Implements the DICOM VOI formula (C-0.5, W-1) rather than a simple low/high
    clip. This matters for narrow CT brain windows.
    """
    mode = (sharpen or "off").lower().strip()
    a = np.asarray(a, dtype=np.float32)

    # Fidelity Engine 2.1/PRO: denoise CT brain in HU space BEFORE windowing.
    # This prevents W80/W100 brain windows from amplifying quantum noise first.
    if mode in {"brain_bilateral_pro", "brain bilateral pro", "bilateral pro"}:
        a = _brain_bilateral_hu(a, "pro")
        post_mode = "off"
    elif mode in {"brain_fidelity_pro", "brain fidelity pro", "ct brain fidelity pro"}:
        a = _brain_fidelity_pro_hu(a, "pro")
        post_mode = "off"
    elif mode in {"brain_fidelity_ultra", "brain fidelity ultra", "ct brain fidelity ultra"}:
        a = _brain_fidelity_pro_hu(a, "ultra")
        post_mode = "off"
    elif mode in {"mpr_fidelity_max", "mpr fidelity max", "ct mpr fidelity max"}:
        a = _brain_fidelity_pro_hu(a, "ultra")
        post_mode = "syngo_soft_max"
    elif mode in {"itk_anisotropic_ct_brain", "itk anisotropic ct brain", "ct brain itk", "brain_itk"}:
        a = _itk_anisotropic_hu(a, "brain")
        post_mode = "off"
    elif mode in {"itk_anisotropic_strong", "itk strong", "ct brain itk strong"}:
        a = _itk_anisotropic_hu(a, "strong")
        post_mode = "off"
    else:
        post_mode = mode

    c = float(center)
    w = max(float(width), 1.0)
    if w <= 1.0:
        out = np.where(a <= (c - 0.5), 0.0, 255.0)
    else:
        # DICOM PS3.3 C.11.2.1.2 VOI LUT windowing formula.
        out = ((a - (c - 0.5)) / (w - 1.0) + 0.5) * 255.0
        out = np.clip(out, 0.0, 255.0)
    if invert:
        out = 255.0 - out
    img = out.astype(np.float32)

    if post_mode in {"clahe_low", "clahe low"}:
        img = _clahe_u8(img, "low").astype(np.float32)
    elif post_mode in {"clahe_medium", "clahe medium"}:
        img = _clahe_u8(img, "medium").astype(np.float32)
    elif post_mode in {"clahe_angio", "clahe angio", "angio fidelity"}:
        img = _clahe_u8(img, "angio").astype(np.float32)
    elif post_mode in {"brain_smooth", "smooth", "brain smooth", "brain_smooth_less_noise"}:
        img = _noise_safe_smooth(img, "brain_smooth")
    elif post_mode in {"ct_brain_strong", "ct brain fidelity", "ct brain fidelity (strong)"}:
        img = _noise_safe_smooth(img, "ct_brain_strong")
    elif post_mode in {"syngo_soft_max", "syngo soft brain", "syngo soft brain (max)"}:
        img = _noise_safe_smooth(img, "syngo_soft_max")
    elif post_mode == "low":
        img = _noise_safe_unsharp(img, 0.10)
    elif post_mode == "medium":
        img = _noise_safe_unsharp(img, 0.18)
    elif post_mode in {"off", "raw", "raw diagnostic", ""}:
        pass
    return np.ascontiguousarray(np.clip(img, 0, 255).astype(np.uint8))


def get_slice(volume: np.ndarray, plane: str, index: int) -> np.ndarray:
    z, y, x = volume.shape
    if plane == "axial":
        return volume[int(np.clip(index, 0, z-1)), :, :]
    if plane == "coronal":
        return volume[:, int(np.clip(index, 0, y-1)), :]
    if plane == "sagittal":
        return volume[:, :, int(np.clip(index, 0, x-1))]
    raise ValueError(f"Unknown plane: {plane}")


def projection(volume: np.ndarray, mode: str, axis: int = 0) -> np.ndarray:
    m = mode.lower()
    axis = int(axis)
    if m == "mip":
        return np.max(volume, axis=axis)
    if m == "minip":
        return np.min(volume, axis=axis)
    if m == "avgip":
        return np.mean(volume, axis=axis)
    raise ValueError(mode)


def _largest_component_bbox(mask: np.ndarray) -> tuple[int, int, int, int] | None:
    """Return bbox x0,y0,x1,y1 of largest connected component in a 2D mask."""
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim != 2 or not mask.any():
        return None
    if mask.shape[0] > 256 or mask.shape[1] > 256:
        step_y = max(1, int(np.ceil(mask.shape[0] / 256)))
        step_x = max(1, int(np.ceil(mask.shape[1] / 256)))
        small = mask[::step_y, ::step_x]
        bbox = _largest_component_bbox(small)
        if bbox is None:
            return None
        x0, y0, x1, y1 = bbox
        return (x0 * step_x, y0 * step_y, min(mask.shape[1], x1 * step_x), min(mask.shape[0], y1 * step_y))
    h, w = mask.shape
    seen = np.zeros(mask.shape, dtype=bool)
    best_count = 0
    best = None
    ys, xs = np.nonzero(mask)
    for start_y, start_x in zip(ys.tolist(), xs.tolist()):
        if seen[start_y, start_x] or not mask[start_y, start_x]:
            continue
        stack = [(start_y, start_x)]
        seen[start_y, start_x] = True
        count = 0
        minx = maxx = start_x
        miny = maxy = start_y
        while stack:
            y, x = stack.pop()
            count += 1
            minx = min(minx, x); maxx = max(maxx, x)
            miny = min(miny, y); maxy = max(maxy, y)
            for ny, nx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                if 0 <= ny < h and 0 <= nx < w and (not seen[ny, nx]) and mask[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        if count > best_count:
            best_count = count
            best = (minx, miny, maxx + 1, maxy + 1)
    return best


def diagnostic_content_bbox(display_u8: np.ndarray, margin: int = 12) -> tuple[int, int, int, int] | None:
    """Find anatomical bbox for optional manual fit-to-content view.

    Normal diagnostic mode should use Fit-to-window. This function is deliberately
    conservative because aggressive auto-crop magnifies CT quantum noise.
    """
    img = np.asarray(display_u8)
    if img.ndim != 2 or img.size == 0:
        return None
    h, w = img.shape
    nz = img[img > 0]
    thr = max(2.0, min(12.0, float(np.percentile(nz, 2)))) if nz.size else 2.0
    mask = img > thr
    bbox = _largest_component_bbox(mask)
    if bbox is None:
        return None
    x0, y0, x1, y1 = bbox
    # Reject crops that are too aggressive; otherwise noise gets magnified.
    if (x1-x0) < w * 0.55 or (y1-y0) < h * 0.55:
        return None
    x0 = max(0, x0 - margin); y0 = max(0, y0 - margin)
    x1 = min(w, x1 + margin); y1 = min(h, y1 + margin)
    return (x0, y0, x1, y1)
