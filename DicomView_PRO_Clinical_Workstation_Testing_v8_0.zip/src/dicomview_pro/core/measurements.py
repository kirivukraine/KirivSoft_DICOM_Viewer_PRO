from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class DistanceResult:
    millimeters: float
    pixels: float

@dataclass(frozen=True)
class AngleResult:
    degrees: float

@dataclass(frozen=True)
class RoiStats:
    count: int
    min_hu: float
    max_hu: float
    mean_hu: float
    median_hu: float
    std_hu: float
    area_mm2: float


def distance_mm(p1: tuple[int, int], p2: tuple[int, int], spacing_row_col: tuple[float, float]) -> DistanceResult:
    x1, y1 = p1
    x2, y2 = p2
    row_mm, col_mm = spacing_row_col
    dx_px = float(x2 - x1)
    dy_px = float(y2 - y1)
    pixels = math.hypot(dx_px, dy_px)
    mm = math.hypot(dx_px * float(col_mm), dy_px * float(row_mm))
    return DistanceResult(mm, pixels)


def angle_degrees(p1: tuple[int, int], vertex: tuple[int, int], p3: tuple[int, int]) -> AngleResult:
    ax, ay = p1[0] - vertex[0], p1[1] - vertex[1]
    bx, by = p3[0] - vertex[0], p3[1] - vertex[1]
    na = math.hypot(ax, ay)
    nb = math.hypot(bx, by)
    if na <= 0 or nb <= 0:
        return AngleResult(0.0)
    cosv = max(-1.0, min(1.0, (ax * bx + ay * by) / (na * nb)))
    return AngleResult(math.degrees(math.acos(cosv)))


def _stats_from_mask(slice_hu: np.ndarray, mask: np.ndarray, spacing_row_col: tuple[float, float]) -> RoiStats:
    a = np.asarray(slice_hu, dtype=np.float32)
    if mask.shape != a.shape[:2]:
        raise ValueError("ROI mask shape does not match image shape")
    finite = a[mask & np.isfinite(a)]
    row_mm, col_mm = spacing_row_col
    area = float(finite.size) * float(row_mm) * float(col_mm)
    if finite.size == 0:
        return RoiStats(0, 0, 0, 0, 0, 0, 0)
    return RoiStats(
        int(finite.size),
        float(np.min(finite)),
        float(np.max(finite)),
        float(np.mean(finite)),
        float(np.median(finite)),
        float(np.std(finite)),
        area,
    )


def roi_stats_hu(slice_hu: np.ndarray, p1: tuple[int, int], p2: tuple[int, int], spacing_row_col: tuple[float, float]) -> RoiStats:
    a = np.asarray(slice_hu, dtype=np.float32)
    h, w = a.shape[:2]
    ax, ay = p1
    bx, by = p2
    x0, x1 = sorted((max(0, min(w - 1, int(ax))), max(0, min(w - 1, int(bx)))))
    y0, y1 = sorted((max(0, min(h - 1, int(ay))), max(0, min(h - 1, int(by)))))
    mask = np.zeros((h, w), dtype=bool)
    mask[y0:y1 + 1, x0:x1 + 1] = True
    return _stats_from_mask(a, mask, spacing_row_col)


def circle_roi_stats_hu(slice_hu: np.ndarray, center: tuple[int, int], edge: tuple[int, int], spacing_row_col: tuple[float, float]) -> RoiStats:
    a = np.asarray(slice_hu, dtype=np.float32)
    h, w = a.shape[:2]
    cx, cy = center
    ex, ey = edge
    # True circular ROI in pixel space.  The second point defines the radius.
    radius = max(1.0, float(np.hypot(float(ex - cx), float(ey - cy))))
    yy, xx = np.ogrid[:h, :w]
    mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= radius ** 2
    return _stats_from_mask(a, mask, spacing_row_col)


def polygon_roi_stats_hu(slice_hu: np.ndarray, points: list[tuple[int, int]], spacing_row_col: tuple[float, float]) -> RoiStats:
    a = np.asarray(slice_hu, dtype=np.float32)
    h, w = a.shape[:2]
    if len(points) < 3:
        return RoiStats(0, 0, 0, 0, 0, 0, 0)
    pts = [(max(0, min(w - 1, int(x))), max(0, min(h - 1, int(y)))) for x, y in points]
    yy, xx = np.mgrid[:h, :w]
    mask = np.zeros((h, w), dtype=bool)
    # Ray casting vectorized over the image grid.
    x = xx.astype(np.float32) + 0.5
    y = yy.astype(np.float32) + 0.5
    n = len(pts)
    inside = np.zeros((h, w), dtype=bool)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        cond = ((y1 > y) != (y2 > y)) & (x < (x2 - x1) * (y - y1) / ((y2 - y1) if (y2 - y1) != 0 else 1e-6) + x1)
        inside ^= cond
    mask |= inside
    return _stats_from_mask(a, mask, spacing_row_col)
