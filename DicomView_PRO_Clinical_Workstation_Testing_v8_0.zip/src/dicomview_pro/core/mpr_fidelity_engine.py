from __future__ import annotations

"""High-fidelity 2D/MPR slice extraction for DicomView PRO.

The engine is intentionally display-only.  It does not mutate the loaded DICOM
volume and it does not change the 3D rendering pipeline.  Its job is to make
coronal/sagittal reconstructed CT views readable by compensating anisotropic
slice spacing and using cubic interpolation instead of raw array transpose.
"""

from dataclasses import dataclass
from typing import Literal
import numpy as np

Plane = Literal["axial", "coronal", "sagittal"]


@dataclass(frozen=True)
class MPRSlice:
    image: np.ndarray
    pixel_spacing: tuple[float, float]  # row, col mm after display resampling
    original_plane: str
    original_index: int
    resample_factor: float


def _spacing3(spacing) -> tuple[float, float, float]:
    try:
        z, y, x = [float(v) for v in spacing]
        return max(z, 1e-6), max(y, 1e-6), max(x, 1e-6)
    except Exception:
        return 1.0, 1.0, 1.0


def _clip_index(index: int, maximum: int) -> int:
    return int(max(0, min(maximum, int(index))))


def _resize_rows_numpy(img: np.ndarray, factor: float) -> np.ndarray:
    """Dependency-free linear row interpolation fallback.

    Used only when SciPy/Pillow is not available.  It is still much better than
    showing raw thick-slice rows in coronal/sagittal MPR.
    """
    src = np.asarray(img, dtype=np.float32)
    if factor <= 1.01 or src.shape[0] < 2:
        return np.ascontiguousarray(src)
    new_h = max(2, int(round(src.shape[0] * float(factor))))
    old_y = np.arange(src.shape[0], dtype=np.float32)
    new_y = np.linspace(0.0, float(src.shape[0] - 1), new_h, dtype=np.float32)
    out = np.empty((new_h, src.shape[1]), dtype=np.float32)
    for c in range(src.shape[1]):
        out[:, c] = np.interp(new_y, old_y, src[:, c])
    return np.ascontiguousarray(out)


def _resize_rows(img: np.ndarray, factor: float, order: int = 3) -> np.ndarray:
    if factor <= 1.01:
        return np.ascontiguousarray(img.astype(np.float32, copy=False))
    factor = min(float(factor), 8.0)  # safety: avoid pathological huge previews
    try:
        from scipy.ndimage import zoom  # type: ignore
        out = zoom(np.asarray(img, dtype=np.float32), (factor, 1.0), order=int(order), mode="nearest", prefilter=True)
        return np.ascontiguousarray(out.astype(np.float32, copy=False))
    except Exception:
        return _resize_rows_numpy(img, factor)




def _mean_slab(volume: np.ndarray, axis: int, index: int, half: int) -> np.ndarray:
    """Return a thin HU slab averaged around index for cleaner MPR display.

    This is display-oriented and deterministic.  For coronal/sagittal CT with
    thick Z spacing, a 3-slice in-plane slab reduces single-slice quantum noise
    and stair-step artifacts without hiding large structures.  When half == 0,
    it returns the original plane.
    """
    vol = np.asarray(volume, dtype=np.float32)
    n = vol.shape[int(axis)]
    i0 = max(0, int(index) - int(max(0, half)))
    i1 = min(n, int(index) + int(max(0, half)) + 1)
    if axis == 0:
        return np.mean(vol[i0:i1, :, :], axis=0)
    if axis == 1:
        return np.mean(vol[:, i0:i1, :], axis=1)
    return np.mean(vol[:, :, i0:i1], axis=2)


def extract_mpr_slice(volume: np.ndarray, plane: str, index: int, spacing=(1.0, 1.0, 1.0), *, cubic: bool = True, slab_slices: int | None = None) -> MPRSlice:
    """Return an MPR slice corrected for anisotropic CT spacing.

    volume layout is z, y, x.  Axial is returned as-is.  Coronal/sagittal are
    flipped into clinical head-up orientation and vertically resampled when the
    source z-spacing is thicker than in-plane spacing.
    """
    vol = np.asarray(volume)
    if vol.ndim != 3:
        raise ValueError("MPR volume must be a 3D numpy array in z,y,x order")
    zsp, ysp, xsp = _spacing3(spacing)
    z, y, x = vol.shape
    p = (plane or "axial").lower()
    order = 3 if cubic else 1
    # Default for reconstructed planes: a tiny 3-slice slab in the in-plane axis.
    # It improves noisy coronal/sagittal CT display while axial remains a true slice.
    slab = 3 if slab_slices is None else int(max(1, slab_slices))
    half = max(0, slab // 2)
    if p == "coronal":
        idx = _clip_index(index, y - 1)
        raw = np.flipud(np.asarray(_mean_slab(vol, 1, idx, half), dtype=np.float32))
        # Rows are z, columns are x.  Resample rows to x spacing.
        factor = zsp / max(xsp, 1e-6)
        img = _resize_rows(raw, factor, order=order)
        return MPRSlice(img, (xsp, xsp), "coronal", idx, float(max(1.0, factor)))
    if p == "sagittal":
        idx = _clip_index(index, x - 1)
        raw = np.flipud(np.asarray(_mean_slab(vol, 2, idx, half), dtype=np.float32))
        # Rows are z, columns are y.  Resample rows to y spacing.
        factor = zsp / max(ysp, 1e-6)
        img = _resize_rows(raw, factor, order=order)
        return MPRSlice(img, (ysp, ysp), "sagittal", idx, float(max(1.0, factor)))
    idx = _clip_index(index, z - 1)
    return MPRSlice(np.ascontiguousarray(vol[idx].astype(np.float32, copy=False)), (ysp, xsp), "axial", idx, 1.0)



def _resize_rows_mask(mask: np.ndarray, factor: float) -> np.ndarray:
    """Nearest-neighbour row resize for binary MPR overlays.

    Used for protocol masks so the colored overlay stays geometrically aligned
    with coronal/sagittal high-fidelity MPR slices.
    """
    src = np.asarray(mask).astype(bool)
    if factor <= 1.01 or src.shape[0] < 2:
        return np.ascontiguousarray(src)
    factor = min(float(factor), 8.0)
    new_h = max(2, int(round(src.shape[0] * factor)))
    idx = np.clip(np.round(np.linspace(0.0, src.shape[0] - 1, new_h)).astype(int), 0, src.shape[0] - 1)
    return np.ascontiguousarray(src[idx, :])


def _max_slab_mask(mask: np.ndarray, axis: int, index: int, half: int) -> np.ndarray:
    m = np.asarray(mask).astype(bool)
    n = m.shape[int(axis)]
    i0 = max(0, int(index) - int(max(0, half)))
    i1 = min(n, int(index) + int(max(0, half)) + 1)
    if axis == 0:
        return np.max(m[i0:i1, :, :], axis=0)
    if axis == 1:
        return np.max(m[:, i0:i1, :], axis=1)
    return np.max(m[:, :, i0:i1], axis=2)


def extract_mpr_mask_slice(mask: np.ndarray, plane: str, index: int, spacing=(1.0, 1.0, 1.0), *, slab_slices: int = 3) -> np.ndarray:
    """Return a binary protocol mask aligned with ``extract_mpr_slice`` output."""
    m = np.asarray(mask).astype(bool)
    if m.ndim != 3:
        raise ValueError("MPR mask must be a 3D numpy array in z,y,x order")
    zsp, ysp, xsp = _spacing3(spacing)
    z, y, x = m.shape
    p = (plane or "axial").lower()
    half = max(0, int(max(1, slab_slices)) // 2)
    if p == "coronal":
        idx = _clip_index(index, y - 1)
        raw = np.flipud(_max_slab_mask(m, 1, idx, half))
        return _resize_rows_mask(raw, zsp / max(xsp, 1e-6))
    if p == "sagittal":
        idx = _clip_index(index, x - 1)
        raw = np.flipud(_max_slab_mask(m, 2, idx, half))
        return _resize_rows_mask(raw, zsp / max(ysp, 1e-6))
    idx = _clip_index(index, z - 1)
    return np.ascontiguousarray(m[idx])


def display_crosshair_for_mpr(plane: str, cross_z: int, cross_y: int, cross_x: int, volume_shape, resample_factor: float = 1.0) -> tuple[int, int]:
    """Map volume crosshair to the resampled display image coordinates."""
    z, y, x = volume_shape
    p = (plane or "axial").lower()
    if p == "coronal":
        row = int(round((z - 1 - int(cross_z)) * float(max(1.0, resample_factor))))
        return int(cross_x), row
    if p == "sagittal":
        row = int(round((z - 1 - int(cross_z)) * float(max(1.0, resample_factor))))
        return int(cross_y), row
    return int(cross_x), int(cross_y)

class MPRFidelityCache:
    """Small per-series MPR slice cache.

    The cache stores display-ready HU slices produced by ``extract_mpr_slice``.
    It is intentionally bounded so Lite remains responsive on older machines.
    Key includes volume id, shape, spacing, plane and index.  When a new series is
    loaded ``clear()`` should be called.
    """
    def __init__(self, max_items: int = 192):
        self.max_items = int(max(24, max_items))
        self._cache: dict[tuple, MPRSlice] = {}
        self._order: list[tuple] = []

    def clear(self) -> None:
        self._cache.clear()
        self._order.clear()

    def get(self, volume: np.ndarray, plane: str, index: int, spacing=(1.0, 1.0, 1.0), *, cubic: bool = True, slab_slices: int | None = None) -> MPRSlice:
        try:
            sp = tuple(round(float(v), 6) for v in spacing)
        except Exception:
            sp = (1.0, 1.0, 1.0)
        key = (id(volume), tuple(getattr(volume, "shape", ())), sp, str(plane).lower(), int(index), bool(cubic), int(slab_slices or 0))
        item = self._cache.get(key)
        if item is not None:
            return item
        item = extract_mpr_slice(volume, plane, index, spacing, cubic=cubic, slab_slices=slab_slices)
        self._cache[key] = item
        self._order.append(key)
        while len(self._order) > self.max_items:
            old = self._order.pop(0)
            self._cache.pop(old, None)
        return item


def estimate_mpr_cache_items(volume_shape, ram_budget_mb: int | float | None = None) -> int:
    """Return a safe number of cached MPR slices for the current study.

    One MPR slice is usually 0.5-4 MB in float32 after resampling.  This helper
    keeps the cache useful without consuming excessive RAM.
    """
    try:
        z, y, x = [int(v) for v in volume_shape]
        approx_slice_mb = max(y * x, z * x, z * y) * 4 / (1024 * 1024)
        budget = float(ram_budget_mb or 512)
        return int(max(48, min(768, budget / max(approx_slice_mb, 0.5))))
    except Exception:
        return 192
