from __future__ import annotations

"""Classic CPU trauma protocol helpers for DicomView PRO.

The module is deterministic and HU/morphology based.  It is designed to create
visual attention masks and measurements for trauma review; it is not an
automatic fracture diagnosis system.

Volume layout: (z, y, x).  Spacing layout: (z, y, x) in millimetres.
"""

from dataclasses import dataclass
from typing import Any
import math

import numpy as np


@dataclass(frozen=True)
class TraumaProtocolConfig:
    bone_min_hu: float = 220.0
    cortical_bone_min_hu: float = 520.0
    dense_fragment_min_hu: float = 700.0
    air_max_hu: float = -700.0
    hematoma_min_hu: float = 45.0
    hematoma_max_hu: float = 105.0
    min_component_ml: float = 0.03
    max_component_ml: float = 5000.0
    keep_components: int = 96
    morphology_iterations: int = 1


@dataclass
class TraumaProtocolResult:
    mask: np.ndarray
    bone_mask: np.ndarray
    cortical_mask: np.ndarray
    air_mask: np.ndarray
    dense_fragment_mask: np.ndarray
    hematoma_candidate_mask: np.ndarray
    volume_ml: float
    voxel_count: int
    component_count: int
    components: list[dict[str, Any]]
    class_metrics: dict[str, Any]
    bbox_voxels: tuple[int, int, int, int, int, int] | None
    bbox_mm: tuple[float, float, float] | None
    center_of_mass_voxels: tuple[float, float, float] | None
    confidence: float
    notes: list[str]
    debug: dict[str, Any]


class TraumaProtocolAnalyzer:
    """Create trauma-focused masks for bone, air and dense fragments."""

    def __init__(self, config: TraumaProtocolConfig | None = None) -> None:
        self.config = config or TraumaProtocolConfig()

    def analyze(self, volume_hu: np.ndarray, spacing_zyx_mm: tuple[float, float, float]) -> TraumaProtocolResult:
        if volume_hu is None or np.asarray(volume_hu).ndim != 3:
            raise ValueError("volume_hu must be a 3D array shaped (z, y, x)")
        v = np.asarray(volume_hu, dtype=np.float32)
        spacing = tuple(float(x) for x in spacing_zyx_mm)
        cfg = self.config
        finite = np.isfinite(v)

        raw_bone = finite & (v >= cfg.bone_min_hu)
        raw_cortical = finite & (v >= cfg.cortical_bone_min_hu)
        raw_dense = finite & (v >= cfg.dense_fragment_min_hu)
        raw_air = finite & (v <= cfg.air_max_hu)
        raw_hema = finite & (v >= cfg.hematoma_min_hu) & (v <= cfg.hematoma_max_hu)

        bone = self._clean(raw_bone, cfg.morphology_iterations)
        cortical = self._clean(raw_cortical, max(0, cfg.morphology_iterations - 1))
        air = self._clean(raw_air, 0)
        dense = self._keep_components(raw_dense, spacing, min_ml=cfg.min_component_ml, max_ml=250.0, keep=cfg.keep_components)
        hema = self._keep_components(raw_hema, spacing, min_ml=0.10, max_ml=500.0, keep=48)

        # Unified trauma attention mask.  Bone/cortical structures dominate the 3D
        # focus; air and hematoma candidates are included for 2D overlay/reporting.
        mask = bone | dense | hema | air
        mask = self._keep_components(mask, spacing, min_ml=cfg.min_component_ml, max_ml=cfg.max_component_ml, keep=cfg.keep_components)

        components = self._components(mask, spacing, v, dense, air, hema, cortical)
        voxel_count = int(np.count_nonzero(mask))
        volume_ml = voxel_count * self._voxel_ml(spacing)
        bbox = self._bbox(mask)
        bbox_mm = self._bbox_mm(bbox, spacing) if bbox else None
        com = self._center(mask)
        class_metrics = {
            "bone_ml": round(float(np.count_nonzero(bone) * self._voxel_ml(spacing)), 4),
            "cortical_bone_ml": round(float(np.count_nonzero(cortical) * self._voxel_ml(spacing)), 4),
            "dense_fragment_candidate_ml": round(float(np.count_nonzero(dense) * self._voxel_ml(spacing)), 4),
            "air_candidate_ml": round(float(np.count_nonzero(air) * self._voxel_ml(spacing)), 4),
            "hematoma_candidate_ml": round(float(np.count_nonzero(hema) * self._voxel_ml(spacing)), 4),
            "bone_voxels": int(np.count_nonzero(bone)),
            "air_voxels": int(np.count_nonzero(air)),
            "dense_fragment_voxels": int(np.count_nonzero(dense)),
            "hematoma_candidate_voxels": int(np.count_nonzero(hema)),
        }
        notes = [
            "Травма-протокол підсвічує кістку, щільні фрагменти, повітря та HU-кандидати гематоми.",
            "Це карта уваги для лікаря. Лінію перелому та пошкодження органів підтверджувати на 2D/MPR.",
        ]
        if spacing[0] >= 3.0:
            notes.append(f"Товщина/крок Z ≈ {spacing[0]:.2f} мм: дрібні переломи та фрагменти можуть бути непомітні.")
        confidence = self._confidence(class_metrics, components, spacing)
        debug = {
            "hu_thresholds": {
                "bone_min": cfg.bone_min_hu,
                "cortical_min": cfg.cortical_bone_min_hu,
                "dense_fragment_min": cfg.dense_fragment_min_hu,
                "air_max": cfg.air_max_hu,
                "hematoma_range": [cfg.hematoma_min_hu, cfg.hematoma_max_hu],
            },
            "raw_counts": {
                "bone": int(np.count_nonzero(raw_bone)),
                "cortical": int(np.count_nonzero(raw_cortical)),
                "dense": int(np.count_nonzero(raw_dense)),
                "air": int(np.count_nonzero(raw_air)),
                "hematoma_candidate": int(np.count_nonzero(raw_hema)),
            },
            "algorithm": "ClassicTrauma HU masks + 3D morphology + connected components",
        }
        return TraumaProtocolResult(
            mask=mask.astype(bool),
            bone_mask=bone.astype(bool),
            cortical_mask=cortical.astype(bool),
            air_mask=air.astype(bool),
            dense_fragment_mask=dense.astype(bool),
            hematoma_candidate_mask=hema.astype(bool),
            volume_ml=float(volume_ml),
            voxel_count=voxel_count,
            component_count=len(components),
            components=components,
            class_metrics=class_metrics,
            bbox_voxels=bbox,
            bbox_mm=bbox_mm,
            center_of_mass_voxels=com,
            confidence=confidence,
            notes=notes,
            debug=debug,
        )

    def _clean(self, mask: np.ndarray, iterations: int) -> np.ndarray:
        out = np.asarray(mask, dtype=bool)
        if iterations <= 0 or not np.any(out):
            return out
        try:
            from scipy import ndimage as ndi  # type: ignore
            struct = ndi.generate_binary_structure(3, 1)
            out = ndi.binary_closing(out, structure=struct, iterations=iterations)
            out = ndi.binary_opening(out, structure=struct, iterations=max(1, iterations - 1))
        except Exception:
            pass
        return out.astype(bool)

    def _keep_components(self, mask: np.ndarray, spacing: tuple[float, float, float], min_ml: float, max_ml: float, keep: int) -> np.ndarray:
        m = np.asarray(mask, dtype=bool)
        if not np.any(m):
            return m
        try:
            from scipy import ndimage as ndi  # type: ignore
            labels, n = ndi.label(m)
            voxel_ml = self._voxel_ml(spacing)
            candidates: list[tuple[int, float]] = []
            for lid in range(1, int(n) + 1):
                vox = int(np.count_nonzero(labels == lid))
                ml = vox * voxel_ml
                if min_ml <= ml <= max_ml:
                    candidates.append((lid, ml))
            candidates.sort(key=lambda x: x[1], reverse=True)
            ids = [lid for lid, _ in candidates[: max(1, int(keep))]]
            return np.isin(labels, ids) if ids else (m & False)
        except Exception:
            return m

    def _components(self, mask: np.ndarray, spacing: tuple[float, float, float], volume_hu: np.ndarray, dense: np.ndarray, air: np.ndarray, hema: np.ndarray, cortical: np.ndarray) -> list[dict[str, Any]]:
        try:
            from scipy import ndimage as ndi  # type: ignore
            labels, n = ndi.label(np.asarray(mask, dtype=bool))
            out: list[dict[str, Any]] = []
            voxel_ml = self._voxel_ml(spacing)
            for lid in range(1, int(n) + 1):
                cm = labels == lid
                vox = int(np.count_nonzero(cm))
                if vox <= 0:
                    continue
                bbox = self._bbox(cm)
                dims = self._bbox_mm(bbox, spacing) if bbox else (0.0, 0.0, 0.0)
                vals = volume_hu[cm]
                cls = self._component_class(cm, dense, air, hema, cortical)
                out.append({
                    "label": int(lid),
                    "class": cls,
                    "voxels": vox,
                    "volume_ml": round(float(vox * voxel_ml), 4),
                    "bbox_voxels": list(bbox) if bbox else None,
                    "bbox_mm": [round(float(x), 3) for x in dims],
                    "max_dimension_mm": round(float(max(dims)), 3),
                    "center_of_mass_voxels": [round(float(x), 3) for x in (self._center(cm) or (0.0, 0.0, 0.0))],
                    "hu_min": round(float(np.nanmin(vals)), 2) if vals.size else None,
                    "hu_max": round(float(np.nanmax(vals)), 2) if vals.size else None,
                    "hu_mean": round(float(np.nanmean(vals)), 2) if vals.size else None,
                })
            out.sort(key=lambda d: d.get("volume_ml", 0.0), reverse=True)
            return out
        except Exception:
            return []

    @staticmethod
    def _component_class(cm: np.ndarray, dense: np.ndarray, air: np.ndarray, hema: np.ndarray, cortical: np.ndarray) -> str:
        total = max(1, int(np.count_nonzero(cm)))
        ratios = {
            "dense_fragment_candidate": int(np.count_nonzero(cm & dense)) / total,
            "air_candidate": int(np.count_nonzero(cm & air)) / total,
            "hematoma_candidate": int(np.count_nonzero(cm & hema)) / total,
            "cortical_bone": int(np.count_nonzero(cm & cortical)) / total,
        }
        return max(ratios, key=ratios.get)

    @staticmethod
    def _voxel_ml(spacing: tuple[float, float, float]) -> float:
        return float(spacing[0] * spacing[1] * spacing[2]) / 1000.0

    @staticmethod
    def _bbox(mask: np.ndarray) -> tuple[int, int, int, int, int, int] | None:
        if not np.any(mask):
            return None
        z, y, x = np.where(mask)
        return int(z.min()), int(z.max()), int(y.min()), int(y.max()), int(x.min()), int(x.max())

    @staticmethod
    def _bbox_mm(bbox: tuple[int, int, int, int, int, int] | None, spacing: tuple[float, float, float]) -> tuple[float, float, float] | None:
        if bbox is None:
            return None
        z0, z1, y0, y1, x0, x1 = bbox
        return ((z1 - z0 + 1) * spacing[0], (y1 - y0 + 1) * spacing[1], (x1 - x0 + 1) * spacing[2])

    @staticmethod
    def _center(mask: np.ndarray) -> tuple[float, float, float] | None:
        if not np.any(mask):
            return None
        c = np.argwhere(mask).mean(axis=0)
        return float(c[0]), float(c[1]), float(c[2])

    @staticmethod
    def _confidence(class_metrics: dict[str, Any], components: list[dict[str, Any]], spacing: tuple[float, float, float]) -> float:
        score = 0.25
        if class_metrics.get("bone_voxels", 0) > 0:
            score += 0.25
        if class_metrics.get("dense_fragment_voxels", 0) > 0:
            score += 0.12
        if class_metrics.get("air_voxels", 0) > 0:
            score += 0.10
        if components:
            score += min(0.18, len(components) * 0.01)
        if spacing[0] > 3.0:
            score -= 0.12
        return float(np.clip(score, 0.0, 0.82))
