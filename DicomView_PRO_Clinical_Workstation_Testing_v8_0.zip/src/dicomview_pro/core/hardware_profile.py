from __future__ import annotations
import os, platform, ctypes
from dataclasses import dataclass, asdict

@dataclass
class HardwareProfile:
    cpu: str
    cores: int
    ram_gb: float
    os_name: str
    recommended_3d_mode: str
    note: str
    gpu_hint: str = "unknown"
    safe_mode: bool = False


def _windows_total_ram_gb() -> float:
    if platform.system().lower() != "windows":
        try:
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            return round(pages * page_size / (1024**3), 2)
        except Exception:
            return 0.0
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]
    try:
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        return round(stat.ullTotalPhys / (1024**3), 2)
    except Exception:
        return 0.0


def detect_hardware_profile() -> HardwareProfile:
    cpu = platform.processor() or platform.machine() or "Unknown CPU"
    cores = os.cpu_count() or 1
    ram = _windows_total_ram_gb()
    os_name = f"{platform.system()} {platform.release()}"
    weak = False
    reasons = []
    if cores <= 2:
        weak = True; reasons.append("мало ядер CPU")
    if 0 < ram < 6:
        weak = True; reasons.append("мало RAM")
    low_cpu_words = ("celeron", "atom", "pentium", "core(tm)2", "sempron", "e-", "n3050", "n3060")
    if any(w in cpu.lower() for w in low_cpu_words):
        weak = True; reasons.append("старий/слабкий CPU")
    if weak:
        return HardwareProfile(cpu, cores, ram, os_name, "Auto Safe / старий ПК", "Рекомендовано безпечний CPU MIP Preview; VTK запускати тільки вручну.", "low_or_unknown", True)
    return HardwareProfile(cpu, cores, ram, os_name, "VTK Surface Safe", "Можна пробувати легкий VTK Surface; повний Volume Rendering — за наявності нормального OpenGL-драйвера.", "standard_or_unknown", False)


def profile_dict() -> dict:
    return asdict(detect_hardware_profile())
