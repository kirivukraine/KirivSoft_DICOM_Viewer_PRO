
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, logging, time

log = logging.getLogger(__name__)

@dataclass
class PacsConfig:
    ae_title: str = "DICOMVIEW"
    peer_ae_title: str = "ANY-SCP"
    host: str = "127.0.0.1"
    port: int = 104
    timeout: int = 10

@dataclass
class PacsResult:
    ok: bool
    message: str
    details: dict


def _require_pynetdicom():
    try:
        import pynetdicom  # noqa: F401
        import pydicom  # noqa: F401
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("PACS PRO потребує pynetdicom та pydicom. Встановіть залежності з requirements.txt") from exc


def echo(cfg: PacsConfig) -> PacsResult:
    _require_pynetdicom()
    from pynetdicom import AE
    from pynetdicom.sop_class import Verification
    ae = AE(ae_title=cfg.ae_title)
    ae.add_requested_context(Verification)
    assoc = ae.associate(cfg.host, int(cfg.port), ae_title=cfg.peer_ae_title, max_pdu=16384)
    try:
        if not assoc.is_established:
            return PacsResult(False, "Асоціацію з PACS не встановлено", asdict(cfg))
        status = assoc.send_c_echo()
        ok = bool(status and status.Status == 0x0000)
        return PacsResult(ok, "C-ECHO OK" if ok else f"C-ECHO status={getattr(status,'Status',None)}", {"status": getattr(status,'Status',None)})
    finally:
        try: assoc.release()
        except Exception: pass


def find_studies(cfg: PacsConfig, patient_name: str = "*", limit: int = 50) -> PacsResult:
    _require_pynetdicom()
    from pydicom.dataset import Dataset
    from pynetdicom import AE
    from pynetdicom.sop_class import StudyRootQueryRetrieveInformationModelFind
    ae = AE(ae_title=cfg.ae_title)
    ae.add_requested_context(StudyRootQueryRetrieveInformationModelFind)
    assoc = ae.associate(cfg.host, int(cfg.port), ae_title=cfg.peer_ae_title)
    rows = []
    try:
        if not assoc.is_established:
            return PacsResult(False, "Асоціацію з PACS не встановлено", asdict(cfg))
        ds = Dataset()
        ds.QueryRetrieveLevel = "STUDY"
        ds.PatientName = patient_name or "*"
        ds.PatientID = ""
        ds.StudyDate = ""
        ds.StudyDescription = ""
        ds.StudyInstanceUID = ""
        ds.ModalitiesInStudy = ""
        for status, ident in assoc.send_c_find(ds, StudyRootQueryRetrieveInformationModelFind):
            if status is None:
                continue
            if getattr(status, 'Status', None) in (0xFF00, 0xFF01) and ident is not None:
                rows.append({
                    "PatientName": str(getattr(ident, 'PatientName', '')),
                    "PatientID": str(getattr(ident, 'PatientID', '')),
                    "StudyDate": str(getattr(ident, 'StudyDate', '')),
                    "StudyDescription": str(getattr(ident, 'StudyDescription', '')),
                    "ModalitiesInStudy": str(getattr(ident, 'ModalitiesInStudy', '')),
                    "StudyInstanceUID": str(getattr(ident, 'StudyInstanceUID', '')),
                })
                if len(rows) >= int(limit):
                    break
        return PacsResult(True, f"Знайдено досліджень: {len(rows)}", {"rows": rows})
    finally:
        try: assoc.release()
        except Exception: pass


def store_file(cfg: PacsConfig, file_path: str | Path) -> PacsResult:
    _require_pynetdicom()
    import pydicom
    from pynetdicom import AE
    from pynetdicom.sop_class import CTImageStorage, MRImageStorage, DigitalXRayImageStorageForPresentation, SecondaryCaptureImageStorage, XRayAngiographicImageStorage
    path = Path(file_path)
    ds = pydicom.dcmread(str(path), force=True)
    ae = AE(ae_title=cfg.ae_title)
    for context in [CTImageStorage, MRImageStorage, DigitalXRayImageStorageForPresentation, SecondaryCaptureImageStorage, XRayAngiographicImageStorage]:
        ae.add_requested_context(context)
    assoc = ae.associate(cfg.host, int(cfg.port), ae_title=cfg.peer_ae_title)
    try:
        if not assoc.is_established:
            return PacsResult(False, "Асоціацію з PACS не встановлено", {"file": str(path)})
        status = assoc.send_c_store(ds)
        ok = bool(status and getattr(status, 'Status', None) in (0x0000, 0xB000, 0xB006, 0xB007))
        return PacsResult(ok, "C-STORE завершено" if ok else f"C-STORE status={getattr(status,'Status',None)}", {"file": str(path), "status": getattr(status,'Status',None)})
    finally:
        try: assoc.release()
        except Exception: pass


def write_pacs_audit(event: str, result: PacsResult, log_dir: str | Path) -> Path:
    out = Path(log_dir); out.mkdir(parents=True, exist_ok=True)
    path = out / "pacs_audit.jsonl"
    row = {"ts": time.time(), "event": event, "ok": result.ok, "message": result.message, "details": result.details}
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return path
