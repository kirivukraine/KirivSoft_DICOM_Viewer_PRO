from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import datetime as _dt
try:
    import pydicom
    from pydicom.dataset import Dataset, FileDataset, FileMetaDataset
    from pydicom.uid import ExplicitVRLittleEndian, generate_uid
except Exception:  # optional in lightweight test/build environments
    pydicom = None
    Dataset = FileDataset = FileMetaDataset = None
    ExplicitVRLittleEndian = None
    def generate_uid():
        raise RuntimeError("pydicom is required for Dicomizer")

SECONDARY_CAPTURE = "1.2.840.10008.5.1.4.1.1.7"
ENCAPSULATED_PDF = "1.2.840.10008.5.1.4.1.1.104.1"
ENCAPSULATED_STL = "1.2.840.10008.5.1.4.1.1.104.3"
ENCAPSULATED_OBJ = "1.2.840.10008.5.1.4.1.1.104.4"
ENCAPSULATED_MTL = "1.2.840.10008.5.1.4.1.1.104.5"

@dataclass
class DicomizerResult:
    ok: bool
    output_path: str
    message: str
    sop_class_uid: str = ""


def _base_dataset(out_path: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> FileDataset:
    if pydicom is None or FileDataset is None or FileMetaDataset is None:
        raise RuntimeError("pydicom is required for Dicomizer")
    now = _dt.datetime.now()
    meta = FileMetaDataset()
    meta.TransferSyntaxUID = ExplicitVRLittleEndian
    meta.MediaStorageSOPInstanceUID = generate_uid()
    ds = FileDataset(str(out_path), {}, file_meta=meta, preamble=b"\0" * 128)
    ds.PatientName = patient_name or "Anonymous"
    ds.PatientID = patient_id or "DICOMIZER"
    ds.StudyInstanceUID = generate_uid()
    ds.SeriesInstanceUID = generate_uid()
    ds.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
    ds.StudyDate = now.strftime("%Y%m%d")
    ds.StudyTime = now.strftime("%H%M%S")
    ds.Modality = "OT"
    ds.Manufacturer = "KirivSoft"
    ds.SoftwareVersions = "DicomView PRO Dicomizer"
    return ds


def image_to_secondary_capture(input_path: str | Path, output_path: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:
    try:
        from PIL import Image
        import numpy as np
    except Exception as exc:
        return DicomizerResult(False, str(output_path), f"Pillow/NumPy unavailable: {exc}", SECONDARY_CAPTURE)
    inp, out = Path(input_path), Path(output_path)
    img = Image.open(inp).convert("L")
    arr = np.asarray(img, dtype="uint8")
    ds = _base_dataset(out, patient_name, patient_id)
    ds.SOPClassUID = SECONDARY_CAPTURE
    ds.file_meta.MediaStorageSOPClassUID = SECONDARY_CAPTURE
    ds.Modality = "OT"
    ds.Rows, ds.Columns = int(arr.shape[0]), int(arr.shape[1])
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.BitsAllocated = 8
    ds.BitsStored = 8
    ds.HighBit = 7
    ds.PixelRepresentation = 0
    ds.PixelData = arr.tobytes()
    out.parent.mkdir(parents=True, exist_ok=True)
    ds.save_as(str(out), write_like_original=False)
    return DicomizerResult(True, str(out), "Image converted to DICOM Secondary Capture", SECONDARY_CAPTURE)


def pdf_to_dicom(input_path: str | Path, output_path: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:
    inp, out = Path(input_path), Path(output_path)
    ds = _base_dataset(out, patient_name, patient_id)
    ds.SOPClassUID = ENCAPSULATED_PDF
    ds.file_meta.MediaStorageSOPClassUID = ENCAPSULATED_PDF
    ds.Modality = "DOC"
    ds.MIMETypeOfEncapsulatedDocument = "application/pdf"
    ds.EncapsulatedDocument = inp.read_bytes()
    out.parent.mkdir(parents=True, exist_ok=True)
    ds.save_as(str(out), write_like_original=False)
    return DicomizerResult(True, str(out), "PDF encapsulated as DICOM", ENCAPSULATED_PDF)


def stl_to_dicom(input_path: str | Path, output_path: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:
    inp, out = Path(input_path), Path(output_path)
    ds = _base_dataset(out, patient_name, patient_id)
    ds.SOPClassUID = ENCAPSULATED_STL
    ds.file_meta.MediaStorageSOPClassUID = ENCAPSULATED_STL
    ds.Modality = "M3D"
    ds.MIMETypeOfEncapsulatedDocument = "model/stl"
    ds.EncapsulatedDocument = inp.read_bytes()
    out.parent.mkdir(parents=True, exist_ok=True)
    ds.save_as(str(out), write_like_original=False)
    return DicomizerResult(True, str(out), "STL encapsulated as DICOM", ENCAPSULATED_STL)


def dicomize_file(input_path: str | Path, output_dir: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:
    inp = Path(input_path)
    out = Path(output_dir) / (inp.stem + ".dcm")
    ext = inp.suffix.lower()
    if ext in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}:
        return image_to_secondary_capture(inp, out, patient_name, patient_id)
    if ext == ".pdf":
        return pdf_to_dicom(inp, out, patient_name, patient_id)
    if ext == ".stl":
        return stl_to_dicom(inp, out, patient_name, patient_id)
    return DicomizerResult(False, str(out), f"Unsupported input type: {ext}")


def obj_to_dicom(input_path: str | Path, output_path: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:
    inp, out = Path(input_path), Path(output_path)
    ds = _base_dataset(out, patient_name, patient_id)
    ds.SOPClassUID = ENCAPSULATED_OBJ
    ds.file_meta.MediaStorageSOPClassUID = ENCAPSULATED_OBJ
    ds.Modality = "M3D"
    ds.MIMETypeOfEncapsulatedDocument = "model/obj"
    ds.EncapsulatedDocument = inp.read_bytes()
    out.parent.mkdir(parents=True, exist_ok=True)
    ds.save_as(str(out), write_like_original=False)
    return DicomizerResult(True, str(out), "OBJ encapsulated as DICOM", ENCAPSULATED_OBJ)

# Replace dispatcher with extended input support. PLY/GLB are preserved as a safe
# secondary encapsulated document placeholder because DICOM standard storage SOP
# classes for these formats are not universally supported in viewers.
def dicomize_file(input_path: str | Path, output_dir: str | Path, patient_name: str = "Anonymous", patient_id: str = "DICOMIZER") -> DicomizerResult:  # type: ignore[override]
    inp = Path(input_path)
    out = Path(output_dir) / (inp.stem + ".dcm")
    ext = inp.suffix.lower()
    if ext in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}:
        return image_to_secondary_capture(inp, out, patient_name, patient_id)
    if ext == ".pdf":
        return pdf_to_dicom(inp, out, patient_name, patient_id)
    if ext == ".stl":
        return stl_to_dicom(inp, out, patient_name, patient_id)
    if ext == ".obj":
        return obj_to_dicom(inp, out, patient_name, patient_id)
    if ext in {".ply", ".glb", ".gltf"}:
        ds = _base_dataset(out, patient_name, patient_id)
        ds.SOPClassUID = ENCAPSULATED_STL
        ds.file_meta.MediaStorageSOPClassUID = ENCAPSULATED_STL
        ds.Modality = "M3D"
        ds.MIMETypeOfEncapsulatedDocument = "application/octet-stream"
        ds.EncapsulatedDocument = inp.read_bytes()
        out.parent.mkdir(parents=True, exist_ok=True)
        ds.save_as(str(out), write_like_original=False)
        return DicomizerResult(True, str(out), f"{ext.upper()} encapsulated as DICOM M3D compatibility object", ENCAPSULATED_STL)
    return DicomizerResult(False, str(out), f"Unsupported input type: {ext}")
