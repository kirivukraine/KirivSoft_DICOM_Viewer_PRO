from dataclasses import dataclass

@dataclass(frozen=True)
class HemorrhageConfig:
    """Default CT brain hemorrhage segmentation settings.

    Values are conservative defaults for non-contrast head CT. They must be
    adjustable in UI because acquisition protocol, scanner kernel and windowing
    change apparent HU distribution.
    """
    blood_hu_min: float = 45.0
    blood_hu_max: float = 95.0
    brain_hu_min: float = 0.0
    brain_hu_max: float = 120.0
    bone_hu_min: float = 180.0
    min_component_ml: float = 0.05
    max_component_ml: float = 120.0
    close_radius_vox: int = 1
    fill_holes: bool = True
    keep_largest_components: int = 8
    skull_strip_soft: bool = True
    remove_midline_calcified_structures: bool = True
    midline_exclusion_mm: float = 4.0
