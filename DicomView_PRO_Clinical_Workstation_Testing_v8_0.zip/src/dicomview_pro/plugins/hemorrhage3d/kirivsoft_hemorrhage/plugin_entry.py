from __future__ import annotations
from pathlib import Path
from typing import Any, Dict
from .hemorrhage_detector import HemorrhageDetector
from .midline_shift import estimate_midline_shift_mm
from .mesh_export import export_mask_mesh
from .render_presets import vtk_volume_transfer_preset


class Hemorrhage3DPlugin:
    name = "Hemorrhage 3D PRO"
    author = "Іван Кіранчук / KirivSoft"
    version = "1.0.0"

    def __init__(self) -> None:
        self.detector = HemorrhageDetector()
        self.last_result = None

    def analyze_volume(self, volume_hu, spacing_zyx_mm) -> Dict[str, Any]:
        result = self.detector.detect(volume_hu, spacing_zyx_mm)
        shift = estimate_midline_shift_mm(result.brain_mask, result.mask, spacing_zyx_mm)
        self.last_result = result
        return {
            "hemorrhage_mask": result.mask,
            "brain_mask": result.brain_mask,
            "bone_mask": result.bone_mask,
            "volume_ml": result.volume_ml,
            "bbox_mm": result.bbox_mm,
            "confidence": result.confidence,
            "components": result.components,
            "midline_shift": shift,
            "render_preset": vtk_volume_transfer_preset(),
            "notes": result.notes,
        }

    def export_hemorrhage_mesh(self, out_path: str | Path, spacing_zyx_mm) -> Path:
        if self.last_result is None:
            raise RuntimeError("Run analyze_volume() before export")
        return export_mask_mesh(self.last_result.mask, spacing_zyx_mm, out_path)


def register(app: Any) -> Hemorrhage3DPlugin:
    """Optional DicomView PRO plugin hook.

    Expected app hooks if present:
    - app.plugin_manager.add_plugin(plugin)
    - app.volume_tools.add_transfer_preset(dict)
    - app.tools_menu.addAction(...)
    """
    plugin = Hemorrhage3DPlugin()
    if hasattr(app, "plugin_manager") and hasattr(app.plugin_manager, "add_plugin"):
        app.plugin_manager.add_plugin(plugin)
    if hasattr(app, "volume_tools") and hasattr(app.volume_tools, "add_transfer_preset"):
        app.volume_tools.add_transfer_preset(vtk_volume_transfer_preset())
    return plugin
