from __future__ import annotations
from pathlib import Path
from typing import Tuple
import numpy as np


def export_mask_mesh(mask: np.ndarray, spacing_zyx_mm: Tuple[float, float, float], out_path: str | Path) -> Path:
    """Export hemorrhage mask to STL/PLY/OBJ using marching cubes."""
    out = Path(out_path)
    if mask.ndim != 3 or not np.any(mask):
        raise ValueError("mask must be a non-empty 3D boolean array")
    try:
        from skimage import measure  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("scikit-image is required for mesh export") from exc
    verts, faces, _, _ = measure.marching_cubes(mask.astype(np.uint8), level=0.5, spacing=spacing_zyx_mm)
    # marching_cubes returns z,y,x. Export x,y,z for common viewers.
    xyz = verts[:, [2, 1, 0]]
    suffix = out.suffix.lower()
    if suffix == ".obj":
        _write_obj(out, xyz, faces)
    elif suffix == ".ply":
        _write_ply(out, xyz, faces)
    elif suffix == ".stl":
        _write_ascii_stl(out, xyz, faces)
    else:
        raise ValueError("Supported mesh formats: .stl, .ply, .obj")
    return out


def _write_obj(path: Path, verts: np.ndarray, faces: np.ndarray) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write("# KirivSoft hemorrhage mask OBJ\n")
        for v in verts:
            f.write(f"v {v[0]:.5f} {v[1]:.5f} {v[2]:.5f}\n")
        for tri in faces:
            a, b, c = tri + 1
            f.write(f"f {a} {b} {c}\n")


def _write_ply(path: Path, verts: np.ndarray, faces: np.ndarray) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write("ply\nformat ascii 1.0\n")
        f.write(f"element vertex {len(verts)}\nproperty float x\nproperty float y\nproperty float z\n")
        f.write(f"element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n")
        for v in verts:
            f.write(f"{v[0]:.5f} {v[1]:.5f} {v[2]:.5f}\n")
        for tri in faces:
            f.write(f"3 {tri[0]} {tri[1]} {tri[2]}\n")


def _write_ascii_stl(path: Path, verts: np.ndarray, faces: np.ndarray) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write("solid hemorrhage\n")
        for tri in faces:
            p = verts[tri]
            n = np.cross(p[1] - p[0], p[2] - p[0])
            norm = np.linalg.norm(n)
            if norm > 0:
                n = n / norm
            f.write(f" facet normal {n[0]:.6f} {n[1]:.6f} {n[2]:.6f}\n  outer loop\n")
            for v in p:
                f.write(f"   vertex {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            f.write("  endloop\n endfacet\n")
        f.write("endsolid hemorrhage\n")
