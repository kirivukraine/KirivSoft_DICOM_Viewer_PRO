from __future__ import annotations
from typing import Tuple, Dict, Any
import numpy as np


def estimate_midline_shift_mm(brain_mask: np.ndarray, hemorrhage_mask: np.ndarray, spacing_zyx_mm: Tuple[float, float, float]) -> Dict[str, Any]:
    """Estimate rough midline shift from brain mask symmetry.

    Returns a conservative visualization metric. For clinical use it must be
    reviewed on axial slices by a radiologist/neurosurgeon.
    """
    if brain_mask.ndim != 3:
        raise ValueError("brain_mask must be 3D")
    shifts = []
    weights = []
    center_x = (brain_mask.shape[2] - 1) / 2.0
    for z in range(brain_mask.shape[0]):
        sl = brain_mask[z]
        if np.count_nonzero(sl) < 200:
            continue
        ys, xs = np.nonzero(sl)
        cx = float(np.mean(xs))
        lesion_w = 1.0 + float(np.count_nonzero(hemorrhage_mask[z])) / max(1.0, float(np.count_nonzero(sl)))
        shifts.append((cx - center_x) * spacing_zyx_mm[2])
        weights.append(lesion_w)
    if not shifts:
        return {"shift_mm": 0.0, "direction": "unknown", "confidence": 0.0}
    val = float(np.average(shifts, weights=weights))
    direction = "right" if val > 0.75 else "left" if val < -0.75 else "none"
    return {"shift_mm": abs(val), "signed_shift_mm": val, "direction": direction, "confidence": min(0.9, len(shifts) / max(1, brain_mask.shape[0]))}
