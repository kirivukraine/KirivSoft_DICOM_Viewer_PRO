from __future__ import annotations
from pathlib import Path
from typing import Iterable, Tuple, List
import numpy as np


def load_dicom_series(path: str | Path) -> Tuple[np.ndarray, Tuple[float, float, float], dict]:
    """Load a DICOM folder into HU volume shaped (z, y, x).

    Requires pydicom and a pixel decoder for compressed transfer syntaxes.
    Returns volume_hu, spacing_zyx_mm, metadata.
    """
    try:
        import pydicom  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("pydicom is required to load DICOM series") from exc

    files: List[Path] = [p for p in Path(path).rglob("*") if p.is_file()]
    slices = []
    for fp in files:
        try:
            ds = pydicom.dcmread(str(fp), stop_before_pixels=False, force=True)
            if not hasattr(ds, "PixelData"):
                continue
            inst = int(getattr(ds, "InstanceNumber", len(slices)))
            ipp = getattr(ds, "ImagePositionPatient", None)
            zpos = float(ipp[2]) if ipp is not None and len(ipp) >= 3 else float(inst)
            arr = ds.pixel_array.astype(np.float32)
            slope = float(getattr(ds, "RescaleSlope", 1.0))
            intercept = float(getattr(ds, "RescaleIntercept", 0.0))
            arr = arr * slope + intercept
            slices.append((zpos, inst, arr, ds))
        except Exception:
            continue
    if not slices:
        raise RuntimeError("No readable DICOM slices with PixelData found")
    slices.sort(key=lambda x: (x[0], x[1]))
    volume = np.stack([s[2] for s in slices], axis=0).astype(np.float32)
    ds0 = slices[0][3]
    px = getattr(ds0, "PixelSpacing", [1.0, 1.0])
    sy, sx = float(px[0]), float(px[1])
    if len(slices) > 1:
        zs = [s[0] for s in slices]
        diffs = np.diff(sorted(zs))
        sz = float(np.median(np.abs(diffs[diffs != 0]))) if np.any(diffs != 0) else float(getattr(ds0, "SliceThickness", 1.0))
    else:
        sz = float(getattr(ds0, "SliceThickness", 1.0))
    meta = {
        "slices": len(slices),
        "rows": int(volume.shape[1]),
        "cols": int(volume.shape[2]),
        "modality": str(getattr(ds0, "Modality", "CT")),
        "series_description": str(getattr(ds0, "SeriesDescription", "")),
    }
    return volume, (sz, sy, sx), meta
