from __future__ import annotations
from typing import Dict, Any

HEMORRHAGE_RED_RGBA = (1.0, 0.02, 0.0, 0.92)
BRAIN_GHOST_RGBA = (0.78, 0.78, 0.72, 0.16)
SKULL_GHOST_RGBA = (0.95, 0.88, 0.72, 0.10)


def vtk_volume_transfer_preset() -> Dict[str, Any]:
    """Transfer-function points for DicomView PRO VTK renderer."""
    return {
        "name": "Brain_Hemorrhage_GhostSkull",
        "color_points": [
            (-1000, (0.0, 0.0, 0.0)),
            (0, (0.20, 0.20, 0.22)),
            (35, (0.72, 0.72, 0.68)),
            (65, (1.0, 0.02, 0.0)),
            (95, (1.0, 0.12, 0.04)),
            (180, (0.95, 0.88, 0.72)),
            (1000, (1.0, 1.0, 0.95)),
        ],
        "opacity_points": [
            (-1000, 0.0),
            (0, 0.0),
            (35, 0.06),
            (45, 0.10),
            (65, 0.75),
            (95, 0.65),
            (180, 0.04),
            (1000, 0.08),
        ],
        "blend_mode": "composite",
        "shade": True,
        "ambient": 0.35,
        "diffuse": 0.65,
        "specular": 0.20,
    }
