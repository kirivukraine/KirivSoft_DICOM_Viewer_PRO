from __future__ import annotations

class HemorrhagePanelFactory:
    """Lazy Qt panel factory to avoid importing PySide6 in headless tests."""

    @staticmethod
    def create(on_analyze, on_export):
        try:
            from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QDoubleSpinBox, QHBoxLayout
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("PySide6 is required for Hemorrhage UI panel") from exc
        w = QWidget()
        w.setObjectName("Hemorrhage3DPanel")
        layout = QVBoxLayout(w)
        title = QLabel("Hemorrhage 3D PRO — KirivSoft")
        title.setStyleSheet("font-weight:700; font-size:14px;")
        layout.addWidget(title)
        row = QHBoxLayout()
        row.addWidget(QLabel("Blood HU:"))
        hu_min = QDoubleSpinBox(); hu_min.setRange(20, 120); hu_min.setValue(45)
        hu_max = QDoubleSpinBox(); hu_max.setRange(40, 160); hu_max.setValue(95)
        row.addWidget(hu_min); row.addWidget(hu_max)
        layout.addLayout(row)
        analyze = QPushButton("Auto Hemorrhage Detection + 3D Red Render")
        export = QPushButton("Export STL/PLY/OBJ")
        info = QLabel("Volume: — ml | Midline shift: — mm")
        info.setWordWrap(True)
        layout.addWidget(analyze); layout.addWidget(export); layout.addWidget(info)
        analyze.clicked.connect(lambda: on_analyze(float(hu_min.value()), float(hu_max.value()), info))
        export.clicked.connect(lambda: on_export())
        return w
