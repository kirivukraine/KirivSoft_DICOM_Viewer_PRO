from __future__ import annotations
from dataclasses import dataclass, field
from typing import Tuple, Dict, Any
import numpy as np
from .config import HemorrhageConfig
from .volume_metrics import mask_volume_ml, voxel_volume_ml, bounding_box_mm


@dataclass
class HemorrhageResult:
    mask: np.ndarray
    brain_mask: np.ndarray
    bone_mask: np.ndarray
    volume_ml: float
    bbox_mm: tuple[float, float, float] | None
    confidence: float
    components: int
    notes: list[str] = field(default_factory=list)
    debug: Dict[str, Any] = field(default_factory=dict)


class HemorrhageDetector:
    """Rule-based non-contrast head CT hemorrhage segmentation.

    This is intended as a visualization aid, not a diagnostic medical device.
    Pipeline: HU threshold -> soft skull strip -> optional midline cleanup ->
    morphology -> connected component filtering.
    """
    def __init__(self, config: HemorrhageConfig | None = None):
        self.config = config or HemorrhageConfig()

    def detect(self, volume_hu: np.ndarray, spacing_zyx_mm: Tuple[float, float, float]) -> HemorrhageResult:
        if volume_hu.ndim != 3:
            raise ValueError("volume_hu must have shape (z, y, x)")
        v = np.asarray(volume_hu, dtype=np.float32)
        c = self.config
        notes: list[str] = []

        finite = np.isfinite(v)
        brain_mask = finite & (v >= c.brain_hu_min) & (v <= c.brain_hu_max)
        bone_mask = finite & (v >= c.bone_hu_min)
        blood = finite & (v >= c.blood_hu_min) & (v <= c.blood_hu_max)

        # Remove obvious skull-adjacent rim by eroding a broad intracranial soft-tissue mask.
        if c.skull_strip_soft:
            intracranial = finite & (v > -20) & (v < c.bone_hu_min)
            intracranial = self._largest_soft_region(intracranial)
            if np.any(intracranial):
                blood &= intracranial
            else:
                notes.append("Soft skull-strip fallback: no intracranial region found")

        if c.remove_midline_calcified_structures:
            blood = self._remove_midline_band(blood, spacing_zyx_mm, c.midline_exclusion_mm)

        blood = self._morphology(blood, c.close_radius_vox, c.fill_holes)
        blood, components = self._filter_components(blood, spacing_zyx_mm)

        vol_ml = mask_volume_ml(blood, spacing_zyx_mm)
        conf = self._confidence(v, blood, vol_ml)
        return HemorrhageResult(
            mask=blood.astype(bool),
            brain_mask=brain_mask.astype(bool),
            bone_mask=bone_mask.astype(bool),
            volume_ml=vol_ml,
            bbox_mm=bounding_box_mm(blood, spacing_zyx_mm),
            confidence=conf,
            components=components,
            notes=notes,
            debug={"hu_min": c.blood_hu_min, "hu_max": c.blood_hu_max},
        )

    def _largest_soft_region(self, mask: np.ndarray) -> np.ndarray:
        try:
            from scipy import ndimage as ndi  # type: ignore
            filled = ndi.binary_fill_holes(mask)
            labels, n = ndi.label(filled)
            if n == 0:
                return mask
            counts = np.bincount(labels.ravel())
            counts[0] = 0
            main = labels == int(counts.argmax())
            # Light erosion removes skull/skin border artifacts.
            return ndi.binary_erosion(main, iterations=1)
        except Exception:
            return mask

    def _remove_midline_band(self, mask: np.ndarray, spacing: Tuple[float, float, float], width_mm: float) -> np.ndarray:
        out = mask.copy()
        cx = out.shape[2] // 2
        half = max(1, int(round(width_mm / max(spacing[2], 1e-3))))
        # Keep very large midline lesions by removing only tiny midline speckles later through components.
        out[:, :, max(0, cx-half):min(out.shape[2], cx+half+1)] &= mask[:, :, max(0, cx-half):min(out.shape[2], cx+half+1)]
        return out

    def _morphology(self, mask: np.ndarray, radius: int, fill_holes: bool) -> np.ndarray:
        try:
            from scipy import ndimage as ndi  # type: ignore
            st = ndi.generate_binary_structure(3, 1)
            out = mask
            for _ in range(max(0, radius)):
                out = ndi.binary_closing(out, structure=st)
            if fill_holes:
                out = ndi.binary_fill_holes(out)
            return out
        except Exception:
            return mask

    def _filter_components(self, mask: np.ndarray, spacing: Tuple[float, float, float]) -> tuple[np.ndarray, int]:
        try:
            from scipy import ndimage as ndi  # type: ignore
            labels, n = ndi.label(mask)
            if n == 0:
                return mask & False, 0
            voxel_ml = voxel_volume_ml(spacing)
            sizes = np.bincount(labels.ravel()).astype(float) * voxel_ml
            keep = []
            for label in range(1, n + 1):
                ml = sizes[label]
                if self.config.min_component_ml <= ml <= self.config.max_component_ml:
                    keep.append((ml, label))
            keep.sort(reverse=True)
            keep_labels = [label for _, label in keep[: self.config.keep_largest_components]]
            return np.isin(labels, keep_labels), len(keep_labels)
        except Exception:
            return mask, 1 if np.any(mask) else 0

    def _confidence(self, volume: np.ndarray, mask: np.ndarray, vol_ml: float) -> float:
        if not np.any(mask):
            return 0.0
        vals = volume[mask]
        hu_score = 1.0 - min(1.0, abs(float(np.median(vals)) - 65.0) / 35.0)
        volume_score = min(1.0, max(0.0, vol_ml / 1.0))
        return float(max(0.05, min(0.98, 0.65 * hu_score + 0.35 * volume_score)))
