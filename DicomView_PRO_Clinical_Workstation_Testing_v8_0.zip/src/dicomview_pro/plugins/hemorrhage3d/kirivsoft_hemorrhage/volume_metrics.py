from __future__ import annotations
from typing import Tuple, Optional
import numpy as np


def voxel_volume_ml(spacing_zyx_mm: Tuple[float, float, float]) -> float:
    return float(spacing_zyx_mm[0] * spacing_zyx_mm[1] * spacing_zyx_mm[2] / 1000.0)


def mask_volume_ml(mask: np.ndarray, spacing_zyx_mm: Tuple[float, float, float]) -> float:
    return float(np.count_nonzero(mask) * voxel_volume_ml(spacing_zyx_mm))


def bounding_box_vox(mask: np.ndarray) -> Optional[Tuple[slice, slice, slice]]:
    pts = np.argwhere(mask)
    if pts.size == 0:
        return None
    z0, y0, x0 = pts.min(axis=0)
    z1, y1, x1 = pts.max(axis=0) + 1
    return slice(z0, z1), slice(y0, y1), slice(x0, x1)


def bounding_box_mm(mask: np.ndarray, spacing_zyx_mm: Tuple[float, float, float]) -> Optional[Tuple[float, float, float]]:
    bb = bounding_box_vox(mask)
    if bb is None:
        return None
    return (
        (bb[0].stop - bb[0].start) * spacing_zyx_mm[0],
        (bb[1].stop - bb[1].start) * spacing_zyx_mm[1],
        (bb[2].stop - bb[2].start) * spacing_zyx_mm[2],
    )
