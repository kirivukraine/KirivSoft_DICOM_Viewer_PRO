from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .common import ModuleResult, Spacing, binary_cleanup, mask_volume_ml, bbox_mm

@dataclass(frozen=True)
class FractureConfig:
    bone_hu_min: float = 180.0
    cortical_hu_min: float = 650.0
    crack_hu_max: float = 120.0
    search_gap_vox: int = 1
    min_component_voxels: int = 6

class FracturePRO:
    """Bone/fracture visualization aid for CT. Highlights cortical discontinuities and sharp low-HU gaps near bone."""
    def __init__(self, config: FractureConfig | None = None): self.config = config or FractureConfig()
    def analyze(self, volume_hu: np.ndarray, spacing: Spacing) -> ModuleResult:
        v = np.asarray(volume_hu, dtype=np.float32); c = self.config
        bone = v >= c.bone_hu_min
        cortical = v >= c.cortical_hu_min
        try:
            from scipy import ndimage as ndi  # type: ignore
            near_bone = ndi.binary_dilation(cortical, iterations=2) & ~cortical
            grad = np.abs(ndi.gaussian_gradient_magnitude(v, sigma=0.8))
            suspicious = near_bone & (v < c.crack_hu_max) & (grad > np.percentile(grad[bone], 65) if np.any(bone) else grad > 100)
        except Exception:
            suspicious = bone & (v < c.cortical_hu_min)  # very conservative fallback
        mask = binary_cleanup(suspicious, close_iter=1, keep=32, min_voxels=c.min_component_voxels)
        vol = mask_volume_ml(mask, spacing)
        conf = min(0.85, 0.25 + np.count_nonzero(mask) / max(1, np.count_nonzero(bone)) * 8.0) if np.any(mask) else 0.0
        findings = ['suspicious cortical discontinuity / fracture candidate'] if vol > 0 else []
        return ModuleResult('Fracture PRO', mask, vol, conf, findings, {'bbox_mm': bbox_mm(mask, spacing), 'candidate_voxels': int(np.count_nonzero(mask))}, {'color':'yellow','opacity':0.85})
