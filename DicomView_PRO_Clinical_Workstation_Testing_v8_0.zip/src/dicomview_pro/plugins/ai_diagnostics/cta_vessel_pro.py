from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .common import ModuleResult, Spacing, binary_cleanup, mask_volume_ml, bbox_mm

@dataclass(frozen=True)
class VesselConfig:
    contrast_hu_min: float = 130.0
    contrast_hu_max: float = 700.0
    stenosis_low_hu_max: float = 110.0
    keep_components: int = 64

class CTAVesselPRO:
    """CTA vessel segmentation aid: extracts contrast-filled vessels and flags possible stenosis/occlusion gaps."""
    def __init__(self, config: VesselConfig | None = None): self.config = config or VesselConfig()
    def analyze(self, volume_hu: np.ndarray, spacing: Spacing) -> ModuleResult:
        v = np.asarray(volume_hu, dtype=np.float32); c = self.config
        vessel = (v >= c.contrast_hu_min) & (v <= c.contrast_hu_max)
        vessel = binary_cleanup(vessel, close_iter=1, keep=c.keep_components, min_voxels=12)
        vol = mask_volume_ml(vessel, spacing)
        try:
            from scipy import ndimage as ndi  # type: ignore
            shell = ndi.binary_dilation(vessel, iterations=2) & ~vessel
            gaps = shell & (v < c.stenosis_low_hu_max)
            gap_vox = int(np.count_nonzero(gaps))
        except Exception:
            gap_vox = 0
        conf = 0.75 if vol > 0 else 0.0
        findings = ['contrast vessel tree segmented'] if vol else []
        if gap_vox > 50: findings.append('possible vessel gap / stenosis candidate')
        return ModuleResult('CTA Vessel PRO', vessel, vol, conf, findings, {'bbox_mm': bbox_mm(vessel, spacing), 'possible_gap_voxels': gap_vox}, {'artery_color':'red','vein_color':'blue','opacity':0.72})
