from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .common import ModuleResult, Spacing, binary_cleanup, mask_volume_ml, bbox_mm

@dataclass(frozen=True)
class StrokeConfig:
    ischemia_hu_min: float = 10.0
    ischemia_hu_max: float = 32.0
    hemorrhage_hu_min: float = 45.0
    hemorrhage_hu_max: float = 95.0

class StrokePRO:
    """Acute stroke visualization aid: hypodensity/hemorrhage masks and approximate ASPECTS-like count."""
    def __init__(self, config: StrokeConfig | None = None): self.config = config or StrokeConfig()
    def analyze(self, volume_hu: np.ndarray, spacing: Spacing) -> ModuleResult:
        v = np.asarray(volume_hu, dtype=np.float32); c = self.config
        brain = (v >= -5) & (v <= 120)
        ischemia = brain & (v >= c.ischemia_hu_min) & (v <= c.ischemia_hu_max)
        hemorrhage = brain & (v >= c.hemorrhage_hu_min) & (v <= c.hemorrhage_hu_max)
        ischemia = binary_cleanup(ischemia, close_iter=1, keep=18, min_voxels=50)
        hemorrhage = binary_cleanup(hemorrhage, close_iter=1, keep=8, min_voxels=16)
        mask = ischemia | hemorrhage
        ish_ml = mask_volume_ml(ischemia, spacing); hem_ml = mask_volume_ml(hemorrhage, spacing)
        # Approximate ASPECTS-style penalty by number of affected z-bands, not clinical ASPECTS.
        bands = np.array_split(np.arange(mask.shape[0]), 10)
        affected = sum(1 for b in bands if np.count_nonzero(mask[b]) > 20)
        approx_aspects = max(0, 10 - affected)
        findings = []
        if ish_ml: findings.append('ischemic hypodensity candidate')
        if hem_ml: findings.append('hemorrhagic component candidate')
        conf = 0.55 if findings else 0.0
        return ModuleResult('Stroke PRO', mask, ish_ml + hem_ml, conf, findings, {'ischemia_ml': ish_ml, 'hemorrhage_ml': hem_ml, 'approx_aspects_visual': approx_aspects, 'bbox_mm': bbox_mm(mask, spacing)}, {'ischemia_color':'blue','hemorrhage_color':'red','opacity':0.70})
