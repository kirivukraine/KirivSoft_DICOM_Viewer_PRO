from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable
import numpy as np
from .common import ModuleResult, Spacing, export_mask_mesh
from .fracture_pro import FracturePRO
from .cta_vessel_pro import CTAVesselPRO
from .brain_tumor_pro import BrainTumorPRO
from .stroke_pro import StrokePRO
from .organ_segmentation_pro import OrganSegmentationPRO

class EnterpriseAISuite:
    """Runs all DicomView PRO diagnostic visualization modules in a safe sequence."""
    def __init__(self):
        self.modules = [FracturePRO(), CTAVesselPRO(), BrainTumorPRO(), StrokePRO(), OrganSegmentationPRO()]
        self.last_results: list[ModuleResult] = []

    def analyze_volume(self, volume_hu: np.ndarray, spacing: Spacing) -> Dict[str, Any]:
        self.last_results = []
        for mod in self.modules:
            try:
                self.last_results.append(mod.analyze(volume_hu, spacing))
            except Exception as exc:
                empty = np.zeros_like(volume_hu, dtype=bool)
                self.last_results.append(ModuleResult(mod.__class__.__name__, empty, 0.0, 0.0, [], {}, {}, [f'FAILED safely: {exc}']))
        return self.to_dict()

    def to_dict(self) -> Dict[str, Any]:
        out = {'suite': 'KirivSoft DicomView PRO Enterprise AI Suite', 'modules': []}
        for r in self.last_results:
            out['modules'].append({
                'name': r.name,
                'volume_ml': r.volume_ml,
                'confidence': r.confidence,
                'findings': r.findings,
                'measurements': r.measurements,
                'overlays': r.overlays,
                'notes': r.notes,
                'mask_voxels': int(np.count_nonzero(r.mask)),
            })
        return out

    def export_all_meshes(self, folder: str | Path, spacing: Spacing, fmt: str = 'obj') -> list[Path]:
        folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        for r in self.last_results:
            if np.any(r.mask):
                name = r.name.lower().replace(' ', '_').replace('/', '_')
                paths.append(export_mask_mesh(r.mask, spacing, folder / f'{name}.{fmt.lstrip(".")}'))
        return paths
