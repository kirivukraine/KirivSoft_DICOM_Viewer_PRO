from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .common import ModuleResult, Spacing, binary_cleanup, mask_volume_ml, bbox_mm

@dataclass(frozen=True)
class TumorConfig:
    soft_tissue_hu_min: float = 25.0
    soft_tissue_hu_max: float = 120.0
    edema_hu_min: float = 5.0
    edema_hu_max: float = 35.0
    asymmetry_threshold_ml: float = 0.2

class BrainTumorPRO:
    """Rule-based brain mass/edema visualization aid. Best with contrast CT/MRI-derived masks when available."""
    def __init__(self, config: TumorConfig | None = None): self.config = config or TumorConfig()
    def analyze(self, volume_hu: np.ndarray, spacing: Spacing) -> ModuleResult:
        v = np.asarray(volume_hu, dtype=np.float32); c = self.config
        brain = (v >= -5) & (v <= 130)
        lesion_core = brain & (v >= c.soft_tissue_hu_min) & (v <= c.soft_tissue_hu_max)
        # exclude likely hemorrhage calcification/bone-heavy voxels by keeping soft mass range only
        lesion_core = binary_cleanup(lesion_core, close_iter=2, keep=12, min_voxels=30)
        edema = brain & (v >= c.edema_hu_min) & (v <= c.edema_hu_max)
        edema = binary_cleanup(edema, close_iter=1, keep=24, min_voxels=40)
        vol = mask_volume_ml(lesion_core, spacing)
        edema_ml = mask_volume_ml(edema & ~lesion_core, spacing)
        conf = 0.45 if vol > 0 else 0.0
        if edema_ml > vol * 0.5 and vol > c.asymmetry_threshold_ml: conf = 0.62
        findings = ['soft-tissue mass candidate'] if vol > c.asymmetry_threshold_ml else []
        if edema_ml > 0: findings.append('perilesional edema candidate')
        return ModuleResult('Brain Tumor PRO', lesion_core, vol, conf, findings, {'bbox_mm': bbox_mm(lesion_core, spacing), 'edema_ml': edema_ml}, {'tumor_color':'violet','edema_color':'cyan','brain_opacity':0.16})
