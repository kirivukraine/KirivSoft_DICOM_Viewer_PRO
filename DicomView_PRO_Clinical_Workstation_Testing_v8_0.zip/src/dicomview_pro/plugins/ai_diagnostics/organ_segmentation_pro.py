from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import numpy as np
from .common import ModuleResult, Spacing, binary_cleanup, mask_volume_ml, bbox_mm

@dataclass(frozen=True)
class OrganConfig:
    lung_min: float = -1000.0
    lung_max: float = -350.0
    bone_min: float = 180.0
    soft_min: float = 20.0
    soft_max: float = 120.0

class OrganSegmentationPRO:
    """Safe organ segmentation fallback. Uses TotalSegmentator if connected externally; otherwise HU masks."""
    def __init__(self, config: OrganConfig | None = None): self.config = config or OrganConfig()
    def analyze(self, volume_hu: np.ndarray, spacing: Spacing) -> ModuleResult:
        v = np.asarray(volume_hu, dtype=np.float32); c = self.config
        lung = binary_cleanup((v >= c.lung_min) & (v <= c.lung_max), close_iter=2, keep=2, min_voxels=100)
        bone = binary_cleanup(v >= c.bone_min, close_iter=1, keep=80, min_voxels=20)
        soft = binary_cleanup((v >= c.soft_min) & (v <= c.soft_max), close_iter=1, keep=12, min_voxels=200)
        combined = lung | bone | soft
        measurements: Dict[str, object] = {
            'lung_ml': mask_volume_ml(lung, spacing),
            'bone_ml': mask_volume_ml(bone, spacing),
            'soft_tissue_ml': mask_volume_ml(soft, spacing),
            'bbox_mm': bbox_mm(combined, spacing),
            'totalsegmentator_hook': 'ready: replace fallback masks with TotalSegmentator NIfTI masks when installed'
        }
        findings = ['fallback organ masks generated'] if np.any(combined) else []
        return ModuleResult('Organ Segmentation PRO', combined, mask_volume_ml(combined, spacing), 0.50 if findings else 0.0, findings, measurements, {'lung':'light_blue','bone':'ivory','soft':'orange','opacity':0.35})
