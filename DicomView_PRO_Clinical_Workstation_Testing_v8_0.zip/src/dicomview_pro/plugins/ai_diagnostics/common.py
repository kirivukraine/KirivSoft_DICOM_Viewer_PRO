from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Tuple
import numpy as np

Spacing = Tuple[float, float, float]  # z,y,x mm

@dataclass
class ModuleResult:
    name: str
    mask: np.ndarray
    volume_ml: float
    confidence: float
    findings: list[str] = field(default_factory=list)
    measurements: Dict[str, Any] = field(default_factory=dict)
    overlays: Dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def voxel_volume_ml(spacing: Spacing) -> float:
    return float(spacing[0] * spacing[1] * spacing[2] / 1000.0)


def mask_volume_ml(mask: np.ndarray, spacing: Spacing) -> float:
    return float(np.count_nonzero(mask) * voxel_volume_ml(spacing))


def bbox_mm(mask: np.ndarray, spacing: Spacing):
    pts = np.argwhere(mask)
    if pts.size == 0:
        return None
    mn = pts.min(axis=0); mx = pts.max(axis=0) + 1
    return tuple(float((mx[i]-mn[i]) * spacing[i]) for i in range(3))


def keep_largest_components(mask: np.ndarray, keep: int = 5, min_voxels: int = 8) -> np.ndarray:
    mask = np.asarray(mask, dtype=bool)
    if not np.any(mask):
        return mask
    try:
        from scipy import ndimage as ndi  # type: ignore
        lab, n = ndi.label(mask)
        if n == 0:
            return mask
        sizes = np.bincount(lab.ravel())
        ids = np.argsort(sizes[1:])[::-1] + 1
        ids = [i for i in ids if sizes[i] >= min_voxels][:keep]
        return np.isin(lab, ids)
    except Exception:
        # Safe fallback: no component cleanup, but never crashes.
        return mask


def binary_cleanup(mask: np.ndarray, close_iter: int = 1, keep: int = 5, min_voxels: int = 8) -> np.ndarray:
    mask = np.asarray(mask, dtype=bool)
    try:
        from scipy import ndimage as ndi  # type: ignore
        if close_iter > 0:
            mask = ndi.binary_closing(mask, iterations=close_iter)
            mask = ndi.binary_opening(mask, iterations=1)
            mask = ndi.binary_fill_holes(mask)
    except Exception:
        pass
    return keep_largest_components(mask, keep=keep, min_voxels=min_voxels)


def export_mask_mesh(mask: np.ndarray, spacing: Spacing, out_path: str | Path) -> Path:
    out = Path(out_path)
    if mask.ndim != 3 or not np.any(mask):
        raise ValueError('mask must be non-empty 3D array')
    try:
        from skimage import measure  # type: ignore
    except Exception as exc:
        raise RuntimeError('scikit-image is required for STL/PLY/OBJ mesh export') from exc
    verts, faces, _, _ = measure.marching_cubes(mask.astype(np.uint8), level=0.5, spacing=spacing)
    xyz = verts[:, [2, 1, 0]]
    if out.suffix.lower() == '.obj':
        with out.open('w', encoding='utf-8') as f:
            f.write('# KirivSoft AI Diagnostics OBJ\n')
            for v in xyz: f.write(f'v {v[0]:.5f} {v[1]:.5f} {v[2]:.5f}\n')
            for tri in faces:
                a,b,c = tri + 1; f.write(f'f {a} {b} {c}\n')
    elif out.suffix.lower() == '.ply':
        with out.open('w', encoding='utf-8') as f:
            f.write('ply\nformat ascii 1.0\n')
            f.write(f'element vertex {len(xyz)}\nproperty float x\nproperty float y\nproperty float z\n')
            f.write(f'element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n')
            for v in xyz: f.write(f'{v[0]:.5f} {v[1]:.5f} {v[2]:.5f}\n')
            for tri in faces: f.write(f'3 {tri[0]} {tri[1]} {tri[2]}\n')
    elif out.suffix.lower() == '.stl':
        with out.open('w', encoding='utf-8') as f:
            f.write('solid kirivsoft_ai_mask\n')
            for tri in faces:
                pts = xyz[tri]
                f.write(' facet normal 0 0 0\n  outer loop\n')
                for p in pts: f.write(f'   vertex {p[0]:.5f} {p[1]:.5f} {p[2]:.5f}\n')
                f.write('  endloop\n endfacet\n')
            f.write('endsolid kirivsoft_ai_mask\n')
    else:
        raise ValueError('Supported formats: .stl, .ply, .obj')
    return out


def safe_float(v: Any, default: float = 0.0) -> float:
    try: return float(v)
    except Exception: return default
