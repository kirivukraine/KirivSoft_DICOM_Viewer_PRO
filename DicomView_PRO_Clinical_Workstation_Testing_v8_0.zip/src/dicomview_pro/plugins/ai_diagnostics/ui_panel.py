from __future__ import annotations
from typing import Any

class AIDiagnosticsPanelMixin:
    """Minimal PySide6 integration mixin for DicomView PRO main window.

    Main app should provide:
      - self.current_volume_hu: numpy array (z,y,x)
      - self.current_spacing_zyx_mm: tuple
      - self.add_mask_overlay(name, mask, color, opacity)
      - self.show_status_message(text)
    """
    def run_enterprise_ai_suite(self):
        from .enterprise_ai_suite import EnterpriseAISuite
        suite = EnterpriseAISuite()
        data = suite.analyze_volume(self.current_volume_hu, self.current_spacing_zyx_mm)
        for result in suite.last_results:
            color = result.overlays.get('color') or result.overlays.get('tumor_color') or result.overlays.get('ischemia_color') or 'red'
            opacity = float(result.overlays.get('opacity', 0.65))
            if hasattr(self, 'add_mask_overlay'):
                self.add_mask_overlay(result.name, result.mask, color=color, opacity=opacity)
        if hasattr(self, 'show_status_message'):
            self.show_status_message('Enterprise AI Suite завершив аналіз: ' + ', '.join(r.name for r in suite.last_results))
        return data
