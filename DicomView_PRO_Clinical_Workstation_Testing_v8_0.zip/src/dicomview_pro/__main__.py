from __future__ import annotations
import sys, logging, traceback, os
# Do not force software OpenGL by default: VTK Volume Rendering needs hardware OpenGL.
# Users can still force compatibility mode externally: set QT_OPENGL=software
os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
from PySide6.QtWidgets import QApplication, QMessageBox
from .runtime.logging_setup import setup_logging
from .ui.main_window import MainWindow


def main() -> int:
    log_file = setup_logging()
    try:
        app = QApplication(sys.argv)
        win = MainWindow()
        win.resize(1320, 850)
        win.show()
        return app.exec()
    except Exception as exc:
        logging.exception("Fatal GUI error")
        try:
            QMessageBox.critical(None, "DicomView PRO", f"Критична помилка:\n{exc}\n\nЛог: {log_file}")
        except Exception:
            print(traceback.format_exc(), file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
