from __future__ import annotations

from typing import Tuple
import numpy as np

try:
    import vtk  # type: ignore
    from vtk.util import numpy_support  # type: ignore
except Exception:  # pragma: no cover
    vtk = None
    numpy_support = None


def numpy_zyx_to_vtk_image(
    volume_zyx: np.ndarray,
    spacing_xyz: Tuple[float, float, float],
    origin_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0),
):
    """
    Конвертує numpy volume z,y,x у vtkImageData без втрати spacing.
    """
    if vtk is None or numpy_support is None:
        raise RuntimeError("VTK is not installed.")

    if volume_zyx.ndim != 3:
        raise ValueError("volume_zyx must be a 3D numpy array in z,y,x order.")

    z, y, x = volume_zyx.shape
    arr = np.ascontiguousarray(volume_zyx)

    vtk_data = numpy_support.numpy_to_vtk(
        num_array=arr.ravel(order="C"),
        deep=True,
        array_type=vtk.VTK_SHORT if arr.dtype.kind in {"i", "u"} else vtk.VTK_FLOAT,
    )

    image = vtk.vtkImageData()
    image.SetDimensions(int(x), int(y), int(z))
    image.SetSpacing(float(spacing_xyz[0]), float(spacing_xyz[1]), float(spacing_xyz[2]))
    image.SetOrigin(float(origin_xyz[0]), float(origin_xyz[1]), float(origin_xyz[2]))
    image.GetPointData().SetScalars(vtk_data)

    return image
