from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class OrganStyle:
    color: Tuple[float, float, float]
    opacity: float = 0.45
    visible: bool = True


DEFAULT_ORGAN_STYLES: Dict[str, OrganStyle] = {
    "lungs": OrganStyle((0.25, 0.45, 1.0), 0.26),
    "heart": OrganStyle((1.0, 0.08, 0.08), 0.62),
    "liver": OrganStyle((0.72, 0.18, 0.16), 0.48),
    "kidneys": OrganStyle((0.88, 0.12, 0.64), 0.55),
    "pancreas": OrganStyle((1.0, 0.70, 0.22), 0.55),
    "stomach": OrganStyle((0.30, 0.85, 0.25), 0.36),
    "intestine": OrganStyle((0.85, 0.55, 0.20), 0.32),
    "bladder": OrganStyle((0.25, 0.95, 0.95), 0.42),
}


class OrganOverlayManager:
    """Adds colored organ masks over volume rendering.

    Accepts vtkImageData masks or vtkPolyData meshes.  Intended for TotalSegmentator
    output and manual segmentations.
    """
    def __init__(self, renderer, render_window=None) -> None:
        try:
            import vtkmodules.all as vtk  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("VTK is not installed") from exc
        self.vtk = vtk
        self.renderer = renderer
        self.render_window = render_window
        self.actors: Dict[str, object] = {}

    def add_polydata(self, name: str, polydata, style: Optional[OrganStyle] = None) -> None:
        vtk = self.vtk
        style = style or DEFAULT_ORGAN_STYLES.get(name, OrganStyle((1, 1, 1), 0.45))
        mapper = vtk.vtkPolyDataMapper(); mapper.SetInputData(polydata); mapper.ScalarVisibilityOff()
        actor = vtk.vtkActor(); actor.SetMapper(mapper)
        actor.GetProperty().SetColor(*style.color); actor.GetProperty().SetOpacity(float(style.opacity))
        actor.GetProperty().SetInterpolationToPhong()
        actor.SetVisibility(bool(style.visible))
        self.remove(name)
        self.renderer.AddActor(actor); self.actors[name] = actor; self.render()

    def add_mask_image(self, name: str, mask_image, iso_value: float = 0.5, style: Optional[OrganStyle] = None) -> None:
        vtk = self.vtk
        contour = vtk.vtkFlyingEdges3D() if hasattr(vtk, "vtkFlyingEdges3D") else vtk.vtkMarchingCubes()
        contour.SetInputData(mask_image); contour.SetValue(0, float(iso_value)); contour.Update()
        smoother = vtk.vtkWindowedSincPolyDataFilter(); smoother.SetInputConnection(contour.GetOutputPort())
        smoother.SetNumberOfIterations(12); smoother.BoundarySmoothingOff(); smoother.FeatureEdgeSmoothingOff(); smoother.Update()
        self.add_polydata(name, smoother.GetOutput(), style)

    def set_visible(self, name: str, visible: bool) -> None:
        actor = self.actors.get(name)
        if actor is not None:
            try: actor.SetVisibility(bool(visible))
            except Exception: pass
            self.render()

    def remove(self, name: str) -> None:
        actor = self.actors.pop(name, None)
        if actor is not None:
            try: self.renderer.RemoveActor(actor)
            except Exception: pass
            self.render()

    def clear(self) -> None:
        for name in list(self.actors): self.remove(name)

    def render(self) -> None:
        try:
            if self.render_window is not None: self.render_window.Render()
        except Exception: pass
