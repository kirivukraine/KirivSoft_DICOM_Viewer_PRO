from __future__ import annotations

import math
from typing import Optional, Tuple

from .shared_crosshair_state import SharedCrosshairState


class DeepCameraController:
    """
    Реальний рух камери всередину об'єму:
    - не SetZoom;
    - не тільки Dolly;
    - рухає і Position, і FocalPoint уздовж view direction.
    """

    def __init__(self, renderer, render_window=None, shared_state: Optional[SharedCrosshairState] = None) -> None:
        self.renderer = renderer
        self.render_window = render_window
        self.shared_state = shared_state
        self.default_step_mm = 2.0

    def move_forward_mm(self, delta_mm: float) -> None:
        camera = self._camera()
        if camera is None:
            return

        px, py, pz = camera.GetPosition()
        fx, fy, fz = camera.GetFocalPoint()
        dx, dy, dz = fx - px, fy - py, fz - pz

        length = max(1e-9, math.sqrt(dx * dx + dy * dy + dz * dz))
        ux, uy, uz = dx / length, dy / length, dz / length

        step = float(delta_mm)
        camera.SetPosition(px + ux * step, py + uy * step, pz + uz * step)
        camera.SetFocalPoint(fx + ux * step, fy + uy * step, fz + uz * step)

        if self.shared_state is not None:
            self.shared_state.set_from_patient_xyz((fx + ux * step, fy + uy * step, fz + uz * step), notify=True)

        self._render()

    def move_backward_mm(self, delta_mm: float) -> None:
        self.move_forward_mm(-abs(delta_mm))

    def zoom_dolly(self, factor: float) -> None:
        camera = self._camera()
        if camera is None:
            return
        camera.Dolly(float(factor))
        try:
            self.renderer.ResetCameraClippingRange()
        except Exception:
            pass
        self._render()

    def reset_camera(self) -> None:
        try:
            self.renderer.ResetCamera()
            self.renderer.ResetCameraClippingRange()
        except Exception:
            pass
        self._render()

    def bind_wheel_event(self, interactor, clip_controller=None, slab_controller=None, step_mm: float = 2.0) -> None:
        """
        Опціональна прив'язка до VTK interactor.
        У Qt-інтеграції часто краще перехоплювати wheelEvent у QWidget і викликати handle_wheel().
        """
        self.default_step_mm = float(step_mm)

        def _key(obj, name: str) -> bool:
            getter = getattr(obj, name, None)
            try:
                return bool(getter()) if getter is not None else False
            except Exception:
                return False

        def on_wheel_forward(obj, event):
            self.handle_wheel(+1, shift=_key(obj, "GetShiftKey"), ctrl=_key(obj, "GetControlKey"), alt=_key(obj, "GetAltKey"),
                              clip_controller=clip_controller, slab_controller=slab_controller)

        def on_wheel_backward(obj, event):
            self.handle_wheel(-1, shift=_key(obj, "GetShiftKey"), ctrl=_key(obj, "GetControlKey"), alt=_key(obj, "GetAltKey"),
                              clip_controller=clip_controller, slab_controller=slab_controller)

        interactor.AddObserver("MouseWheelForwardEvent", on_wheel_forward)
        interactor.AddObserver("MouseWheelBackwardEvent", on_wheel_backward)

    def handle_wheel(
        self,
        wheel_direction: int,
        *,
        shift: bool = False,
        ctrl: bool = False,
        alt: bool = False,
        clip_controller=None,
        slab_controller=None,
    ) -> None:
        delta = self.default_step_mm if wheel_direction > 0 else -self.default_step_mm

        if shift:
            self.move_forward_mm(delta)
        elif ctrl and slab_controller is not None:
            slab_controller.increase_thickness(delta)
        elif alt and clip_controller is not None:
            clip_controller.move_mm(delta)
        else:
            self.zoom_dolly(1.08 if wheel_direction > 0 else 0.92)

    def _camera(self):
        try:
            return self.renderer.GetActiveCamera()
        except Exception:
            return None

    def _render(self) -> None:
        try:
            if self.render_window is not None:
                self.render_window.Render()
        except Exception:
            pass
