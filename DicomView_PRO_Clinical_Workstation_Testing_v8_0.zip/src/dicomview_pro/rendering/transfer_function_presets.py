from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

ColorPoint = Tuple[float, float, float, float]
OpacityPoint = Tuple[float, float]


@dataclass(frozen=True)
class TransferFunctionPreset:
    """HU based color/opacity preset for CT volume rendering."""
    name: str
    description_ua: str
    color_points: Tuple[ColorPoint, ...]
    opacity_points: Tuple[OpacityPoint, ...]
    gradient_points: Tuple[OpacityPoint, ...] = ((0.0, 0.00), (25.0, 0.05), (80.0, 0.40), (250.0, 0.85))
    shade: bool = True
    ambient: float = 0.22
    diffuse: float = 0.72
    specular: float = 0.18
    specular_power: float = 18.0
    interpolation: str = "linear"


PRESETS: Dict[str, TransferFunctionPreset] = {
    "thorax_cinematic": TransferFunctionPreset(
        name="thorax_cinematic",
        description_ua="Грудна клітка: прозорі м'які тканини, легені, кістки та контрастні судини.",
        color_points=(( -1000,0.00,0.00,0.00),(-780,0.20,0.24,0.75),(-520,0.42,0.50,0.95),(-120,0.55,0.34,0.28),(60,0.95,0.52,0.42),(260,1.0,0.85,0.58),(650,1.0,0.95,0.75),(1300,1.0,1.0,0.96)),
        opacity_points=((-1000,0.00),(-850,0.03),(-600,0.10),(-180,0.00),(40,0.035),(110,0.075),(260,0.16),(700,0.46),(1300,0.72)),
    ),
    "lung_vessels": TransferFunctionPreset(
        name="lung_vessels",
        description_ua="Легені + судини: MinIP-подібний синьо-фіолетовий паренхіматозний пресет.",
        color_points=((-1000,0.0,0.0,0.0),(-850,0.25,0.28,0.90),(-650,0.48,0.58,1.0),(-350,0.30,0.40,0.75),(-100,0.0,0.0,0.0),(120,1.0,0.28,0.18),(350,1.0,0.62,0.20),(900,1.0,0.95,0.82)),
        opacity_points=((-1000,0.00),(-850,0.10),(-650,0.22),(-350,0.08),(-120,0.00),(80,0.04),(180,0.16),(420,0.28),(900,0.42)),
        ambient=0.18, diffuse=0.78, specular=0.22,
    ),
    "heart_cardio": TransferFunctionPreset(
        name="heart_cardio",
        description_ua="Серце/кардіо: підсилення м'яких тканин і контрасту.",
        color_points=((-1000,0,0,0),(-160,0.12,0.02,0.02),(30,0.72,0.16,0.12),(90,0.95,0.28,0.20),(220,1.0,0.55,0.32),(500,1.0,0.78,0.45),(1100,1.0,0.96,0.86)),
        opacity_points=((-1000,0.0),(-170,0.0),(20,0.04),(70,0.17),(160,0.30),(350,0.42),(900,0.62)),
        gradient_points=((0,0),(30,0.05),(90,0.55),(250,0.95)),
    ),
    "abdomen_organs": TransferFunctionPreset(
        name="abdomen_organs",
        description_ua="Живіт: печінка, нирки, підшлункова, шлунок/кишківник, м'які тканини.",
        color_points=((-1000,0,0,0),(-180,0.55,0.38,0.18),(-80,0.78,0.52,0.28),(35,0.86,0.38,0.25),(75,0.95,0.55,0.35),(140,0.96,0.70,0.45),(300,1.0,0.86,0.62),(900,1.0,0.98,0.90)),
        opacity_points=((-1000,0),(-220,0),(-90,0.025),(30,0.07),(80,0.16),(150,0.25),(320,0.34),(900,0.52)),
    ),
    "bone_soft_transparent": TransferFunctionPreset(
        name="bone_soft_transparent",
        description_ua="Кістки + прозорі м'які тканини.",
        color_points=((-1000,0,0,0),(-250,0.45,0.30,0.22),(80,0.82,0.52,0.42),(250,0.95,0.82,0.65),(700,1.0,0.94,0.82),(1600,1,1,0.98)),
        opacity_points=((-1000,0),(-250,0),(60,0.025),(180,0.055),(350,0.16),(800,0.52),(1600,0.88)),
    ),
    "angio_mip": TransferFunctionPreset(
        name="angio_mip",
        description_ua="Ангіо/MIP: високі HU, контрастні судини і кістки.",
        color_points=((-1000,0,0,0),(80,0,0,0),(180,1.0,0.22,0.06),(350,1.0,0.62,0.12),(700,1.0,0.90,0.55),(1500,1,1,0.98)),
        opacity_points=((-1000,0),(80,0),(150,0.02),(250,0.20),(450,0.42),(900,0.70),(1500,0.92)),
        gradient_points=((0,0),(50,0.04),(120,0.70),(300,1.0)),
        specular=0.35, specular_power=28,
    ),
}


def list_presets() -> List[str]:
    return list(PRESETS.keys())


def get_preset(name: str) -> TransferFunctionPreset:
    return PRESETS.get((name or "").strip().lower(), PRESETS["thorax_cinematic"])


def build_vtk_property(name: str):
    """Create vtkVolumeProperty. Raises RuntimeError only when VTK is absent."""
    try:
        import vtkmodules.all as vtk  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("VTK is not installed") from exc
    p = get_preset(name)
    color = vtk.vtkColorTransferFunction()
    scalar_opacity = vtk.vtkPiecewiseFunction()
    gradient_opacity = vtk.vtkPiecewiseFunction()
    for hu, r, g, b in p.color_points:
        color.AddRGBPoint(float(hu), float(r), float(g), float(b))
    for hu, op in p.opacity_points:
        scalar_opacity.AddPoint(float(hu), float(op))
    for grad, op in p.gradient_points:
        gradient_opacity.AddPoint(float(grad), float(op))
    prop = vtk.vtkVolumeProperty()
    prop.SetColor(color)
    prop.SetScalarOpacity(scalar_opacity)
    prop.SetGradientOpacity(gradient_opacity)
    prop.SetInterpolationTypeToLinear()
    if p.shade:
        prop.ShadeOn(); prop.SetAmbient(p.ambient); prop.SetDiffuse(p.diffuse); prop.SetSpecular(p.specular); prop.SetSpecularPower(p.specular_power)
    else:
        prop.ShadeOff()
    return prop
