from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
import os
import traceback


@dataclass
class HardwareProfile:
    """
    Визначає безпечний режим рендерингу.

    AUTO/HIGH/MEDIUM/LOW/SAFE:
    - HIGH: повний GPU volume rendering.
    - MEDIUM: GPU без важких ефектів/downsample.
    - LOW: MPR + slab, 3D low-res або вимкнено.
    - SAFE: тільки 2D/MPR.
    """

    mode: str = "AUTO"
    gpu_volume_ok: bool = False
    safe_mode_reason: str = ""
    last_exception: str = ""

    def detect(self) -> None:
        forced = os.environ.get("DICOMVIEW_RENDER_MODE", "").strip().upper()
        if forced in {"HIGH", "MEDIUM", "LOW", "SAFE"}:
            self.mode = forced
            self.gpu_volume_ok = forced in {"HIGH", "MEDIUM"}
            self.safe_mode_reason = f"Forced by DICOMVIEW_RENDER_MODE={forced}"
            return

        try:
            import vtk  # type: ignore

            # Мінімальна перевірка: чи існує GPU mapper.
            if hasattr(vtk, "vtkGPUVolumeRayCastMapper"):
                self.gpu_volume_ok = True
                self.mode = "AUTO"
            else:
                self.gpu_volume_ok = False
                self.mode = "SAFE"
                self.safe_mode_reason = "vtkGPUVolumeRayCastMapper is unavailable."
        except Exception as exc:
            self.gpu_volume_ok = False
            self.mode = "SAFE"
            self.safe_mode_reason = f"VTK import/init failed: {exc}"
            self.last_exception = traceback.format_exc()

    def choose_render_mode(
        self,
        volume_shape_zyx: Tuple[int, int, int],
        spacing_xyz: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> str:
        if self.mode in {"HIGH", "MEDIUM", "LOW", "SAFE"}:
            return self.mode

        if not self.gpu_volume_ok:
            return "SAFE"

        z, y, x = volume_shape_zyx
        voxels = int(z) * int(y) * int(x)

        if voxels >= 512 * 512 * 900:
            return "LOW"
        if voxels >= 512 * 512 * 450:
            return "MEDIUM"
        return "HIGH"

    def mark_gpu_failure(self, exc: Exception) -> str:
        self.gpu_volume_ok = False
        self.mode = "SAFE"
        self.safe_mode_reason = f"GPU 3D failed; switched to SAFE MPR mode: {exc}"
        self.last_exception = traceback.format_exc()
        return "SAFE"


def safe_create_gpu_volume_mapper():
    """
    Безпечне створення vtkGPUVolumeRayCastMapper.
    Якщо GPU/VTK падає — повертає (None, reason).
    """
    try:
        import vtk  # type: ignore
        mapper = vtk.vtkGPUVolumeRayCastMapper()
        return mapper, ""
    except Exception as exc:
        return None, f"Cannot create vtkGPUVolumeRayCastMapper: {exc}"
