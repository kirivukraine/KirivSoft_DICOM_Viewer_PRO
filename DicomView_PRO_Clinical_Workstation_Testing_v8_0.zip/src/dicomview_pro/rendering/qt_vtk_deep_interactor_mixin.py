from __future__ import annotations


class QtVtkDeepInteractorMixin:
    """
    Mixin для QWidget/QVTK widget.

    Очікує, що клас має:
        self.deep_camera_controller
        self.clip_plane_controller
        self.slab_controller

    Використання:
        class Viewer3DWidget(QVTKRenderWindowInteractor, QtVtkDeepInteractorMixin):
            def wheelEvent(self, event):
                self.deep_wheel_event(event)
    """

    def deep_wheel_event(self, event) -> None:
        modifiers = event.modifiers()
        try:
            from PySide6.QtCore import Qt
        except Exception:
            from PyQt6.QtCore import Qt  # fallback

        delta = event.angleDelta().y()
        direction = 1 if delta > 0 else -1

        shift = bool(modifiers & Qt.KeyboardModifier.ShiftModifier)
        ctrl = bool(modifiers & Qt.KeyboardModifier.ControlModifier)
        alt = bool(modifiers & Qt.KeyboardModifier.AltModifier)

        self.deep_camera_controller.handle_wheel(
            direction,
            shift=shift,
            ctrl=ctrl,
            alt=alt,
            clip_controller=getattr(self, "clip_plane_controller", None),
            slab_controller=getattr(self, "slab_controller", None),
        )
        event.accept()
