from __future__ import annotations

"""Cinematic/Fidelity 3D presets for DicomView PRO.

CPU/GPU safe VTK-only volume-rendering tuning.  This module contains no AI and
is intentionally small: it only builds HU transfer functions and lighting
parameters for medical CT volume rendering.
"""

from dataclasses import dataclass
from typing import Dict, Tuple

ColorPoint = Tuple[float, float, float, float]
OpacityPoint = Tuple[float, float]


def _key(name: str) -> str:
    return (name or "").strip().lower().replace("/", "_").replace("-", "_").replace(" ", "_")


@dataclass(frozen=True)
class CinematicPreset:
    name: str
    color: Tuple[ColorPoint, ...]
    opacity: Tuple[OpacityPoint, ...]
    gradient: Tuple[OpacityPoint, ...]
    ambient: float = 0.28
    diffuse: float = 0.76
    specular: float = 0.18
    specular_power: float = 22.0
    opacity_unit_distance: float = 0.55
    blend: str = "composite"
    sample_factor: float = 0.85
    image_sample_distance: float = 1.0


PRESETS: Dict[str, CinematicPreset] = {
    "classic_hospital": CinematicPreset(
        name="Classic Hospital",
        color=(( -1000,0,0,0),(-760,0.05,0.10,0.18),(-420,0.25,0.30,0.38),(-150,0.62,0.42,0.34),(40,0.86,0.55,0.44),(170,0.95,0.68,0.52),(520,1.0,0.84,0.63),(1200,1.0,0.98,0.86)),
        opacity=((-1000,0),(-760,0.006),(-520,0.018),(-300,0.035),(-120,0.060),(35,0.090),(150,0.145),(360,0.245),(700,0.48),(1300,0.80)),
        gradient=((0,0),(22,0.015),(55,0.10),(110,0.26),(220,0.50),(460,0.76)),
        ambient=0.18, diffuse=0.92, specular=0.28, specular_power=28, opacity_unit_distance=0.60, sample_factor=0.60,
    ),
    "classic_lung": CinematicPreset(
        name="Classic Lung",
        color=((-1000,0.00,0.01,0.03),(-920,0.05,0.12,0.30),(-820,0.22,0.43,0.90),(-680,0.54,0.78,1.00),(-420,0.72,0.88,1.00),(-100,0.30,0.30,0.32),(180,0.96,0.64,0.48),(650,1.0,0.88,0.66),(1300,1.0,0.98,0.86)),
        opacity=((-1000,0.0),(-930,0.020),(-820,0.085),(-680,0.155),(-420,0.110),(-150,0.018),(80,0.030),(240,0.105),(650,0.43),(1300,0.78)),
        gradient=((0,0),(20,0.025),(55,0.17),(120,0.42),(260,0.74),(520,0.92)),
        ambient=0.30, diffuse=0.78, specular=0.20, specular_power=24, opacity_unit_distance=0.55, sample_factor=0.65,
    ),
    "classic_lung_fidelity": CinematicPreset(
        name="Classic Lung Fidelity",
        color=((-1000,0.00,0.01,0.03),(-940,0.035,0.09,0.24),(-840,0.16,0.34,0.82),(-720,0.42,0.66,0.98),(-520,0.62,0.82,1.00),(-220,0.38,0.42,0.45),(60,0.70,0.46,0.38),(260,0.98,0.68,0.48),(680,1.0,0.86,0.62),(1300,1.0,0.98,0.86)),
        opacity=((-1000,0.0),(-940,0.012),(-840,0.055),(-720,0.118),(-520,0.090),(-220,0.018),(40,0.018),(220,0.070),(620,0.34),(1300,0.70)),
        gradient=((0,0),(18,0.018),(52,0.12),(120,0.36),(260,0.64),(520,0.86)),
        ambient=0.22, diffuse=0.88, specular=0.24, specular_power=30, opacity_unit_distance=0.58, sample_factor=0.55,
    ),
    "classic_bone": CinematicPreset(
        name="Classic Bone",
        color=((-1000,0,0,0),(80,0,0,0),(210,0.36,0.23,0.12),(360,0.82,0.63,0.36),(620,0.98,0.86,0.62),(1100,1.0,0.96,0.82),(1800,1.0,1.0,0.94)),
        opacity=((-1000,0),(120,0),(230,0.020),(330,0.16),(500,0.46),(850,0.82),(1500,1.0)),
        gradient=((0,0),(35,0.05),(90,0.42),(180,0.78),(360,1.0)),
        ambient=0.18, diffuse=0.82, specular=0.30, specular_power=34, opacity_unit_distance=0.45, sample_factor=0.55,
    ),
    "classic_soft_tissue": CinematicPreset(
        name="Classic Soft Tissue",
        color=((-1000,0,0,0),(-240,0.18,0.10,0.08),(-120,0.58,0.34,0.28),(35,0.85,0.50,0.40),(95,0.94,0.62,0.48),(230,0.98,0.75,0.56),(650,1.0,0.90,0.72),(1200,1.0,0.98,0.86)),
        opacity=((-1000,0),(-240,0),(-140,0.035),(-40,0.080),(40,0.135),(120,0.190),(250,0.285),(700,0.50),(1200,0.76)),
        gradient=((0,0),(25,0.03),(70,0.22),(160,0.50),(420,0.78)),
        ambient=0.34, diffuse=0.72, specular=0.16, specular_power=20, opacity_unit_distance=0.70, sample_factor=0.75,
    ),
    "hemorrhage_focus": CinematicPreset(
        name="Hemorrhage Focus",
        color=((-1000,0,0,0),(-60,0.20,0.18,0.16),(25,0.56,0.50,0.46),(45,0.95,0.04,0.02),(70,1.0,0.00,0.00),(100,1.0,0.12,0.04),(170,0.92,0.62,0.48),(500,0.95,0.86,0.68),(1200,1.0,0.96,0.84)),
        opacity=((-1000,0),(-60,0),(25,0.020),(42,0.075),(55,0.48),(80,0.84),(110,0.56),(160,0.08),(400,0.16),(1000,0.34)),
        gradient=((0,0),(20,0.02),(55,0.25),(100,0.58),(240,0.88)),
        ambient=0.30, diffuse=0.74, specular=0.20, specular_power=24, opacity_unit_distance=0.50, sample_factor=0.60,
    ),
    "trauma_cinematic": CinematicPreset(
        name="Trauma Cinematic",
        color=((-1000,0,0,0),(-180,0.28,0.18,0.14),(60,0.64,0.42,0.34),(220,0.82,0.60,0.42),(380,0.98,0.78,0.50),(760,1.0,0.92,0.70),(1450,1.0,0.99,0.90)),
        opacity=((-1000,0),(-180,0),(60,0.025),(220,0.075),(340,0.25),(520,0.60),(900,0.92),(1450,1.0)),
        gradient=((0,0),(30,0.04),(80,0.35),(160,0.72),(360,1.0)),
        ambient=0.20, diffuse=0.80, specular=0.28, specular_power=32, opacity_unit_distance=0.42, sample_factor=0.55,
    ),
}

ALIASES = {
    "classic_anatomy": "classic_hospital",
    "classic_head_face": "classic_hospital",
    "head_face": "classic_hospital",
    "classic_lung_old": "classic_lung",
    "classic_lung_fidelity": "classic_lung_fidelity",
    "lung_fidelity": "classic_lung_fidelity",
    "lung": "classic_lung_fidelity",
    "classic_bone_old": "classic_bone",
    "bone_ultra": "classic_bone",
    "bone": "classic_bone",
    "fracture_ultra": "trauma_cinematic",
    "classic_soft": "classic_soft_tissue",
    "soft_tissue": "classic_soft_tissue",
    "skin_muscle": "classic_soft_tissue",
    "brain_hemorrhage": "hemorrhage_focus",
    "brain_transparent": "hemorrhage_focus",
    "blood": "hemorrhage_focus",
    "hemorrhage": "hemorrhage_focus",
    "trauma": "trauma_cinematic",
}


def preset_key(name: str) -> str:
    k = _key(name)
    return ALIASES.get(k, k)


def is_cinematic_preset(name: str) -> bool:
    return preset_key(name) in PRESETS


def get_cinematic_preset(name: str) -> CinematicPreset:
    return PRESETS[preset_key(name)]


def build_cinematic_property(name: str):
    """Build vtkVolumeProperty with shading, gradient opacity and unit distance."""
    import vtkmodules.all as vtk  # type: ignore
    p = get_cinematic_preset(name)
    color = vtk.vtkColorTransferFunction(); op = vtk.vtkPiecewiseFunction(); grad = vtk.vtkPiecewiseFunction()
    for hu, r, g, b in p.color:
        color.AddRGBPoint(float(hu), float(r), float(g), float(b))
    for hu, a in p.opacity:
        op.AddPoint(float(hu), float(a))
    for g, a in p.gradient:
        grad.AddPoint(float(g), float(a))
    prop = vtk.vtkVolumeProperty()
    prop.SetColor(color); prop.SetScalarOpacity(op); prop.SetGradientOpacity(grad)
    prop.SetInterpolationTypeToLinear(); prop.ShadeOn()
    prop.SetAmbient(float(p.ambient)); prop.SetDiffuse(float(p.diffuse)); prop.SetSpecular(float(p.specular)); prop.SetSpecularPower(float(p.specular_power))
    try:
        prop.SetScalarOpacityUnitDistance(float(p.opacity_unit_distance))
    except Exception:
        pass
    try:
        if hasattr(prop, "SetUseGradientOpacity"):
            prop.SetUseGradientOpacity(True)
    except Exception:
        pass
    return prop


def apply_cinematic_mapper_quality(mapper, preset_name: str, spacing_zyx) -> None:
    """Apply safe sample/image distances; no-op on unsupported mapper methods."""
    try:
        p = get_cinematic_preset(preset_name)
    except Exception:
        return
    try:
        if p.blend == "mip": mapper.SetBlendModeToMaximumIntensity()
        else: mapper.SetBlendModeToComposite()
    except Exception:
        pass
    try:
        sz, sy, sx = (float(spacing_zyx[0]), float(spacing_zyx[1]), float(spacing_zyx[2]))
        base = max(0.28, min(sx, sy, sz) * float(p.sample_factor))
        mapper.SetSampleDistance(base)
    except Exception:
        pass
    try:
        mapper.SetImageSampleDistance(float(p.image_sample_distance))
    except Exception:
        pass
    try:
        if hasattr(mapper, "SetUseJittering"):
            mapper.SetUseJittering(True)
    except Exception:
        pass
