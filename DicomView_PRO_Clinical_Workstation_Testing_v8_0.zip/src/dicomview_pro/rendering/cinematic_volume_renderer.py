from __future__ import annotations

from typing import Optional, Tuple
from dicomview_pro.rendering.gpu_quality_manager import GPUQualityManager
from dicomview_pro.rendering.transfer_function_presets import build_vtk_property


class CinematicVolumeRenderer:
    """RadiAnt/syngo-like CT volume renderer built on vtkGPUVolumeRayCastMapper.

    Input must be vtkImageData with calibrated HU scalar values and correct spacing.
    """
    def __init__(self, renderer, render_window=None, quality: str = "auto") -> None:
        try:
            import vtkmodules.all as vtk  # type: ignore
            import vtkmodules.vtkRenderingVolumeOpenGL2  # noqa: F401
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("VTK Volume OpenGL2 is not available") from exc
        self.vtk = vtk
        self.renderer = renderer
        self.render_window = render_window
        self.quality_manager = GPUQualityManager(quality)
        self.mapper = None
        self.volume = None
        self.property = None
        self.current_preset = "thorax_cinematic"

    def set_input(self, vtk_image, preset: str = "thorax_cinematic", blend: str = "composite") -> None:
        vtk = self.vtk
        dims = vtk_image.GetDimensions()
        settings = self.quality_manager.choose((dims[2], dims[1], dims[0]))
        mapper = vtk.vtkGPUVolumeRayCastMapper()
        mapper.SetInputData(vtk_image)
        blend_l = (blend or "composite").lower()
        if blend_l == "mip": mapper.SetBlendModeToMaximumIntensity()
        elif blend_l == "minip": mapper.SetBlendModeToMinimumIntensity()
        elif blend_l in {"average", "avg"}: mapper.SetBlendModeToAverageIntensity()
        else: mapper.SetBlendModeToComposite()
        GPUQualityManager.apply_to_mapper(mapper, settings)
        prop = build_vtk_property(preset)
        volume = vtk.vtkVolume(); volume.SetMapper(mapper); volume.SetProperty(prop)
        if self.volume is not None:
            try: self.renderer.RemoveVolume(self.volume)
            except Exception: pass
        self.mapper = mapper; self.property = prop; self.volume = volume; self.current_preset = preset
        self.renderer.AddVolume(volume)
        self._enable_cinematic_scene()
        self.renderer.ResetCamera()
        self.render()

    def set_preset(self, preset: str) -> None:
        if self.volume is None: return
        self.property = build_vtk_property(preset)
        self.volume.SetProperty(self.property)
        self.current_preset = preset
        self.render()

    def set_blend_mode(self, blend: str) -> None:
        if self.mapper is None: return
        b = (blend or "composite").lower()
        if b == "mip": self.mapper.SetBlendModeToMaximumIntensity()
        elif b == "minip": self.mapper.SetBlendModeToMinimumIntensity()
        elif b in {"average", "avg"}: self.mapper.SetBlendModeToAverageIntensity()
        else: self.mapper.SetBlendModeToComposite()
        self.render()

    def set_crop_planes(self, bounds: Tuple[float, float, float, float, float, float]) -> None:
        if self.mapper is None: return
        self.mapper.SetCroppingRegionPlanes(*[float(v) for v in bounds])
        self.mapper.CroppingOn(); self.render()

    def clear_crop(self) -> None:
        if self.mapper is not None:
            self.mapper.CroppingOff(); self.render()

    def _enable_cinematic_scene(self) -> None:
        try:
            self.renderer.SetUseDepthPeeling(True)
            self.renderer.SetMaximumNumberOfPeels(80)
            self.renderer.SetOcclusionRatio(0.08)
        except Exception: pass
        try:
            self.renderer.SetBackground(0.0, 0.0, 0.0)
        except Exception: pass
        try:
            if self.render_window is not None:
                self.render_window.SetAlphaBitPlanes(True)
                self.render_window.SetMultiSamples(0)
        except Exception: pass

    def render(self) -> None:
        try:
            if self.render_window is not None: self.render_window.Render()
        except Exception: pass
