from __future__ import annotations

try:
    import vtk  # type: ignore
except Exception:  # pragma: no cover
    vtk = None

from dicomview_pro.rendering.hardware_profile import HardwareProfile, safe_create_gpu_volume_mapper


class VolumeRenderEngine:
    """
    Мінімальний стабільний engine для GPU volume rendering.
    Його можна підключити до існуючого QVTKRenderWindowInteractor.
    """

    def __init__(self, renderer, render_window=None, hardware: HardwareProfile | None = None) -> None:
        if vtk is None:
            raise RuntimeError("VTK is not installed.")

        self.renderer = renderer
        self.render_window = render_window
        self.hardware = hardware or HardwareProfile()
        self.hardware.detect()

        self.mapper = None
        self.volume = None
        self.property = None

    def set_volume(self, vtk_image, preset: str = "transparent_bone") -> str:
        mode = self.hardware.choose_render_mode(
            volume_shape_zyx=(
                vtk_image.GetDimensions()[2],
                vtk_image.GetDimensions()[1],
                vtk_image.GetDimensions()[0],
            )
        )

        if mode in {"LOW", "SAFE"}:
            return mode

        mapper, reason = safe_create_gpu_volume_mapper()
        if mapper is None:
            self.hardware.safe_mode_reason = reason
            return "SAFE"

        try:
            mapper.SetInputData(vtk_image)
            self.mapper = mapper
            self.property = self._make_property(preset)

            volume = vtk.vtkVolume()
            volume.SetMapper(self.mapper)
            volume.SetProperty(self.property)

            if self.volume is not None:
                self.renderer.RemoveVolume(self.volume)

            self.volume = volume
            self.renderer.AddVolume(volume)
            self.renderer.ResetCamera()
            self._render()
            return mode
        except Exception as exc:
            self.hardware.mark_gpu_failure(exc)
            return "SAFE"

    def set_preset(self, preset: str) -> None:
        if self.volume is None:
            return
        self.property = self._make_property(preset)
        self.volume.SetProperty(self.property)
        self._render()

    def _make_property(self, preset: str):
        color = vtk.vtkColorTransferFunction()
        opacity = vtk.vtkPiecewiseFunction()

        preset = preset.lower().strip()

        if preset in {"bone", "transparent_bone", "skull"}:
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(-300, 0.6, 0.45, 0.35)
            color.AddRGBPoint(250, 0.9, 0.85, 0.75)
            color.AddRGBPoint(1200, 1.0, 1.0, 0.95)
            opacity.AddPoint(-1000, 0.00)
            opacity.AddPoint(-300, 0.00)
            opacity.AddPoint(100, 0.02)
            opacity.AddPoint(250, 0.08 if preset == "transparent_bone" else 0.18)
            opacity.AddPoint(1200, 0.35 if preset == "transparent_bone" else 0.85)
        elif preset in {"soft", "soft_tissue"}:
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(-100, 0.6, 0.35, 0.25)
            color.AddRGBPoint(80, 0.9, 0.55, 0.45)
            color.AddRGBPoint(400, 1.0, 0.9, 0.8)
            opacity.AddPoint(-1000, 0.00)
            opacity.AddPoint(-100, 0.04)
            opacity.AddPoint(80, 0.18)
            opacity.AddPoint(400, 0.35)
        else:
            color.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color.AddRGBPoint(0, 0.8, 0.8, 0.8)
            color.AddRGBPoint(1000, 1.0, 1.0, 1.0)
            opacity.AddPoint(-1000, 0.00)
            opacity.AddPoint(0, 0.05)
            opacity.AddPoint(1000, 0.45)

        prop = vtk.vtkVolumeProperty()
        prop.SetColor(color)
        prop.SetScalarOpacity(opacity)
        prop.SetInterpolationTypeToLinear()
        prop.ShadeOff()
        return prop

    def _render(self) -> None:
        try:
            if self.render_window is not None:
                self.render_window.Render()
        except Exception:
            pass
