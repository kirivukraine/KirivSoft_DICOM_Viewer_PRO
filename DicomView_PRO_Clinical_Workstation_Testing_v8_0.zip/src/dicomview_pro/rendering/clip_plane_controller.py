from __future__ import annotations

from typing import Optional
import math

try:
    import vtk  # type: ignore
except Exception:  # pragma: no cover
    vtk = None

from .shared_crosshair_state import SharedCrosshairState


class ClipPlaneController:
    """
    Керує 3D-ножем для vtkVolumeMapper / vtkGPUVolumeRayCastMapper.

    Інтеграція:
        controller = ClipPlaneController(volume_mapper, shared_state, renderer, render_window)
        controller.enable(True)
        controller.set_mode("axial")
        controller.move_mm(2.0)
    """

    VALID_MODES = {"axial", "coronal", "sagittal", "free"}

    def __init__(
        self,
        vtk_volume_mapper,
        shared_state: SharedCrosshairState,
        renderer=None,
        render_window=None,
    ) -> None:
        if vtk is None:
            raise RuntimeError("VTK is not installed. ClipPlaneController requires vtk.")

        self.mapper = vtk_volume_mapper
        self.shared_state = shared_state
        self.renderer = renderer
        self.render_window = render_window

        self.enabled = False
        self.mode = "axial"
        self.plane = vtk.vtkPlane()
        self.plane_actor = None
        self._free_normal = (0.0, 0.0, 1.0)

        self._update_plane_from_state()
        self.shared_state.subscribe(self._on_shared_state_changed)

    def dispose(self) -> None:
        try:
            self.shared_state.unsubscribe(self._on_shared_state_changed)
        except Exception:
            pass
        self.enable(False)

    def enable(self, enabled: bool) -> None:
        self.enabled = bool(enabled)

        if self.mapper is not None:
            planes = self.mapper.GetClippingPlanes() if hasattr(self.mapper, "GetClippingPlanes") else None

            if self.enabled:
                self._update_plane_from_state()
                if planes is None:
                    planes = vtk.vtkPlaneCollection()
                    self.mapper.SetClippingPlanes(planes)
                planes.RemoveAllItems()
                planes.AddItem(self.plane)
            else:
                if planes is not None:
                    planes.RemoveAllItems()

        self._set_plane_actor_visible(self.enabled)
        self._render()

    def set_mode(self, mode: str) -> None:
        mode = mode.lower().strip()
        if mode not in self.VALID_MODES:
            raise ValueError(f"Unsupported clip plane mode: {mode}")

        self.mode = mode
        self._update_plane_from_state()
        if self.enabled:
            self.enable(True)
        self._render()

    def move_mm(self, delta_mm: float) -> None:
        """
        Рух площини у мм вздовж її нормалі.
        Також оновлює SharedCrosshairState, щоб MPR не роз'їжджався з 3D.
        """
        ox, oy, oz = self.plane.GetOrigin()
        nx, ny, nz = self.plane.GetNormal()
        new_xyz = (
            ox + nx * float(delta_mm),
            oy + ny * float(delta_mm),
            oz + nz * float(delta_mm),
        )
        self.shared_state.set_from_patient_xyz(new_xyz)

    def rotate_free_plane(self, rx_deg: float, ry_deg: float, rz_deg: float) -> None:
        """
        Простий поворот free-plane нормалі. Для axial/coronal/sagittal не застосовується.
        """
        if self.mode != "free":
            return

        nx, ny, nz = self._free_normal

        # rotation around X
        rx = math.radians(rx_deg)
        cy, sy = math.cos(rx), math.sin(rx)
        ny, nz = ny * cy - nz * sy, ny * sy + nz * cy

        # rotation around Y
        ry = math.radians(ry_deg)
        cx, sx = math.cos(ry), math.sin(ry)
        nx, nz = nx * cx + nz * sx, -nx * sx + nz * cx

        # rotation around Z
        rz = math.radians(rz_deg)
        cz, sz = math.cos(rz), math.sin(rz)
        nx, ny = nx * cz - ny * sz, nx * sz + ny * cz

        length = max(1e-9, math.sqrt(nx * nx + ny * ny + nz * nz))
        self._free_normal = (nx / length, ny / length, nz / length)

        self._update_plane_from_state()
        self._render()

    def reset(self) -> None:
        z, y, x = self.shared_state.shape_zyx
        self.shared_state.set_from_voxel_zyx((z // 2, y // 2, x // 2))
        self._free_normal = (0.0, 0.0, 1.0)
        self._update_plane_from_state()
        self._render()

    def get_plane(self):
        return self.plane

    def _on_shared_state_changed(self, state: SharedCrosshairState) -> None:
        self._update_plane_from_state()
        self._render()

    def _update_plane_from_state(self) -> None:
        xyz = self.shared_state.patient_position_xyz

        if self.mode == "axial":
            normal = (0.0, 0.0, 1.0)
        elif self.mode == "coronal":
            normal = (0.0, 1.0, 0.0)
        elif self.mode == "sagittal":
            normal = (1.0, 0.0, 0.0)
        else:
            normal = self._free_normal

        self.plane.SetOrigin(*xyz)
        self.plane.SetNormal(*normal)
        self._update_plane_actor()

    def _update_plane_actor(self) -> None:
        if vtk is None or self.renderer is None:
            return

        bounds = self.shared_state.volume_bounds_xyz()
        xmin, xmax, ymin, ymax, zmin, zmax = bounds
        cx, cy, cz = self.shared_state.patient_position_xyz

        if self.plane_actor is None:
            plane_source = vtk.vtkPlaneSource()
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(plane_source.GetOutputPort())

            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetOpacity(0.18)
            actor.GetProperty().SetColor(0.2, 0.8, 1.0)
            actor.SetVisibility(False)

            self._plane_source = plane_source
            self.plane_actor = actor
            self.renderer.AddActor(actor)

        # Build a visible plane centered on the current clip origin.
        # For free-mode this keeps the visual indicator aligned with the rotated normal.
        nx, ny, nz = self.plane.GetNormal()
        n_len = max(1e-9, math.sqrt(nx * nx + ny * ny + nz * nz))
        nx, ny, nz = nx / n_len, ny / n_len, nz / n_len

        # Pick a stable helper vector that is not parallel to the normal.
        helper = (0.0, 0.0, 1.0) if abs(nz) < 0.9 else (0.0, 1.0, 0.0)
        hx, hy, hz = helper

        # u = normal x helper
        ux, uy, uz = ny * hz - nz * hy, nz * hx - nx * hz, nx * hy - ny * hx
        u_len = max(1e-9, math.sqrt(ux * ux + uy * uy + uz * uz))
        ux, uy, uz = ux / u_len, uy / u_len, uz / u_len

        # v = normal x u
        vx, vy, vz = ny * uz - nz * uy, nz * ux - nx * uz, nx * uy - ny * ux
        v_len = max(1e-9, math.sqrt(vx * vx + vy * vy + vz * vz))
        vx, vy, vz = vx / v_len, vy / v_len, vz / v_len

        size_u = max(10.0, abs(xmax - xmin), abs(ymax - ymin), abs(zmax - zmin)) * 0.70
        size_v = size_u

        p0 = (cx - ux * size_u - vx * size_v, cy - uy * size_u - vy * size_v, cz - uz * size_u - vz * size_v)
        p1 = (cx + ux * size_u - vx * size_v, cy + uy * size_u - vy * size_v, cz + uz * size_u - vz * size_v)
        p2 = (cx - ux * size_u + vx * size_v, cy - uy * size_u + vy * size_v, cz - uz * size_u + vz * size_v)

        self._plane_source.SetOrigin(*p0)
        self._plane_source.SetPoint1(*p1)
        self._plane_source.SetPoint2(*p2)
        self._plane_source.Update()

    def _set_plane_actor_visible(self, visible: bool) -> None:
        if self.plane_actor is not None:
            self.plane_actor.SetVisibility(bool(visible))

    def _render(self) -> None:
        try:
            if self.render_window is not None:
                self.render_window.Render()
        except Exception:
            pass
