from __future__ import annotations

from typing import Optional
import numpy as np

try:
    import vtk  # type: ignore
except Exception:  # pragma: no cover
    vtk = None

from .shared_crosshair_state import SharedCrosshairState


class SlabController:
    """
    Thick MPR Slab: Off / MIP / MinIP / Average.

    Може працювати:
    1) через vtkImageSlabReslice, якщо доступний;
    2) через numpy fallback, щоб не ламати програму на слабкому ПК/старому VTK.
    """

    VALID_MODES = {"Off", "MIP", "MinIP", "Average"}

    def __init__(
        self,
        vtk_image=None,
        shared_state: Optional[SharedCrosshairState] = None,
        numpy_volume_zyx: Optional[np.ndarray] = None,
    ) -> None:
        self.vtk_image = vtk_image
        self.shared_state = shared_state or SharedCrosshairState()
        self.numpy_volume_zyx = numpy_volume_zyx

        self.mode = "Off"
        self.thickness_mm = 1.0

    def set_mode(self, mode: str) -> None:
        normalized = mode.strip()
        if normalized.lower() == "off":
            normalized = "Off"
        elif normalized.lower() == "mip":
            normalized = "MIP"
        elif normalized.lower() == "minip":
            normalized = "MinIP"
        elif normalized.lower() in {"avg", "average"}:
            normalized = "Average"

        if normalized not in self.VALID_MODES:
            raise ValueError(f"Unsupported slab mode: {mode}")

        self.mode = normalized

    def set_thickness_mm(self, thickness_mm: float) -> None:
        self.thickness_mm = max(0.1, float(thickness_mm))

    def increase_thickness(self, delta_mm: float) -> None:
        self.set_thickness_mm(self.thickness_mm + float(delta_mm))

    def reslice_numpy(self, orientation: str) -> np.ndarray:
        """
        Надійний fallback через numpy.
        Повертає 2D slice у numpy.
        """
        if self.numpy_volume_zyx is None:
            raise RuntimeError("numpy_volume_zyx is required for numpy slab fallback.")

        orientation = orientation.lower()
        vol = self.numpy_volume_zyx
        z, y, x = self.shared_state.voxel_index_zyx
        sx, sy, sz = self.shared_state.spacing

        if self.mode == "Off" or self.thickness_mm <= 1.0:
            if orientation == "axial":
                return vol[z, :, :]
            if orientation == "coronal":
                return vol[:, y, :]
            if orientation == "sagittal":
                return vol[:, :, x]
            raise ValueError(f"Unknown orientation: {orientation}")

        if orientation == "axial":
            half_count = max(1, round((self.thickness_mm / sz) / 2))
            block = vol[max(0, z - half_count):min(vol.shape[0], z + half_count + 1), :, :]
        elif orientation == "coronal":
            half_count = max(1, round((self.thickness_mm / sy) / 2))
            block = vol[:, max(0, y - half_count):min(vol.shape[1], y + half_count + 1), :]
        elif orientation == "sagittal":
            half_count = max(1, round((self.thickness_mm / sx) / 2))
            block = vol[:, :, max(0, x - half_count):min(vol.shape[2], x + half_count + 1)]
        else:
            raise ValueError(f"Unknown orientation: {orientation}")

        axis = 0 if orientation == "axial" else 1 if orientation == "coronal" else 2

        if self.mode == "MIP":
            return np.max(block, axis=axis)
        if self.mode == "MinIP":
            return np.min(block, axis=axis)
        if self.mode == "Average":
            return np.mean(block, axis=axis).astype(vol.dtype, copy=False)

        raise ValueError(f"Unsupported slab mode: {self.mode}")

    def create_vtk_slab_reslice(self, orientation: str):
        """
        Створює vtkImageSlabReslice pipeline.
        Це заготовка для інтеграції з існуючим MPR renderer.
        """
        if vtk is None:
            raise RuntimeError("VTK is not installed.")
        if self.vtk_image is None:
            raise RuntimeError("vtk_image is required for vtk slab reslice.")
        if not hasattr(vtk, "vtkImageSlabReslice"):
            raise RuntimeError("vtkImageSlabReslice is not available in this VTK build.")

        orientation = orientation.lower()
        reslice = vtk.vtkImageSlabReslice()
        reslice.SetInputData(self.vtk_image)
        reslice.SetSlabThickness(float(self.thickness_mm))

        if self.mode == "MIP":
            reslice.SetBlendModeToMax()
        elif self.mode == "MinIP":
            reslice.SetBlendModeToMin()
        elif self.mode == "Average":
            reslice.SetBlendModeToMean()
        else:
            # Off: звичайний тонкий reslice.
            reslice.SetSlabThickness(0.0)

        # Матрицю ResliceAxes краще підставити з вашого існуючого MPR engine.
        # Тут повертається об'єкт, щоб інтегратор міг задати axes.
        return reslice
