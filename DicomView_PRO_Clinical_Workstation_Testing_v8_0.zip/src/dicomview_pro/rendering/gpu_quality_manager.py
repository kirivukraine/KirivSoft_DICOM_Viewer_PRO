from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass
class GPUQualitySettings:
    mode: str = "auto"
    sample_distance: float = 0.8
    image_sample_distance: float = 1.0
    max_voxels: int = 512 * 512 * 650
    use_jittering: bool = True
    enable_shading: bool = True
    fallback_reason: str = ""


class GPUQualityManager:
    """Chooses safe volume-rendering quality for old and modern PCs."""
    def __init__(self, mode: str = "auto") -> None:
        self.settings = GPUQualitySettings(mode=mode)

    def choose(self, volume_shape_zyx: Tuple[int, int, int]) -> GPUQualitySettings:
        z, y, x = [int(v) for v in volume_shape_zyx]
        voxels = max(1, z * y * x)
        mode = (self.settings.mode or "auto").lower()
        s = GPUQualitySettings(mode=mode)
        if mode in {"low", "safe"} or voxels > 900_000_000:
            s.sample_distance = 2.0; s.image_sample_distance = 2.0; s.use_jittering = False
            s.fallback_reason = "Low/Safe якість для слабкого GPU або дуже великого об'єму."
        elif mode in {"high", "ultra", "cinematic"}:
            s.sample_distance = 0.45; s.image_sample_distance = 0.75; s.use_jittering = True
        elif voxels > 350_000_000:
            s.sample_distance = 1.25; s.image_sample_distance = 1.5
        else:
            s.sample_distance = 0.75; s.image_sample_distance = 1.0
        self.settings = s
        return s

    @staticmethod
    def apply_to_mapper(mapper, settings: GPUQualitySettings) -> None:
        for name, value in (("SetSampleDistance", settings.sample_distance), ("SetImageSampleDistance", settings.image_sample_distance)):
            try: getattr(mapper, name)(float(value))
            except Exception: pass
        try:
            if settings.use_jittering and hasattr(mapper, "SetUseJittering"):
                mapper.SetUseJittering(True)
        except Exception: pass
