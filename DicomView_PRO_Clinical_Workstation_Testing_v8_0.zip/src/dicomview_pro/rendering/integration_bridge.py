from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

try:
    from .shared_crosshair_state import SharedCrosshairState
    from .deep_camera_controller import DeepCameraController
    from .slab_controller import SlabController
    from .clip_plane_controller import ClipPlaneController
except Exception:  # pragma: no cover
    SharedCrosshairState = None  # type: ignore
    DeepCameraController = None  # type: ignore
    SlabController = None  # type: ignore
    ClipPlaneController = None  # type: ignore


@dataclass
class Deep3DControllers:
    shared_state: Any = None
    deep_camera: Any = None
    slab: Any = None
    clip: Any = None


def attach_deep3d_controllers(viewer: Any, volume_zyx=None, spacing_zyx=(1.0, 1.0, 1.0)) -> Deep3DControllers:
    """Attach lightweight Deep3D controllers to the existing VtkVolumeViewer.

    This bridge keeps the old UI working while the new modular rendering package is
    integrated step by step.  It never raises to the GUI: if VTK/Qt pieces are not
    ready, the caller receives empty controllers and can continue in safe mode.
    """
    ctrls = Deep3DControllers()
    try:
        if SharedCrosshairState is None:
            return ctrls
        zyx_shape = tuple(int(v) for v in getattr(volume_zyx, 'shape', (1, 1, 1)))
        sz, sy, sx = tuple(float(v) for v in spacing_zyx)
        state = SharedCrosshairState()
        state.configure_volume(zyx_shape, spacing_xyz=(sx, sy, sz), origin_xyz=(0.0, 0.0, 0.0), notify=False)
        ctrls.shared_state = state
        renderer = getattr(viewer, '_renderer', None)
        render_widget = getattr(viewer, '_render_widget', None)
        render_window = render_widget.GetRenderWindow() if render_widget is not None else None
        if DeepCameraController is not None and renderer is not None:
            ctrls.deep_camera = DeepCameraController(renderer, render_window, state)
        if SlabController is not None:
            ctrls.slab = SlabController(shared_state=state, numpy_volume_zyx=volume_zyx)

        # Attach modular ClipPlaneController when a mapper is already available.
        # This does not enable clipping immediately, so normal rotation/zoom stays unchanged.
        mapper = getattr(viewer, '_volume_mapper', None)
        if ClipPlaneController is not None and mapper is not None:
            try:
                ctrls.clip = ClipPlaneController(mapper, state, renderer, render_window)
            except Exception:
                ctrls.clip = None

        viewer._deep3d_controllers = ctrls
    except Exception:
        viewer._deep3d_controllers = ctrls
    return ctrls
