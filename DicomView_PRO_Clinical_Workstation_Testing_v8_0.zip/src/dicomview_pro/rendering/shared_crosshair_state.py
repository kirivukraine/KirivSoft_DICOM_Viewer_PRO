from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable, Optional, Tuple
import math

Vec3 = Tuple[float, float, float]
Index3 = Tuple[int, int, int]


def _clamp_int(value: int, low: int, high: int) -> int:
    return max(low, min(high, int(value)))


@dataclass
class SharedCrosshairState:
    """
    Єдиний стан позиції для 3D, MPR, slab і clipping plane.

    Важливо:
    - patient_position_xyz зберігається у world/patient координатах VTK: x, y, z.
    - voxel_index_zyx зберігається як індекси numpy volume: z, y, x.
    - spacing/origin у VTK-форматі: x, y, z.
    """

    spacing: Vec3 = (1.0, 1.0, 1.0)
    origin: Vec3 = (0.0, 0.0, 0.0)
    shape_zyx: Index3 = (1, 1, 1)

    patient_position_xyz: Vec3 = (0.0, 0.0, 0.0)
    voxel_index_zyx: Index3 = (0, 0, 0)

    axial_index: int = 0
    coronal_index: int = 0
    sagittal_index: int = 0

    _subscribers: list[Callable[["SharedCrosshairState"], None]] = field(default_factory=list)
    _mute_notify: bool = False

    def configure_volume(
        self,
        shape_zyx: Index3,
        spacing_xyz: Vec3,
        origin_xyz: Vec3 = (0.0, 0.0, 0.0),
        initial_zyx: Optional[Index3] = None,
        notify: bool = True,
    ) -> None:
        self.shape_zyx = tuple(int(max(1, v)) for v in shape_zyx)  # type: ignore[assignment]
        self.spacing = tuple(float(max(1e-6, v)) for v in spacing_xyz)  # type: ignore[assignment]
        self.origin = tuple(float(v) for v in origin_xyz)  # type: ignore[assignment]

        if initial_zyx is None:
            z, y, x = self.shape_zyx
            initial_zyx = (z // 2, y // 2, x // 2)

        self.set_from_voxel_zyx(initial_zyx, notify=notify)

    def subscribe(self, callback: Callable[["SharedCrosshairState"], None]) -> None:
        if callback not in self._subscribers:
            self._subscribers.append(callback)

    def unsubscribe(self, callback: Callable[["SharedCrosshairState"], None]) -> None:
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    def notify(self) -> None:
        if self._mute_notify:
            return
        for cb in list(self._subscribers):
            try:
                cb(self)
            except Exception:
                # Не даємо одному віджету завалити весь viewer.
                pass

    def set_from_patient_xyz(self, xyz: Vec3, notify: bool = True) -> None:
        x, y, z = xyz
        ox, oy, oz = self.origin
        sx, sy, sz = self.spacing

        ix = round((x - ox) / sx)
        iy = round((y - oy) / sy)
        iz = round((z - oz) / sz)

        self.set_from_voxel_zyx((iz, iy, ix), notify=notify)

    def set_from_voxel_zyx(self, zyx: Index3, notify: bool = True) -> None:
        max_z, max_y, max_x = self.shape_zyx
        z = _clamp_int(zyx[0], 0, max_z - 1)
        y = _clamp_int(zyx[1], 0, max_y - 1)
        x = _clamp_int(zyx[2], 0, max_x - 1)

        self.voxel_index_zyx = (z, y, x)
        self.axial_index = z
        self.coronal_index = y
        self.sagittal_index = x

        ox, oy, oz = self.origin
        sx, sy, sz = self.spacing
        self.patient_position_xyz = (
            ox + x * sx,
            oy + y * sy,
            oz + z * sz,
        )

        if notify:
            self.notify()

    def set_axial_index(self, z: int, notify: bool = True) -> None:
        _, y, x = self.voxel_index_zyx
        self.set_from_voxel_zyx((z, y, x), notify=notify)

    def set_coronal_index(self, y: int, notify: bool = True) -> None:
        z, _, x = self.voxel_index_zyx
        self.set_from_voxel_zyx((z, y, x), notify=notify)

    def set_sagittal_index(self, x: int, notify: bool = True) -> None:
        z, y, _ = self.voxel_index_zyx
        self.set_from_voxel_zyx((z, y, x), notify=notify)

    def volume_bounds_xyz(self) -> tuple[float, float, float, float, float, float]:
        z, y, x = self.shape_zyx
        ox, oy, oz = self.origin
        sx, sy, sz = self.spacing
        return (
            ox, ox + max(0, x - 1) * sx,
            oy, oy + max(0, y - 1) * sy,
            oz, oz + max(0, z - 1) * sz,
        )
