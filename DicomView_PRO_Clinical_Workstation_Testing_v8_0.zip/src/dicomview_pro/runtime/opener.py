from __future__ import annotations
import argparse, json, traceback
from dicomview_pro.core.dicom_reader import load_series_to_runtime, scan_series
from dicomview_pro.runtime.logging_setup import setup_logging

def main() -> int:
    setup_logging()
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["scan", "load"])
    ap.add_argument("path")
    ap.add_argument("out_dir", nargs="?")
    ap.add_argument("--series-uid", default=None)
    args = ap.parse_args()
    try:
        if args.action == "scan":
            series = scan_series(args.path)
            print(json.dumps({"ok": True, "series": [s.__dict__ for s in series]}, ensure_ascii=False), flush=True)
            return 0
        if not args.out_dir:
            raise RuntimeError("out_dir required for load")
        loaded = load_series_to_runtime(args.path, args.out_dir, args.series_uid)
        print(json.dumps({"ok": True, "volume": loaded.__dict__}, ensure_ascii=False), flush=True)
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc), "traceback": traceback.format_exc()}, ensure_ascii=False), flush=True)
        return 2
if __name__ == "__main__":
    raise SystemExit(main())
