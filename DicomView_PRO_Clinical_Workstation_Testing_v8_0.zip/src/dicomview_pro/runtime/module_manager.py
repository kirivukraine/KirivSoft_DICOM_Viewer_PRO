from __future__ import annotations

"""Safe optional-module manager for DicomView PRO.

v7.9 Stability Cleanup: optional Enterprise/AI/Slicer modules are detected
without importing absent packages.  Missing modules are reported as unavailable
instead of crashing the application at import time.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
import os


@dataclass(frozen=True)
class OptionalModule:
    key: str
    title: str
    installed: bool
    path: str
    mode: str
    message: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class RuntimeProbe:
    ok: bool
    path: str = ""
    python_path: str = ""
    message: str = ""


def project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _probe_totalsegmentator() -> RuntimeProbe:
    candidates = [
        os.environ.get("DICOMVIEW_TOTALSEG_PYTHON", ""),
        os.environ.get("TOTALSEGMENTATOR_PYTHON", ""),
        str(project_root() / "external_runtime" / "totalsegmentator" / "Scripts" / "python.exe"),
    ]
    for c in candidates:
        if c and Path(c).exists():
            return RuntimeProbe(True, path=str(Path(c).parent), python_path=str(c), message="TotalSegmentator external Python found.")
    return RuntimeProbe(False, message="TotalSegmentator runtime not configured; optional module disabled.")


def _probe_slicer() -> RuntimeProbe:
    candidates = [
        os.environ.get("DICOMVIEW_SLICER_EXE", ""),
        os.environ.get("SLICER_EXE", ""),
        str(project_root() / "_internal" / "slicer" / "Slicer.exe"),
        str(project_root() / "external_runtime" / "Slicer" / "Slicer.exe"),
    ]
    for c in candidates:
        if c and Path(c).exists():
            return RuntimeProbe(True, path=str(c), message="3D Slicer executable found.")
    return RuntimeProbe(False, message="3D Slicer bridge not configured; optional module disabled.")


def list_optional_modules() -> list[OptionalModule]:
    root = project_root()
    ts = _probe_totalsegmentator()
    slicer = _probe_slicer()
    realesrgan = root / "external_runtime" / "realesrgan" / "realesrgan-ncnn-vulkan.exe"
    nnunet = root / "external_runtime" / "nnunet"
    return [
        OptionalModule("totalsegmentator", "TotalSegmentator AI", ts.ok, ts.python_path or ts.path, "external_python", ts.message),
        OptionalModule("slicer", "3D Slicer Bridge", slicer.ok, slicer.path, "external_app", slicer.message),
        OptionalModule("realesrgan", "Real-ESRGAN Super Resolution", realesrgan.exists(), str(realesrgan), "external_tool", "Optional external super-resolution tool."),
        OptionalModule("nnunet", "nnU-Net Research", nnunet.exists(), str(nnunet), "external_python", "Experimental optional research runtime."),
    ]


def safe_mode_enabled() -> bool:
    marker = project_root() / "SAFE_MODE.txt"
    return marker.exists()
