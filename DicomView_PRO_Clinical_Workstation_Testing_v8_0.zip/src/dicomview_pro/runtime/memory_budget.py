from __future__ import annotations

import os
import ctypes

def total_ram_bytes() -> int:
    try:
        import psutil  # type: ignore
        return int(psutil.virtual_memory().total)
    except Exception:
        pass
    # Windows fallback without psutil.
    try:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong), ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong), ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong), ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
        stat = MEMORYSTATUSEX(); stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return int(stat.ullTotalPhys)
    except Exception:
        pass
    if hasattr(os, "sysconf"):
        try:
            return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
        except Exception:
            pass
    return 8 * 1024**3

def dicom_cache_budget_bytes(volume_bytes: int | float = 0) -> int:
    """Adaptive Lite cache budget: 10–40% of RAM depending on study size.

    Small studies do not need much memory; big CT/MR packages can use more RAM
    on workstations like Dell Precision with 64 GB.  This is a budget/guard, not
    a requirement to preallocate memory.
    """
    total = max(1, total_ram_bytes())
    vb = max(0, int(volume_bytes or 0))
    if vb < 512 * 1024**2:
        frac = 0.10
    elif vb < 2 * 1024**3:
        frac = 0.20
    elif vb < 6 * 1024**3:
        frac = 0.30
    else:
        frac = 0.40
    # Keep at least 2 GB for OS/GUI and cap to 40% by design.
    return int(min(total * 0.40, max(256 * 1024**2, total * frac)))

def human_bytes(n: int) -> str:
    n = int(n)
    for unit in ("B", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return str(n)
