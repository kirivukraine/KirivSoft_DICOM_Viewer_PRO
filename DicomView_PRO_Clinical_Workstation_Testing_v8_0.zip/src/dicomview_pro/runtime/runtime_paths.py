from __future__ import annotations
import os, shutil, tempfile, uuid
from pathlib import Path

ROOT = Path(tempfile.gettempdir()) / "DicomViewPRO_KirivSoft_runtime"

def runtime_root() -> Path:
    ROOT.mkdir(parents=True, exist_ok=True)
    return ROOT

def new_session_dir() -> Path:
    p = runtime_root() / uuid.uuid4().hex
    p.mkdir(parents=True, exist_ok=True)
    return p

def cleanup_runtime_dir() -> int:
    root = runtime_root()
    removed = 0
    for item in list(root.iterdir()):
        try:
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
                removed += 1
            else:
                item.unlink(missing_ok=True)
                removed += 1
        except Exception:
            pass
    return removed


def data_dir() -> Path:
    """Persistent application data directory for settings, case database and exports."""
    base = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local'))) if os.name == 'nt' else Path.home() / '.local' / 'share'
    d = base / 'KirivSoft' / 'DicomViewPRO'
    d.mkdir(parents=True, exist_ok=True)
    return d


def cleanup_old_runtime_dirs(max_age_hours: int = 24) -> int:
    """Remove stale runtime sessions left after crashes or forced shutdowns."""
    import time
    root = runtime_root()
    cutoff = time.time() - max(1, int(max_age_hours)) * 3600
    removed = 0
    for item in list(root.iterdir()):
        try:
            if item.stat().st_mtime > cutoff:
                continue
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
            else:
                item.unlink(missing_ok=True)
            removed += 1
        except Exception:
            pass
    return removed
