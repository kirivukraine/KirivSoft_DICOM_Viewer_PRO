from __future__ import annotations
"""Disabled-safe AI worker helpers.

v7.9 Stability Cleanup: the Lite/clinical builds must never crash simply by
importing this module.  The real AI implementation is intentionally kept outside
of the active source tree (plugins_disabled/enterprise_ai).  These functions are
safe stubs until a future Enterprise AI runtime is explicitly enabled.
"""
from dataclasses import dataclass
from typing import Literal, Any
import numpy as np

TaskName = Literal["segment", "denoise", "superres"]

@dataclass
class AITask:
    name: TaskName
    image2d: np.ndarray
    params: dict[str, Any]


def _disabled_result(task: str) -> dict[str, Any]:
    return {
        "ok": False,
        "message": f"AI task '{task}' is disabled in this build. Use deterministic clinical protocols instead.",
        "details": {"mode": "disabled_stub", "safe": True},
    }


def run_ai_task(task: AITask) -> dict[str, Any]:
    """Return a safe disabled response instead of importing missing AI modules."""
    if task.name not in ("segment", "denoise", "superres"):
        raise ValueError(f"Unknown AI task: {task.name}")
    result = _disabled_result(task.name)
    if task.name == "segment":
        result["mask2d"] = None
    else:
        result["image2d"] = task.image2d
    return result
