from __future__ import annotations
import json, logging, subprocess, sys
try:
    from PySide6.QtCore import QObject, Signal, QThread
except Exception:  # headless test environment
    class QObject:  # type: ignore
        def __init__(self, *a, **k): pass
    def Signal(*a, **k):  # type: ignore
        class _S:
            def emit(self, *a, **k): pass
        return _S()
    class QThread:  # type: ignore
        def __init__(self, *a, **k): pass
        def start(self): self.run()
        def run(self): pass
from .runtime_paths import new_session_dir

log = logging.getLogger(__name__)

class LoadResult:
    def __init__(self, ok: bool, data: dict | None = None, error: str = ""):
        self.ok = ok
        self.data = data or {}
        self.error = error

def _is_frozen_exe() -> bool:
    return bool(getattr(sys, "frozen", False))


def _parse_worker_json(stdout: str, stderr: str = "") -> dict:
    """Parse JSON from worker output robustly.

Workers should print one JSON object, but dependency warnings sometimes leak to
stdout.  Scan from the last line backwards and keep full stdout/stderr in debug
logs for diagnostics.
    """
    lines = [line.strip() for line in (stdout or "").splitlines() if line.strip()]
    for line in reversed(lines):
        try:
            data = json.loads(line)
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    log.debug("Worker stdout without parseable JSON:\n%s", stdout)
    if stderr:
        log.debug("Worker stderr:\n%s", stderr)
    return {"ok": False, "error": (stderr or "No parseable JSON from worker output"), "stdout_tail": lines[-5:]}

class LoadThread(QThread):
    """Loads a selected DICOM series in background.

    In source mode it can use a separate opener process.
    In PyInstaller/frozen EXE mode it MUST NOT call sys.executable -m ...
    because sys.executable is the GUI EXE and would spawn extra windows.
    Therefore frozen mode calls the loader directly inside this QThread.
    """
    done = Signal(object)
    def __init__(self, path: str, series_uid: str | None = None):
        super().__init__()
        self.path = path
        self.series_uid = series_uid

    def run(self):
        out_dir = new_session_dir()
        try:
            if _is_frozen_exe():
                from dicomview_pro.core.dicom_reader import load_series_to_runtime
                loaded = load_series_to_runtime(self.path, out_dir, self.series_uid)
                self.done.emit(LoadResult(True, {"ok": True, "volume": loaded.__dict__}))
                return

            cmd = [sys.executable, "-m", "dicomview_pro.runtime.opener", "load", self.path, str(out_dir)]
            if self.series_uid:
                cmd += ["--series-uid", self.series_uid]
            cp = subprocess.run(cmd, text=True, capture_output=True, timeout=240)
            data = _parse_worker_json(cp.stdout or "", cp.stderr or "")
            self.done.emit(LoadResult(bool(data.get("ok")), data, data.get("error", cp.stderr)))
        except Exception as exc:
            log.exception("Load worker failed")
            self.done.emit(LoadResult(False, {}, str(exc)))

class ScanThread(QThread):
    """Scans DICOM series in background.

    Frozen EXE mode uses direct call to avoid recursive GUI windows.
    """
    done = Signal(object)
    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self):
        try:
            if _is_frozen_exe():
                from dicomview_pro.core.dicom_reader import scan_series
                series = scan_series(self.path)
                self.done.emit(LoadResult(True, {"ok": True, "series": [s.__dict__ for s in series]}))
                return

            cmd = [sys.executable, "-m", "dicomview_pro.runtime.opener", "scan", self.path]
            cp = subprocess.run(cmd, text=True, capture_output=True, timeout=120)
            data = _parse_worker_json(cp.stdout or "", cp.stderr or "")
            self.done.emit(LoadResult(bool(data.get("ok")), data, data.get("error", cp.stderr)))
        except Exception as exc:
            log.exception("Scan worker failed")
            self.done.emit(LoadResult(False, {}, str(exc)))

class Controller(QObject):
    def __init__(self):
        super().__init__()
        self.current_session: str | None = None

    def cleanup_all(self):
        try:
            if _is_frozen_exe():
                from dicomview_pro.runtime.runtime_paths import cleanup_runtime_dir
                cleanup_runtime_dir()
                return
            subprocess.run([sys.executable, "-m", "dicomview_pro.runtime.closer", "cleanup"], timeout=30)
        except Exception:
            log.exception("Runtime cleanup failed")
