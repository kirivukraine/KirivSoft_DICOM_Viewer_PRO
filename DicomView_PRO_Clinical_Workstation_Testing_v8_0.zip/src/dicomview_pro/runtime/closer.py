from __future__ import annotations
import argparse, json, shutil
from pathlib import Path
from dicomview_pro.runtime.runtime_paths import cleanup_runtime_dir

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["cleanup", "remove"])
    ap.add_argument("path", nargs="?")
    args = ap.parse_args()
    if args.action == "cleanup":
        print(json.dumps({"ok": True, "removed": cleanup_runtime_dir()}), flush=True)
        return 0
    if args.path:
        shutil.rmtree(Path(args.path), ignore_errors=True)
    print(json.dumps({"ok": True}), flush=True)
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
