from __future__ import annotations
import logging, os, sys
from pathlib import Path

APP_DIR = (Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "KirivSoft" / "DicomViewPRO") if sys.platform.startswith("win") else Path.home() / ".dicomview_pro"
LOG_DIR = APP_DIR / "logs"
LOG_FILE = LOG_DIR / "dicomview_pro.log"

def setup_logging() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler(sys.stderr)],
        force=True,
    )
    logging.getLogger("pydicom").setLevel(logging.WARNING)
    return LOG_FILE

def log_path() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_FILE
