from __future__ import annotations
import sys
from pathlib import Path


def app_root() -> Path:
    """Return application root for source, one-folder EXE, and one-file PyInstaller."""
    if getattr(sys, "frozen", False):
        # One-file: sys._MEIPASS contains bundled data. One-folder: data can be beside exe too.
        mei = getattr(sys, "_MEIPASS", None)
        if mei:
            return Path(mei)
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def resource_path(*parts: str) -> Path:
    root = app_root()
    candidate = root.joinpath(*parts)
    if candidate.exists():
        return candidate
    # Source fallback when called from package file tree.
    source_root = Path(__file__).resolve().parents[2]
    return source_root.joinpath(*parts)


def icon_path() -> Path:
    # Prefer .ico for Windows window/taskbar icon; use .png for QLabel if ico missing.
    ico = resource_path("assets", "icon.ico")
    if ico.exists():
        return ico
    return resource_path("assets", "icon.png")


def icon_png_path() -> Path:
    png = resource_path("assets", "icon.png")
    if png.exists():
        return png
    return icon_path()
