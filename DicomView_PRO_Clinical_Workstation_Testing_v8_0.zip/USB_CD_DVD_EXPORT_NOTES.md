# DicomView PRO — USB / CD/DVD Export

Додано меню **Експорт / носій**.

## Зберегти поточну серію на USB флешку

Створює на вибраному носії папку з DICOM-файлами поточної серії:

```text
<USB>\DicomView_<Patient>_<Study>_<Series>\
 ├─ DICOM\
 ├─ KIRIVSOFT_DICOM_EXPORT_MANIFEST.json
 └─ README_КИРИВСОФТ_DICOM_EXPORT.txt
```

Manifest містить SHA-256 контрольні суми для перевірки цілісності.

## Підготувати папку для CD/DVD

Створює папку, яку можна записати як data-disc на CD/DVD, і додатково ZIP-копію для перенесення.

## Примітка

Це не DICOMDIR-диск повного стандарту, а практичний export/folder-layout для старих медичних робочих станцій. Надалі можна додати справжню генерацію DICOMDIR.
