@echo off
REM Lite/Core build entrypoint. Heavy AI runtime is external and optional.
call "%~dp0build_portable.bat"
