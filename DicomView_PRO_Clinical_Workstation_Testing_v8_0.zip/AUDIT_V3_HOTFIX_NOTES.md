# DicomView PRO — Audit v3 Hotfix

Виправлено за аудитом v3:

- Повернено `MainWindow.about()` для меню «Про програму».
- Повернено `MainWindow.toggle_fullscreen()` для F11 / Esc і пункту меню.
- `keyPressEvent()` лишається єдиним методом і обробляє F11/Esc/PageUp/PageDown/Up/Down.
- Імпортовано `cleanup_old_runtime_dirs` з `runtime_paths.py`, тому очищення старих runtime-сесій тепер реально виконується.
- Прибрано невикористаний `InvalidDicomError` з `dicom_reader.py`.
- Прибрано дублювання `QInputDialog` у глобальному імпорті; локальний імпорт для Orthanc залишено.

Перевірка:

- `python -m compileall -q src tests` — OK.
- `PYTHONPATH=src pytest -q` — 24 passed, 1 skipped.
- ZIP integrity — OK.
