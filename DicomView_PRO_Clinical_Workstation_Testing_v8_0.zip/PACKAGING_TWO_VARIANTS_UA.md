# DicomView PRO — два варіанти збірки

У проєкті підготовлено два основні варіанти розгортання.

## 1. Portable-збірка з папкою `_internal`

Запуск:

```bat
build_portable.bat
```

Результат:

```text
dist\DicomView_PRO\DicomView_PRO.exe
dist\DicomView_PRO\_internal\...
```

Це найстабільніший варіант для складних Python/VTK/DICOM-залежностей.
Його можна скопіювати на USB або інший комп’ютер цілою папкою.

## 2. Інсталятор у Program Files

Запуск:

```bat
build_installer.bat
```

Потрібен Inno Setup 6. Інсталятор встановлює програму в:

```text
C:\Program Files\KirivSoft\DicomView PRO
```

і створює ярлики в меню Пуск та, за вибором, на робочому столі.

## One-file EXE

One-file EXE залишено як додатковий варіант (`build_onefile_exe.bat`), але для VTK/PySide6/pylibjpeg він може стартувати повільніше і бути менш стабільним на старих ПК.
Для лікарняного використання рекомендовано інсталятор або portable-папку.
