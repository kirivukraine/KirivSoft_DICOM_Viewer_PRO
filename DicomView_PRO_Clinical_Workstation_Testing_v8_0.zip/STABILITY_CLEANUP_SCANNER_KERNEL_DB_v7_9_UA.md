# DicomView PRO v7.9 Stability Cleanup + Scanner Kernel DB

## Зроблено
- Знешкоджено мертві AI імпорти у `runtime/ai_worker.py`: модуль тепер безпечний disabled-stub.
- Переписано `runtime/module_manager.py`: optional модулі визначаються без імпорту відсутніх пакетів.
- Посилено `runtime/controller.py`: JSON від opener/worker шукається надійно, повний stdout/stderr логуються в DEBUG.
- Додано `core/dicom_validation.py`: базова перевірка PixelData, Rows/Columns, PixelSpacing, ImageOrientationPatient, TransferSyntax.
- Додано `core/scanner_kernel_db.py`: база Siemens/GE/Philips/Canon/Toshiba/Hitachi reconstruction kernels.
- Інтегровано scanner kernel profile у `scanner_profile_engine.py`: category, noise, sharpness, suggested display filter, 3D preset.
- UI автоматично застосовує vendor-aware 2D sharpen та 3D preset.
- Додано `requirements_decoders_optional.txt`; `pylibjpeg-libjpeg` винесено з default requirements як optional decoder через ліцензійний ризик.

## Що не чіпав у v7.9
- Великий рефакторинг `MainWindow` не виконаний перед v8.0, щоб не зламати робочу гілку перед тестуванням.
- Orthanc/PET/AI/нові великі модулі не додавались.

## Наступний крок
- v8.0 Clinical Workstation Edition: інтеграційна стабілізація Viewer Fidelity + Scanner Intelligence + Hemorrhage + Trauma + Comparative Viewer.
