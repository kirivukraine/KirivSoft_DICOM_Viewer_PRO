# DicomView PRO — PACS / Adaptive / Cine Export patch

Додано:

- PACS PRO вкладка:
  - C-ECHO;
  - C-FIND Studies;
  - C-STORE одного DICOM файла;
  - PACS audit log у `logs/pacs_audit.jsonl`.
- Cine PRO:
  - експорт cine/multi-frame серії у GIF;
  - експорт cine/multi-frame серії у MP4;
  - FPS береться з UI або DICOM metadata.
- Adaptive Engine 2.0:
  - режим `Auto Safe / старий ПК` лишається дефолтним для слабких ПК;
  - VTK не ініціалізується при старті, лише при ручному запуску 3D;
  - слабкі ПК можуть використовувати CPU-only MIP Preview.
- Build:
  - додано `pynetdicom`, `Pillow`, `imageio`, `imageio-ffmpeg`;
  - `build_exe.bat` включає PACS/Cine залежності для PyInstaller.

Примітка: PACS потребує реального PACS сервера та правильних AE Title/IP/Port. Якщо PACS недоступний, програма показує помилку й пише її в лог, але не повинна падати.
