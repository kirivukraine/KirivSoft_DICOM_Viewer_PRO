# DicomView PRO — Portable `_internal/models` AI Models Fix

У цій збірці шлях до ONNX-моделей зроблено максимально простим для користувача.

## Куди копіювати MobileSAM

Після збірки EXE через `build_portable.bat` або `build_exe.bat` покладіть модель сюди:

```text
dist\DicomView_PRO\_internal\models\segmentation\mobile_sam.onnx
```

У вже розпакованому portable-пакеті шлях такий самий:

```text
DicomView_PRO\_internal\models\segmentation\mobile_sam.onnx
```

## Що змінилось

- Додано автоматичне створення `_internal/models` з підпапками.
- AI Models Manager показує `portable_copy_target` і всі `search_roots`.
- MobileSAM, DnCNN, Real-ESRGAN і MONAI шукаються спочатку в `_internal/models`.
- Старий шлях `models/` лишено як fallback для сумісності.
- Якщо моделі немає, програма не падає, а показує зрозуміле повідомлення / fallback.

## Папки

```text
_internal/models/segmentation/mobile_sam.onnx
_internal/models/denoise/dncnn.onnx
_internal/models/superres/realesrgan_x2.onnx
_internal/models/monai/*.onnx
```
