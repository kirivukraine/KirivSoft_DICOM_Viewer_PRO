DicomView PRO AI Models
========================

Папки для локальних моделей:
- segmentation/mobile_sam.onnx або medsam.onnx
- denoise/dncnn.onnx або ffdnet.onnx
- superres/realesrgan_x2.onnx або realesrgan_x4.onnx
- monai/*.onnx для медичних органних моделей

Програма працює без цих файлів у safe fallback-режимі.
Для ONNX inference рекомендовано встановити: onnxruntime або onnxruntime-gpu.
Real-ESRGAN використовуйте тільки як preview/enhancement, не як діагностичну реконструкцію.

Real-ESRGAN external tool:
  _internal\tools\realesrgan\realesrgan-ncnn-vulkan.exe
  _internal\tools\realesrgan\models\*.bin / *.param
