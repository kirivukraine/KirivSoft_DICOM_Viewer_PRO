Put MobileSAM ONNX model here:

  models/segmentation/mobile_sam.onnx

Supported best: combined model with image + point_coords + point_labels inputs.
Decoder-only models that require image_embeddings need a separate encoder.onnx and are reported clearly by the app.
