# DicomView PRO Fidelity Edition — Adaptive CT Brain Rendering

Мета: прибрати надмірну зернистість у CT Brain Siemens/SOMATOM Hr64/high-resolution серіях без зміни DICOM-даних, HU, ROI та вимірювань.

## Зміни

- DICOM VOI windowing: `window_to_uint8()` використовує формулу DICOM VOI (`center - 0.5`, `width - 1`), а не просте low/high clip.
- За замовчуванням для 2D використовується `Cubic/Smooth (soft tissue)`, а не Lanczos.
- `Lanczos` залишений як режим `Lanczos (bone/detail)` для кісток, MIP, судин і деталей.
- Додано `Brain Soft W100 C35`.
- Для CT brain/head з ознаками жорсткого kernel (`Hr`, `Hr64`, `sharp`, `high`) дефолтне вікно: W100/C35.
- Додано display-only режими:
  - `Syngo soft brain (max)` — дефолтний м'який режим для шумних CT Brain;
  - `CT Brain fidelity (strong)`;
  - `Brain smooth (less noise)`;
  - `Off / raw diagnostic`.
- Denoise/sharpness застосовується тільки до фінальної 8-bit display-картинки, не до HU-даних.
- Fit-to-window лишається дефолтним режимом. Auto-crop/fit anatomy не нав'язується.

## Рекомендовані налаштування

Для CT Brain Hr64:
- Preset: `Brain Soft W100 C35`
- Interpolation: `Cubic/Smooth (soft tissue)`
- Display: `Fit-to-window`
- Sharpness: `Syngo soft brain (max)`

Для сирого контролю:
- Sharpness: `Off / raw diagnostic`

Для кістки:
- Preset: `Bone W2000 C500`
- Interpolation: `Lanczos (bone/detail)`
