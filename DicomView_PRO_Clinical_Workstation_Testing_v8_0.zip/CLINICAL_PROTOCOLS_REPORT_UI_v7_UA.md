# DicomView PRO v7 Clinical Protocols / Report UI

Зміни:

- Додано меню **Протоколи**:
  - Гемораж
  - Травма
  - Ішемія
  - Онко
  - Запалення
- Протокол **Гемораж** запускає CPU-only HU/morphology аналіз крововиливу через `classic_ct_diagnostics.py`.
- Автоматично виставляється Brain Window 40/80.
- У вкладку **Звіт** виводяться:
  - обʼєм крововиливу, мл;
  - voxel count;
  - кількість компонентів;
  - розміри Z/Y/X, мм;
  - максимальний діаметр;
  - axial max diameter;
  - bbox;
  - confidence;
  - JSON-поля для подальшого експорту.
- Окрема вкладка **Legacy 3D** прихована, щоб не дублювати 3D. Старий режим лишається у виборі **3D → Legacy Head/Face 3D (old)**.
- Верхній режим-бар спрощено: 2D / MPR / 3D / Звіт.
- Старий архів `DicomView_PRO(2).zip` — це скомпільована PyInstaller-збірка без відкритих `.py` файлів. Його можна використовувати як візуальний еталон, але точні transfer functions з нього без вихідного коду витягнути надійно не можна.

Перевірка:

- `python -m compileall -q src` — OK
- `PYTHONPATH=src pytest -q tests/test_classic_ct_diagnostics.py tests/test_classic_ct_measurements_v64.py tests/test_mpr_fidelity_engine_v2.py tests/test_core.py` — 13 passed, 1 skipped

Важливо:

Це клінічна підказка для лікаря, не автоматична постановка діагнозу.
