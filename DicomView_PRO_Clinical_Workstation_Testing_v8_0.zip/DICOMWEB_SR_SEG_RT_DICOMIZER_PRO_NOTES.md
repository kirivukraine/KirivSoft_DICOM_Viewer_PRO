# DicomView PRO — DICOMweb / SR / SEG / RT / Dicomizer PRO update

## Що додано

### 1. DICOMweb PRO foundation
- QIDO-RS пошук досліджень виконується у фоновому потоці, GUI не зависає.
- STOW-RS upload поточної серії виконується у фоновому потоці.
- WADO-RS raw series download зберігає multipart-відповідь у файл для подальшого аналізу/парсингу.

### 2. DICOM SR Viewer
- Додано перегляд DICOM Structured Report у текстовому дереві.
- Підтримує вкладені ContentSequence.
- Показує Patient/Study metadata.

### 3. DICOM SEG / RT summary
- Додано summary для DICOM SEG: номер сегмента, назва, опис, алгоритм.
- Додано summary для RTSTRUCT/RTDOSE: ROI та базова інформація дози.

### 4. Dicomizer PRO foundation
- JPG/PNG/TIFF/BMP → DICOM Secondary Capture.
- PDF → Encapsulated PDF DICOM.
- STL → Encapsulated STL DICOM.
- OBJ → Encapsulated OBJ DICOM.
- PLY/GLB/GLTF → compatibility M3D encapsulated object.

### 5. Audit v4 UX hotfix
- Прибрано невикористаний import `infos_to_dict`.
- Прибрано невикористаний `QSizePolicy`.
- Блокуючі Compatibility/DICOMweb операції винесені у QThread.
- Додано status message і WaitCursor під час довгих задач.

## Обмеження
- WADO-RS raw download поки зберігає multipart як є; повний multipart parser буде окремим модулем.
- SEG/RT overlay на зображення — наступний крок. Поточна версія показує summary.
- Dicomizer для PLY/GLB робить compatibility encapsulation, бо не всі DICOM viewer підтримують ці формати як стандартні M3D SOP.
