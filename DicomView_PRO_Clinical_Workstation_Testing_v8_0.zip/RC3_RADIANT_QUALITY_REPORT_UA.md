# DicomView PRO Lite RC3 — RadiAnt Quality

## База
Збірка створена на базі `DicomView_PRO_Lite_RC2_Core_Stability`.

## Головні зміни

### 1. MPR Fidelity Cache
- Додано `MPRFidelityCache` у `core/mpr_fidelity_engine.py`.
- Coronal/Sagittal/Axial MPR-зрізи кешуються в RAM.
- Розмір кешу адаптується під `cache_budget_mb`, який був доданий у RC2.
- При завантаженні нової серії кеш скидається.

### 2. Якість Coronal/Sagittal
- Залишено cubic interpolation через `scipy.ndimage.zoom`.
- Coronal/Sagittal будуються через display-resampling з урахуванням spacing.
- Для reconstructed planes примусово використовується посилена display-фільтрація `brain_fidelity_ultra`.

### 3. Правильні вимірювання в 2D/MPR
- `_slice_for_plane()` тепер використовує той самий MPR Fidelity pipeline, що й візуалізація.
- Pixel spacing для Coronal/Sagittal береться з `MPRSlice.pixel_spacing` після resampling.
- ROI/HU/2D-лінійка менше ризикують працювати на іншому зрізі, ніж той, що бачить користувач.

### 4. Прокрутка та масштаб
- Поточна логіка збережена: Wheel = Zoom, Shift+Wheel = Slice.
- Slider кожної площини рухає саме її анатомічну вісь: Axial=Z, Coronal=Y, Sagittal=X.

## Що НЕ додавалось у цій збірці
- AI/TotalSegmentator/nnU-Net.
- Slicer/VMTK/Radiomics.
- Нові 3D-пресети та клінічні HU-маски — це наступні збірки RC4/RC5.

## Перевірка
- Python compileall: OK.
- ZIP integrity: OK.
