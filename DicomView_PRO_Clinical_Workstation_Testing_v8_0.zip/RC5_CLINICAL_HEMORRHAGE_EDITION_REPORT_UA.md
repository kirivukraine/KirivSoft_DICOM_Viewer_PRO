# DicomView PRO Lite RC5 Clinical Hemorrhage Edition — звіт

## База
- Взято за основу: RC4 Dual 3D Engine.
- Збережено RC2 Fast Folder Scanner, RC3 MPR Fidelity, RC4 Dual 3D Engine.

## Додано / змінено

### 1. Legacy 3D окремою вкладкою
- Додано вкладку **Legacy 3D**.
- Legacy 3D ізольовано від Modern 3D, 3D Knife, Artifact Cleaner, масок і лінійки.
- Додано окремий метод `set_legacy_headface_volume()` у VTK viewer.
- Мета: максимально наблизити вигляд до старих вдалих збірок: обличчя, вуха, шкіра, контури голови, м’які тканини.

### 2. Modern 3D залишено окремо
- Вкладка **3D** зберігає Advanced-функції:
  - 3D Knife / Clip Box;
  - 3D Ruler;
  - Artifact Cleaner;
  - Brain Hemorrhage preset;
  - Air preset;
  - MIP / Slab.

### 3. Ctrl+Alt Lock Camera для 3D-лінійки
- Повернуто стару логіку **Ctrl+Alt** для фіксації камери.
- Поки активна 3D-лінійка і затиснуті Ctrl+Alt:
  - zoom блокується;
  - pan блокується;
  - rotation блокується;
  - точки P1/P2 ставляться стабільніше.
- Залишено fallback на Ctrl, якщо Alt перехоплюється системою/драйвером.

### 4. Видимий результат 3D-лінійки
- Додано overlay-панель **3D Measurement** у VTK viewer.
- Додано 2D-текст поверх 3D сцени біля лінії, щоб відстань не ховалася за черепом.
- Показуються:
  - P1;
  - P2;
  - Distance в мм.

### 5. Hemorrhage3D PRO
- Інтегровано модуль `kirivsoft_hemorrhage` як легкий plugin без TotalSegmentator/torch/nnUNet.
- Додано вкладку Clinical → Hemorrhage 3D PRO:
  - HU min/max;
  - Auto Hemorrhage Detection;
  - Ghost Skull / Brain Hemorrhage 3D;
  - Export hemorrhage STL/PLY/OBJ.
- Функції:
  - HU-маска крововиливу 45–95 HU за замовчуванням;
  - об’єм гематоми в мл;
  - rough midline shift в мм;
  - confidence;
  - bbox;
  - червоний 3D overlay mesh.

## Важливо
Hemorrhage3D PRO — це візуальна HU-маска для допомоги перегляду, не автоматичний діагноз і не сертифікований медичний алгоритм.

## Перевірка
- `python -m compileall` по `src` — OK.
- Core subset tests: 17 passed, 1 skipped.
- Hemorrhage module tests: 3 passed.
- Plugin import/runtime smoke test — OK.
- ZIP integrity — OK.
