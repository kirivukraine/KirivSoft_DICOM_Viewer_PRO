@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: run_clinic_test_harness.bat PATH_TO_DICOM_FOLDER_OR_DATA_ZIP
  echo Example: run_clinic_test_harness.bat C:\DICOM\Data.zip
  pause
  exit /b 1
)
if not exist diagnostics mkdir diagnostics
if exist .venv\Scripts\python.exe (
  set PY=.venv\Scripts\python.exe
) else (
  set PY=python
)
set PYTHONPATH=%cd%\src
%PY% scripts\clinic_test_harness.py --input "%~1" --output diagnostics\clinic_test_report.json
pause
