@echo off
REM Compatibility wrapper. Main Lite build script is build_portable.bat.
call "%~dp0build_portable.bat"
