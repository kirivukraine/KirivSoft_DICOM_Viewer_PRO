DicomView PRO Lite — фінальна пробна Lite-гілка
Автор: Іван Кіранчук / KirivSoft

Мета Lite:
- швидкий запуск;
- стабільне ядро перегляду DICOM;
- без обов'язкових AI/Slicer/TotalSegmentator/nnU-Net залежностей;
- робота як базовий RadiAnt-подібний viewer + базовий 3D.

У Lite залишено:
1) 2D:
   - Axial / Coronal / Sagittal;
   - Cine;
   - Window/Level;
   - zoom / pan;
   - 2D лінійка;
   - Cubic/Smooth профіль якості.

2) MPR:
   - Axial / Coronal / Sagittal;
   - Shared Crosshair;
   - покращений MPR pipeline: cubic interpolation, reslice-логіка, spacing-aware перегляд.

3) 3D:
   - VTK Volume Rendering;
   - Surface Rendering;
   - Clip Box / 3D ніж;
   - Artifact Mask Cleaner;
   - 3D Ruler;
   - наявні 3D presets без зміни базової поведінки.

4) Експорт:
   - PNG;
   - STL / OBJ / PLY;
   - PDF/DOCX report.

Вимкнено у Lite:
- Organ AI / TotalSegmentator;
- nnU-Net;
- Slicer/VMTK;
- Radiomics;
- AI вкладка;
- важкі optional runtimes.

Плагінна архітектура:
- важкі модулі винесені в plugins/ як опційні;
- Lite запускається навіть якщо plugins/AI, plugins/SlicerBridge, plugins/Radiomics, plugins/VMTK, plugins/TotalSegmentator відсутні.

Збірка:
1. Запустіть build_portable.bat
2. Готовий EXE буде в dist\DicomView_PRO_Lite\DicomView_PRO_Lite.exe
3. Лог збірки: build_logs\build_lite.log

Важливо:
- Не запускайте EXE з build\. Запускати тільки з dist\.
- Якщо потрібен AI, використовуйте Enterprise-гілку або зовнішній plugin runtime.
