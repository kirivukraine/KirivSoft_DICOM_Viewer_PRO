from dicomview_pro.rendering.cinematic_fidelity import (
    is_cinematic_preset,
    preset_key,
    get_cinematic_preset,
)


def test_ui_preset_aliases_are_resolved():
    assert preset_key("Classic Hospital") == "classic_hospital"
    assert preset_key("Classic Lung") == "classic_lung"
    assert preset_key("Brain Hemorrhage") == "hemorrhage_focus"
    assert preset_key("Fracture Ultra") == "trauma_cinematic"


def test_cinematic_presets_exist_for_core_workflows():
    for name in ["Classic Hospital", "Classic Lung", "Classic Bone", "Classic Soft Tissue", "Brain Hemorrhage", "Trauma"]:
        assert is_cinematic_preset(name)
        p = get_cinematic_preset(name)
        assert p.color
        assert p.opacity
        assert p.gradient
        assert p.opacity_unit_distance > 0
        assert p.sample_factor > 0
