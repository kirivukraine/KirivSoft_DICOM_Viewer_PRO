from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_rc4_presets_and_dual_3d_ui_present():
    mw = (ROOT / 'src' / 'dicomview_pro' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
    vv = (ROOT / 'src' / 'dicomview_pro' / 'ui' / 'vtk_viewer.py').read_text(encoding='utf-8')
    assert 'Legacy Head/Face 3D (old)' in mw
    assert 'Modern VTK Volume Rendering' in mw
    assert 'Classic Anatomy' in mw
    assert 'Brain Hemorrhage' in mw
    assert 'Air' in mw
    assert 'hemorrhage' in vv.lower()
    assert 'classic' in vv.lower()


def test_rc4_ctrl_freeze_uses_qt_and_vtk_style_user():
    vv = (ROOT / 'src' / 'dicomview_pro' / 'ui' / 'vtk_viewer.py').read_text(encoding='utf-8')
    assert 'vtkInteractorStyleUser' in vv
    assert 'QApplication.keyboardModifiers' in vv
    assert 'installEventFilter' in vv
    assert 'Ctrl LOCK' in vv or 'Ctrl' in vv
