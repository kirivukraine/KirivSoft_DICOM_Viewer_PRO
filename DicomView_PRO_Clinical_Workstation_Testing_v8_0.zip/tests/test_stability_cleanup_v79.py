from dicomview_pro.runtime.ai_worker import AITask, run_ai_task
from dicomview_pro.runtime.module_manager import list_optional_modules
from dicomview_pro.runtime.controller import _parse_worker_json
from dicomview_pro.core.scanner_kernel_db import get_kernel_profile
from dicomview_pro.core.scanner_profile_engine import analyze_scanner_profile
import numpy as np


def test_ai_worker_import_is_safe_stub():
    r = run_ai_task(AITask("denoise", np.zeros((2, 2), dtype=np.float32), {}))
    assert r["ok"] is False
    assert "image2d" in r


def test_module_manager_import_is_safe():
    mods = list_optional_modules()
    assert any(m.key == "totalsegmentator" for m in mods)


def test_controller_json_parser_skips_logs():
    data = _parse_worker_json("warning line\n{\"ok\": true, \"value\": 3}\ntrailing log", "")
    assert data["ok"] is True
    assert data["value"] == 3


def test_scanner_kernel_db_vendor_match():
    p = get_kernel_profile("Siemens Healthineers", "B70f", "SOMATOM")
    assert p.vendor == "SIEMENS"
    assert p.category in ("sharp", "ultra_sharp")


def test_scanner_profile_uses_kernel_db():
    prof = analyze_scanner_profile({
        "Manufacturer": "GE MEDICAL SYSTEMS",
        "ManufacturerModelName": "Revolution",
        "ConvolutionKernel": "LUNG",
        "SeriesDescription": "CHEST",
        "spacing": [0.625, 0.625, 0.625],
    }, (300, 512, 512))
    assert prof.vendor_kernel_category == "sharp"
    assert "Lung" in prof.recommended_3d_preset
