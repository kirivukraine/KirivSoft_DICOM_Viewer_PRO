import numpy as np
from dicomview_pro.core.volume_cleaner import auto_clean_volume_for_3d


def test_auto_clean_keeps_largest_bone_component():
    vol = np.full((20, 30, 30), -1000, dtype=np.float32)
    vol[5:15, 8:22, 8:22] = 500  # skull/main object
    vol[2:5, 2:5, 2:5] = 700      # small plate/noise
    res = auto_clean_volume_for_3d(vol, threshold_hu=200, mode="bone_largest")
    assert res.ok
    assert res.cleaned_volume.shape == vol.shape
    assert res.mask[10, 10, 10] == 1
    assert res.cleaned_volume[3, 3, 3] <= -900
    assert res.removed_voxels > 0


def test_auto_clean_no_threshold_voxels_is_safe():
    vol = np.full((5, 5, 5), -1000, dtype=np.float32)
    res = auto_clean_volume_for_3d(vol, threshold_hu=200)
    assert not res.ok
    assert res.cleaned_volume.shape == vol.shape


def test_auto_clean_numpy_fallback_removes_small_component(monkeypatch):
    monkeypatch.setenv("DICOMVIEW_VOLUME_CLEANER_NO_SCIPY", "1")
    vol = np.full((20, 30, 30), -1000, dtype=np.float32)
    vol[5:15, 8:22, 8:22] = 500
    vol[2:5, 2:5, 2:5] = 700
    res = auto_clean_volume_for_3d(vol, threshold_hu=200, mode="bone_largest")
    assert res.ok
    assert res.cleaned_volume[10, 10, 10] == 500
    assert res.cleaned_volume[3, 3, 3] <= -900
    assert res.removed_voxels > 0
