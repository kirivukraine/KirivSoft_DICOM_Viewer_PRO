import numpy as np

from dicomview_pro.core.mpr_fidelity_engine import extract_mpr_slice, display_crosshair_for_mpr


def test_coronal_and_sagittal_are_anisotropy_resampled():
    vol = np.arange(8 * 4 * 6, dtype=np.float32).reshape(8, 4, 6)
    spacing = (2.0, 0.5, 0.5)
    cor = extract_mpr_slice(vol, "coronal", 2, spacing)
    sag = extract_mpr_slice(vol, "sagittal", 3, spacing)
    assert cor.image.shape[0] > vol.shape[0]
    assert sag.image.shape[0] > vol.shape[0]
    assert cor.pixel_spacing == (0.5, 0.5)
    assert sag.pixel_spacing == (0.5, 0.5)
    assert cor.resample_factor >= 3.9
    assert sag.resample_factor >= 3.9


def test_axial_is_not_resampled_and_crosshair_maps():
    vol = np.zeros((10, 20, 30), dtype=np.float32)
    ax = extract_mpr_slice(vol, "axial", 5, (1.0, 0.7, 0.8))
    assert ax.image.shape == (20, 30)
    assert ax.pixel_spacing == (0.7, 0.8)
    assert display_crosshair_for_mpr("axial", 5, 6, 7, vol.shape) == (7, 6)
    assert display_crosshair_for_mpr("coronal", 5, 6, 7, vol.shape, 2.0) == (7, 8)
