from dicomview_pro.core.clinical_workstation_v80 import (
    VERSION,
    clinical_workstation_manifest,
    clinical_workstation_text,
)


def test_v80_manifest_contains_core_testing_subsystems():
    manifest = clinical_workstation_manifest()
    assert manifest["version"] == "8.0"
    keys = {item["key"] for item in manifest["subsystems"]}
    assert "viewer_fidelity" in keys
    assert "scanner_intelligence" in keys
    assert "scanner_kernel_db" in keys
    assert "hemorrhage_protocol" in keys
    assert "trauma_protocol" in keys
    assert "comparative_viewer" in keys
    assert "dicom_validation" in keys


def test_v80_summary_is_human_readable():
    text = clinical_workstation_text()
    assert VERSION in text
    assert "Clinical Workstation" in text
    assert "Not a certified medical device" in text
