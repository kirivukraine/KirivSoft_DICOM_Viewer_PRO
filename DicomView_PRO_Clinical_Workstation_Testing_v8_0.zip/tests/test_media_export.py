from pathlib import Path
from dicomview_pro.core.media_export import export_series_to_folder, create_cd_dvd_ready_folder


def test_export_series_to_folder(tmp_path):
    f1 = tmp_path / "a.dcm"
    f2 = tmp_path / "b.dcm"
    f1.write_bytes(b"DICOM-A")
    f2.write_bytes(b"DICOM-B")
    out = tmp_path / "usb"
    res = export_series_to_folder([str(f1), str(f2)], out, label="test")
    assert res.ok
    assert res.files_written == 2
    assert (out / "DICOM" / "a.dcm").exists()
    assert Path(res.manifest_path).exists()


def test_cd_dvd_ready_folder(tmp_path):
    f = tmp_path / "one.dcm"
    f.write_bytes(b"DICOM")
    res = create_cd_dvd_ready_folder([str(f)], tmp_path / "export", study_label="study")
    assert res.ok
    assert Path(res.zip_path).exists()
