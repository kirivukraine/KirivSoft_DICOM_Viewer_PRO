import numpy as np

from dicomview_pro.core.radiomics_pro import analyze_roi_or_mask
from dicomview_pro.core.reporting_pro import create_report_bundle
from dicomview_pro.core.orthanc_explorer_pro import OrthancExplorerPRO


def test_radiomics_pro_safe_basic():
    v=np.arange(27, dtype=np.float32).reshape(3,3,3)
    m=v>10
    r=analyze_roi_or_mask(v, m, spacing=(1,1,2))
    assert r.ok
    assert r.features['count'] == int(m.sum())
    assert 'histogram_entropy' in r.features
    assert r.engine == 'numpy_safe'


def test_reporting_bundle_fallback_or_pdf(tmp_path):
    r=create_report_bundle(tmp_path, {'patient_name':'Test','modality':'CT'}, ['ROI mean HU: 42'], [])
    assert r.ok
    assert any(str(x).endswith('.json') for x in r.files)


def test_orthanc_explorer_constructs_without_server():
    ex=OrthancExplorerPRO()
    assert ex.cfg.url.startswith('http')
