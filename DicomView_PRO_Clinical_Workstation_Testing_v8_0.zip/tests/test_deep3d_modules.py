from __future__ import annotations

import numpy as np

from dicomview_pro.rendering.shared_crosshair_state import SharedCrosshairState
from dicomview_pro.rendering.slab_controller import SlabController
from dicomview_pro.rendering.hardware_profile import HardwareProfile


def test_shared_crosshair_state_roundtrip():
    st = SharedCrosshairState()
    st.configure_volume((10, 20, 30), spacing_xyz=(0.5, 0.6, 2.0), origin_xyz=(1.0, 2.0, 3.0), notify=False)
    st.set_from_voxel_zyx((4, 5, 6), notify=False)
    assert st.patient_position_xyz == (1.0 + 6 * 0.5, 2.0 + 5 * 0.6, 3.0 + 4 * 2.0)
    st.set_from_patient_xyz(st.patient_position_xyz, notify=False)
    assert st.voxel_index_zyx == (4, 5, 6)


def test_slab_controller_numpy_mip_minip_average():
    vol = np.arange(5 * 4 * 3, dtype=np.int16).reshape(5, 4, 3)
    st = SharedCrosshairState()
    st.configure_volume(vol.shape, spacing_xyz=(1.0, 1.0, 1.0), initial_zyx=(2, 2, 1), notify=False)
    slab = SlabController(shared_state=st, numpy_volume_zyx=vol)
    slab.set_thickness_mm(3.0)
    slab.set_mode("MIP")
    assert np.array_equal(slab.reslice_numpy("axial"), np.max(vol[0:5, :, :], axis=0))
    slab.set_mode("MinIP")
    assert np.array_equal(slab.reslice_numpy("coronal"), np.min(vol[:, 0:4, :], axis=1))
    slab.set_mode("Average")
    out = slab.reslice_numpy("sagittal")
    assert out.shape == (5, 4)


def test_hardware_profile_forced_safe(monkeypatch):
    monkeypatch.setenv("DICOMVIEW_RENDER_MODE", "SAFE")
    hp = HardwareProfile(); hp.detect()
    assert hp.choose_render_mode((512, 512, 100)) == "SAFE"
