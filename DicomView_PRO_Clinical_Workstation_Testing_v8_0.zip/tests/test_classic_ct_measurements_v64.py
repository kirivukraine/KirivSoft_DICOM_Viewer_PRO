import numpy as np
from dicomview_pro.core.classic_ct_diagnostics import Hemorrhage3DClassicAnalyzer, ClassicHemorrhageConfig


def test_classic_hemorrhage_measurements_bbox_and_summary():
    vol = np.zeros((20, 80, 80), dtype=np.float32) - 1000
    vol[:, 10:70, 10:70] = 35
    vol[8:12, 30:45, 35:55] = 70
    spacing = (2.5, 0.5, 0.5)
    analyzer = Hemorrhage3DClassicAnalyzer(ClassicHemorrhageConfig(min_component_ml=0.01, use_intracranial_mask=False))
    res = analyzer.detect_volume(vol, spacing)
    d = res.to_json_dict()
    assert res.volume_ml > 0
    assert d["diameters_mm_zyx"] is not None
    assert d["max_dimension_mm"] > 0
    assert res.components[0]["axial_max_diameter_mm"] > 0
    assert "Крововилив" in Hemorrhage3DClassicAnalyzer.measurement_summary(res)
