from __future__ import annotations
import numpy as np
from dicomview_pro.core.image_ops import auto_window, window_to_uint8, get_slice, projection
from dicomview_pro.core.measurements import distance_mm, angle_degrees, roi_stats_hu
from dicomview_pro.core.segmentation import segment_bones, segment_lungs, segment_vessels, mask_projection


def test_window_and_slices():
    vol = np.arange(3*4*5, dtype=np.float32).reshape(3,4,5)
    c,w = auto_window(vol)
    assert w > 0
    assert window_to_uint8(get_slice(vol, 'axial', 1), c, w).shape == (4,5)
    assert get_slice(vol, 'coronal', 2).shape == (3,5)
    assert get_slice(vol, 'sagittal', 3).shape == (3,4)


def test_projection_axes():
    vol = np.arange(3*4*5, dtype=np.float32).reshape(3,4,5)
    assert projection(vol, 'MIP', axis=0).shape == (4,5)
    assert projection(vol, 'MinIP', axis=1).shape == (3,5)
    assert projection(vol, 'AvgIP', axis=2).shape == (3,4)


def test_measurements():
    d = distance_mm((0,0), (3,4), (1.0, 1.0))
    assert round(d.millimeters, 2) == 5.00
    a = angle_degrees((1,0), (0,0), (0,1))
    assert round(a.degrees) == 90
    arr = np.arange(100, dtype=np.float32).reshape(10,10)
    r = roi_stats_hu(arr, (0,0), (9,9), (1.0, 1.0))
    assert r.count == 100 and r.max_hu == 99


def test_segmentation():
    vol = np.zeros((4,4,4), dtype=np.float32)
    vol[0] = 400
    vol[1] = -700
    vol[2] = 220
    spacing = (1.0, 1.0, 1.0)
    assert segment_bones(vol, spacing, 300).voxel_count == 16
    assert segment_lungs(vol, spacing).voxel_count == 16
    assert segment_vessels(vol, spacing, 180).voxel_count == 32
    assert mask_projection(segment_bones(vol, spacing).mask).shape == (4,4)


def test_scan_series_reports_cine_metadata(tmp_path):
    import pytest
    pydicom = pytest.importorskip("pydicom")
    import numpy as np
    from pydicom.dataset import FileDataset, FileMetaDataset
    from pydicom.uid import ExplicitVRLittleEndian, generate_uid
    from dicomview_pro.core.dicom_reader import scan_series, load_series_to_runtime
    file_meta = FileMetaDataset(); file_meta.TransferSyntaxUID = ExplicitVRLittleEndian; file_meta.MediaStorageSOPClassUID = generate_uid(); file_meta.MediaStorageSOPInstanceUID = generate_uid()
    path = tmp_path / "cine.dcm"
    ds = FileDataset(str(path), {}, file_meta=file_meta, preamble=b"\0"*128)
    ds.SOPClassUID = file_meta.MediaStorageSOPClassUID; ds.SOPInstanceUID = file_meta.MediaStorageSOPInstanceUID
    ds.Modality = "XA"; ds.SeriesInstanceUID = "1.2.3.cine"; ds.SeriesDescription = "Angio cine"; ds.PatientName = "Test"
    ds.Rows = 8; ds.Columns = 8; ds.NumberOfFrames = 3; ds.SamplesPerPixel = 1; ds.PhotometricInterpretation = "MONOCHROME2"
    ds.BitsAllocated = 16; ds.BitsStored = 16; ds.HighBit = 15; ds.PixelRepresentation = 0; ds.CineRate = 12
    arr = (np.arange(3*8*8, dtype=np.uint16).reshape(3,8,8))
    ds.PixelData = arr.tobytes(); ds.save_as(str(path))
    series = scan_series(tmp_path)
    assert series and series[0].is_cine and series[0].frames == 3
    loaded = load_series_to_runtime(tmp_path, tmp_path / "runtime", series[0].uid)
    assert loaded.shape == (3, 8, 8)

def test_roi_pro_shapes():
    from dicomview_pro.core.measurements import circle_roi_stats_hu, polygon_roi_stats_hu
    arr = np.arange(100, dtype=np.float32).reshape(10,10)
    c = circle_roi_stats_hu(arr, (5,5), (8,8), (1.0, 1.0))
    assert c.count > 0 and c.area_mm2 > 0
    p = polygon_roi_stats_hu(arr, [(1,1),(8,1),(8,8),(1,8)], (1.0, 1.0))
    assert p.count > 0 and p.mean_hu > 0

def test_reporting_and_radiomics_basic(tmp_path):
    import numpy as np
    from dicomview_pro.core.reporting import create_pdf_report, create_docx_report
    from dicomview_pro.core.radiomics_base import basic_radiomics
    meta = {"patient_name":"Test", "modality":"CT", "shape":[2,3,4], "spacing":[1,1,2]}
    pdf = create_pdf_report(tmp_path / "report.pdf", meta, ["Mean HU: 42"])
    assert (tmp_path / "report.pdf").exists() or (tmp_path / "report.txt").exists()
    docx = create_docx_report(tmp_path / "report.docx", meta, ["Mean HU: 42"])
    assert (tmp_path / "report.docx").exists() or (tmp_path / "report.txt").exists()
    vol = np.arange(24, dtype=np.float32).reshape(2,3,4)
    mask = vol > 10
    r = basic_radiomics(vol, mask, (1,1,2))
    assert r.available and r.features["count"] == int(mask.sum())


def test_orthanc_client_config_only():
    from dicomview_pro.core.orthanc_client import OrthancConfig, OrthancClient
    c = OrthancClient(OrthancConfig(url="http://localhost:8042"))
    assert c.base == "http://localhost:8042"
