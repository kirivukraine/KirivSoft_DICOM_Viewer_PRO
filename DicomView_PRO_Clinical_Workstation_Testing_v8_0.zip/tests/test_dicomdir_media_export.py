from pathlib import Path
from dicomview_pro.core.media_export import create_dicomdir_ready_folder


def test_dicomdir_ready_folder_fallback(tmp_path):
    f1 = tmp_path / "img0001.dcm"
    f2 = tmp_path / "img0002.dcm"
    f1.write_bytes(b"DICOM-A")
    f2.write_bytes(b"DICOM-B")
    res = create_dicomdir_ready_folder([str(f1), str(f2)], tmp_path / "out", study_label="case", make_zip=True)
    assert res.ok
    target = Path(res.target)
    assert (target / "DICOM").exists()
    assert (target / "KIRIVSOFT_DICOM_INDEX.json").exists()
    assert (target / "START_DicomView_PRO.bat").exists()
    assert (target / "autorun.inf").exists()
    assert Path(res.zip_path).exists()
