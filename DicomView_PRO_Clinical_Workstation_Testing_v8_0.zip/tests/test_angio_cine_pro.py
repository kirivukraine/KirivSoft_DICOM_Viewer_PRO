import numpy as np
from dicomview_pro.core.angio_cine_pro import detect_angio_cine_profile, dsa_frame, temporal_projection, export_png_sequence


def test_detect_xa_profile_defaults():
    meta = {"modality":"XA", "cine_frames":42, "cine_fps":12.5}
    p = detect_angio_cine_profile(meta, (42, 512, 512))
    assert p.is_xa_xrf
    assert p.is_multiframe
    assert p.frames == 42
    assert p.recommended_window_width >= 1


def test_dsa_frame_and_projection():
    vol = np.zeros((3, 4, 4), dtype=np.float32)
    vol[1] = 10
    vol[2] = 20
    assert np.allclose(dsa_frame(vol, 1, 0), 10)
    assert temporal_projection(vol, "max").shape == (4, 4)


def test_png_sequence_export(tmp_path):
    vol = np.arange(2*5*5, dtype=np.float32).reshape(2,5,5)
    res = export_png_sequence(vol, tmp_path, center=25, width=50, fps=10)
    assert res["frames"] == 2
    assert (tmp_path/"cine_png_sequence_manifest.json").exists()
