import pytest

pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication
from dicomview_pro.ui.image_label import ImageLabel


def test_image_label_clear_series_state():
    app = QApplication.instance() or QApplication([])
    lab = ImageLabel()
    lab.zoom_factor = 3.0
    lab.pan_x = 42
    lab.pan_y = -9
    lab.set_locked_crop_bbox((1, 2, 10, 20))
    lab.points.append((5, 5))
    lab.crosshair = (7, 8)
    lab.clear_series_state()
    assert lab.zoom_factor == 1.0
    assert lab.pan_x == 0
    assert lab.pan_y == 0
    assert lab._locked_crop_bbox is None
    assert lab._crop_bbox is None
    assert lab._pix is None
    assert lab.points == []
    assert lab.crosshair is None
