from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pytest

PySide6 = pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication

from dicomview_pro.ui.image_label import ImageLabel
from dicomview_pro.core.image_ops import window_to_uint8, diagnostic_content_bbox


def _app():
    app = QApplication.instance()
    return app or QApplication([])


def test_locked_crop_bbox_keeps_display_size_between_frames():
    _app()
    base = np.zeros((128, 128), dtype=np.float32)
    base[30:95, 35:100] = 40
    bbox = diagnostic_content_bbox(window_to_uint8(base, 35, 80))
    assert bbox is not None

    frame2 = np.zeros((128, 128), dtype=np.float32)
    frame2[24:100, 29:108] = 40  # different anatomy extent: would jump without lock

    lab = ImageLabel()
    lab.resize(512, 512)
    lab.set_fit_mode("fit_content")
    lab.set_locked_crop_bbox(bbox)
    lab.set_image(window_to_uint8(base, 35, 80), base)
    size1 = lab._last_scaled_size
    crop1 = lab._crop_bbox
    lab.set_image(window_to_uint8(frame2, 35, 80), frame2)
    size2 = lab._last_scaled_size
    crop2 = lab._crop_bbox
    assert crop1 == crop2 == bbox
    assert size1 == size2
