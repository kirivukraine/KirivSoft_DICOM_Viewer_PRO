from __future__ import annotations

import numpy as np

from dicomview_pro.core.image_ops import window_to_uint8, auto_window


def test_sharpen_default_off_does_not_amplify_flat_noise():
    arr = np.full((16, 16), 35.0, dtype=np.float32)
    out = window_to_uint8(arr, 35, 80)
    assert out.dtype == np.uint8
    assert int(out.max()) == int(out.min())


def test_current_slice_window_helper_values():
    vol = np.zeros((3, 8, 8), dtype=np.float32)
    vol[0] = 0
    vol[1] = np.linspace(0, 100, 64, dtype=np.float32).reshape(8, 8)
    c, w = auto_window(vol[1], 2, 98)
    assert w > 80
    assert 40 <= c <= 60
