import numpy as np

from dicomview_pro.core.trauma_protocol import TraumaProtocolAnalyzer
from dicomview_pro.core.clinical_protocol_engine import ClinicalProtocolEngine, protocol_pretty_text


def synthetic_trauma_volume():
    v = np.full((20, 64, 64), -950.0, dtype=np.float32)
    # soft tissue background
    v[:, 10:54, 10:54] = 40.0
    # bone shell/cube
    v[5:15, 20:44, 20:44] = 360.0
    v[7:13, 26:38, 26:38] = 70.0
    # dense fragment candidate
    v[8:12, 44:50, 30:38] = 900.0
    # air candidate pocket
    v[8:12, 14:18, 14:18] = -850.0
    # hematoma-like soft candidate
    v[11:14, 30:36, 43:50] = 75.0
    return v


def test_trauma_analyzer_detects_classes():
    spacing = (1.0, 0.7, 0.7)
    res = TraumaProtocolAnalyzer().analyze(synthetic_trauma_volume(), spacing)
    assert res.voxel_count > 0
    assert res.volume_ml > 0
    assert res.component_count >= 1
    assert res.class_metrics["bone_voxels"] > 0
    assert res.class_metrics["dense_fragment_voxels"] > 0
    assert res.class_metrics["air_voxels"] > 0
    assert res.bbox_mm is not None
    assert max(res.bbox_mm) > 0


def test_clinical_engine_trauma_protocol_report():
    spacing = (1.0, 0.7, 0.7)
    result = ClinicalProtocolEngine().run("trauma", synthetic_trauma_volume(), spacing)
    assert result.protocol.key == "trauma"
    assert result.volume_ml > 0
    assert result.debug["class_metrics"]["bone_voxels"] > 0
    text = protocol_pretty_text(result)
    assert "Протокол: Травма" in text
    assert "JSON" in text
