from pathlib import Path

from dicomview_pro.rendering.cinematic_fidelity import (
    get_cinematic_preset,
    is_cinematic_preset,
    preset_key,
)


def test_lung_fidelity_alias_is_cinematic():
    assert is_cinematic_preset("Classic Lung Fidelity")
    assert preset_key("lung") == "classic_lung_fidelity"
    preset = get_cinematic_preset("lung")
    assert preset.name == "Classic Lung Fidelity"
    assert preset.sample_factor <= 0.60


def test_classic_hospital_lighting_is_fidelity_tuned():
    preset = get_cinematic_preset("classic_hospital")
    assert preset.ambient <= 0.20
    assert preset.diffuse >= 0.90
    assert preset.specular >= 0.25
    assert preset.specular_power >= 28


def test_vtk_viewer_contains_real_pipeline_adaptive_sampling_patch():
    src = Path(__file__).resolve().parents[1] / "src" / "dicomview_pro" / "ui" / "vtk_viewer.py"
    text = src.read_text(encoding="utf-8")
    assert "vtkSmartVolumeMapper" in text
    assert "_attach_adaptive_render_quality" in text
    assert "StartInteractionEvent" in text
    assert "EndInteractionEvent" in text
    assert "SetUseJittering" in text
    assert "RemoveObserver" in text
