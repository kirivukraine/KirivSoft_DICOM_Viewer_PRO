from dicomview_pro.core.clinical_foundation import clinical_foundation_status, clinical_foundation_report, clinical_foundation_json


def test_clinical_foundation_core_always_ready():
    statuses = clinical_foundation_status('test hardware')
    names = {s.module: s for s in statuses}
    assert names['Core DICOM Viewer'].ready is True
    assert names['Core DICOM Viewer'].required_for_core is True
    assert 'Fallback' in clinical_foundation_report('test')


def test_clinical_foundation_json_shape():
    data = clinical_foundation_json('test')
    assert 'modules' in data
    assert any(x['module'] == 'AI / MONAI' for x in data['modules'])
