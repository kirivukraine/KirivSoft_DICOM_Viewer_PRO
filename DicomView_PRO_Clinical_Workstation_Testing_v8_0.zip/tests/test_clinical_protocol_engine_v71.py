import numpy as np
from dicomview_pro.core.clinical_protocol_engine import ClinicalProtocolEngine, protocol_pretty_text


def test_hemorrhage_protocol_measures_volume_and_bbox():
    v = np.full((10, 20, 20), 30.0, dtype=np.float32)
    v[3:7, 7:14, 7:14] = 70.0
    res = ClinicalProtocolEngine().run("hemorrhage", v, (2.0, 1.0, 1.0))
    assert res.volume_ml > 0
    assert res.component_count >= 1
    assert res.bbox_mm is not None
    assert "Гемораж" in protocol_pretty_text(res)


def test_all_protocols_return_json_shape():
    v = np.zeros((8, 16, 16), dtype=np.float32)
    v[:, 4:12, 4:12] = 40
    v[2:5, 7:10, 7:10] = 70
    v[:, 1:3, 1:3] = 500
    engine = ClinicalProtocolEngine()
    for key in ["hemorrhage", "trauma", "ischemia", "onco", "inflammation"]:
        res = engine.run(key, v, (1.5, 0.8, 0.8))
        data = res.to_json_dict()
        assert data["protocol"]
        assert "volume_ml" in data
        assert "warning" in data
