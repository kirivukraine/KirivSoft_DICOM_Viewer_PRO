import numpy as np
from dicomview_pro.core.volume_cleaner import post_render_artifact_mask_clean_volume


def test_post_cleaner_preserves_central_anatomy_and_removes_edge_plate():
    vol = np.full((32, 64, 64), -1000.0, dtype=np.float32)
    # central skull-like object
    zz, yy, xx = np.ogrid[:32, :64, :64]
    skull = ((zz - 16) ** 2 / 9**2 + (yy - 32) ** 2 / 18**2 + (xx - 32) ** 2 / 18**2) <= 1
    vol[skull] = 450.0
    # external plate near the right border
    vol[8:25, 12:55, 58:62] = 600.0
    res = post_render_artifact_mask_clean_volume(vol, threshold_hu=180, min_component_voxels=50, strength_percent=25)
    assert res.ok
    assert res.removed_voxels > 0
    assert res.display_volume[16, 32, 32] == 450.0
    assert res.display_volume[12, 20, 60] == -1000.0


def test_post_cleaner_no_threshold_match_returns_original():
    vol = np.full((8, 8, 8), -1000.0, dtype=np.float32)
    res = post_render_artifact_mask_clean_volume(vol, threshold_hu=200)
    assert not res.ok
    assert np.array_equal(res.display_volume, vol)
