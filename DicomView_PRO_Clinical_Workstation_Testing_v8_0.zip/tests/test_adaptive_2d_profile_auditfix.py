
import pytest
pytest.importorskip("PySide6")
from dicomview_pro.ui.main_window import MainWindow


def make_window(metadata):
    w = MainWindow.__new__(MainWindow)
    w.metadata = metadata
    return w


def test_mr_is_not_ct_brain_series():
    w = make_window({"modality": "MR", "series_description": "Brain T1"})
    assert w._is_ct_brain_series() is False


def test_skull_without_base_is_not_ct_brain_series():
    w = make_window({"modality": "CT", "series_description": "Skull Bone", "body_part": "SKULL"})
    assert w._is_ct_brain_series() is False


def test_skull_base_is_ct_brain_series():
    w = make_window({"modality": "CT", "series_description": "Skull Base"})
    assert w._is_ct_brain_series() is True


def test_bone_kernel_does_not_trigger_sharp_brain_ultra():
    w = make_window({"modality": "CT", "convolution_kernel": "BONE", "series_description": "Head"})
    assert w._is_sharp_ct_kernel() is False


def test_hr64_triggers_sharp_brain_ultra():
    w = make_window({"modality": "CT", "convolution_kernel": "Hr64", "series_description": "Brain"})
    assert w._is_sharp_ct_kernel() is True
