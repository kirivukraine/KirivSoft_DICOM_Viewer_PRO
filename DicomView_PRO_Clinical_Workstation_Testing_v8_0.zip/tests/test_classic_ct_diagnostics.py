import numpy as np
from dicomview_pro.core.classic_ct_diagnostics import Hemorrhage3DClassicAnalyzer, ClassicHemorrhageConfig, DicomViewDiagnosticsClassic


def test_classic_detects_synthetic_hemorrhage_volume():
    vol = np.zeros((16, 64, 64), dtype=np.float32)
    vol[:] = 30
    vol[6:10, 28:36, 30:38] = 70
    spacing = (2.5, 0.5, 0.5)
    res = Hemorrhage3DClassicAnalyzer(ClassicHemorrhageConfig(min_hu=50, max_hu=95, min_component_ml=0.01)).detect_volume(vol, spacing)
    assert res.volume_ml > 0
    assert res.component_count >= 1
    assert res.mask.shape == vol.shape


def test_window_output_uint8_range():
    img = np.array([[-100, 0, 40, 80, 200]], dtype=np.float32)
    out = DicomViewDiagnosticsClassic.apply_window(img, 40, 80)
    assert out.dtype == np.uint8
    assert out.min() >= 0 and out.max() <= 255


def test_asymmetry_volume_shape():
    vol = np.zeros((3, 32, 32), dtype=np.float32)
    vol[:, 12:18, 8:12] = 80
    asym = DicomViewDiagnosticsClassic.analyze_brain_asymmetry_volume(vol)
    assert asym.shape == vol.shape
    assert asym.dtype == np.uint8
