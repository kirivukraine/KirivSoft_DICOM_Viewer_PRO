import json
import numpy as np

from dicomview_pro.core.clinical_protocol_engine import ClinicalProtocolEngine
from dicomview_pro.core.comparison_engine import ComparativeViewerEngine, comparison_pretty_text


def test_compare_masks_reports_growth_and_overlay():
    spacing = (1.0, 1.0, 1.0)
    a = np.zeros((12, 24, 24), dtype=bool)
    b = np.zeros_like(a)
    a[3:6, 8:12, 8:12] = True
    b[3:7, 8:14, 8:14] = True

    res = ComparativeViewerEngine().compare_masks(a, b, spacing, "2024", "2026", "hemorrhage")
    assert res.delta_volume_ml > 0
    assert res.delta_volume_percent is not None and res.delta_volume_percent > 0
    assert res.overlay is not None
    assert res.overlay.growth_volume_ml > 0
    assert "збільшення" in res.direction
    text = comparison_pretty_text(res)
    assert "Порівняння" in text
    assert "JSON" in text


def test_compare_masks_disables_overlay_for_different_shape():
    engine = ComparativeViewerEngine()
    a = np.zeros((8, 16, 16), dtype=bool)
    b = np.zeros((10, 16, 16), dtype=bool)
    a[2:4, 5:8, 5:8] = True
    b[2:5, 5:9, 5:9] = True
    res = engine.compare_masks(a, b, (1.0, 1.0, 1.0))
    assert res.overlay is None
    assert res.warnings


def test_compare_protocol_results_from_hemorrhage_engine():
    spacing = (1.5, 0.8, 0.8)
    v1 = np.full((10, 32, 32), 30.0, dtype=np.float32)
    v2 = v1.copy()
    v1[2:6, 10:20, 10:20] = 70.0
    v2[2:8, 9:22, 9:22] = 70.0
    engine = ClinicalProtocolEngine()
    p1 = engine.run("hemorrhage", v1, spacing)
    p2 = engine.run("hemorrhage", v2, spacing)
    res = ComparativeViewerEngine().compare_protocol_results(p1, p2, "A", "B")
    data = res.to_json_dict()
    assert data["delta_volume_ml"] > 0
    assert data["baseline"]["protocol_key"] == "hemorrhage"
    assert data["followup"]["protocol_key"] == "hemorrhage"
    assert json.dumps(data, ensure_ascii=False)
