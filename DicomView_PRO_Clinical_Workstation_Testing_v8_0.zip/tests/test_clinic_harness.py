from __future__ import annotations
import importlib.util
from pathlib import Path


def _load_harness_module():
    root = Path(__file__).resolve().parents[1]
    path = root / 'scripts' / 'clinic_test_harness.py'
    spec = importlib.util.spec_from_file_location('clinic_test_harness', path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def test_clinic_harness_json_safe_basic():
    mod = _load_harness_module()
    assert mod._json_safe((1, 2, 3)) == [1, 2, 3]
    assert mod._json_safe({'a': (1, 2)}) == {'a': [1, 2]}
