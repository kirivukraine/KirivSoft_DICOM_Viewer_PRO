from dicomview_pro.core.scanner_profile_engine import analyze_scanner_profile


def test_scanner_profile_excellent_thin_brain():
    md = {
        "manufacturer": "SIEMENS",
        "model_name": "SOMATOM",
        "convolution_kernel": "B30",
        "series_description": "CT Brain",
        "spacing": [0.625, 0.5, 0.5],
    }
    p = analyze_scanner_profile(md, (240, 512, 512))
    assert p.quality_label == "Excellent"
    assert p.anatomy_profile == "Brain CT"
    assert p.recommended_slab_slices == 3
    assert p.recommended_window_center == 35


def test_scanner_profile_poor_thick_slices():
    md = {
        "manufacturer": "GE",
        "series_description": "Head CT",
        "spacing": [5.0, 0.9, 0.9],
    }
    p = analyze_scanner_profile(md, (24, 512, 512))
    assert p.quality_label == "Poor"
    assert p.recommended_slab_slices == 7
    assert "товсті" in p.warning_ua


def test_scanner_profile_lung_recommendation():
    md = {"series_description": "HRCT Lung", "spacing": [1.0, 0.7, 0.7]}
    p = analyze_scanner_profile(md, (120, 512, 512))
    assert p.anatomy_profile == "Lung/Thorax"
    assert p.recommended_3d_preset == "Classic Lung"
    assert p.recommended_window_center == -600
