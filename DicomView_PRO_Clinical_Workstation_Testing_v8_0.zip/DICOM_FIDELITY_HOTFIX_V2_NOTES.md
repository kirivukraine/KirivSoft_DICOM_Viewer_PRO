# DicomView PRO — DICOM Fidelity Hotfix v2

Виправлення після аудиту зернистості 2D:

- `image_label.py`: PIL/Lanczos більше не деградує мовчки — пише warning у лог, якщо Pillow недоступний або Lanczos-resize впав.
- `image_label.py`: `QImage` тепер створюється з правильним `bytes_per_line = arr.strides[0]`, а не `w`. Це критично для нестандартної ширини DICOM-зрізів.
- `image_label.py`: координатне перетворення використовує кеш останнього scaled image, без повторного дорогого resize при кліку.
- `image_ops.py`: sharpen за замовчуванням OFF. Low/Medium лишаються ручними режимами, бо unsharp mask підсилював зернистість на CT Brain W=80/C=35.
- `main_window.py`: MR/US/NM auto-window тепер рахується по поточному зрізу, а не по всьому 3D-об’єму.
- PyInstaller scripts: Pillow/PIL явно включено через `--collect-submodules PIL`, `--collect-data PIL`, `--hidden-import PIL.Image`, `--hidden-import PIL.ImageQt`.

Мета: зменшити зернистість 2D, зберегти 16-bit/HU pipeline до фінального display-етапу і не втрачати якість через silent fallback.
