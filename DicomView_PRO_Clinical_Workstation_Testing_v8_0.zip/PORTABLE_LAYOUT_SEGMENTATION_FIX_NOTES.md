# DicomView PRO — Portable Layout / Segmentation Fix

Виправлено у цій збірці:

- `Segmentation Basic`: поля `Min HU` і `Max HU` більше не обрізаються у вузькій лівій панелі.
- Значення HU видно повністю, поля мають збільшену мінімальну ширину.
- Додано підказку поточного пресету: кістки / легені / судини.
- Ліва панель трохи розширена, але Viewer все ще має основний простір.
- Додано `run_codec_diagnostics.bat` для швидкої перевірки DICOM codec pack, VTK, PACS, report/export залежностей.
- Portable-режим лишається основним для тестування: `build_portable.bat` або `build_exe.bat`.

Рекомендований тест після збірки:

1. Відкрити CT brain / chest.
2. Перевірити видимість `Min HU` / `Max HU` у `Segmentation Basic`.
3. Перевірити пресети `Кістки`, `Легені`, `Судини/контраст`.
4. Перевірити 2D, MPR, 3D Safe та VTK Surface Safe.
5. Запустити `run_codec_diagnostics.bat`.
