DicomView PRO Lite — нормальна portable-збірка
==============================================

Головний скрипт збірки:
  build_portable.bat

Що виправлено:
  1. Lite-збірка більше НЕ вимагає onnxruntime.
  2. TotalSegmentator, torch, nnUNet, MONAI, 3D Slicer не ставляться в базову збірку.
  3. AI/ONNX/Slicer залишені як опційні зовнішні модулі.
  4. Скрипт робить перевірку Python 3.11 x64, залежностей і синтаксису.
  5. Усі логи пишуться в build_logs\build_lite.log.

Як зібрати:
  1. Розпакувати архів у шлях без кирилиці, наприклад C:\DicomView_PRO_Lite
  2. Запустити build_portable.bat
  3. Готовий EXE буде тут:
     dist\DicomView_PRO_Lite\DicomView_PRO_Lite.exe

Важливо:
  - Не запускати EXE з папки build.
  - Запускати тільки з dist.
  - Якщо потрібен TotalSegmentator, він підключається окремим runtime:
    C:\TotalSegmentatorRuntime\Scripts\python.exe
  - Для Lite це не обов'язково.
