# DICOMDIR / USB / CD-DVD media export

Додано окремий режим **Експорт / носій → Створити DICOMDIR + стартовий носій**.

Що створюється:

- `DICOM/` — копії файлів поточної серії;
- `KIRIVSOFT_DICOM_EXPORT_MANIFEST.json` — SHA-256 manifest;
- `KIRIVSOFT_DICOM_INDEX.json` — індекс для DicomView PRO;
- `DICOMDIR` — створюється best-effort через `pydicom.fileset`, якщо DICOM-файли сумісні;
- `START_DicomView_PRO.bat` — launcher для носія;
- `autorun.inf` — сумісність зі старими CD/DVD сценаріями;
- `.zip` копія всієї папки.

Якщо Windows блокує autorun, запускайте `START_DicomView_PRO.bat` вручну або відкривайте папку `DICOM` через DicomView PRO.
