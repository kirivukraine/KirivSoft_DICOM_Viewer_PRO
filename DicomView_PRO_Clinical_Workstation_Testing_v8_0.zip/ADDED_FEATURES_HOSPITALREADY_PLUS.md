
## Додаткові перевірки
- Синтаксис Python: OK
- Pytest: 7 passed, 1 skipped
- Архів збирається без __pycache__/.pytest_cache

## HospitalReady Advanced clinical modules

Added in this build:
- Orthanc Explorer PRO foundation remains available.
- Reporting PRO foundation remains available.
- Radiomics Base remains available with optional PyRadiomics path.
- Cine PRO for XA/XRF/coronary angio multi-frame playback and export.
- Vessel Analysis module: threshold vessel candidate mask, MIP preview, basic volume/area/HU statistics.
- 3D Angio Reconstruction preview: metadata inspection, DSA subtraction preview, temporal maximum projection, pseudo-3D vessel mask.
- 4D Cardiac Viewer foundation: identifies cine/4D datasets and routes them to Cine Viewer timeline.
- AI / MONAI tab: optional MONAI/Torch environment check and safe fallback bone/lung masks.

Important: 3D Angio Reconstruction is a preview workflow. Real diagnostic 3D coronary reconstruction requires rotational angiography geometry, C-arm calibration and validation.
