# DicomView PRO AI Enterprise — Full MobileSAM Build Report

Збірка: MobileSAM Full Integration

## Додано

- Повний комплект MobileSAM ONNX:
  - `_internal/models/segmentation/mobile_sam_image_encoder.onnx`
  - `_internal/models/segmentation/sam_mask_decoder_single.onnx`
  - `_internal/models/segmentation/sam_mask_decoder_multi.onnx`
  - `_internal/models/segmentation/mobile_sam.onnx` для сумісності зі старою назвою decoder.
- Автоматичний режим `encoder -> image_embeddings -> decoder`.
- Підтримка decoder-only моделей без падіння програми.
- `Smart Click ROI` працює як реальний MobileSAM pipeline, якщо встановлено `onnxruntime`.
- Safe fallback залишається активним, якщо ONNX Runtime або модель недоступні.
- Оновлений AI Models Manager показує encoder і обидва decoder-файли.

## Перевірка

- `python -m compileall -q src tests` — OK.
- `PYTHONPATH=src pytest -q` — 36 passed, 4 skipped.

## Як користуватися

1. Запустити програму.
2. Відкрити DICOM-серію.
3. Перейти на вкладку 2D.
4. Натиснути `Smart Click ROI: OFF`, щоб стало `Smart Click ROI: ON`.
5. Клікнути по структурі на знімку.
6. Маска з'явиться в AI Preview і буде записана як поточна AI-маска.

## Важливо

Це експериментальний AI-модуль, не сертифікований медичний виріб. Для реальної діагностики потрібна клінічна перевірка.
