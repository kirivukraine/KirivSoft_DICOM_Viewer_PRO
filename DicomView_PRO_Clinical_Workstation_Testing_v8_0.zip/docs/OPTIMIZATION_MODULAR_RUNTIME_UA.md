# DicomView PRO Optimization & Modular Runtime Edition

Ця збірка завершує Enterprise-гілку перед Lite-версією.

## Головний принцип

Основна програма більше не повинна залежати від важких AI-пакетів напряму.
DicomView PRO запускається як стабільний DICOM/MPR/3D viewer, а важкі модулі
підключаються тільки як зовнішні runtime.

## У базовому ядрі залишено

- відкриття DICOM-серій;
- 2D Axial / Coronal / Sagittal;
- MPR Fidelity / прокрутка зрізів / zoom logic;
- 3D Volume / Surface viewer;
- 3D ruler / 3D knife / clip navigation foundation;
- artifact cleaner через safe-mask підхід;
- fullscreen F11, вихід Esc або F11;
- Scanner-Aware presets;
- Slicer Bridge API;
- AI Bridge API.

## Винесено у зовнішні модулі

- TotalSegmentator;
- nnU-Net;
- 3D Slicer;
- Real-ESRGAN;
- MONAI/SAM/MedSAM.

## TotalSegmentator тепер запускається правильно

Для вашого встановлення використовується не команда `totalsegmentator`, а:

```powershell
C:\TotalSegmentatorRuntime\Scripts\python.exe -m totalsegmentator.bin.TotalSegmentator
```

Програма автоматично шукає runtime у:

```text
C:\TotalSegmentatorRuntime\Scripts\python.exe
external_runtime\TotalSegmentatorRuntime\Scripts\python.exe
_internal\ai_runtime\TotalSegmentatorRuntime\Scripts\python.exe
```

Також можна задати змінну середовища:

```text
DICOMVIEW_TOTALSEG_PYTHON=C:\TotalSegmentatorRuntime\Scripts\python.exe
```

## Чому так краще

- основний EXE не тягне torch/nnU-Net/TotalSegmentator;
- менше шансів зламати запуск програми через AI-залежності;
- можна оновлювати AI окремо від DicomView PRO;
- можна робити Lite-версію без важких модулів;
- Safe Mode залишається працездатним без AI.

## Що перевіряти після запуску

1. Відкриття DICOM.
2. Axial / Coronal / Sagittal якість і прокрутка.
3. F11 fullscreen: тільки робоча зона, вихід Esc/F11.
4. 3D Head/Face не повинен деградувати.
5. Artifact Cleaner не повинен руйнувати модель.
6. AI Runtime Diagnostics має показати зовнішній TotalSegmentator, якщо він встановлений.

