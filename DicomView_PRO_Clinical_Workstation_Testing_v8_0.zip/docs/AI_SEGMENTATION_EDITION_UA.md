# DicomView PRO AI Segmentation Edition

## Що додано

- Панель AI Segmentation з 4 режимами:
  1. TotalSegmentator Fast GPU
  2. TotalSegmentator CPU Safe
  3. Slicer TotalSegmentator Bridge
  4. nnU-Net Research Mode
- Автовизначення NVIDIA/CUDA/VRAM через `torch` і `nvidia-smi`.
- Для Quadro 4 GB використовується low-VRAM логіка: спочатку Fast GPU, при помилці — CPU Safe.
- Експорт масок органів у STL/PLY/OBJ.
- Панель органів із чекбоксами показати/сховати.
- Підготовлена структура `_internal/ai_modules` і `_internal/models`.

## Чого немає всередині ZIP

- Готових ваг TotalSegmentator/nnU-Net. Архіви GitHub містять вихідний код.
- 3D Slicer. Його можна пізніше покласти у `_internal/slicer`.
- Клінічної сертифікації. Це інженерна інтеграція, результати потребують перевірки лікарем.

## Рекомендовано для Dell Precision 7530

- TotalSegmentator Fast GPU — спробувати першим.
- Якщо буде CUDA OOM або помилка VRAM — TotalSegmentator CPU Safe.
- nnU-Net Research — тільки після встановлення тренованих моделей.
