# DicomView PRO — Clinic Test Harness

Цей пакет додає контрольний тестовий режим для перевірки DicomView PRO на реальних DICOM-наборах, зокрема на `Data.zip`.

## Навіщо це потрібно

Звичайна перевірка `compileall` або `pytest` показує, що код запускається, але не гарантує, що програма правильно відкриє велику КТ-серію, побудує MPR, MIP, сегментацію та 3D Safe Preview.

`Clinic Test Harness` перевіряє саме практичний сценарій:

1. знайти DICOM-файли;
2. згрупувати серії;
3. завантажити першу або вибрану серію;
4. перевірити форму об'єму і spacing;
5. порахувати Window/Level;
6. перевірити MPR / MIP / MinIP / AvgIP;
7. перевірити базову сегментацію;
8. записати звіт у JSON.

## Як запускати

У корені проєкту:

```bat
.venv\Scripts\activate
set PYTHONPATH=%cd%\src
python scripts\clinic_test_harness.py --input C:\Path\To\Data.zip --output diagnostics\clinic_test_report.json
```

Або для вже розпакованої папки:

```bat
python scripts\clinic_test_harness.py --input C:\Path\To\DICOM_FOLDER --output diagnostics\clinic_test_report.json
```

## Швидкий BAT

```bat
run_clinic_test_harness.bat C:\Path\To\Data.zip
```

## Що дивитися у звіті

- `series_count` — скільки серій знайдено;
- `selected_series` — яка серія тестувалась;
- `shape` — форма об'єму `z,y,x`;
- `spacing` — spacing `z,y,x`;
- `window` — центр і ширина;
- `projections` — перевірка MIP/MinIP/AvgIP;
- `segmentation` — кількість вокселів і об'єм для bones/lungs/vessels;
- `status` — `ok` або помилка.

## Важливо

`Data.zip` не включається в релізну збірку, бо це великий тестовий набір. Його треба зберігати окремо і використовувати тільки для тестування.
