# DicomView PRO — Organ Segmentation Executor Patch

Додано повний інтеграційний патч для автоматичної сегментації органів:

## Нові можливості

- Фоновий запуск TotalSegmentator без зависання GUI.
- Progress bar зі статусами етапів:
  - підготовка;
  - DICOM → NIfTI;
  - запуск TotalSegmentator;
  - генерація STL/PLY/OBJ;
  - завантаження моделей у 3D-вікно.
- Кнопка скасування виконання.
- Safe fallback: якщо TotalSegmentator/dicom2nifti/nibabel/skimage/trimesh не встановлені, програма не падає.
- Експорт органів у STL, PLY, OBJ.
- Нова вкладка `Organ 3D`.
- Чекбокс-список моделей органів.
- Вмикання/вимикання видимості кожної 3D-моделі у VTK-сцені.
- Можливість відкрити вже готову папку STL/PLY/OBJ без повторної сегментації.

## Нові файли

- `src/dicomview_pro/core/organ_segmentation_executor.py`
- `src/dicomview_pro/ui/organ_segmentation_panel.py`
- `tests/test_organ_segmentation_executor_patch.py`

## Змінені файли

- `src/dicomview_pro/ui/main_window.py`
- `src/dicomview_pro/ui/vtk_viewer.py`

## Optional runtime

Для повного запуску потрібно встановити:

```bash
pip install TotalSegmentator dicom2nifti nibabel scikit-image trimesh
```

Без цих залежностей вкладка працює в режимі перевірки готовності й не ламає основну програму.

## Перевірка

Виконано:

```bash
python -m compileall -q src tests scripts
PYTHONPATH=src pytest -q
```

Результат:

```text
52 passed, 4 skipped
```
