# DicomView PRO — Deep3D Cinematic Volume Rendering Patch

Додано модулі для якості 3D-реконструкції рівня RadiAnt/syngo.via:

- `rendering/cinematic_volume_renderer.py` — GPU Volume Rendering через `vtkGPUVolumeRayCastMapper`.
- `rendering/transfer_function_presets.py` — HU-пресети: Thorax, Lung+Vessels, Heart/Cardio, Abdomen Organs, Bone+Soft Tissue, Angio/MIP.
- `rendering/gpu_quality_manager.py` — режими Auto/Low/High/Cinematic і fallback для слабких GPU.
- `rendering/organ_overlay_manager.py` — кольорові накладки органів із масок TotalSegmentator/STL/PLY.
- `core/totalsegmentator_executor.py` — безпечний фоновий запуск TotalSegmentator без блокування GUI.

## Як інтегрувати у 3D-вікно

1. Після створення `vtkRenderer` і `QVTKRenderWindowInteractor`:

```python
from dicomview_pro.rendering.cinematic_volume_renderer import CinematicVolumeRenderer

self.cine3d = CinematicVolumeRenderer(
    renderer=self._renderer,
    render_window=self._render_widget.GetRenderWindow(),
    quality="auto",
)
self.cine3d.set_input(vtk_image, preset="thorax_cinematic", blend="composite")
```

2. Для зміни пресетів:

```python
self.cine3d.set_preset("lung_vessels")
self.cine3d.set_preset("heart_cardio")
self.cine3d.set_preset("abdomen_organs")
self.cine3d.set_preset("angio_mip")
```

3. Для MIP/MinIP/Average:

```python
self.cine3d.set_blend_mode("mip")
self.cine3d.set_blend_mode("minip")
self.cine3d.set_blend_mode("average")
```

4. Для кольорових органів поверх Volume Rendering:

```python
from dicomview_pro.rendering.organ_overlay_manager import OrganOverlayManager
self.organs3d = OrganOverlayManager(self._renderer, self._render_widget.GetRenderWindow())
self.organs3d.add_mask_image("liver", liver_mask_vtk_image)
self.organs3d.set_visible("liver", True)
```

## Рекомендовані залежності

```bash
pip install vtk numpy pydicom SimpleITK pylibjpeg pylibjpeg-libjpeg pylibjpeg-openjpeg gdcm
pip install TotalSegmentator nibabel scipy scikit-image
```

TotalSegmentator бажано запускати в окремому venv/процесі, бо він тягне torch і може довго стартувати.

## Важливо

Цей патч дає якісний технічний 3D-рендер. Для діагностичної клінічної сегментації потрібна перевірка лікарем і валідація на медичних даних.
