# DicomView PRO Lite Trial

Пробна лайтовa збірка на базі стабільного ядра DicomView PRO.

## Основна ідея

Залишити щоденний функціонал перегляду DICOM, 2D/MPR/3D, лінійки, 3D ніж, F11 fullscreen і напрацювання 3D, але прибрати важкі AI-runtime з основного пакета.

## Є в Lite

- сучасний UI з останніх збірок;
- 2D Axial / Coronal / Sagittal;
- MPR Fidelity Engine;
- прокрутка зрізів слайдером і колесом;
- Ctrl + колесо для zoom;
- 2D лінійка;
- 3D VTK Surface / Volume Rendering;
- 3D лінійка з Ctrl-lock;
- 3D ніж / Clip Box / Clip Navigate;
- безпечна очистка артефактів;
- F11 fullscreen, Esc або F11 — вихід;
- Window/Level presets;
- PACS/Orthanc/Report базові модулі;
- export STL/PLY/OBJ, PNG/GIF/MP4 за наявності залежностей.

## Не входить у Lite

- TotalSegmentator;
- nnU-Net;
- PyTorch;
- MONAI;
- 3D Slicer Runtime;
- Real-ESRGAN;
- великі ONNX-моделі SAM/MedSAM.

Ці модулі пізніше мають підключатися зовнішньо через `external_runtime/` або Module Manager.

## Збірка EXE на Windows

1. Встановити Python 3.11 x64.
2. Відкрити папку проекту.
3. Запустити:

```bat
build_lite_exe.bat
```

Готовий EXE буде тут:

```text
dist\DicomView_PRO_Lite\DicomView_PRO_Lite.exe
```

## Перевірка

У контейнері виконано:

- `python -m compileall src scripts tests` — OK;
- `pytest` — 66 passed, 4 skipped.

Windows EXE у Linux-контейнері не перезбирався.
