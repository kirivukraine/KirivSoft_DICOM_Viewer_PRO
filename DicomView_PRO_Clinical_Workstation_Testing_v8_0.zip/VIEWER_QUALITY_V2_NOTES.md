# DicomView PRO — Diagnostic Viewer Quality v2

Фокус збірки: якість базового 2D-перегляду, максимально наближена до старих медичних viewer-ів типу syngo FastView / Vidar.

## Додано / виправлено

- Максимальна якість 2D увімкнена автоматично при старті.
- Brain CT window за замовчуванням: **W=80 / C=35** для серій Brain/Head.
- Виправлено пріоритет пресетів: `Brain` більше не перехоплюється словом `Hr` як Bone-window.
- Додано коректніший DICOM rendering pipeline:
  - PixelData;
  - Modality LUT / RescaleSlope / RescaleIntercept;
  - HU / modality pixels;
  - Window/Level;
  - MONOCHROME1 / Presentation LUT inversion;
  - final 8-bit display тільки на останньому етапі.
- Додано Display mode **Fit anatomy (max)** — автоматичне збільшення області анатомії без пустого чорного полотна.
- Залишено ручні режими:
  - Fit anatomy (max);
  - Fit-to-window;
  - 1:1 pixel;
  - Fit no crop.
- Lanczos interpolation за замовчуванням.
- Додано ручний вибір interpolation:
  - Lanczos;
  - Cubic/Smooth;
  - Linear;
  - Nearest.
- Додано м'яке medical sharpen:
  - Low за замовчуванням;
  - Off;
  - Medium.
- Координати вимірювань/ROI залишаються прив'язаними до оригінального зрізу навіть якщо ввімкнено Fit anatomy crop.
- Швидка прокрутка серій збережена:
  - Ctrl + колесо;
  - PageUp/PageDown;
  - Up/Down.

## Чому це важливо

Попередня версія вже мала Lanczos, але все ще показувала надто багато чорного полотна, а не саму анатомію. У цій збірці за замовчуванням використовується анатомічний fit, тому slice має займати значно більше простору, як у syngo/Vidar.

## Перевірка

- compileall: OK
- pytest: 22 passed, 1 skipped
- ZIP integrity: OK
