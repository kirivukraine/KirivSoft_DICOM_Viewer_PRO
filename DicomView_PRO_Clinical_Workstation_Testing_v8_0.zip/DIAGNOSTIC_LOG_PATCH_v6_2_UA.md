# DicomView PRO Diagnostic Log Patch v6.2

Це мала збірка для перевірки реальної роботи програми на ПК користувача.
Вона не заявляє виправлення якості 3D. Її мета — дати доказовий лог, щоб було видно, які події реально спрацьовують.

## Додано

1. Меню `Файл → Відкрити папку логів`.
2. Меню `Файл → Створити тестовий діагностичний лог`.
3. Меню `Файл → Зберегти лог як...`.
4. Розширений 3D diagnostic snapshot:
   - стан VTK viewer;
   - клас mapper/interactor/style;
   - стан Ctrl/Alt/Shift у VTK;
   - камера, preset, source volume shape/min/max;
   - активність 3D ruler/clip/artifact clean.
5. Логування 3D-подій у `dicomview_pro.log`:
   - `SET_VOLUME`;
   - `SET_LEGACY_VOLUME`;
   - `RULER_ON` / `RULER_OFF`;
   - `CTRL_ALT_LOCK_ON` / `CTRL_ALT_LOCK_OFF`;
   - `VTK_ABORT`;
   - `QT_EVENT_SWALLOWED`.
6. Шлях логів на Windows тепер береться через `%LOCALAPPDATA%`, а не через жорстко заданий `AppData/Local`.

## Де шукати лог

Основний лог:

`%LOCALAPPDATA%\KirivSoft\DicomViewPRO\logs\dicomview_pro.log`

Діагностичний лог після натискання кнопки:

`%LOCALAPPDATA%\KirivSoft\DicomViewPRO\logs\dicomview_pro_diagnostic_YYYYMMDD_HHMMSS.txt`

## Що перевіряти

1. Відкрити DICOM.
2. Побудувати 3D.
3. Увімкнути 3D лінійку.
4. Натиснути Ctrl+Alt і спробувати рухати модель.
5. Створити тестовий діагностичний лог.
6. Надіслати `.txt` файл і `dicomview_pro.log`.

Якщо в логах немає `CTRL_ALT_LOCK_ON`, значить програма не бачить потрібні клавіші.
Якщо `CTRL_ALT_LOCK_ON` є, але модель рухається, значить VTK interactor або інший event handler обходить блокування.
