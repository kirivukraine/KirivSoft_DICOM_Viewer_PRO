# DicomView PRO Lite — RC2 Core Stability

Автор: Іван Кіранчук / KirivSoft

## Мета збірки
Стабілізувати Lite-гілку перед подальшими роботами над MPR/3D/клінічними пресетами.

## Що змінено

### 1. Smart DICOM Loader
- Відкриття папки пацієнта більше не декодує PixelData всіх вкладених серій.
- Перший етап читає тільки DICOM-теги через `stop_before_pixels=True`.
- Серії групуються по `SeriesInstanceUID`.
- Якщо знайдено кілька серій — програма показує Series Selector і чекає вибору.
- Додана кнопка `Завантажити вибрану серію`, щоб можна було відкрити навіть перший елемент списку без зміни combo box.

### 2. Фонові потоки
- Сканування папки виконується через `ScanThread`.
- Завантаження вибраної серії виконується через `LoadThread`.
- Папка пацієнта не повинна блокувати GUI на 10+ хвилин.

### 3. Адаптивний RAM Cache
- Додано бюджет кешу 10/20/30/40% від RAM залежно від розміру обстеження.
- Додано Windows fallback через `GlobalMemoryStatusEx`, якщо `psutil` відсутній.
- Бюджет записується у metadata як `cache_budget_bytes` / `cache_budget_text`.

### 4. Lite без AI startup
- AI preload у Lite вимкнений повністю.
- TotalSegmentator / nnU-Net / Slicer / Radiomics / VMTK не імпортуються при старті.
- AI-вкладки залишені як external/plugin placeholders, без runtime-завантаження.

### 5. Краші Lite
- `status_label` прив’язано до `system_status`.
- `ai_preview.set_image(...)` захищено від `None`.
- `slicer_path.setText(...)` захищено через `hasattr`.
- Build script не додає `_internal/tools`, `_internal/models`, `_internal/slicer`, якщо таких папок немає.

### 6. 3D Ruler Ctrl Lock
- У режимі 3D-лінійки Ctrl переводить VTK interactor у frozen style.
- Блокуються rotate / zoom / pan під час постановки точок.
- Точки ставляться по поверхні моделі через VTK picker у world coordinates.

### 7. Два 3D режими залишені
- `Legacy Head/Face 3D (old)` — старий вигляд 3D.
- `Modern VTK Volume Rendering` / Advanced режими — для knife/clip/ruler.

## Перевірки
- `python -m compileall -q src` — OK.
- ZIP integrity — OK.
- AI/ONNX/TotalSegmentator не є обов’язковими для Lite.

## Що тестувати першим
1. Запуск програми.
2. Відкрити папку пацієнта з кількома серіями.
3. Перевірити, що Series Selector з’являється швидко.
4. Натиснути `Завантажити вибрану серію`.
5. Перевірити 2D Axial/Coronal/Sagittal.
6. Перевірити 3D Legacy і Advanced.
7. Перевірити Ctrl у 3D-лінійці.

## Що не входить у RC2
- Повний RadiAnt-grade MPR — це RC3.
- Hemorrhage / Tumor / Thrombus маски — це RC5.
- Enterprise AI plugins — окрема гілка.
