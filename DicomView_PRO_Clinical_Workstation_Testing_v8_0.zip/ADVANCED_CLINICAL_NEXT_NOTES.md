# DicomView PRO — Vessel / Angio / 4D / Adaptive Packaging Pack

Додано стабільну основу наступних великих модулів:

- Vessel Analysis PRO: safe/fallback аналіз судинної маски, оцінка довжини, діаметрів і стенозу.
- 3D Angio Foundation: існуючі preview/DSA інструменти залишаються безпечними, без примусової важкої реконструкції.
- 4D Cardiac Foundation: додано розрахунок EDV/ESV/SV/EF з готової 4D маски.
- Adaptive Engine 3.0: визначає safe/balanced/full режим для старих лікарняних ПК.
- Пакування: portable folder, one-file EXE, Inno Setup installer.

Важливо: 3D Angio Reconstruction і 4D Cardiac Viewer є foundation-рівнем. Для клінічної діагностики потрібні валідовані дані, реальні cardiac/rotational angiography DICOM і медична валідація.
