[Setup]
AppName=DicomView PRO
AppVersion=1.0
AppPublisher=KirivSoft
DefaultDirName={autopf}\KirivSoft\DicomView PRO
DefaultGroupName=DicomView PRO
OutputBaseFilename=DicomView_PRO_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Files]
Source: "..\dist\DicomView_PRO\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

[Icons]
Name: "{group}\DicomView PRO"; Filename: "{app}\DicomView_PRO.exe"
Name: "{autodesktop}\DicomView PRO"; Filename: "{app}\DicomView_PRO.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Створити ярлик на робочому столі"; GroupDescription: "Додаткові ярлики:"; Flags: unchecked
