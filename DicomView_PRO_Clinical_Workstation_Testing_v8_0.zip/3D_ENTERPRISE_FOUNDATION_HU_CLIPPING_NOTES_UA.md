# DicomView PRO — 3D Enterprise Foundation HU/Clipping Update

Додано/посилено:

- `core/volume_inspect_controller.py` — окремий контролер для 3D Transfer Functions і Clipping.
- Динамічна прозорість по HU через `vtkPiecewiseFunction`.
- Живе застосування 3D-пресетів без повної перебудови об'єму:
  - Color anatomy
  - Skin_Muscle
  - Soft tissue
  - Lung
  - Bone
  - Bone Color
  - Angio_MIP
  - MIP
  - Vessel
- Повзунок `Density Threshold / прозорість по HU`.
- `MIP судини` через `SetBlendModeToMaximumIntensity()`.
- `Sub-Tissue +200 HU` для швидкого приховування поверхневих/низькощільних тканин.
- `Clip Box / 3D ніж` через `vtkBoxWidget2`, `vtkPlanes`, `SetClippingPlanes()`.
- Стартовий 3D режим лишається `VTK Volume Rendering`; Surface Safe і MIP Preview залишені як fallback.
- 3D лінійка збережена.

Призначення: перетворити Volume Rendering з статичного перегляду на інструмент інтерактивної 3D-інспекції.
