# DicomView PRO v7.8 — Rendering Refactor & Fidelity Audit

## Мета

Ця збірка виправляє ключову архітектурну проблему 3D-візуалізації: попередні модулі `cinematic_volume_renderer.py` і `volume_render_engine.py` існували як паралельні/експериментальні рушії, але реальний 3D, який бачить користувач, будується у `src/dicomview_pro/ui/vtk_viewer.py`.

Тому v7.8 переносить важливі покращення саме у реальний pipeline `vtk_viewer.py`, а не в неактивні експериментальні файли.

## Реальний 3D pipeline

Підтверджено робочий шлях:

- `src/dicomview_pro/ui/vtk_viewer.py`
- метод `set_volume(...)`
- `vtkSmartVolumeMapper`
- `vtkVolumeProperty`
- `vtkColorTransferFunction`
- `vtkPiecewiseFunction`
- `build_cinematic_property(...)`, якщо пресет є cinematic

## Що змінено

### 1. Adaptive Render Quality у реальному VTK pipeline

Додано у `vtk_viewer.py`:

- `_clear_render_quality_observers()`
- `_attach_adaptive_render_quality(...)`

Поведінка:

- коли камера рухається — sample distance грубіший, щоб обертання було плавнішим;
- коли камера зупинилась — sample distance тонший, щоб картинка ставала чіткішою;
- старі VTK observers очищаються при кожному новому `set_volume()`, щоб не накопичувались дублікати.

### 2. Jittering для зменшення banding/сходинок

Якщо VTK підтримує `SetUseJittering`, він вмикається в робочому mapper.

### 3. М'якший fallback Gradient Opacity

Для пресетів, які не проходять через `cinematic_fidelity.py`, змінено fallback-градієнт:

- менше "пластмасового" блиску;
- плавніша межа тканина/кістка;
- збережено достатній контраст для кісток і судин.

### 4. Classic Hospital lighting tuned

У `cinematic_fidelity.py` змінено параметри `classic_hospital`:

- `ambient = 0.18`
- `diffuse = 0.92`
- `specular = 0.28`
- `specular_power = 28`

Ціль — глибша картинка, менше воскового вигляду, краща передача об'єму.

### 5. Новий пресет Classic Lung Fidelity

Додано:

- `classic_lung_fidelity`
- aliases: `lung`, `classic_lung`, `lung_fidelity`

Ціль — легені прозоріші, судини контрастніші, ребра менш агресивні.

## Що НЕ зроблено навмисно

- `cinematic_volume_renderer.py` і `volume_render_engine.py` не видалені, щоб не зламати майбутню інтеграцію.
- У v8.0 можна або підключити їх як єдиний renderer-engine, або винести в disabled/experimental.
- PET/CT Fusion і Orthanc не додавались — за планом вони йдуть пізніше.

## Перевірка

- `compileall`: пройдено
- `pytest`: пройдено
- ZIP integrity: пройдено

## Наступний етап

Після v7.8 логічно збирати v8.0 Clinical Workstation Edition:

- Viewer Fidelity
- Scanner Intelligence
- Series Quality
- Hemorrhage Protocol
- Trauma Protocol
- Comparative Viewer
- Smart Report

Після v8.0 потрібно реальне тестування на DICOM-дисках з відео та логами.
