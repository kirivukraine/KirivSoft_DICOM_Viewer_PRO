# DicomView PRO — Orthanc / Reporting / Radiomics PRO Foundation

Цей пакет додає стабільну основу трьох великих клінічних модулів без зміни ядра переглядача.

## Orthanc Explorer PRO
- безпечний ping Orthanc;
- пошук Study через `/tools/find`;
- побудова Patient/Study/Series-орієнтованого дерева;
- download Series ZIP;
- усі помилки повертаються як результат, а не валять GUI.

## Reporting PRO
- PDF/DOCX/JSON bundle;
- fallback у TXT/JSON, якщо бібліотека звітності недоступна;
- підтримка DICOM metadata, ROI/HU, screenshots.

## Radiomics PRO
- безпечна NumPy-база;
- count, volume, mean/min/max/std, percentiles, entropy, IQR, range;
- PyRadiomics перевіряється як optional backend, але не є обов'язковим для запуску.

## Принцип сумісності зі старими ПК
Важкі модулі не запускаються автоматично. Якщо Orthanc/PyRadiomics/ReportLab/Docx недоступні — програма продовжує працювати у fallback-режимі.
