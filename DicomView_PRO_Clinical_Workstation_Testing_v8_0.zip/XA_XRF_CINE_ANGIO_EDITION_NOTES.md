# DicomView PRO — XA/XRF Cine & Angio Edition

## Мета
Збірка орієнтована на коронарографії, ангіографії з контрастом і мультифреймові DICOM серії XA/XRF/RF.

## Додано
- Cine/Angio profile detection для XA/XRF/RF.
- Автовизначення FPS з DICOM metadata з fallback 15 fps.
- Компактніші Cine controls: Play/Pause, frame step, Loop, Lock viewport, FPS.
- DSA mode у Cine Viewer.
- Вибір mask frame для DSA subtraction.
- Contrast Enhance режим для ангіографічних кадрів.
- Export PNG sequence для кадрів cine.
- GIF/MP4 export залишено.
- DSA preview у Angio 3D використовує вибраний mask frame.
- Cine viewport lock використовує SmoothStack bbox, щоб кадри не стрибали масштабом.

## Обмеження
- Звичайна 2D коронарографія не дає справжню 3D реконструкцію без ротаційної геометрії C-arm.
- DSA preview — допоміжний режим перегляду, не сертифікований діагностичний алгоритм.
- Для MPEG/JPEG2000 compressed XA потрібні відповідні codec backend у portable/installer збірці.

## Перевірка
- compileall: OK
- pytest: 30 passed, 2 skipped
- ZIP integrity: OK
