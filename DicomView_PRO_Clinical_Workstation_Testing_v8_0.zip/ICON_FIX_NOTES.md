# DicomView PRO — Icon and adaptive build fix

Виправлено відображення іконки в самій програмі та в EXE.

## Що змінено
- Додано `src/dicomview_pro/resources.py` для правильного пошуку ресурсів у source-режимі, portable EXE folder і PyInstaller one-file.
- Додано `assets/icon.ico` для коректної іконки Windows EXE.
- Заголовок програми тепер показує `assets/icon.png` через безпечний шлях ресурсів.
- `build_exe.bat` використовує `assets\icon.ico` для іконки EXE та включає всю папку `assets`.

## Для старих ПК
3D за замовчуванням рекомендовано запускати в Auto Safe / VTK Surface Safe або MIP Preview. Повний VTK Volume Rendering залежить від OpenGL-драйвера.
