@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Installing AI runtime for source-mode run...
python -m pip install --upgrade pip
python -m pip install onnxruntime scipy pillow numpy
python -c "import onnxruntime as ort; print('ONNX Runtime OK:', ort.__version__, ort.get_available_providers())"
pause
