# DicomView PRO AI Runtime Fix

У цій збірці `onnxruntime` і `scipy` додані як реальні залежності, а не як коментар у `requirements.txt`.

## Що виправлено

- `onnxruntime>=1.17` додано в `requirements.txt`.
- `scipy>=1.11` додано в `requirements.txt`.
- PyInstaller build BAT отримав `--collect-submodules onnxruntime`, `--collect-binaries onnxruntime`, `--hidden-import onnxruntime.capi._pybind_state`.
- MobileSAM ONNX-файли вже лежать у `_internal/models/segmentation`.

## Як перевірити

У програмі натисніть **AI → Перевірити AI середовище**. Має бути:

```json
"onnxruntime": true,
"onnx_providers": ["CPUExecutionProvider"]
```

Якщо запускаєте source-mode без EXE, виконайте:

```bat
install_ai_runtime_current_python.bat
```

## Моделі MobileSAM

Папка:

```text
DicomView_PRO\_internal\models\segmentation\
```

Файли:

```text
mobile_sam_image_encoder.onnx
sam_mask_decoder_single.onnx
sam_mask_decoder_multi.onnx
mobile_sam.onnx
```
