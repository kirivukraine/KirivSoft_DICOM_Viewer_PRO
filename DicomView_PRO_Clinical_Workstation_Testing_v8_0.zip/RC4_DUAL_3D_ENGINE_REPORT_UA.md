# DicomView PRO Lite RC4 — Dual 3D Engine

## База
База збірки: `DicomView_PRO_Lite_RC3_RadiAnt_Quality`.

## Що додано

### 1. Dual 3D Engine
У 3D вкладці залишено два робочі сценарії:

- **Legacy Head/Face 3D (old)** — старий візуальний стиль для голови/обличчя, мінімальна фільтрація, збереження контурів шкіри, носа, вух та м'яких тканин.
- **Modern VTK Volume Rendering** — сучасний режим із Clip Box, 3D Knife, 3D Ruler, Slab/MIP та Artifact Mask.

### 2. Classic Anatomy preset
Додано preset `Classic Anatomy`, який відтворює старий м'який 3D-вигляд без агресивного відсікання HU.

### 3. Brain Hemorrhage preset
Додано beta-presет `Brain Hemorrhage` для нативної КТ голови:

- 40–110 HU підсвічуються червоним/малиновим як можлива гіперденсна кров;
- кістка залишається видимою, але не повинна повністю забивати візуалізацію;
- це візуальна допомога, не автоматичний діагноз.

### 4. Air preset
Додано `Air` preset для повітряних структур: пазухи, легені, кишківник, пневмоцефалія/пневмоторакс як візуальний режим.

### 5. Ctrl Freeze для 3D-лінійки
Посилено блокування камери:

- перевірка Ctrl через VTK і Qt;
- `QApplication` event filter;
- `vtkInteractorStyleUser` під час фіксації;
- блокування rotate / zoom / pan / wheel під час постановки точок.

### 6. 3D Ruler world coordinates
Лінійка використовує VTK picker і world coordinates, а не координати екрана.

### 7. Artifact Mask v2 збережено
Очищення артефактів залишається пост-білд дією через маску, оригінальний volume не змінюється.

## Перевірка

- `compileall` по `src` і `tests`: OK
- RC4 smoke tests: OK
- Core/MPR/cleaner tests: `16 passed, 1 skipped`
- Lite selected tests: `22 passed, 4 skipped`

## Обмеження

- Hemorrhage preset — HU-візуалізація, не AI-сегментація і не діагноз.
- Для точного виділення пухлин/тромбів потрібні контрастні дослідження, ручна ROI або Enterprise AI/plugin runtime.
