# DicomView PRO v7.3 — Viewer Fidelity + Scanner Intelligence

Фокус збірки: якість відображення, чистіший інтерфейс і автоматична адаптація під серію DICOM.

## Додано

- `scanner_profile_engine.py` — CPU-only аналіз DICOM metadata.
- Автоматичне визначення:
  - виробник томографа;
  - модель;
  - reconstruction kernel;
  - slice thickness;
  - spacing Z/Y/X;
  - анатомічний профіль: Brain / Lung / Bone / CTA / Abdomen / General.
- Індикатор **Series Quality**:
  - Excellent;
  - Good;
  - Limited;
  - Poor.
- Пояснення причини якості серії:
  - тонкі зрізи;
  - товсті зрізи;
  - anisotropic spacing;
  - обмеження для 3D/MPR.
- Автоматичне display-only налаштування:
  - WL/WW;
  - MPR Fidelity/Adaptive Smooth;
  - slab 3/5/7 залежно від товщини зрізів;
  - рекомендований 3D пресет.

## Важливо

Модуль **не змінює HU-дані** і не впливає на вимірювання. Він змінює тільки візуалізацію.

