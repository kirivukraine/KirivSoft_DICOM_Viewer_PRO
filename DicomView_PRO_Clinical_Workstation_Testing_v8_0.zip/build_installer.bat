@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo Building portable package first...
call build_portable.bat
if errorlevel 1 exit /b 1

if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
  "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" installer\DicomView_PRO.iss
) else if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" (
  "%ProgramFiles%\Inno Setup 6\ISCC.exe" installer\DicomView_PRO.iss
) else (
  echo Inno Setup 6 not found. Install Inno Setup 6 to create installer.
  echo Portable version is already available in dist\DicomView_PRO\
  pause
  exit /b 1
)

echo Installer ready in installer output folder.
pause
